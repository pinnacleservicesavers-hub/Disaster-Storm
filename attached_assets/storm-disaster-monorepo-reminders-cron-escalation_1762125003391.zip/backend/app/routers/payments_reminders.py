from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store
from datetime import datetime, timedelta
import smtplib, ssl, os
from email.message import EmailMessage

router=APIRouter()
TEMPLATES={'gentle':{'subject':'Friendly reminder — invoice for Job {job_id}','body':'Hi, this is a friendly reminder that the invoice for Job {job_id} is ready for payment. Please use the link provided or contact us with any questions.'},'firm':{'subject':'Second notice — invoice for Job {job_id}','body':'This is a second notice regarding payment for Job {job_id}. Please arrange payment. If you\'ve already paid, thank you—no further action is needed.'},'final':{'subject':'Final notice — invoice for Job {job_id}','body':'Final notice for Job {job_id}. If payment is not received promptly, further action may be taken in accordance with the contract and applicable law.'}}
ESCALATION_ORDER=['gentle','firm','final']
class ScheduleBody(BaseModel):
    job_id:str
    to_emails:list[str]
    message:str|None=None
    first_in_days:int=3
    repeat_days:int|None=7
    level:str|None=None
@router.post('/payments/reminders/schedule')
def schedule_reminder(body:ScheduleBody):
    job=store.jobs.setdefault(body.job_id,{})
    reminders=job.setdefault('reminders',[])
    due_at=(datetime.utcnow()+timedelta(days=body.first_in_days)).isoformat()
    level=body.level or 'gentle'
    item={'id':store.new_id(),'to_emails':body.to_emails,'message':(body.message or TEMPLATES[level]['body'].format(job_id=body.job_id)),'subject':TEMPLATES[level]['subject'].format(job_id=body.job_id),'due_at':due_at,'repeat_days':body.repeat_days,'status':'scheduled','level':level}
    reminders.append(item)
    job.setdefault('timeline',[]).append({'job_id':body.job_id,'kind':'note','message':f'Payment reminder ({level}) scheduled for {due_at}','when':datetime.utcnow().isoformat()})
    store.jobs[body.job_id]=job
    return {'ok':True,'reminder':item}

def _send_email(smtp_host,smtp_port,smtp_user,smtp_pass,to_list,subject,text):
    msg=EmailMessage(); msg['Subject']=subject; msg['From']=smtp_user or 'no-reply@stormdisaster.local'; msg['To']=', '.join(to_list); msg.set_content(text)
    try:
        ctx=ssl.create_default_context();
        with smtplib.SMTP(smtp_host,smtp_port) as server:
            server.starttls(context=ctx)
            if smtp_user: server.login(smtp_user,smtp_pass)
            server.send_message(msg)
        return True,None
    except Exception as e:
        return False,str(e)

def _next_level(level:str):
    try:
        idx=ESCALATION_ORDER.index(level)
        return ESCALATION_ORDER[idx+1] if idx+1<len(ESCALATION_ORDER) else None
    except ValueError:
        return None
@router.post('/payments/reminders/run')
def run_reminders():
    now=datetime.utcnow().isoformat(); processed=[]
    for job_id,job in store.jobs.items():
        if (job.get('payments') or {}).get('status')=='paid':
            continue
        for r in job.get('reminders',[]):
            if r['status']=='scheduled' and r['due_at']<=now:
                ok,err=_send_email(os.getenv('SMTP_HOST','smtp.example.com'),int(os.getenv('SMTP_PORT','587')),os.getenv('SMTP_USER','user@example.com'),os.getenv('SMTP_PASS','pass'),r['to_emails'],r.get('subject') or TEMPLATES.get(r.get('level') or 'gentle',TEMPLATES['gentle'])['subject'].format(job_id=job_id),r.get('message') or TEMPLATES.get(r.get('level') or 'gentle',TEMPLATES['gentle'])['body'].format(job_id=job_id))
                r['status']='sent' if ok else f'error:{err}'
                job.setdefault('timeline',[]).append({'job_id':job_id,'kind':'note','message':f"Reminder {r['id']} ({r.get('level')}) status: {r['status']}",'when':datetime.utcnow().isoformat()})
                processed.append({'job_id':job_id,'reminder_id':r['id'],'status':r['status'],'level':r.get('level')})
                nxt=_next_level(r.get('level'))
                if nxt:
                    from datetime import timedelta as td
                    due=(datetime.utcnow()+td(days=r.get('repeat_days') or 7)).isoformat()
                    job.setdefault('reminders',[]).append({'id':store.new_id(),'to_emails':r['to_emails'],'message':TEMPLATES[nxt]['body'].format(job_id=job_id),'subject':TEMPLATES[nxt]['subject'].format(job_id=job_id),'due_at':due,'repeat_days':r.get('repeat_days'),'status':'scheduled','level':nxt})
                elif r.get('repeat_days'):
                    from datetime import timedelta as td
                    r['due_at']=(datetime.utcnow()+td(days=r['repeat_days'])).isoformat(); r['status']='scheduled'
    return {'processed':processed}
