## Reminder Automation (Cron Examples)
- Docker Compose: docker compose -f docker-compose.reminders.yml up -d --build
- GitHub Actions: set secret REMINDERS_URL
- Kubernetes: apply ops/cron/k8s/cronjob.yaml with secret reminders-secret
