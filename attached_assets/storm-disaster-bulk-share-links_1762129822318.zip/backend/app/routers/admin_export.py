
from fastapi import APIRouter, Response
from ..utils.store import store
import io, zipfile, json, csv

router = APIRouter()

@router.get('/admin/contractors')
def list_contractors(only_active: bool = False):
    items = []
    for uid, u in (store.users or {}).items():
        if only_active:
            mem = (store.memberships or {}).get(uid)
            if not (isinstance(mem, dict) and mem.get('status') in ('active','trial')):
                continue
        # Heuristic: user marked as contractor or has a profile with company name
        profile = (u or {}).get('profile', {})
        if (u or {}).get('role') == 'contractor' or profile.get('company_name'):
            items.append({ 'id': uid, 'company_name': profile.get('company_name') or u.get('name') or uid, 'email': profile.get('email') or u.get('email'), 'membership': (store.memberships or {}).get(uid) })
    return { 'contractors': items }


@router.get("/admin/export/all.zip")
def export_all(scrub: bool = False):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr('README_DATA_DICTIONARY.md', '''# Storm Disaster Export - Data Dictionary

This document describes the top-level files in the export ZIP.

## users.json
- **id (key)**: user id
- **role**: ''contractor'' | ''admin'' | ''homeowner'' | etc.
- **email / phone**: contact info (*scrubbed to ''***'' when `?scrub=true`*)
- **profile**: object with contractor branding & contact data
  - **company_name, legal_name, address, phone, email, logo_url**

## jobs.json
- **job_id (key)**: job id
- **contractor_id**: owner contractor
- **homeowner_email / insurer_email**: contacts (*scrubbed when `?scrub=true`*)
- **payments**: { status: ''paid''|''unpaid'', checkout_url?, hosted_invoice_url? }
- **reminders**: scheduled reminder entries
  - **id, level (''gentle''|''firm''|''final''), due_at (ISO), status (''scheduled''|''sent''|...)**
- **reminder_audit**: audit records of reminder sends
  - **id, when (ISO), to (list of recipients, scrubbed when `?scrub=true`), subject, status**
- **letters**: generated letters (text bodies & metadata)
- **timeline**: chronological notes/events

## invoices.json
- **invoice_id (key)**: invoice id
- **job_id**: related job
- **breakdown**: { description: amount } map
- **xactimate**: { total? } comparable

## settings.json
- **reminders.cadence**: org-wide cadence (gentle_days, firm_days, final_days)

## reminder-audit-all.csv
- Columns: id, when, job_id, to, subject, status (*''to'' scrubbed when `?scrub=true`*)

### Scrubbing
When `?scrub=true`, emails, phones, and recipient lists are redacted to ''***'' to enable safe sharing.
''')
        # SCRUB helper
        def _scrub_user(u):
            if not scrub: return u
            u = dict(u or {})
            for k in ['email','phone','phone_number']:
                if k in u: u[k] = '***'
            p = dict(u.get('profile') or {})
            for k in ['email','phone','phone_number','address']:
                if k in p: p[k] = '***'
            u['profile'] = p
            return u

        def _scrub_job(j):
            if not scrub: return j
            j = dict(j or {})
            for k in ['homeowner_email','insurer_email','phone','phone_number']:
                if k in j: j[k] = '***'
            # scrub reminder audit recipients
            ra = []
            for r in j.get('reminder_audit', []) or []:
                r = dict(r)
                if isinstance(r.get('to'), list): r['to'] = ['***' for _ in r['to']]
                elif r.get('to'): r['to'] = '***'
                ra.append(r)
            j['reminder_audit'] = ra
            return j

        # JSON dumps
        z.writestr("users.json", json.dumps({uid:_scrub_user(u) for uid,u in (store.users or {}).items()}, indent=2, default=str))
        z.writestr("jobs.json", json.dumps({jid:_scrub_job(j) for jid,j in (store.jobs or {}).items()}, indent=2, default=str))
        z.writestr("invoices.json", json.dumps(store.invoices, indent=2, default=str))
        z.writestr("settings.json", json.dumps(store.settings, indent=2, default=str))

        # CSV audit (org-wide)
        out = "id,when,job_id,to,subject,status\n"
        for job_id, job in store.jobs.items():
            for r in job.get("reminder_audit", []):
                to_raw = r.get('to', [])
                to_str = ';'.join(['***' for _ in to_raw]) if (scrub and isinstance(to_raw, list)) else ('***' if (scrub and to_raw) else (';'.join(to_raw) if isinstance(to_raw, list) else str(to_raw)))
                subj = (r.get("subject") or "").replace('"','""')
                out += f"{r.get('id')},{r.get('when')},{job_id},"{to_str}","{subj}",{r.get('status')}\n"
        z.writestr("reminder-audit-all.csv", out)

    buf.seek(0)
    return Response(content=buf.read(), media_type="application/zip",
                    headers={"Content-Disposition": "attachment; filename=storm-disaster-export-all.zip"})


@router.get("/admin/export/contractor/{contractor_id}.zip")
def export_contractor(contractor_id: str, scrub: bool = False):
    import io, zipfile, json
    buf = io.BytesIO()

    # SCRUB helpers (reuse logic similar to export_all)
    def _scrub_user(u):
        if not scrub: return u
        u = dict(u or {})
        for k in ['email','phone','phone_number']:
            if k in u: u[k] = '***'
        p = dict(u.get('profile') or {})
        for k in ['email','phone','phone_number','address']:
            if k in p: p[k] = '***'
        u['profile'] = p
        return u

    def _scrub_job(j):
        if not scrub: return j
        j = dict(j or {})
        for k in ['homeowner_email','insurer_email','phone','phone_number']:
            if k in j: j[k] = '***'
        ra = []
        for r in j.get('reminder_audit', []) or []:
            r = dict(r)
            if isinstance(r.get('to'), list): r['to'] = ['***' for _ in r['to']]
            elif r.get('to'): r['to'] = '***'
            ra.append(r)
        j['reminder_audit'] = ra
        return j

    # Collect jobs for contractor
    jobs = { jid:j for jid,j in (store.jobs or {}).items() if j.get('contractor_id') == contractor_id }
    # Invoices for those jobs
    job_ids = set(jobs.keys())
    invoices = { iid:i for iid,i in (store.invoices or {}).items() if i.get('job_id') in job_ids }
    # Contractor user record (and optionally related users later)
    user = (store.users or {}).get(contractor_id, {})

    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("contractor_id.txt", contractor_id)
        z.writestr("user.json", json.dumps(_scrub_user(user), indent=2, default=str))
        z.writestr("jobs.json", json.dumps({jid:_scrub_job(j) for jid,j in jobs.items()}, indent=2, default=str))
        z.writestr("invoices.json", json.dumps(invoices, indent=2, default=str))

        # CSV audit for this contractor
        out = "id,when,job_id,to,subject,status\n"
        for jid, j in jobs.items():
            for r in j.get("reminder_audit", []) or []:
                to_raw = r.get('to', [])
                to_str = ';'.join(['***' for _ in to_raw]) if (scrub and isinstance(to_raw, list)) else ('***' if (scrub and to_raw) else (';'.join(to_raw) if isinstance(to_raw, list) else str(to_raw)))
                subj = (r.get("subject") or "").replace('"','""')
                out += f"{r.get('id')},{r.get('when')},{jid},"{to_str}","{subj}",{r.get('status')}\n"
        z.writestr("reminder-audit.csv", out)

        # Minimal README
        z.writestr("README_CONTRACTOR_EXPORT.md", "This export contains only the selected contractor's user profile, their jobs, invoices, and reminder audit. Use ?scrub=true to redact PII.")

    buf.seek(0)
    from fastapi import Response
    return Response(content=buf.read(), media_type="application/zip",
                    headers={"Content-Disposition": f"attachment; filename=contractor-{contractor_id}.zip"})


from pydantic import BaseModel
from fastapi import Body

class BulkBody(BaseModel):
    contractor_ids: list[str]
    scrub: bool | None = False

@router.post("/admin/export/bulk.zip")
def export_bulk(body: BulkBody):
    # Reuse export_contractor logic by calling subroutine inline
    import io, zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as master:
        for cid in body.contractor_ids or []:
            # generate per-contractor zip content via same logic as endpoint
            inner = export_contractor(cid, scrub=bool(body.scrub))
            content = inner.body if hasattr(inner, "body") else inner
            master.writestr(f"contractor-{cid}.zip", content)
    buf.seek(0)
    from fastapi import Response
    return Response(content=buf.read(), media_type="application/zip",
                    headers={"Content-Disposition": "attachment; filename=contractors-bulk.zip"})


class ShareBody(BaseModel):
    kind: str  # 'contractor' or 'all'
    contractor_id: str | None = None
    scrub: bool | None = False
    ttl_minutes: int | None = 60

@router.post("/admin/export/share")
def create_share(body: ShareBody):
    # Prepare content
    if body.kind == "contractor":
        if not body.contractor_id:
            return {"ok": False, "error": "contractor_id required for kind=contractor"}
        resp = export_contractor(body.contractor_id, scrub=bool(body.scrub))
        filename = f"contractor-{body.contractor_id}.zip"
        content = resp.body if hasattr(resp, "body") else resp
    elif body.kind == "all":
        resp = export_all(scrub=bool(body.scrub))
        filename = "storm-disaster-export-all.zip"
        content = resp.body if hasattr(resp, "body") else resp
    else:
        return {"ok": False, "error": "unknown kind"}

    token = str(uuid.uuid4())
    from datetime import datetime, timedelta, timezone
    exp = datetime.now(timezone.utc) + timedelta(minutes=body.ttl_minutes or 60)

    # Stash in store.settings.shares
    store.settings.setdefault("shares", {})[token] = {
        "filename": filename,
        "content": content,
        "expires_at": exp.isoformat()
    }
    return {"ok": True, "url": f"/admin/export/download/{token}", "expires_at": exp.isoformat()}

@router.get("/admin/export/download/{token}")
def download_share(token: str):
    item = (store.settings.get("shares") or {}).get(token)
    if not item:
        from fastapi import Response
        return Response(content=b"Not found", media_type="text/plain", status_code=404)
    from datetime import datetime, timezone
    if datetime.fromisoformat(item["expires_at"]) < datetime.now(timezone.utc):
        return Response(content=b"Link expired", media_type="text/plain", status_code=410)
    from fastapi import Response
    return Response(content=item["content"], media_type="application/zip",
                    headers={"Content-Disposition": f"attachment; filename={item['filename']}"})
