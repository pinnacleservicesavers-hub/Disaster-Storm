from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
app=FastAPI()
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])

from .routers import reminders_settings, reminders_control
app.include_router(reminders_settings.router, tags=['admin'])
app.include_router(reminders_control.router, tags=['payments'])

from .routers import payments_reminders
app.include_router(payments_reminders.router, tags=['payments'])

from .routers import admin_export
app.include_router(admin_export.router, tags=['admin'])

# bulk/share endpoints already in admin_export router
