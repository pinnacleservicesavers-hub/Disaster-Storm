from typing import Optional
from datetime import datetime

def log_audit(db_session, actor: Optional[str], role: Optional[str], action: str, detail: str = "", ip: Optional[str] = None):
    """
    Writes an audit entry using raw SQL so it works even if ORM model isn't wired.
    Creates the table if it doesn't exist.
    """
    ts = datetime.utcnow().isoformat() + "Z"
    sql_create = """
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL,
        actor TEXT,
        role TEXT,
        action TEXT NOT NULL,
        detail TEXT,
        ip TEXT
    );
    """
    sql_insert = "INSERT INTO audit_log (ts, actor, role, action, detail, ip) VALUES (:ts, :actor, :role, :action, :detail, :ip)"
    conn = db_session.connection()
    conn.execute(sql_create)
    conn.execute(sql_insert, {"ts": ts, "actor": actor, "role": role, "action": action, "detail": detail[:1000], "ip": ip or ""})
