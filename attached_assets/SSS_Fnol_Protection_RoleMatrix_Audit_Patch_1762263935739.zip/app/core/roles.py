from typing import Dict, Set

# Define actions and which roles are allowed.
# You can edit this mapping to tune capabilities without changing endpoint code.
ROLE_MATRIX: Dict[str, Set[str]] = {
    # Read-only
    "view_dashboard": {"analyst", "admin"},
    "view_alerts": {"analyst", "admin"},
    "view_claims": {"analyst", "admin"},
    "view_assets": {"analyst", "admin"},
    "view_contractors": {"analyst", "admin"},
    "view_alignment": {"analyst", "admin"},
    "view_fnol_pdf": {"analyst", "admin"},

    # Admin defaults
    "ingest_all": {"admin"},
    "ingest_mrms": {"admin"},
    "bulk_sms": {"admin"},
    "create_claim": {"admin"},
    "create_asset": {"admin"},
    "create_contractor": {"admin"},
    "store_fnol_pdf": {"admin"},   # storing to object storage
    "sign_storage_url": {"admin"},  # mint presigned URLs
}

def can(role: str, action: str) -> bool:
    allowed = ROLE_MATRIX.get(action, set())
    return role in allowed
