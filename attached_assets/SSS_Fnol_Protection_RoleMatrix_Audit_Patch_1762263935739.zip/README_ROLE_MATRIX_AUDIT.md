# SSS Patch — FNOL Protection + Role Matrix + Audit Log

## What’s included
- `app/core/roles.py` — central **ROLE_MATRIX** + `can(role, action)` helper.
- `app/core/audit.py` — raw-SQL **audit logger**; creates `audit_log` table if not exists.
- `app/core/security.py` — guard stores JWT payload at `request.state.user` for auditing.
- `app/routers/reports.py` — **JWT-protected FNOL** endpoint: view allowed for analyst/admin; storing to object storage requires admin; audit logs both.
- `app/routers/reports_admin.py` — admin-only list/sign, **with audit logs**.

## Wire-up
1) Copy files into your project.
2) Ensure your app registers the `reports.router` (replace/augment existing reports router):
   ```python
   from app.routers import reports
   app.include_router(reports.router, prefix="/api", tags=["reports"])
   ```
   And keep `reports_admin` if you use the Admin UI:
   ```python
   from app.routers import reports_admin
   app.include_router(reports_admin.router, prefix="/api", tags=["reports-admin"])
   ```
3) No new dependencies required beyond your JWT lib (`PyJWT`).

## Role tuning
Edit `app/core/roles.py` to adjust who can:
- open FNOL PDFs (`view_fnol_pdf`)
- store FNOL to object storage (`store_fnol_pdf`)
- mint signed URLs (`sign_storage_url`)
- trigger ingests / SMS / create entities, etc.

## Audit storage
- Writes table `audit_log` with cols: `ts, actor, role, action, detail, ip` (SQLite syntax; works with most DBs).
- You can later replace with a SQLAlchemy model.

