# Storm Owner Lookup Service

Turn **GPS → Address → Parcel → Owner** with compliance-friendly data providers, then optionally **verify/append contact**.

## Endpoints

- `GET /lookup?lat=32.4609&lon=-84.9877` → reverse geocode (Smarty/Google) → Regrid point-in-parcel → fallback ATTOM by address.
- `GET /owner-by-address?address=123 Main St, Columbus, GA 31901` → ATTOM owner record.
- `POST /verify-contact` with JSON `{ "name": "Jane Smith", "address": "123 Main St, Columbus, GA 31901", "phone": "706-555-1212", "email": "jane@example.com" }` → Melissa verification & appends.

All adapters are **optional**—the service uses whatever API keys you set in `.env`.

## Quick Start (Replit or local)

1. Create a new Repl (Node.js) or run locally.
2. Upload this folder and run:

```bash
npm install
cp .env.example .env  # then put your keys
npm run dev           # or npm start
```

3. Test requests:

```bash
# GPS -> owner
curl "http://localhost:8080/lookup?lat=32.4609&lon=-84.9877"

# Owner by address
curl "http://localhost:8080/owner-by-address?address=4155 US-27, Cataula, GA 31804"

# Verify contact
curl -X POST "http://localhost:8080/verify-contact"   -H "Content-Type: application/json"   -d '{"name":"John Doe","address":"4155 US-27, Cataula, GA 31804","phone":"7068408949","email":"info@slm.example"}'
```

## Notes

- **TruthFinder is NOT used** (FCRA/ToS risk). Use official APIs/open-data only.
- Always log `source` and `retrieved_at`. Data may lag—treat as a lead, not gospel.
- Respect TCPA for any outbound calls/texts.
