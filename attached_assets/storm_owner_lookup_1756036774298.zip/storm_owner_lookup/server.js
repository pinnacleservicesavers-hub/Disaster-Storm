import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import pino from 'pino';
import pinoHttp from 'pino-http';

import { reverseGeocode } from './services/geocode.js';
import { getParcelByPoint, getOwnerByAddress } from './services/parcel.js';
import { verifyContact } from './services/enrich.js';

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('tiny'));

const logger = pino();
app.use(pinoHttp({ logger }));

app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    message: 'Storm Owner Lookup Service',
    endpoints: ['/lookup?lat=..&lon=..', '/owner-by-address?address=..', '/verify-contact (POST)']
  });
});

// 1) GPS -> Address -> Parcel/Owner
app.get('/lookup', async (req, res) => {
  try {
    const { lat, lon } = req.query;
    if (!lat || !lon) return res.status(400).json({ error: 'lat and lon are required' });

    const geo = await reverseGeocode(lat, lon);
    if (!geo?.address) return res.status(404).json({ error: 'Address not found for provided coordinates', geo });

    // Try Regrid point lookup first
    let parcel = null;
    try {
      parcel = await getParcelByPoint(lat, lon);
    } catch (e) {
      req.log.warn({ err: e }, 'Regrid lookup failed');
    }

    // Fallback: ATTOM by address if no parcel/owner found
    let attomOwner = null;
    if (!parcel?.owner_name && process.env.ATTOM_API_KEY) {
      try {
        attomOwner = await getOwnerByAddress(geo.address);
      } catch (e) {
        req.log.warn({ err: e }, 'ATTOM lookup failed');
      }
    }

    const result = {
      input: { lat, lon },
      address: geo.address,
      geocode_meta: geo.meta,
      parcel: parcel ? {
        apn: parcel.apn,
        situs_address: parcel.situs_address,
        owner_name: parcel.owner_name,
        owner_mailing_address: parcel.owner_mailing_address,
        source: parcel.source
      } : null,
      attom_owner: attomOwner,
      retrieved_at: new Date().toISOString()
    };

    res.json(result);
  } catch (err) {
    req.log.error({ err }, 'Lookup error');
    res.status(500).json({ error: 'Internal error', details: err.message });
  }
});

// 2) Owner by address (direct ATTOM path)
app.get('/owner-by-address', async (req, res) => {
  try {
    const { address } = req.query;
    if (!address) return res.status(400).json({ error: 'address is required' });
    const attomOwner = await getOwnerByAddress(address);
    res.json({ address, attom_owner: attomOwner, retrieved_at: new Date().toISOString() });
  } catch (err) {
    res.status(500).json({ error: 'Internal error', details: err.message });
  }
});

// 3) Verify/append contact (Melissa). POST JSON: { name, address, phone, email }
app.post('/verify-contact', async (req, res) => {
  try {
    const payload = req.body || {};
    const verified = await verifyContact(payload);
    res.json({ input: payload, verified, retrieved_at: new Date().toISOString() });
  } catch (err) {
    res.status(500).json({ error: 'Internal error', details: err.message });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Listening on http://localhost:${PORT}`));
