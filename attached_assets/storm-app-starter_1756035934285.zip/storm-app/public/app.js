const map = L.map('map').setView([32.46, -84.99], 6);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);

async function loadReports() {
  const r = await fetch('/api/reports?hours=24');
  const reports = await r.json();
  reports.forEach(rep => {
    const m = L.marker([rep.lat, rep.lon]).addTo(map);
    m.bindPopup(`<b>${rep.address || 'Unverified address'}</b><br/>${rep.notes || ''}<br/><i>${rep.source}</i>`);
  });
}

async function reportDamage() {
  if (!navigator.geolocation) return alert("GPS not available");
  navigator.geolocation.getCurrentPosition(async pos => {
    const body = {
      lat: pos.coords.latitude,
      lon: pos.coords.longitude,
      notes: prompt('Describe the damage (optional)') || ''
    };
    const r = await fetch('/api/report-damage', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
    const data = await r.json();
    if (data.ok) {
      alert('Report received. Thank you.');
      location.reload();
    } else {
      alert('Error: ' + (data.error || 'unknown'));
    }
  }, err => alert(err.message), { enableHighAccuracy: true });
}

document.getElementById('reportBtn').addEventListener('click', reportDamage);
loadReports();
