# SLM Storm App — Starter

This folder is a paste-ready starter for Replit or your own Node host.

## What it does (MVP)

- Fetches **NWS active alerts** (tornado, severe t-storm, hurricane) every 2 minutes and texts subcontractors who opted-in.
- Ingests **SPC Local Storm Reports** (trees down / tornado / wind / hail) every 15 minutes and pins them.
- Public/subcontractors can **report damage** (GPS + notes + photos later) and it's reverse-geocoded to an address.
- Simple **Leaflet map** shows recent reports.
- AI endpoint to draft **over‑Xactimate justifications** (you provide your OpenAI key).

## Quick Start (Replit)

1. Create a new Replit (Node.js) and upload this **entire folder**.
2. Add Secrets:
   - SUPABASE_URL
   - SUPABASE_KEY
   - TWILIO_SID
   - TWILIO_TOKEN
   - TWILIO_NUMBER
   - OPENAI_API_KEY
   - LOCATIONIQ_KEY (optional, for reverse geocoding)
   - COVERED_STATES (optional; default list included)
3. In Supabase, run the SQL in `supabase_schema.sql` to create tables.
4. In Replit shell: `npm install` then `npm run dev`.
5. Open the webview → you should see the map. Click **Report Damage** to test.
6. The background workers run inside the same process (see `server/alertWorker.js`). On Replit free tiers, jobs pause if the repl sleeps. Use **Replit Deployments** or an always-on host for production.

## Next

- Wire payments (Stripe), e-sign (Dropbox Sign/DocuSign), and property owner lookup (ATTOM/Estated).
- Add Twilio voice & call‑recording webhooks with consent prompts.
- Build the Job/Claim UI and artifact uploads.
- Add daily 6 AM task digest and lien-deadline reminders.
