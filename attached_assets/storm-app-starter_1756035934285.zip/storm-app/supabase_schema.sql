-- Enable extensions if needed
-- create extension if not exists "uuid-ossp";

create table if not exists subcontractors (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  name text,
  phone text,
  email text,
  states text[] default '{}',
  counties text[] default '{}',
  sms_opt_in boolean default true
);

create table if not exists alerts (
  id text primary key,
  created_at timestamptz default now(),
  type text,
  state text,
  county_fips text,
  starts_at timestamptz,
  ends_at timestamptz,
  geom jsonb
);

create table if not exists damage_reports (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  source text, -- 'public','lsr','nws','internal'
  lat double precision,
  lon double precision,
  address text,
  city text,
  state text,
  zip text,
  notes text,
  photos text[] default '{}',
  videos text[] default '{}'
);

create table if not exists jobs (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  status text default 'new',
  customer_name text,
  phone text,
  email text,
  address text,
  city text,
  state text,
  zip text,
  county_fips text,
  lat double precision,
  lon double precision,
  claim_number text,
  insurance_name text,
  insurance_phone text,
  insurance_email text,
  folder text,
  aob_signed boolean default false,
  contract_signed boolean default false,
  lien_state text,
  completion_date date,
  lien_deadline date
);

create table if not exists artifacts (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  job_id uuid references jobs(id) on delete cascade,
  kind text, -- 'photo','video','note','call','email','doc','invoice'
  url_or_text text,
  created_by text
);

create table if not exists invoices (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  job_id uuid references jobs(id) on delete cascade,
  subtotal numeric,
  tax numeric,
  total numeric,
  method text, -- 'card','check','insurance'
  paid boolean default false,
  xactimate_like_json jsonb
);
