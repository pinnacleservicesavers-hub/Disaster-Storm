import express from "express";
import cors from "cors";
import axios from "axios";
import { createClient } from "@supabase/supabase-js";
import path from "path";
import { fileURLToPath } from "url";
import "./alertWorker.js"; // starts scheduled jobs

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

// Serve the static frontend
app.use(express.static(path.join(__dirname, "..", "public")));

// Supabase
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

// Healthcheck
app.get("/health", (_, res) => res.json({ ok: true, time: new Date().toISOString() }));

// List recent damage reports (default 24h)
app.get("/api/reports", async (req, res) => {
  const hours = Number(req.query.hours || 24);
  const since = new Date(Date.now() - hours * 3600 * 1000).toISOString();
  const { data, error } = await supabase
    .from("damage_reports")
    .select("*")
    .gte("created_at", since)
    .order("created_at", { ascending: false })
    .limit(500);
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// Create a new damage report from lat/lon and optional photos
app.post("/api/report-damage", async (req, res) => {
  try {
    const { lat, lon, notes = "", photo_urls = [] } = req.body;
    if (typeof lat !== "number" || typeof lon !== "number") {
      return res.status(400).json({ error: "lat and lon required (numbers)" });
    }
    // Reverse geocode (LocationIQ or Google Maps)
    let address = null, city=null, state=null, zip=null;
    try {
      const r = await axios.get("https://us1.locationiq.com/v1/reverse", {
        params: { key: process.env.LOCATIONIQ_KEY, lat, lon, format: "json" }
      });
      const a = r.data?.address || {};
      address = r.data?.display_name || null;
      city = a.city || a.town || a.village || null;
      state = a.state || null;
      zip = a.postcode || null;
    } catch (e) {
      // reverse geocode optional
    }
    const { data, error } = await supabase
      .from("damage_reports")
      .insert({ lat, lon, address, city, state, zip, notes, source: "public", photos: photo_urls })
      .select().single();
    if (error) return res.status(500).json({ error: error.message });
    res.json({ ok: true, report: data });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Simple AI endpoint for justification letters
app.post("/api/ai/explain-overage", async (req, res) => {
  try {
    const { scope, lineItems = [], reasons = [] } = req.body;
    const prompt = `Write a professional justification to an insurance adjuster explaining why an emergency tree service invoice exceeds Xactimate for this scope.
Scope:\n${scope}\n
Line items:\n${JSON.stringify(lineItems, null, 2)}\n
Reasons to emphasize: ${reasons.join(", ")}.
Focus on life-safety, access constraints, crane setup/teardown, utility coordination, traffic control, night/weekend response, debris volume and hazard conditions. Keep it factual and firm.`;

    const resp = await axios.post("https://api.openai.com/v1/chat/completions", {
      model: "gpt-5-thinking",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.2
    }, { headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` } });

    res.json({ text: resp.data.choices?.[0]?.message?.content || "" });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Fallback to index.html for SPA-style routes
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`SLM Storm App server listening on :${PORT}`));
