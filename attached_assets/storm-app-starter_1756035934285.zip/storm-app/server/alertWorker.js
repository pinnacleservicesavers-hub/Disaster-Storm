import axios from "axios";
import cron from "node-cron";
import { createClient } from "@supabase/supabase-js";
import Twilio from "twilio";

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
const twilio = Twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);

// States covered (2-letter codes)
const STATES = (process.env.COVERED_STATES || "GA,FL,AL,NC,SC,TN,TX,LA,MI,VA,MD,DE,NJ,NY,CT,RI,MA,NH,ME,PA,VT,OH,KY,WV,OK,KS,NE,SD,IN,MO,IL").split(",").map(s=>s.trim());

function stateList() {
  // weather.gov accepts comma-separated "area" param
  return STATES.join(",");
}

// --- NWS Active Alerts (TOR/SVR/HUR) ---
async function fetchActiveAlerts() {
  const url = "https://api.weather.gov/alerts/active";
  const params = {
    status: "actual",
    area: stateList(),
    // Comma separated list of events to include
    event: "Tornado Warning,Severe Thunderstorm Warning,Hurricane Warning,Hurricane Watch,Tornado Watch"
  };
  const { data } = await axios.get(url, { params, headers: { "User-Agent": "SLM-StormApp (support@yourdomain.com)" }});
  return data.features || [];
}

async function upsertAlertAndNotify(feature) {
  const id = feature.id;
  const p = feature.properties || {};
  const area = p.areaDesc || "";
  const event = p.event || "";
  const ends = p.ends || p.expires || null;

  // Save alert (idempotent)
  const { error } = await supabase.from("alerts").upsert({
    id, type: event, state: null, county_fips: null, starts_at: p.onset || p.sent, ends_at: ends, geom: feature.geometry
  });
  if (error) console.error("supabase upsert alert error", error);

  const msg = `⚠️ ${event}\n${area}\nStart: ${p.onset || p.sent}\nEnd: ${ends || "TBD"}\n${p.headline || ""}`;

  // Notify subcontractors by simple state match in their preference list
  const { data: subs, error: subErr } = await supabase
    .from("subcontractors")
    .select("name,phone,states,sms_opt_in")
    .not("phone", "is", null)
    .eq("sms_opt_in", true);
  if (subErr) return;

  for (const s of (subs || [])) {
    if (!s.states) continue;
    const hasState = s.states.some(st => STATES.includes(st));
    if (!hasState) continue;
    try {
      await twilio.messages.create({ to: s.phone, from: process.env.TWILIO_NUMBER, body: msg });
    } catch (e) {
      console.log("Twilio SMS error", s.phone, e.message);
    }
  }
}

// --- SPC Local Storm Reports (trees down, tornado, hail, wind) ---
async function fetchLSRToday() {
  // SPC "today.csv" (approx hourly). If JSON available, swap endpoint.
  const url = "https://www.spc.noaa.gov/climo/reports/today.csv";
  const { data } = await axios.get(url, { responseType: "text" });
  return data; // CSV string
}

function parseLSR(csvText) {
  const rows = csvText.split(/\r?\n/).filter(Boolean).slice(1); // skip header
  // Expected cols: time, tz, type, magnitude, city, county, state, lat, lon, remarks
  const out = [];
  for (const line of rows) {
    const cols = line.split(",");
    if (cols.length < 10) continue;
    const type = cols[2]?.trim();
    if (!["TORNADO", "TSTM WND DMG", "HAIL", "TSTM WND GST"].includes(type)) continue;
    const lat = parseFloat(cols[7]); const lon = parseFloat(cols[8]);
    if (Number.isNaN(lat) || Number.isNaN(lon)) continue;
    out.push({ type, lat, lon, city: cols[4], county: cols[5], state: cols[6], remarks: cols.slice(9).join(",") });
  }
  return out;
}

async function ingestLSR() {
  try {
    const text = await fetchLSRToday();
    const items = parseLSR(text);
    for (const it of items) {
      // Upsert a damage_report with source 'lsr'
      await supabase.from("damage_reports").upsert({
        lat: it.lat, lon: it.lon, address: null, city: it.city, state: it.state, notes: `${it.type}: ${it.remarks}`, source: "lsr"
      }, { onConflict: "lat,lon,source" });
    }
  } catch (e) {
    console.log("LSR ingest error", e.message);
  }
}

// --- CRON SCHEDULES ---
// Alerts every 2 minutes
cron.schedule("*/2 * * * *", async () => {
  try {
    const feats = await fetchActiveAlerts();
    for (const f of feats) await upsertAlertAndNotify(f);
    console.log("NWS alerts ok:", feats.length);
  } catch (e) {
    console.log("Alert fetch fail", e.message);
  }
});

// LSR ingest every 15 minutes
cron.schedule("*/15 * * * *", async () => {
  await ingestLSR();
});
