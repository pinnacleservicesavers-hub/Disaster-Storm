"use client";
import CadenceEditor from './cadence';
export default function AdminCenter(){ return (<main className='p-8 space-y-6'><h1 className='text-2xl font-bold'>Admin Command Center</h1><CadenceEditor/></main>); }
