import requests
import asyncio
from fastapi import FastAPI
app=FastAPI()

from .middleware.admin_enforce import AdminVerifiedTokenMiddleware
app.add_middleware(AdminVerifiedTokenMiddleware)

from .routers import health
app.include_router(health.router)


from .utils.store import store

async def _jwks_refresher():
    while True:
        try:
            cfg = store.settings.get("oidc") or {}
            issuer = cfg.get("issuer")
            if issuer:
                url = issuer.rstrip("/") + "/.well-known/jwks.json"
                headers = {}
                meta = cfg.get("jwks_meta") or {}
                if meta.get("etag"):
                    headers["If-None-Match"] = meta["etag"]
                r = requests.get(url, headers=headers, timeout=10)
                if r.status_code == 200:
                    jwks = r.json()
                    store.settings.setdefault("oidc", {})["jwks"] = jwks
                    cc = r.headers.get("Cache-Control","")
                    etag = r.headers.get("ETag")
                    max_age = None
                    for part in cc.split(","):
                        part = part.strip().lower()
                        if part.startswith("max-age="):
                            try:
                                max_age = int(part.split("=",1)[1])
                            except Exception:
                                pass
                    store.settings["oidc"]["jwks_meta"] = {
                        "last_status": 200,
                        "last_fetch": __import__('datetime').datetime.utcnow().isoformat(),
                        "etag": etag,
                        "max_age": max_age
                    }
                elif r.status_code == 304:
                    store.settings.setdefault("oidc", {})["jwks_meta"] = {
                        "last_status": 304,
                        "last_fetch": __import__('datetime').datetime.utcnow().isoformat(),
                        "etag": meta.get("etag"),
                        "max_age": meta.get("max_age")
                    }
        except Exception:
            pass
        # Sleep based on max-age if present, else 6 hours
        try:
            cfg = store.settings.get("oidc") or {}
            ma = ((cfg.get("jwks_meta") or {}).get("max_age") or 21600)
            if not isinstance(ma, int): ma = 21600
            await asyncio.sleep(max(1800, min(ma, 21600)))  # between 30m and 6h
        except Exception:
            await asyncio.sleep(21600)


@app.on_event("startup")
async def _start_jwks_refresher():
    app.state._jwks_ref = asyncio.create_task(_jwks_refresher())

@app.on_event("shutdown")
async def _stop_jwks_refresher():
    t = getattr(app.state, "_jwks_ref", None)
    if t: t.cancel()
