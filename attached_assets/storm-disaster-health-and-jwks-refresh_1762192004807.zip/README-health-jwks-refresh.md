
# Auth Health & JWKS Auto-Refresh

## Health check
- **Endpoint:** `GET /health/auth`
- **Query:** `?token=...` (optional) or provide `Authorization: Bearer ...`
- **Returns:** issuer/audience, JWKS status, last fetch meta, and token verification result.

Example:
```bash
curl -s http://localhost:8000/health/auth
curl -s -H "Authorization: Bearer $ID_TOKEN" http://localhost:8000/health/auth
```

## Auto-refresh
- On app startup, a background task refreshes JWKS on a schedule.
- Honors **ETag** and **Cache-Control: max-age** when available.
- Sleeps between **30 minutes and 6 hours** based on server hints (defaults to 6h).

This keeps signing keys fresh without manual intervention.
