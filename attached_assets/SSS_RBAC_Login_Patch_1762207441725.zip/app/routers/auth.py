import os, json
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.core.security import create_token

router = APIRouter()

class LoginIn(BaseModel):
    username: str
    password: str
    ttl_seconds: int | None = 3600

def _load_users() -> dict:
    # USERS_JSON env can be like: {"admin":{"password":"secret","role":"admin"},"analyst":{"password":"demo","role":"analyst"}}
    raw = os.getenv("USERS_JSON")
    if raw:
        try:
            data = json.loads(raw)
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    # Fallback: single admin user whose password equals ADMIN_TOKEN
    admin_pwd = os.getenv("ADMIN_TOKEN") or "change-me"
    return {"admin": {"password": admin_pwd, "role": "admin"}}

@router.post("/auth/login")
def login(body: LoginIn):
    users = _load_users()
    u = users.get(body.username)
    if not u or u.get("password") != body.password:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_token(body.username, u.get("role","analyst"), ttl_seconds=body.ttl_seconds or 3600)
    return {"access_token": token, "token_type": "bearer", "role": u.get("role","analyst")}
