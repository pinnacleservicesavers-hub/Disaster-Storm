from fastapi import APIRouter, Depends, Query
from app.utils.storage import list_prefix, sign_url_for_key
from app.core.security import role_required

router = APIRouter()

@router.get("/reports/fnol/list")
def list_fnol(_: dict = Depends(role_required(["admin"]))):
    return {"items": list_prefix("fnol/")}

@router.get("/reports/sign")
def sign_key(key: str = Query(..., description="Exact storage key"), _: dict = Depends(role_required(["admin"]))):
    return {"url": sign_url_for_key(key, days=7)}
