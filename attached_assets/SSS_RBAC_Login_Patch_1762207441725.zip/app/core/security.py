import os, time, typing as t
import jwt
from fastapi import Header, HTTPException

JWT_ALG = "HS256"

def _secret() -> str:
    # Use ADMIN_JWT_SECRET if present; otherwise fall back to ADMIN_TOKEN (for simple setups)
    return os.getenv("ADMIN_JWT_SECRET") or os.getenv("ADMIN_TOKEN") or "change-me"

def create_token(sub: str, role: str, ttl_seconds: int = 3600) -> str:
    now = int(time.time())
    payload = {"sub": sub, "role": role, "iat": now, "exp": now + ttl_seconds}
    return jwt.encode(payload, _secret(), algorithm=JWT_ALG)

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, _secret(), algorithms=[JWT_ALG])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

def role_required(roles: t.List[str] | None = None):
    roles = roles or ["admin"]
    def _guard(authorization: t.Optional[str] = Header(default=None, alias="Authorization")) -> dict:
        if not authorization or not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Missing Bearer token")
        token = authorization.split(" ", 1)[1].strip()
        payload = decode_token(token)
        if payload.get("role") not in roles:
            raise HTTPException(status_code=403, detail="Insufficient role")
        return payload
    return _guard
