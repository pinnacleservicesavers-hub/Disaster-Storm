# SSS RBAC + Login Patch

## What’s included
- `app/core/security.py` — JWT helpers and role guard
- `app/routers/auth.py` — `/api/auth/login` (username/password -> JWT)
- `app/routers/reports_admin.py` — admin-only (JWT) list + sign endpoints
- `web/admin/login.html` + updated `web/admin/index.html` — login flow, logout, token storage
- `requirements-append-rbac.txt` — add `PyJWT==2.9.0`

## Env
- `ADMIN_JWT_SECRET` (recommended) or `ADMIN_TOKEN` (fallback)
- `USERS_JSON` (optional) e.g.
  `{"admin":{"password":"secret","role":"admin"},"analyst":{"password":"demo","role":"analyst"}}`
  If omitted, a default `admin` user is created whose password is `ADMIN_TOKEN`.

## Wiring
In `app/main.py`:
```python
from app.routers import auth, reports_admin
app.include_router(auth.router, prefix="/api", tags=["auth"])
app.include_router(reports_admin.router, prefix="/api", tags=["reports"])
```

## Notes
- Tokens default to 1-hour TTL; override by sending `ttl_seconds` on login.
- Replace plain-text passwords with your own user system when ready (or integrate OAuth/IdP).
