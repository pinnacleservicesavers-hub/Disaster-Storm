"use client";
import { useEffect, useState } from "react";
import { api, API_BASE } from "@/lib/api";

export default function InsurerDashboard() {
  const [claims, setClaims] = useState<any[]>([]);
  const [err, setErr] = useState("");

  useEffect(()=>{
    api("/insurer/claims").then(r=>setClaims(r.claims)).catch(()=>setErr("Please log in as an insurer."));
  },[]);

  return (
    <main className="p-8 max-w-5xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Insurer Portal</h1>
      {err && <div className="text-red-600">{err}</div>}
      <div className="border rounded">
        {claims.map((c)=> (
          <div key={c.job_id} className="p-3 border-b flex items-center justify-between">
            <div>
              <div className="font-medium">Job {c.job_id}</div>
              <div className="text-sm text-gray-600">Status: {c.status}</div>
            </div>
            <a className="underline" href={`${API_BASE}/claims/${c.job_id}/submission.zip`} target="_blank">Download Submission</a>
          </div>
        ))}
        {claims.length === 0 && <div className="p-3 text-gray-600">No claims yet.</div>}
      </div>
    </main>
  );
}
