"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import { useUser } from "@/store/user";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const router = useRouter();
  const setUser = useUser(s=>s.setUser);

  const submit = async (e: any) => {
    e.preventDefault();
    try {
      const r = await api("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
      setUser(r.user, r.token);
      localStorage.setItem("refresh", r.refresh);
      if (r.user.role === "contractor") router.push("/contractor/dashboard");
      else if (r.user.role === "homeowner") router.push("/homeowner/dashboard");
      else router.push("/insurer/dashboard");
    } catch (e:any) {
      setErr("Login failed");
    }
  };

  return (
    <main className="p-8 max-w-md mx-auto space-y-4">
      <h1 className="text-xl font-semibold">Login</h1>
      {err && <div className="text-red-600">{err}</div>}
      <form onSubmit={submit} className="space-y-4">
        <input className="border p-2 w-full" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="border p-2 w-full" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="bg-black text-white px-4 py-2 rounded w-full">Login</button>
      </form>
      <p className="text-sm">No account? <a className="underline" href="/signup">Sign up</a></p>
    </main>
  );
}
