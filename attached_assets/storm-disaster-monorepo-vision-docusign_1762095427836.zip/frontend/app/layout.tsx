"use client";
import { useEffect } from "react";
import { useUser } from "@/store/user";

export const metadata = { title: "Storm Disaster", description: "Contractor & Homeowner Portal" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const setUser = useUser(s=>s.setUser);
  useEffect(()=>{
    try {
      const saved = JSON.parse(localStorage.getItem("auth")||"{}");
      if (saved?.user && saved?.token) setUser(saved.user, saved.token);
    } catch {}
  }, [setUser]);
  return (
    <html lang="en">
      <body className="min-h-screen bg-gray-50 text-gray-900">{children}</body>
    </html>
  );
}
