"use client";
import { useState } from "react";
import { api } from "@/lib/api";
import { useUser } from "@/store/user";

export default function Settings() {
  const user = useUser(s=>s.user);
  const [consent, setConsent] = useState(true);
  const [plan, setPlan] = useState("one_time");
  const [msg, setMsg] = useState("");

  const saveConsent = async ()=>{
    if (!user) return;
    await api("/compliance/consent", { method:"POST", body: JSON.stringify({ user_id: user.id, consent_comm: consent })});
    setMsg("Saved consent");
  };
  const checkout = async ()=>{
    if (!user) return;
    const r = await api("/membership/checkout", { method:"POST", body: JSON.stringify({ user_id: user.id, plan })});
    window.location.href = r.checkout_url;
  };

  return (
    <main className="p-8 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold">Settings</h1>
      <section className="border rounded p-4 space-y-2">
        <h2 className="text-lg font-semibold">Consent & Notifications</h2>
        <label className="flex items-center gap-2">
          <input type="checkbox" checked={consent} onChange={e=>setConsent(e.target.checked)} />
          I consent to receive storm/claim updates (SMS/email/calls)
        </label>
        <button onClick={saveConsent} className="bg-black text-white px-4 py-2 rounded">Save</button>
      </section>
      <section className="border rounded p-4 space-y-2">
        <h2 className="text-lg font-semibold">Membership</h2>
        <select className="border p-2" value={plan} onChange={e=>setPlan(e.target.value)}>
          <option value="one_time">One-time</option>
          <option value="monthly">Monthly</option>
        </select>
        <button onClick={checkout} className="bg-black text-white px-4 py-2 rounded">Checkout</button>
      </section>
      {msg && <div className="text-green-700">{msg}</div>}
    </main>
  );
}
