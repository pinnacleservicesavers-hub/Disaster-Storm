"use client";
import { useState } from "react";
import { api } from "@/lib/api";

export default function Uploader() {
  const [key, setKey] = useState("jobs/A1/photo-1.jpg");
  const [file, setFile] = useState<File|null>(null);
  const [msg, setMsg] = useState("");

  const upload = async () => {
    if (!file) return;
    const { url } = await api("/uploads/presign", { method:"POST", body: JSON.stringify({ key }) });
    const res = await fetch(url, { method:"PUT", body: file });
    if (!res.ok) throw new Error("upload failed");
    setMsg("Uploaded to S3 (presigned) ✔");
  };

  return (
    <main className="p-8 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">S3 Uploader (Presigned URL)</h1>
      <input className="border p-2 w-full" value={key} onChange={e=>setKey(e.target.value)} placeholder="S3 key" />
      <input type="file" onChange={e=>setFile(e.target.files?.[0]||null)} />
      <button onClick={upload} className="bg-black text-white px-4 py-2 rounded">Upload</button>
      {msg && <div className="text-green-700">{msg}</div>}
    </main>
  );
}
