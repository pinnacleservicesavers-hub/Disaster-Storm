"use client";
import { useState } from "react";
import { api } from "@/lib/api";

export default function Contracts() {
  const [trade, setTrade] = useState("tree_service");
  const [state, setState] = useState("FL");
  const [contract, setContract] = useState("");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [signUrl, setSignUrl] = useState("");

  const generate = async () => {
    const r = await api("/contractor/contracts/generate", { method:"POST", body: JSON.stringify({ trade, state })});
    setContract(r.contract);
  };

  const sign = async () => {
    const r = await api("/contracts/sign", { method:"POST", body: JSON.stringify({ contract_text: contract, signer_email: email, signer_name: name })});
    setSignUrl(r.sign_url);
  };

  return (
    <main className="p-8 max-w-3xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Contracts</h1>
      <div className="grid grid-cols-2 gap-2">
        <input className="border p-2" value={trade} onChange={e=>setTrade(e.target.value)} placeholder="Trade" />
        <input className="border p-2" value={state} onChange={e=>setState(e.target.value)} placeholder="State" />
      </div>
      <button onClick={generate} className="bg-black text-white px-4 py-2 rounded">Generate AI Contract</button>
      <textarea className="border p-2 w-full h-48" value={contract} onChange={e=>setContract(e.target.value)} />
      <div className="grid grid-cols-2 gap-2">
        <input className="border p-2" value={name} onChange={e=>setName(e.target.value)} placeholder="Signer name" />
        <input className="border p-2" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Signer email" />
      </div>
      <button onClick={sign} className="bg-black text-white px-4 py-2 rounded">Send for e‑signature</button>
      {signUrl && <div className="mt-2"><a className="underline" target="_blank" href={signUrl}>Open signing session</a></div>}
    </main>
  );
}
