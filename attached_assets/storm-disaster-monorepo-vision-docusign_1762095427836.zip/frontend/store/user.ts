"use client";
import { create } from "zustand";

type User = { id: string; email: string; role: "contractor"|"homeowner" };
type State = { user?: User; token?: string; setUser: (u: User, t: string)=>void; logout: ()=>void };

export const useUser = create<State>((set)=> ({
  user: undefined,
  token: undefined,
  setUser: (u, t) => {
    if (typeof window !== "undefined") localStorage.setItem("auth", JSON.stringify({ user: u, token: t }));
    set({ user: u, token: t });
  },
  logout: () => {
    if (typeof window !== "undefined") localStorage.removeItem("auth");
    set({ user: undefined, token: undefined });
  },
}));
