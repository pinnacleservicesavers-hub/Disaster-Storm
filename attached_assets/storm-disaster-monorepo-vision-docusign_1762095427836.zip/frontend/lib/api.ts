export const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";

function getToken() {
  try { return JSON.parse(globalThis.localStorage?.getItem("auth")||"{}").token; } catch { return undefined; }
}

export async function api(path: string, opts: RequestInit = {}) {
  const token = typeof window !== "undefined" ? getToken() : undefined;
  const headers: any = { "Content-Type": "application/json", ...(opts.headers || {}) };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(`${API_BASE}${path}`, { headers, ...opts });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
