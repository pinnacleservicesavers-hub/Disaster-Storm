from alembic import op
import sqlalchemy as sa

revision = '0001_init'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('users',
        sa.Column('id', sa.String(), primary_key=True),
        sa.Column('email', sa.String(), unique=True),
        sa.Column('password', sa.String()),
        sa.Column('role', sa.String()),
        sa.Column('consent_comm', sa.Boolean(), default=False),
        sa.Column('phone', sa.String(), nullable=True),
    )
    op.create_table('memberships',
        sa.Column('id', sa.String(), primary_key=True),
        sa.Column('user_id', sa.String(), sa.ForeignKey('users.id')),
        sa.Column('plan', sa.String()),
        sa.Column('status', sa.String()),
    )
    op.create_table('leads',
        sa.Column('id', sa.String(), primary_key=True),
        sa.Column('scope', sa.String()),
        sa.Column('address', sa.String()),
        sa.Column('region', sa.String()),
        sa.Column('status', sa.String()),
    )
    op.create_table('jobs',
        sa.Column('id', sa.String(), primary_key=True),
        sa.Column('status', sa.String()),
        sa.Column('address', sa.String()),
        sa.Column('contractor_id', sa.String(), nullable=True),
        sa.Column('homeowner_id', sa.String(), nullable=True),
    )
    op.create_table('invoices',
        sa.Column('id', sa.String(), primary_key=True),
        sa.Column('job_id', sa.String()),
        sa.Column('breakdown', sa.JSON()),
        sa.Column('xactimate', sa.JSON()),
        sa.Column('status', sa.String()),
    )

def downgrade():
    op.drop_table('invoices')
    op.drop_table('jobs')
    op.drop_table('leads')
    op.drop_table('memberships')
    op.drop_table('users')
