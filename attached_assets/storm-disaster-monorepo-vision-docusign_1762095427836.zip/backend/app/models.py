from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Boolean, JSON, ForeignKey, Integer, Text
from typing import Optional

class Base(DeclarativeBase): pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    email: Mapped[str] = mapped_column(String, unique=True)
    password: Mapped[str] = mapped_column(String)
    role: Mapped[str] = mapped_column(String)  # contractor | homeowner | insurer
    consent_comm: Mapped[bool] = mapped_column(Boolean, default=False)
    phone: Mapped[Optional[str]] = mapped_column(String, nullable=True)

class Membership(Base):
    __tablename__ = "memberships"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    user_id: Mapped[str] = mapped_column(String, ForeignKey("users.id"))
    plan: Mapped[str] = mapped_column(String)
    status: Mapped[str] = mapped_column(String)

class Lead(Base):
    __tablename__ = "leads"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    scope: Mapped[str] = mapped_column(String)
    address: Mapped[str] = mapped_column(String)
    region: Mapped[str] = mapped_column(String)
    status: Mapped[str] = mapped_column(String)

class Job(Base):
    __tablename__ = "jobs"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    status: Mapped[str] = mapped_column(String)
    address: Mapped[str] = mapped_column(String)
    contractor_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    homeowner_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)

class Invoice(Base):
    __tablename__ = "invoices"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    job_id: Mapped[str] = mapped_column(String)
    breakdown: Mapped[dict] = mapped_column(JSON)
    xactimate: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String)
