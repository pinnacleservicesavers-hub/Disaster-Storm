from fastapi import APIRouter, Depends
from pydantic import BaseModel
from ..services.vision_rekognition import detect_labels_s3
import os
from ..utils.store import store
from ..utils.auth import roles_required

router = APIRouter()
any_guard = roles_required(["contractor","homeowner","admin"])

BUCKET = os.getenv("S3_BUCKET", "storm-disaster-dev")

class IngestBody(BaseModel):
    job_id: str
    key: str

@router.post("/media/ingest", dependencies=[Depends(any_guard)])
def ingest(body: IngestBody):
    labels = detect_labels_s3(BUCKET, body.key)
    # Save labels under job -> media
    media_id = store.new_id()
    if "media" not in store.jobs.get(body.job_id, {}):
        store.jobs.setdefault(body.job_id, {}).setdefault("media", [])
    store.jobs[body.job_id]["media"].append({"id": media_id, "key": body.key, "labels": labels})
    return {"id": media_id, "labels": labels}
