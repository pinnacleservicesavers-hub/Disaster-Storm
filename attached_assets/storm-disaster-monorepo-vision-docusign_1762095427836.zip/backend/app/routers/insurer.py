from fastapi import APIRouter, Depends
from ..utils.auth import roles_required
from ..utils.store import store

router = APIRouter()
insurer_guard = roles_required(["insurer","admin"])

@router.get("/insurer/claims", dependencies=[Depends(insurer_guard)])
def list_claims():
    # minimal: return jobs that have invoices
    job_ids = {inv["job_id"] for inv in store.invoices.values()}
    data = [{"job_id": j, "status":"submitted" if j in job_ids else "none"} for j in job_ids]
    return {"claims": data}
