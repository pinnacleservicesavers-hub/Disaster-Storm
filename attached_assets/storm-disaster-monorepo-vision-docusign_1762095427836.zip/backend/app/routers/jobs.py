from fastapi import APIRouter, Depends
from pydantic import BaseModel
from ..utils.store import store
from ..utils.auth import roles_required

router = APIRouter()
any_guard = roles_required(["contractor","homeowner","admin"])

@router.get("", dependencies=[Depends(any_guard)])
def list_jobs():
    return {"jobs": list(store.jobs.values())}

class AnalyzeBody(BaseModel):
    breakdown: dict = {}

@router.post("/{job_id}/media", dependencies=[Depends(any_guard)])
def upload_media(job_id: str):
    return {"ok": True}

@router.post("/{job_id}/analyze", dependencies=[Depends(any_guard)])
def analyze(job_id: str, body: AnalyzeBody):
    labels = ["tree_diameter: 24in", "roof_shingles_missing: 120", "hail_size: 1.5in"]
    return {"labels": labels, "measurements": {"tree_weight_est_lb": 1800}, "breakdown": body.breakdown}

@router.post("/{job_id}/comparables", dependencies=[Depends(any_guard)])
def comps(job_id: str, body: AnalyzeBody):
    true_total = sum([float(v) for v in body.breakdown.values() if str(v).replace('.','',1).isdigit()])
    xactimate_total = round(true_total*0.9, 2)
    return {"true": {"total": true_total}, "xactimate": {"total": xactimate_total}, "variance": true_total - xactimate_total}

@router.post("/{job_id}/contract/sign", dependencies=[Depends(any_guard)])
def sign(job_id: str): return {"signed": True}
