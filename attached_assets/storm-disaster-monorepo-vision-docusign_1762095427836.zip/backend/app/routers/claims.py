from fastapi import APIRouter, Response, Depends
from pydantic import BaseModel
from ..utils.store import store
from ..deps import build_dependencies
from ..utils.pdf import html_to_pdf_bytes
from ..utils.auth import roles_required
from ..dao import dao

router = APIRouter()
deps = build_dependencies()
any_guard = roles_required(["contractor","homeowner","admin"])

class InvoiceBody(BaseModel):
    breakdown: dict

def build_report_html(job_id: str):
    inv = next((v for v in store.invoices.values() if v["job_id"] == job_id), None)
    true_total = 0.0
    if inv:
        for v in inv["breakdown"].values():
            try: true_total += float(v)
            except: pass
    xact_total = inv["xactimate"]["total"] if inv else 0.0
    variance = true_total - xact_total
    html = f"""
    <!doctype html>
    <html><head><meta charset='utf-8'><title>Claim Report - Job {job_id}</title>
    <style>
      body {{ font-family: Arial, sans-serif; padding: 24px; }}
      h1, h2 {{ margin: 0 0 8px; }}
      .card {{ border: 1px solid #ddd; border-radius: 8px; padding: 16px; margin-bottom: 16px; }}
      table {{ width: 100%; border-collapse: collapse; }}
      td, th {{ border-bottom: 1px solid #eee; padding: 8px; text-align: left; }}
      .muted {{ color: #666; }}
    </style></head><body>
      <h1>Insurer-Facing Claim Report</h1>
      <div class='muted'>Job ID: {job_id}</div>
      <div class='card'>
        <h2>Comparables</h2>
        <table>
          <tr><th>Comparable</th><th>Total</th></tr>
          <tr><td>True apples-to-apples</td><td>${true_total:,.2f}</td></tr>
          <tr><td>Xactimate</td><td>${xact_total:,.2f}</td></tr>
          <tr><td><strong>Variance</strong></td><td><strong>${variance:,.2f}</strong></td></tr>
        </table>
      </div>
      <div class='card'>
        <h2>Breakdown</h2>
        <table>
          <tr><th>Item</th><th>Amount</th></tr>
          {''.join(f'<tr><td>{k}</td><td>${v}</td></tr>' for k,v in (inv['breakdown'].items() if inv else {}.items()))}
        </table>
      </div>
      <div class='card'>
        <h2>Narrative</h2>
        <p>This work was necessary to mitigate further loss and restore safe access per industry standards. 
        Pricing reflects labor, equipment (e.g., crane), and materials at market rates during emergency conditions. 
        Where totals exceed Xactimate, we provide justification based on scope specificity, safety constraints, and local market surge.</p>
      </div>
    </body></html>
    """
    return html

@router.post("/{job_id}/invoice", dependencies=[Depends(any_guard)])
async def create_invoice(job_id: str, body: InvoiceBody):
    xact = await deps.xact.estimate(body.breakdown)
    inv = await dao.create_invoice(job_id, body.breakdown, xact)
    return {"invoice_id": inv["id"], "xactimate": xact}

@router.get("/{job_id}/report.html", dependencies=[Depends(any_guard)])
def report_html(job_id: str):
    html = build_report_html(job_id)
    return Response(content=html, media_type="text/html")

@router.get("/{job_id}/report.pdf", dependencies=[Depends(any_guard)])
def report_pdf(job_id: str):
    html = build_report_html(job_id)
    pdf_bytes = html_to_pdf_bytes(html)
    return Response(content=pdf_bytes, media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename=claim-report-{job_id}.pdf"})

@router.post("/{job_id}/submit", dependencies=[Depends(any_guard)])
def submit(job_id: str): return {"submitted": True}

@router.post("/{job_id}/negotiate", dependencies=[Depends(any_guard)])
def negotiate(job_id: str): return {"status": "in_progress"}

@router.post("/{job_id}/status/ping", dependencies=[Depends(any_guard)])
def ping(job_id: str): return {"ok": True}

@router.post("/{job_id}/letters", dependencies=[Depends(any_guard)])
def letters(job_id: str): return {"generated": ["reminder", "demand"]}
