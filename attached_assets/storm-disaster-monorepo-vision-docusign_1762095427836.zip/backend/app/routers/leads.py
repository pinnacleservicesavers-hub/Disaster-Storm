from fastapi import APIRouter, Depends
from ..utils.store import store
from ..utils.auth import roles_required

router = APIRouter()
contractor_guard = roles_required(["contractor","admin"])

@router.get("", dependencies=[Depends(contractor_guard)])
def list_leads():
    return {"leads": list(store.leads.values())}

@router.post("/accept/{lead_id}", dependencies=[Depends(contractor_guard)])
def accept(lead_id: str):
    lead = store.leads.get(lead_id)
    if not lead: return {"ok": False, "error":"lead not found"}
    lead["status"]="locked"
    return {"accepted": lead_id}
