import os
from fastapi import APIRouter, Request
from pydantic import BaseModel
from ..utils.store import store
from ..services.stripe_svc import create_checkout_session, construct_event_from_webhook

router = APIRouter()

class CheckoutBody(BaseModel):
    user_id: str
    plan: str  # one_time | monthly

@router.post("/checkout")
def checkout(body: CheckoutBody):
    session = create_checkout_session(body.user_id, body.plan)
    return {"checkout_url": session.url}

@router.post("/webhook")
async def webhook(request: Request):
    payload = await request.body()
    sig = request.headers.get("stripe-signature", "")
    try:
        event = construct_event_from_webhook(payload, sig)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    if event["type"] in ("checkout.session.completed", "invoice.paid"):
        data = event["data"]["object"]
        user_id = data.get("metadata", {}).get("user_id")
        plan = data.get("metadata", {}).get("plan", "monthly")
        if user_id:
            store.memberships[user_id] = {"plan": plan, "status":"active"}
    return {"ok": True}
