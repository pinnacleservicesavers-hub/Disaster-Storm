from fastapi import APIRouter
from pydantic import BaseModel
from ..services.storage_s3 import presign_url

router = APIRouter()

class PresignBody(BaseModel):
    key: str

@router.post("/uploads/presign")
def presign(body: PresignBody):
    url = presign_url(body.key)
    return {"url": url}
