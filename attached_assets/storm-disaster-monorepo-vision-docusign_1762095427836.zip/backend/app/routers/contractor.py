from fastapi import APIRouter, Depends
from pydantic import BaseModel
from ..utils.store import store
from ..utils.auth import roles_required

router = APIRouter()
contractor_guard = roles_required(["contractor","admin"])

class Profile(BaseModel):
    user_id: str
    company_name: str|None = None
    licenses: list[str]|None = None
    insurance: str|None = None
    alert_channels: list[str]|None = None

@router.post("/profile", dependencies=[Depends(contractor_guard)])
def upsert_profile(body: Profile):
    u = store.users.get(body.user_id)
    if not u: return {"ok": False, "error":"user not found"}
    u["profile"] = body.dict()
    return {"ok": True}

@router.get("/profile/{user_id}", dependencies=[Depends(contractor_guard)])
def get_profile(user_id: str):
    u = store.users.get(user_id)
    return {"profile": u.get("profile", {}) if u else {}}

@router.post("/contracts/validate", dependencies=[Depends(contractor_guard)])
def validate_contract():
    return {"action": "review", "result": {"is_legal": True, "issues": [], "aob_included": True}}

@router.post("/contracts/generate", dependencies=[Depends(contractor_guard)])
def generate_contract():
    return {"action": "generate", "contract": "Contract Template with AOB (if permitted). Terms..."} 
