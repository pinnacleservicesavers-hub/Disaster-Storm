from fastapi import APIRouter, Query
from pydantic import BaseModel
from ..services.docusign_svc import create_envelope

router = APIRouter()

class SignBody(BaseModel):
    contract_text: str
    signer_email: str
    signer_name: str

@router.post("/contracts/sign")
def create_signing(body: SignBody):
    env = create_envelope(body.contract_text, body.signer_email, body.signer_name)
    return {"sign_url": env["sign_url"]}
