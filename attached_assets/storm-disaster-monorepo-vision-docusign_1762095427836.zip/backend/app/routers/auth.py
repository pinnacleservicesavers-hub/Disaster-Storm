from fastapi import APIRouter, Request, Depends
from pydantic import BaseModel
from ..utils.store import store
from ..utils.auth import create_token, create_refresh, auth_required
from ..dao import dao

router = APIRouter()

class SignupBody(BaseModel):
    email: str
    password: str
    role: str  # contractor | homeowner | insurer
    phone: str | None = None

@router.post("/signup")
async def signup(body: SignupBody):
    # check in-memory first for demo
    if body.email in (u.get("email") for u in store.users.values()):
        return {"ok": False, "error": "Email already exists"}
    uid = store.new_id()
    u = {"id": uid, "email": body.email, "password": body.password, "role": body.role, "phone": body.phone, "consent_comm": False}
    store.users[uid] = u
    await dao.save_user(u)
    return {"ok": True, "id": uid}

class LoginBody(BaseModel):
    email: str
    password: str

@router.post("/login")
async def login(body: LoginBody):
    for uid, u in store.users.items():
        if u["email"] == body.email and u["password"] == body.password:
            token = create_token(uid, u["role"], u["email"])
            refresh = create_refresh(uid, u["role"], u["email"])
            return {"token": token, "refresh": refresh, "user": {"id": uid, "role": u["role"], "email": u["email"]}}
    return {"ok": False, "error": "Invalid credentials"}

class RefreshBody(BaseModel):
    refresh: str

@router.post("/refresh")
def refresh_token(body: RefreshBody):
    # naive verify like access token for demo
    from ..utils.auth import verify_token
    payload = verify_token(body.refresh)
    if not payload or payload.get("typ") != "refresh":
        return {"ok": False, "error": "Invalid refresh"}
    token = create_token(payload["sub"], payload["role"], payload["email"])
    return {"token": token}

@router.get("/me")
def me(payload=Depends(auth_required)):
    return {"user": {"id": payload["sub"], "role": payload["role"], "email": payload["email"]}}
