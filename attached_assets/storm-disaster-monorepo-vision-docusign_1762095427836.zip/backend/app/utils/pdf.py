from weasyprint import HTML

def html_to_pdf_bytes(html: str) -> bytes:
    doc = HTML(string=html)
    return doc.write_pdf()
