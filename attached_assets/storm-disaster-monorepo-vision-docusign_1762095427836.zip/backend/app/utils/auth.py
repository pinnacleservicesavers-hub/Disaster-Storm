import os, time, jwt
from typing import Optional, List
from fastapi import Header, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

JWT_SECRET = os.getenv("JWT_SECRET", "dev_secret_change_me")
JWT_ISS = "storm-disaster"
JWT_AUD = "portal"
security = HTTPBearer(auto_error=False)

def create_token(sub: str, role: str, email: str, expires_in: int = 60*60*24) -> str:
    now = int(time.time())
    payload = {"iss": JWT_ISS, "aud": JWT_AUD, "sub": sub, "role": role, "email": email, "iat": now, "exp": now + expires_in}
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def create_refresh(sub: str, role: str, email: str, expires_in: int = 60*60*24*30) -> str:
    now = int(time.time())
    payload = {"iss": JWT_ISS, "aud": JWT_AUD, "sub": sub, "role": role, "email": email, "iat": now, "exp": now + expires_in, "typ":"refresh"}
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def verify_token(token: str) -> Optional[dict]:
    try:
        return jwt.decode(token, JWT_SECRET, audience=JWT_AUD, algorithms=["HS256"])
    except Exception:
        return None

def auth_required(creds: HTTPAuthorizationCredentials = Depends(security)):
    if not creds: raise HTTPException(status_code=401, detail="Missing token")
    payload = verify_token(creds.credentials)
    if not payload: raise HTTPException(status_code=401, detail="Invalid token")
    return payload

def roles_required(roles: List[str]):
    def _inner(payload: dict = Depends(auth_required)):
        if payload.get("role") not in roles:
            raise HTTPException(status_code=403, detail="Forbidden")
        return payload
    return _inner
