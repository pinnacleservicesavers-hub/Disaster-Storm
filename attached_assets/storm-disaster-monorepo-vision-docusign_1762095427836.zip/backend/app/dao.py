import os
from typing import List, Optional, Dict, Any
from .utils.store import store
from .database import USE_DB, get_session
from .models import User, Membership, Lead, Job, Invoice
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

class DAO:
    async def get_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        if not USE_DB:
            for u in store.users.values():
                if u.get("email") == email:
                    return u
            return None
        async for s in get_session():
            q = await s.execute(select(User).where(User.email==email))
            u = q.scalar_one_or_none()
            return u.__dict__ if u else None

    async def get_user_by_phone(self, phone: str) -> Optional[Dict[str, Any]]:
        if not USE_DB:
            for u in store.users.values():
                if u.get("phone") == phone:
                    return u
            return None
        async for s in get_session():
            q = await s.execute(select(User).where(User.phone==phone))
            u = q.scalar_one_or_none()
            return u.__dict__ if u else None

    async def save_user(self, user: Dict[str, Any]):
        if not USE_DB:
            store.users[user["id"]] = user
            return
        async for s in get_session():
            rec = User(id=user["id"], email=user["email"], password=user["password"],
                       role=user["role"], consent_comm=user.get("consent_comm", False),
                       phone=user.get("phone"))
            s.add(rec); await s.commit()

    async def list_leads(self) -> List[Dict[str, Any]]:
        if not USE_DB:
            return list(store.leads.values())
        async for s in get_session():
            q = await s.execute(select(Lead))
            return [dict(id=r.id, scope=r.scope, address=r.address, region=r.region, status=r.status) for r in q.scalars().all()]

    async def list_jobs(self) -> List[Dict[str, Any]]:
        if not USE_DB:
            return list(store.jobs.values())
        async for s in get_session():
            q = await s.execute(select(Job))
            return [dict(id=r.id, status=r.status, address=r.address, contractor_id=r.contractor_id, homeowner_id=r.homeowner_id) for r in q.scalars().all()]

    async def create_invoice(self, job_id: str, breakdown: Dict[str, Any], xactimate: Dict[str, Any]) -> Dict[str, Any]:
        inv = {"id": store.new_id(), "job_id": job_id, "breakdown": breakdown, "xactimate": xactimate, "status":"draft"}
        if not USE_DB:
            store.invoices[inv["id"]] = inv
            return inv
        async for s in get_session():
            rec = Invoice(id=inv["id"], job_id=job_id, breakdown=breakdown, xactimate=xactimate, status="draft")
            s.add(rec); await s.commit()
            return inv

    async def find_invoice_for_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        if not USE_DB:
            for v in store.invoices.values():
                if v["job_id"] == job_id: return v
            return None
        async for s in get_session():
            q = await s.execute(select(Invoice).where(Invoice.job_id==job_id))
            r = q.scalar_one_or_none()
            return dict(id=r.id, job_id=r.job_id, breakdown=r.breakdown, xactimate=r.xactimate, status=r.status) if r else None
dao = DAO()
