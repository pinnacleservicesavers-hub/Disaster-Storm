import os
from twilio.rest import Client

class MessagingService:
    def __init__(self, sid, token, from_number):
        self.sid = os.getenv("TWILIO_SID", sid)
        self.token = os.getenv("TWILIO_TOKEN", token)
        self.from_number = os.getenv("TWILIO_FROM", from_number)
        self.client = Client(self.sid, self.token)

    async def notify(self, user, template, context):
        # Basic SMS sender using user's phone if present and consented
        phone = user.get("phone") if isinstance(user, dict) else getattr(user, "phone", None)
        if not phone: return False
        body = self.render(template, context)
        self.client.messages.create(from_=self.from_number, to=phone, body=body)
        return True

    def render(self, template, context):
        if template == "storm_lead":
            scope = ", ".join(context.get("scopes", [])) or context.get("scope", "work")
            region = context.get("region", "your area")
            return f"Storm alert: Leads for {scope} in {region}. Log in to accept."
        return "Notification"
