import os, boto3
from botocore.client import Config

bucket = os.getenv("S3_BUCKET", "storm-disaster-dev")

def client():
    return boto3.client("s3", config=Config(signature_version="s3v4"))

def upload_bytes(key: str, data: bytes, content_type: str="application/octet-stream"):
    c = client()
    c.put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
    return f"s3://{bucket}/{key}"

def presign_url(key: str, expires_in=3600):
    c = client()
    return c.generate_presigned_url("get_object", Params={"Bucket": bucket, "Key": key}, ExpiresIn=expires_in)
