import os, boto3

region = os.getenv("REKOGNITION_REGION", os.getenv("AWS_DEFAULT_REGION","us-east-1"))
rek = boto3.client("rekognition", region_name=region)

def detect_labels_s3(bucket: str, key: str, max_labels=15, min_confidence=75):
    resp = rek.detect_labels(Image={"S3Object": {"Bucket": bucket, "Name": key}}, MaxLabels=max_labels, MinConfidence=min_confidence)
    results = []
    for lbl in resp.get("Labels", []):
        results.append({"Name": lbl["Name"], "Confidence": float(lbl.get("Confidence", 0)), "Parents": [p["Name"] for p in lbl.get("Parents", [])]})
    return results
