import os, stripe
stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")

def create_checkout_session(user_id: str, plan: str):
    price = os.getenv("STRIPE_PRICE_ONE_TIME") if plan=="one_time" else os.getenv("STRIPE_PRICE_MONTHLY")
    session = stripe.checkout.Session.create(
        mode="payment" if plan=="one_time" else "subscription",
        line_items=[{"price": price, "quantity": 1}],
        success_url="http://localhost:3000/settings?checkout=success",
        cancel_url="http://localhost:3000/settings?checkout=cancel",
        metadata={"user_id": user_id, "plan": plan},
    )
    return session

def construct_event_from_webhook(payload: bytes, sig_header: str):
    secret = os.getenv("STRIPE_WEBHOOK_SECRET", "")
    return stripe.Webhook.construct_event(payload, sig_header, secret)
