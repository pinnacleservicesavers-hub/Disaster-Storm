from fastapi import APIRouter, Request, Response
from ..utils.store import store
from ..dao import dao

router = APIRouter()

@router.post("/twilio/inbound")
async def twilio_inbound(request: Request):
    form = await request.form()
    from_num = (form.get("From") or "").strip()
    body = (form.get("Body") or "").strip().upper()

    # map phone to user
    user = None
    # check in-memory
    for u in store.users.values():
        if u.get("phone") == from_num:
            user = u; break
    # if DB enabled, try there too
    if not user:
        user = await dao.get_user_by_phone(from_num)

    if body == "STOP" and user:
        user["consent_comm"] = False
        return Response(content="<Response><Message>You are opted out. Reply START to opt in.</Message></Response>", media_type="application/xml")
    if body == "HELP":
        return Response(content="<Response><Message>Storm Disaster Alerts. Reply STOP to opt out.</Message></Response>", media_type="application/xml")
    if body == "START" and user:
        user["consent_comm"] = True
        return Response(content="<Response><Message>Opted in. You will receive alerts.</Message></Response>", media_type="application/xml")

    return Response(content="<Response></Response>", media_type="application/xml")
