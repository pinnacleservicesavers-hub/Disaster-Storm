import os, base64
from docusign_esign import ApiClient, EnvelopesApi
from docusign_esign.models import EnvelopeDefinition, Document, SignHere, Tabs, Signer, Recipients, RecipientViewRequest

INTEGRATOR_KEY = os.getenv("DOCUSIGN_INTEGRATOR_KEY", "")
ACCOUNT_ID = os.getenv("DOCUSIGN_ACCOUNT_ID", "")
USER_ID = os.getenv("DOCUSIGN_USER_ID", "")
PRIVATE_KEY_PATH = os.getenv("DOCUSIGN_PRIVATE_KEY_PATH", "")
BASE_PATH = os.getenv("DOCUSIGN_BASE_PATH", "https://demo.docusign.net/restapi")
OAUTH_BASE_PATH = os.getenv("DOCUSIGN_OAUTH_BASE_PATH", "account-d.docusign.com")
REDIRECT_URL = os.getenv("DOCUSIGN_REDIRECT_URL", "http://localhost:3000/contractor/contracts")
SCOPES = (os.getenv("DOCUSIGN_SCOPES", "signature impersonation") or "signature impersonation").split()

def _api_client_with_jwt():
    api_client = ApiClient()
    api_client.host = BASE_PATH
    private_key_bytes = None
    if PRIVATE_KEY_PATH and os.path.exists(PRIVATE_KEY_PATH):
        with open(PRIVATE_KEY_PATH, "rb") as f:
            private_key_bytes = f.read()
    else:
        raise RuntimeError("DocuSign private key not found. Set DOCUSIGN_PRIVATE_KEY_PATH.")
    # Request a JWT user token; first run may require consent URL visit by the user once
    token = api_client.request_jwt_user_token(
        client_id=INTEGRATOR_KEY,
        user_id=USER_ID,
        oauth_host_name=OAUTH_BASE_PATH,
        private_key_bytes=private_key_bytes,
        expires_in=3600,
        scopes=SCOPES
    )
    api_client.set_default_header("Authorization", f"Bearer {token.access_token}")
    return api_client

def create_envelope(contract_text: str, signer_email: str, signer_name: str):
    # Prepare the envelope with a simple text document; add an anchor "SIGN_HERE" or use tabs with absolute positioning
    api_client = _api_client_with_jwt()
    envelopes_api = EnvelopesApi(api_client)

    # Doc as base64 (DocuSign requires base64-encoded bytes)
    doc_b64 = base64.b64encode(contract_text.encode("utf-8")).decode("utf-8")
    document = Document(document_base64=doc_b64, name="Contract", file_extension="txt", document_id="1")

    sign_here = SignHere(anchor_string="SIGN_HERE", anchor_units="pixels", anchor_x_offset="0", anchor_y_offset="0")
    signer = Signer(email=signer_email, name=signer_name, recipient_id="1", routing_order="1", client_user_id="1")  # client_user_id enables embedded signing
    signer.tabs = Tabs(sign_here_tabs=[sign_here])

    envelope_definition = EnvelopeDefinition(
        email_subject="Please sign the contract",
        documents=[document],
        recipients=Recipients(signers=[signer]),
        status="sent"
    )

    envelope = envelopes_api.create_envelope(account_id=ACCOUNT_ID, envelope_definition=envelope_definition)

    # Create the recipient view (embedded signing URL)
    view_request = RecipientViewRequest(
        authentication_method="none",
        client_user_id="1",
        recipient_id="1",
        return_url=REDIRECT_URL,
        user_name=signer_name,
        email=signer_email,
    )
    view = envelopes_api.create_recipient_view(account_id=ACCOUNT_ID, envelope_id=envelope.envelope_id, recipient_view_request=view_request)
    return {"sign_url": view.url}
