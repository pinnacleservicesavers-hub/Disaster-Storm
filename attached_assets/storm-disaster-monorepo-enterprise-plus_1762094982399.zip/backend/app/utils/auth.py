import os, time, jwt
from typing import Optional

JWT_SECRET = os.getenv("JWT_SECRET", "dev_secret_change_me")
JWT_ISS = "storm-disaster"
JWT_AUD = "portal"

def create_token(sub: str, role: str, email: str, expires_in: int = 60*60*24) -> str:
    now = int(time.time())
    payload = {
        "iss": JWT_ISS, "aud": JWT_AUD, "sub": sub, "role": role, "email": email,
        "iat": now, "exp": now + expires_in
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def verify_token(token: str) -> Optional[dict]:
    try:
        return jwt.decode(token, JWT_SECRET, audience=JWT_AUD, algorithms=["HS256"])
    except Exception:
        return None
