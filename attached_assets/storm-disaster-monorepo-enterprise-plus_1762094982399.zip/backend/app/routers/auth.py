from fastapi import APIRouter, Request
from pydantic import BaseModel
from ..utils.store import store
from ..utils.auth import create_token
from ..dao import dao

router = APIRouter()

class SignupBody(BaseModel):
    email: str
    password: str
    role: str  # contractor | homeowner
    phone: str | None = None

@router.post("/signup")
async def signup(body: SignupBody):
    # check in-memory first for demo
    if body.email in (u.get("email") for u in store.users.values()):
        return {"ok": False, "error": "Email already exists"}
    uid = store.new_id()
    u = {"id": uid, "email": body.email, "password": body.password, "role": body.role, "phone": body.phone, "consent_comm": False}
    store.users[uid] = u
    await dao.save_user(u)
    return {"ok": True, "id": uid}

class LoginBody(BaseModel):
    email: str
    password: str

@router.post("/login")
async def login(body: LoginBody):
    # demo: in-memory auth
    for uid, u in store.users.items():
        if u["email"] == body.email and u["password"] == body.password:
            token = create_token(uid, u["role"], u["email"])
            return {"token": token, "user": {"id": uid, "role": u["role"], "email": u["email"]}}
    return {"ok": False, "error": "Invalid credentials"}
