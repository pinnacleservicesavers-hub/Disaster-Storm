from fastapi import APIRouter
router=APIRouter()


from fastapi import Request
from pydantic import BaseModel
from ..utils.store import store
from ..utils.security import get_ctx, require_admin

class ZipMap(BaseModel):
    # prefix_to_state: {"005": "NY", "006": "PR", ...} or {"00": "MA"} etc.
    mapping: dict

@router.get("/admin/legal/zipmap")
def get_zipmap(request: Request):
    ctx = get_ctx(request); require_admin(ctx)
    m = (store.settings.get("legal") or {}).get("zip_prefix_map", {})
    return {"count": len(m), "sample": {k:m[k] for k in list(m)[:10]}}

@router.post("/admin/legal/zipmap")
def set_zipmap(body: ZipMap, request: Request):
    ctx = get_ctx(request); require_admin(ctx)
    store.settings.setdefault("legal", {})["zip_prefix_map"] = {str(k):str(v).upper() for k,v in (body.mapping or {}).items()}
    return {"ok": True, "count": len(store.settings['legal']['zip_prefix_map'])}
