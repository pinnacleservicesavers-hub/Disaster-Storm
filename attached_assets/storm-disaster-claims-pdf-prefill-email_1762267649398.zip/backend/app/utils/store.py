
class _Store:
    def __init__(self):
        self.settings = {"claims": {"_seq": 1}, "smtp": {}}
        self.jobs = {"A1": {
            "job_id": "A1",
            "customer": {"name":"Jane Homeowner","email":"jane@example.com","phone":"555-0100","address":"123 Main St, Springfield, FL 33333"},
            "policy": {"carrier":"ABC Insurance","claim_number":"","policy_number":"","coverage":"A"},
            "invoice": [{"desc":"Tree removal","qty":1,"price":1500}],
            "notes": "Mitigate further damage; ingress/egress blocked."
        }}
store = _Store()
