
from fastapi import FastAPI
from .routers import claims, jobs

app = FastAPI()
app.include_router(claims.router)
app.include_router(jobs.router)
