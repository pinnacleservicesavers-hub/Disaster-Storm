
# Storm Disaster — Auto-Prefill, Thumbnails, Email

Run backend:
```
pip install -r backend/requirements.txt
uvicorn backend.app.main:app --reload --port 8000
```
Run frontend:
```
cd frontend
npm i
echo "NEXT_PUBLIC_API_BASE=http://localhost:8000" > .env.local
npm run dev
```

Endpoints:
- GET /jobs/{job_id}/prefill
- POST /claims/submit
- GET /claims/packet/{claim_id}.pdf
- POST /claims/email/{claim_id}?to=adjuster@carrier.com&cc=you@company.com

UI:
- /contractor/claims/submit auto-prefills on load & when Job ID changes, generates PDF, and has a one-click "Email to Carrier" link after submit.

Notes:
- PDF builder tries to inline image URLs (.png, .jpg, .jpeg, .gif, .webp). Falls back to plain link if fetch fails.
- Configure SMTP in the backend store or add an admin SMTP settings route as needed.
