import io, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from shapely import wkt
from shapely.geometry import Point, Polygon, MultiPolygon
from sqlalchemy.orm import Session
from app.models.entities import Alert, Asset, Claim

def _as_polygons(geom):
    if isinstance(geom, Polygon):
        return [geom]
    if isinstance(geom, MultiPolygon):
        return list(geom.geoms)
    return []

def _bounds(polys):
    minx=miny=1e9; maxx=maxy=-1e9
    for p in polys:
        x0,y0,x1,y1 = p.bounds
        minx=min(minx,x0); miny=min(miny,y0); maxx=max(maxx,x1); maxy=max(maxy,y1)
    return (minx, miny, maxx, maxy)

def render_claim_hazards_png(db: Session, claim_id: int) -> bytes:
    cl = db.query(Claim).filter(Claim.id==claim_id).first()
    if not cl or not cl.asset_id:
        raise ValueError("Claim or asset not found")
    asset = db.query(Asset).filter(Asset.id==cl.asset_id).first()
    if not asset:
        raise ValueError("Asset not found")

    # Gather geom polygons for active alerts intersecting the asset vicinity
    polys = []
    labels = []
    for al in db.query(Alert).all():
        if not al.geom_wkt:
            continue
        try:
            g = wkt.loads(al.geom_wkt)
        except Exception:
            continue
        for p in _as_polygons(g.buffer(0)):
            polys.append((p, al))
            labels.append(f"{al.title} [{al.source}]")

    # Setup plot
    fig, ax = plt.subplots(figsize=(6,6), dpi=150)
    # Style by source/threshold if available
    def style_for(alert):
        src = alert.source
        color = "#999999"; alpha=0.25; lw=1.0
        if src=="NWS": color="#f59e0b"  # amber
        elif src=="NHC": color="#8b5cf6"  # violet
        elif src=="MRMS":
            # parse threshold if available
            thr=None
            try:
                if alert.properties_json:
                    props=json.loads(alert.properties_json)
                    thr=props.get("threshold")
            except Exception:
                pass
            if thr is not None:
                if thr>=38.1: color="#7f1d1d"  # dark red
                elif thr>=25.4: color="#dc2626"  # red
                else: color="#fb7185"  # rose
            else:
                color="#ef4444"
        return color, alpha, lw

    # Draw polygons
    for p, al in polys:
        x,y = p.exterior.xy
        color, alpha, lw = style_for(al)
        ax.fill(x,y, color=color, alpha=alpha, linewidth=0)
        ax.plot(x,y, color=color, linewidth=lw)

    # Plot asset
    ax.plot([asset.lon],[asset.lat], marker="o", markersize=5, color="#111827")
    ax.text(asset.lon, asset.lat, f" Asset {asset.id}", fontsize=8)

    # Set bounds
    if polys:
        minx,miny,maxx,maxy = _bounds([p for p,_ in polys])
        # pad
        dx = (maxx-minx) or 0.5
        dy = (maxy-miny) or 0.5
        padx = dx*0.25; pady=dy*0.25
        ax.set_xlim(minx-padx, maxx+padx)
        ax.set_ylim(miny-pady, maxy+pady)
    else:
        ax.set_xlim(asset.lon-0.5, asset.lon+0.5)
        ax.set_ylim(asset.lat-0.5, asset.lat+0.5)

    ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude")
    ax.set_title(f"Hazard Snapshot around Asset #{asset.id}")
    ax.grid(True, linestyle=":", linewidth=0.5, alpha=0.4)
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    plt.close(fig)
    return buf.getvalue()
