from fastapi import APIRouter, Depends
from pydantic import BaseModel, EmailStr
from sqlalchemy.orm import Session
from io import BytesIO
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Attachment, Disposition, FileContent, FileName, FileType
from app.core.db import SessionLocal
from app.core.config import settings
from app.models.entities import Claim
from app.routers.reports import fnol_report

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class FNOLMail(BaseModel):
    claim_id: int
    to_email: EmailStr
    subject: str = "FNOL Report"
    message: str = "Attached is the FNOL report."

@router.post("/notify/email-fnol")
def email_fnol(body: FNOLMail, db: Session = Depends(get_db)):
    if not settings or not getattr(settings, "alert_webhook_token", None) and not getattr(settings, "twilio_account_sid", None):
        pass  # just ensure settings loads env
    # Generate PDF bytes by calling fnol_report logic
    from fastapi import Response
    res = fnol_report(body.claim_id, db)
    if isinstance(res, dict) and res.get("error"):
        return res
    pdf_bytes = res.body if hasattr(res, "body") else res
    api_key = os.getenv("SENDGRID_API_KEY")
    if not api_key:
        return {"error":"SENDGRID_API_KEY not set"}
    try:
        sg = SendGridAPIClient(api_key)
        message = Mail(
            from_email="no-reply@s3-platform.local",
            to_emails=body.to_email,
            subject=body.subject,
            html_content=body.message
        )
        att = Attachment(
            FileContent(pdf_bytes.encode("base64") if isinstance(pdf_bytes, str) else pdf_bytes),
            FileName(f"FNOL_{body.claim_id}.pdf"),
            FileType("application/pdf"),
            Disposition("attachment")
        )
        # sendgrid expects base64 string
        import base64
        att.file_content = base64.b64encode(pdf_bytes).decode()
        message.attachment = att
        resp = sg.send(message)
        return {"status":"sent", "status_code": resp.status_code}
    except Exception as e:
        return {"error": str(e)}
