from fastapi import APIRouter, Depends, Response
from sqlalchemy.orm import Session
from shapely import wkt
from shapely.geometry import Point
from io import BytesIO
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from reportlab.lib.units import inch
from datetime import datetime
from app.core.db import SessionLocal
from app.models.entities import Claim, Carrier, Asset, Alert
from app.utils.maprender import render_claim_hazards_png

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def _pdf_text(c, x, y, text, size=10, bold=False):
    c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
    c.drawString(x, y, text)

@router.get("/reports/fnol/{claim_id}")
def fnol_report(claim_id: int, db: Session = Depends(get_db)):
    cl = db.query(Claim).filter(Claim.id==claim_id).first()
    if not cl:
        return {"error": "Claim not found"}
    asset = db.query(Asset).filter(Asset.id==cl.asset_id).first()
    carrier = db.query(Carrier).filter(Carrier.id==cl.carrier_id).first()

    hazards = []
    if asset:
        pt = Point(asset.lon, asset.lat)
        for al in db.query(Alert).all():
            if not al.geom_wkt:
                continue
            try:
                g = wkt.loads(al.geom_wkt)
                if g.buffer(0).intersects(pt):
                    hazards.append(al)
            except Exception:
                continue

    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=LETTER)
    w, h = LETTER
    y = h - 1*inch
    _pdf_text(c, 1*inch, y, "First Notice of Loss (FNOL) — Strategic Service Savers", 14, True); y -= 0.3*inch
    _pdf_text(c, 1*inch, y, f"Generated: {datetime.utcnow().isoformat()}Z"); y -= 0.25*inch
    _pdf_text(c, 1*inch, y, "Claim Information", 12, True); y -= 0.25*inch
    _pdf_text(c, 1*inch, y, f"Claim ID: {cl.id} | Policy: {cl.policy_number or '-'} | Status: {cl.status}"); y -= 0.2*inch
    _pdf_text(c, 1*inch, y, f"Carrier: {(carrier.name if carrier else '-') }"); y -= 0.2*inch

    _pdf_text(c, 1*inch, y, "Asset", 12, True); y -= 0.25*inch
    if asset:
        _pdf_text(c, 1*inch, y, f"Asset ID: {asset.id} — {asset.name}"); y -= 0.2*inch
        _pdf_text(c, 1*inch, y, f"Location: {asset.lat:.4f}, {asset.lon:.4f}"); y -= 0.2*inch
    else:
        _pdf_text(c, 1*inch, y, "No asset linked."); y -= 0.2*inch

    _pdf_text(c, 1*inch, y, "Map Snapshot", 12, True); y -= 0.25*inch
    try:
        img_bytes = render_claim_hazards_png(db, cl.id)
        img = ImageReader(io.BytesIO(img_bytes))
        c.drawImage(img, 1*inch, y-3.5*inch, width=4.5*inch, height=4.0*inch, preserveAspectRatio=True, mask='auto')
        y -= 4.25*inch
    except Exception as e:
        _pdf_text(c, 1*inch, y, f"(Map unavailable: {str(e)[:60]})"); y -= 0.2*inch
    _pdf_text(c, 1*inch, y, "Intersecting Hazards", 12, True); y -= 0.25*inch
    if not hazards:
        _pdf_text(c, 1*inch, y, "None"); y -= 0.2*inch
    else:
        for al in hazards[:12]:
            _pdf_text(c, 1*inch, y, f"- {al.title} [{al.source}] severity={al.severity}"); y -= 0.18*inch
            if y < 1*inch:
                c.showPage(); y = h - 1*inch

    c.showPage(); c.save()
    pdf_bytes = buf.getvalue()
    buf.close()
    return Response(content=pdf_bytes, media_type="application/pdf")
