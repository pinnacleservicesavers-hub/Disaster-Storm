
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from ..utils.store import store
from ..utils.security import get_ctx

router = APIRouter()

class LineItem(BaseModel):
    desc: str
    qty: float = 1
    price: float = 0

class MediaItem(BaseModel):
    url: str
    type: str = Field(default="photo", description="photo|video|drone|satellite")

class PolicyInfo(BaseModel):
    carrier: str
    claim_number: Optional[str] = None
    policy_number: Optional[str] = None
    coverage: Optional[str] = None  # A/B/etc

class CustomerInfo(BaseModel):
    name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    address: str

class ClaimSubmission(BaseModel):
    job_id: str
    invoice_items: List[LineItem]
    invoice_total: float
    notes: Optional[str] = None
    media: List[MediaItem] = []
    story: Optional[str] = None
    comparables_summary: Optional[str] = None
    xactimate_summary: Optional[str] = None
    rebuttal_points: Optional[str] = None
    weather_summary: Optional[str] = None  # hail size, wind speed, event category, etc.
    policy: PolicyInfo
    customer: CustomerInfo
    aob_present: bool = True

@router.post("/claims/submit")
def submit_claim(body: ClaimSubmission, request: Request):
    ctx = get_ctx(request)
    # Minimal validation
    if not body.invoice_items or body.invoice_total <= 0:
        raise HTTPException(status_code=400, detail="Invoice required")
    # Save to in-memory store
    claims = store.settings.setdefault("claims", {})
    seq = claims.get("_seq", 1)
    claim_id = f"C{seq:06d}"
    claims["_seq"] = seq + 1
    claims[claim_id] = {
        "id": claim_id,
        "job_id": body.job_id,
        "contractor_id": ctx.get("user_id"),
        "payload": body.dict(),
        "status": "submitted",
        "history": [{"ts": __import__('datetime').datetime.utcnow().isoformat(), "event": "submitted"}]
    }
    return {"ok": True, "claim_id": claim_id, "status": "submitted"}

@router.get("/claims/status/{claim_id}")
def claim_status(claim_id: str, request: Request):
    claims = store.settings.get("claims", {})
    c = claims.get(claim_id)
    if not c: raise HTTPException(status_code=404, detail="Not found")
    return {"id": c["id"], "status": c["status"], "history": c.get("history", [])}
