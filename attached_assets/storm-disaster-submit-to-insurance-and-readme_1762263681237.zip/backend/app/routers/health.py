
from fastapi import APIRouter, Request
from ..utils.store import store
from ..utils.security import _verify_with_jwks, _parse_unverified

router = APIRouter()

@router.get("/health/auth")
def health_auth(request: Request, token: str | None = None):
    cfg = store.settings.get("oidc") or {}
    issuer = cfg.get("issuer")
    audience = cfg.get("audience")
    jwks = cfg.get("jwks")
    meta = cfg.get("jwks_meta") or {}
    enforce = bool(cfg.get("enforce", False))

    if not token:
        authz = request.headers.get("Authorization") or request.headers.get("authorization") or ""
        if authz.lower().startswith("bearer "):
            token = authz.split(" ",1)[1].strip()

    verified = None
    unverified = None
    err = None
    if token:
        try:
            unverified = _parse_unverified(token).get("payload")
            verified = _verify_with_jwks(token)
        except Exception as e:
            err = str(e)

    return {
        "issuer": issuer,
        "audience": audience,
        "jwks_loaded": bool(jwks),
        "jwks_keys": len((jwks or {}).get("keys", [])) if jwks else 0,
        "jwks_meta": meta,
        "enforce": enforce,
        "token": {
            "provided": bool(token),
            "unverified": unverified,
            "verified_ok": verified is not None,
            "error": err
        }
    }

@router.get("/health/jobs")
def health_jobs():
    return store.jobs
