
# Simple in-memory store for demo/dev
class _Store:
    def __init__(self):
        self.settings = {}
        self.jobs = {
            "workers": [
                {"name": "smtp-sender", "status": "ok", "last_error": None, "errors": 0},
                {"name": "report-builder", "status": "ok", "last_error": None, "errors": 0},
            ]
        }
store = _Store()
