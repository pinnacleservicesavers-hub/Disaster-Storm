
"use client";
import { useEffect, useRef } from 'react';
import { api } from '@/lib/api';
import { showToast } from '@/lib/toast';

export default function JobsHealthWatcher(){
  const prevErrors = useRef<Record<string, number>>({});
  useEffect(()=>{
    const poll = async()=>{
      try{
        const j = await api('/health/jobs');
        const list = (j?.workers || []) as Array<{name:string;errors?:number;last_error?:string}>;
        list.forEach(w => {
          const before = prevErrors.current[w.name] || 0;
          const now = Number(w.errors || 0);
          if (now > before){
            showToast(`Job "${w.name}" reported an error`, 'error');
          }
          prevErrors.current[w.name] = now;
        });
      }catch{ /* ignore */ }
    };
    poll();
    const id = setInterval(poll, 60000);
    return ()=> clearInterval(id);
  },[]);
  return null;
}
