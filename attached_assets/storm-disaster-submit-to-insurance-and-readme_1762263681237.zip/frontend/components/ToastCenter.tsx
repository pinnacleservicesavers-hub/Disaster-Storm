
"use client";
import { useEffect, useState } from 'react';
import { onToast, type Toast } from '@/lib/toast';

export default function ToastCenter(){
  const [items, setItems] = useState<Toast[]>([]);
  useEffect(()=>{
    const off = onToast((t)=>{
      setItems(prev => [...prev, t]);
      const to = setTimeout(()=>{ setItems(prev => prev.filter(x => x.id !== t.id)); }, t.timeout ?? 3500);
      return ()=>clearTimeout(to);
    });
    return off;
  },[]);
  if(items.length === 0) return null;
  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-2 w-[90%] sm:w-auto">
      {items.map(t => (
        <div key={t.id} className={`px-4 py-2 rounded shadow-lg text-sm text-white ${t.type==='error' ? 'bg-red-600' : (t.type==='success' ? 'bg-green-600' : 'bg-black')}`}>{t.message}</div>
      ))}
    </div>
  );
}
