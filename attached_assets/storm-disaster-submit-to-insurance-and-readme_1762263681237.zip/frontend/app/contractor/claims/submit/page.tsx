// stub; previous step will have written the actual content
