
"use client";
import { useState } from 'react';
import { api } from '@/lib/api';

export default function JobA1(){
  const [items, setItems] = useState([{ desc: 'Tree removal', qty: 1, price: 1500 }]);
  const [notes, setNotes] = useState('Mitigate further damage per policy, ingress/egress blocked.');
  const total = items.reduce((s, it)=> s + (Number(it.qty)||0)*(Number(it.price)||0), 0);

  const add = ()=> setItems([...items, { desc: '', qty: 1, price: 0 }]);
  const update = (i: number, key: 'desc'|'qty'|'price', val: any)=>{
    const next = [...items]; (next[i] as any)[key] = key==='desc' ? val : Number(val||0); setItems(next);
  };
  const submit = async()=>{
    await api('/contractor/jobs/A1/invoice', {
      method: 'POST',
      body: JSON.stringify({ items, notes, total }),
      toastSuccess: 'Invoice submitted',
      toastError: 'Invoice submit failed'
    });
  };

  return (
    <main className="p-8 max-w-3xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold">Job A1 — Invoice</h1>
      <div className="space-y-2">
        {items.map((it, i)=> (
          <div key={i} className="grid grid-cols-5 gap-2">
            <input className="border p-2 col-span-3" placeholder="Description" value={it.desc} onChange={e=>update(i,'desc',e.target.value)} />
            <input className="border p-2" type="number" value={it.qty} onChange={e=>update(i,'qty',e.target.value)} />
            <input className="border p-2" type="number" value={it.price} onChange={e=>update(i,'price',e.target.value)} />
          </div>
        ))}
        <button className="px-3 py-1 border rounded" onClick={add}>Add line</button>
      </div>
      <label className="text-sm block">Notes<textarea className="border p-2 w-full h-24" value={notes} onChange={e=>setNotes(e.target.value)} /></label>
      <div className="text-right text-lg font-semibold">Total: ${total.toFixed(2)}</div>
      <button className="px-4 py-2 border rounded" onClick={submit}>Submit Invoice</button>
    </main>
  );
}
