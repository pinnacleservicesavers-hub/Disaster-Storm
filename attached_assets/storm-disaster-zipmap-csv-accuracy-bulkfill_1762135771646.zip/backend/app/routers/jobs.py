
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from ..utils.store import store
from ..utils.security import get_ctx, require_job_access

router = APIRouter()

class NewJob(BaseModel):
    job_id: str
    contractor_id: str
    zip: str | None = None
    state: str | None = None
    address: dict | None = None
    location: dict | None = None
    contract: dict | None = None

@router.post("/jobs")
def create_job(payload: NewJob, request: Request):
    ctx = get_ctx(request)
    if ctx.get("role") != "admin" and payload.contractor_id != ctx.get("user_id"):
        raise HTTPException(status_code=403, detail="Contractors can only create their own jobs")
    job = {
        "contractor_id": payload.contractor_id,
        "zip": payload.zip,
        "state": (payload.state or "").upper() if payload.state else None,
        "address": payload.address or {},
        "location": payload.location or {},
        "contract": payload.contract or {},
        "reminders": [],
        "letters": [],
        "timeline": []
    }
    store.jobs[payload.job_id] = job
    return {"ok": True, "job_id": payload.job_id, "job": job}

@router.post("/jobs/{job_id}/state")
def set_job_state(job_id: str, state: str, request: Request):
    job = store.jobs.setdefault(job_id, {})
    ctx = get_ctx(request); require_job_access(ctx, job)
    job["state"] = (state or "").upper()
    store.jobs[job_id] = job
    return {"ok": True, "job_id": job_id, "state": job["state"]}


@router.post("/jobs/{job_id}/duplicate")
def duplicate_job(job_id: str, new_job_id: str, request: Request):
    ctx = get_ctx(request)
    job = store.jobs.get(job_id)
    if not job:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Source job not found")
    # Access check on source job
    require_job_access(ctx, job)
    new_job = {
        "contractor_id": job.get("contractor_id"),
        "zip": job.get("zip"),
        "state": job.get("state"),
        "address": dict(job.get("address") or {}),
        "location": dict(job.get("location") or {}),
        "contract": dict(job.get("contract") or {}),
        "reminders": [],   # fresh
        "letters": [],     # fresh
        "timeline": [{"job_id": new_job_id, "kind":"note", "message": f"Duplicated from {job_id}", "when": (datetime.utcnow().isoformat())}],
    }
    store.jobs[new_job_id] = new_job
    return {"ok": True, "job_id": new_job_id, "job": new_job}
