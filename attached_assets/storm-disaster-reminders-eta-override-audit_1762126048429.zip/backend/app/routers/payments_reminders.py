from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store
from datetime import datetime, timedelta
import smtplib, ssl, os
from email.message import EmailMessage

router = APIRouter()

TEMPLATES = {
    "gentle": {
        "subject": "Friendly reminder — invoice for Job {job_id}",
        "body": "Hi, this is a friendly reminder that the invoice for Job {job_id} is ready for payment. Please use the link provided or contact us with any questions."
    },
    "firm": {
        "subject": "Second notice — invoice for Job {job_id}",
        "body": "This is a second notice regarding payment for Job {job_id}. Please arrange payment. If you've already paid, thank you—no further action is needed."
    },
    "final": {
        "subject": "Final notice — invoice for Job {job_id}",
        "body": "Final notice for Job {job_id}. If payment is not received promptly, further action may be taken in accordance with the contract and applicable law."
    }
}

ESCALATION_ORDER = ["gentle", "firm", "final"]

def _org_days(level: str) -> int:
    cfg = (store.settings.get("reminders") or {}).get("cadence", {})
    return int(cfg.get(f"{level}_days", 7 if level != "gentle" else 3))

def _job_days(job: dict, level: str) -> int | None:
    meta = job.get("reminders_meta") or {}
    cad = meta.get("cadence") or {}
    if f"{level}_days" in cad:
        try:
            return int(cad[f"{level}_days"])
        except Exception:
            return None
    return None

def _next_level(level: str | None) -> str | None:
    try:
        idx = ESCALATION_ORDER.index(level or "gentle")
        return ESCALATION_ORDER[idx+1] if idx + 1 < len(ESCALATION_ORDER) else None
    except ValueError:
        return None

def _send_email(smtp_host, smtp_port, smtp_user, smtp_pass, to_list, subject, text):
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = smtp_user or "no-reply@stormdisaster.local"
    msg["To"] = ", ".join(to_list)
    msg.set_content(text)
    try:
        ctx = ssl.create_default_context()
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls(context=ctx)
            if smtp_user: server.login(smtp_user, smtp_pass)
            server.send_message(msg)
        return True, None
    except Exception as e:
        return False, str(e)

class ScheduleBody(BaseModel):
    job_id: str
    to_emails: list[str]
    message: str | None = None
    first_in_days: int | None = None
    repeat_days: int | None = None
    level: str | None = None  # gentle|firm|final

@router.post("/payments/reminders/schedule")
def schedule_reminder(body: ScheduleBody):
    job = store.jobs.setdefault(body.job_id, {})
    reminders = job.setdefault("reminders", [])
    level = (body.level or "gentle")
    # determine when to send first reminder
    job_first_days = _job_days(job, level)
    first_days = body.first_in_days if body.first_in_days is not None else (job_first_days if job_first_days is not None else _org_days(level))
    due_at = (datetime.utcnow() + timedelta(days=first_days)).isoformat()
    item = {
        "id": store.new_id(),
        "to_emails": body.to_emails,
        "message": (body.message or TEMPLATES[level]["body"].format(job_id=body.job_id)),
        "subject": TEMPLATES[level]["subject"].format(job_id=body.job_id),
        "due_at": due_at,
        "repeat_days": body.repeat_days,  # fallback if no escalation
        "status": "scheduled",
        "level": level
    }
    reminders.append(item)
    job.setdefault("timeline", []).append({
        "job_id": body.job_id, "kind":"note",
        "message": f"Payment reminder ({level}) scheduled for {due_at}",
        "when": datetime.utcnow().isoformat()
    })
    store.jobs[body.job_id] = job
    return {"ok": True, "reminder": item}

class OverrideCadence(BaseModel):
    job_id: str
    gentle_days: int | None = None
    firm_days: int | None = None
    final_days: int | None = None

@router.post("/payments/reminders/override_cadence")
def override_cadence(body: OverrideCadence):
    job = store.jobs.setdefault(body.job_id, {})
    meta = job.setdefault("reminders_meta", {})
    cad = meta.setdefault("cadence", {})
    for k in ["gentle_days","firm_days","final_days"]:
        v = getattr(body, k)
        if v is not None: cad[k] = int(v)
    store.jobs[body.job_id] = job
    return {"ok": True, "cadence": cad}

@router.get("/payments/reminders/override_cadence/{job_id}")
def get_override(job_id: str):
    job = store.jobs.get(job_id, {})
    cad = (job.get("reminders_meta") or {}).get("cadence", {})
    return {"cadence": {
        "gentle_days": cad.get("gentle_days"),
        "firm_days": cad.get("firm_days"),
        "final_days": cad.get("final_days"),
    }}

@router.get("/payments/reminders/audit/{job_id}")
def audit(job_id: str):
    job = store.jobs.get(job_id, {})
    return {"audit": job.get("reminder_audit", [])}

@router.post("/payments/reminders/run")
def run_reminders():
    now = datetime.utcnow().isoformat()
    processed = []
    for job_id, job in store.jobs.items():
        # Skip paid or paused
        if (job.get("payments") or {}).get("status") == "paid":
            continue
        if (job.get("reminders_meta") or {}).get("paused"):
            continue
        for r in job.get("reminders", []):
            if r["status"] == "scheduled" and r["due_at"] <= now:
                subject = r.get("subject") or TEMPLATES.get(r.get("level") or "gentle", TEMPLATES["gentle"])["subject"].format(job_id=job_id)
                text = r.get("message") or TEMPLATES.get(r.get("level") or "gentle", TEMPLATES["gentle"])["body"].format(job_id=job_id)
                ok, err = _send_email(
                    os.getenv("SMTP_HOST","smtp.example.com"),
                    int(os.getenv("SMTP_PORT","587")),
                    os.getenv("SMTP_USER","user@example.com"),
                    os.getenv("SMTP_PASS","pass"),
                    r["to_emails"],
                    subject,
                    text
                )
                status = "sent" if ok else f"error:{err}"
                r["status"] = status
                # audit trail
                entry = {
                    "id": r["id"],
                    "when": datetime.utcnow().isoformat(),
                    "to": r["to_emails"],
                    "subject": subject,
                    "status": status
                }
                job.setdefault("reminder_audit", []).append(entry)
                job.setdefault("timeline", []).append({
                    "job_id": job_id, "kind":"note",
                    "message": f"Reminder {r['id']} ({r.get('level')}) {status}",
                    "when": entry["when"]
                })
                processed.append({"job_id": job_id, "reminder_id": r["id"], "status": status, "level": r.get("level")})
                # Next due (escalate if possible)
                nxt = _next_level(r.get("level"))
                if nxt:
                    # Determine days for next level (job override > org)
                    days = _job_days(job, nxt) or _org_days(nxt)
                    due = (datetime.utcnow() + timedelta(days=days)).isoformat()
                    job.setdefault("reminders", []).append({
                        "id": store.new_id(),
                        "to_emails": r["to_emails"],
                        "message": TEMPLATES[nxt]["body"].format(job_id=job_id),
                        "subject": TEMPLATES[nxt]["subject"].format(job_id=job_id),
                        "due_at": due,
                        "repeat_days": None,
                        "status": "scheduled",
                        "level": nxt
                    })
                elif r.get("repeat_days"):
                    # Reschedule same level if repeat_days set
                    due = (datetime.utcnow() + timedelta(days=int(r["repeat_days"]))).isoformat()
                    r["due_at"] = due
                    r["status"] = "scheduled"
        store.jobs[job_id] = job
    return {"processed": processed}

@router.get("/admin/reminders/next")
def admin_next():
    """Compute next due_at across all jobs (unpaid & not paused)"""
    next_due = None
    count_scheduled = 0
    sample = []
    for job_id, job in store.jobs.items():
        if (job.get("payments") or {}).get("status") == "paid":
            continue
        if (job.get("reminders_meta") or {}).get("paused"):
            continue
        for r in job.get("reminders", []):
            if r["status"] == "scheduled":
                count_scheduled += 1
                if next_due is None or r["due_at"] < next_due:
                    next_due = r["due_at"]
                sample.append({"job_id": job_id, "level": r.get("level"), "due_at": r["due_at"]})
    # Show the soonest 5 items
    sample_sorted = sorted(sample, key=lambda x: x["due_at"])[:5]
    return {"next_due_at": next_due, "scheduled_count": count_scheduled, "soonest": sample_sorted}
