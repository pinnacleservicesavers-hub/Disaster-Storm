"use client";
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import CadenceEditor from './cadence';

export default function AdminCenter(){
  const [nextInfo, setNextInfo] = useState<any>();
  useEffect(()=>{ api('/admin/reminders/next').then(setNextInfo).catch(()=>{}); },[]);

  return (
    <main className="p-8 max-w-6xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Admin Command Center</h1>

      <section className="grid grid-cols-3 gap-4">
        <div className="border rounded p-4">
          <div className="text-sm text-gray-600">Next reminder ETA</div>
          <div className="text-lg font-semibold">{nextInfo?.next_due_at || '—'}</div>
          <div className="text-xs text-gray-500">{nextInfo?.scheduled_count || 0} scheduled</div>
        </div>
        <div className="border rounded p-4 col-span-2">
          <div className="text-sm font-semibold mb-2">Soonest reminders</div>
          <div className="border rounded">
            {nextInfo?.soonest?.length ? nextInfo.soonest.map((s:any)=> (
              <div key={s.job_id + s.due_at} className="p-2 border-b flex justify-between">
                <div>Job {s.job_id} — {s.level}</div>
                <div>{s.due_at}</div>
              </div>
            )) : <div className="p-2 text-sm text-gray-500">No scheduled reminders</div>}
          </div>
        </div>
      </section>

      <CadenceEditor />
    </main>
  );
}
