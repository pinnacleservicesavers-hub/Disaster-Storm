# Strategic Service Savers (S3) — Disaster Intelligence Platform

A production-ready **starter scaffold** to build a platform that rivals (and extends) insurer-grade hazard intelligence.
This repo focuses on **ingesting public hazard feeds**, **normalizing to GeoJSON**, **intersecting with assets/contractors**,
and **pushing alerts/webhooks**. It is designed for **Replit** (FastAPI + SQLite) and can be migrated to Postgres later.

## Features (in this scaffold)
- FastAPI backend with modular routers
- Ingestors for:
  - NWS / NOAA Weather Alerts (polygons)
  - NHC Hurricane cone & forecast tracks
  - USGS Earthquakes (GeoJSON)
  - NASA FIRMS wildfire hotspots
- Normalization to GeoJSON + geometry using Shapely (WKT storage for SQLite)
- Scheduler (APScheduler) for periodic pulls
- Simple rules engine for geofence intersection + alert creation
- Webhooks + Twilio/SMS integration placeholders
- Leaflet web UI to visualize layers & active alerts
- Audit log for every alert decision

## Install
Create a new **Replit (Python)** project, then copy these files or upload the ZIP.

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Open the web view at `https://<your-repl>`. The map loads from `/`.

## .env (example)
Copy `.env.example` to `.env` and fill values:

```
# Optional Twilio (for SMS alerts)
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_FROM=

# Webhook secret for outbound calls (your downstream service that receives alerts)
ALERT_WEBHOOK_URL=
ALERT_WEBHOOK_TOKEN=dev-token

# NWS / USGS / NHC / FIRMS endpoints are public; you can add keys for paid vendors later.
```

## Useful Endpoints (once running)
- `GET /api/health` — service health
- `GET /api/alerts` — current active alerts (from ingested feeds)
- `GET /api/contractors` — list your contractors (sample data included)
- `POST /api/contractors` — add a contractor `{ name, lat, lon, phone }`
- `GET /api/assets` — list assets (properties) (sample data included)
- `POST /api/assets` — add asset `{ name, lat, lon, ref_id }`
- `POST /api/ingest/run` — on-demand ingestion
- `POST /api/rules/evaluate` — run rules on current data
- `GET /ui` — JSON describing UI layers for the Leaflet map

## Roadmap (beyond this scaffold)
- Paid feeds: Lightning networks, hail/wind footprints, property granularity
- Portfolio accumulation & capacity analytics
- Moratorium verification automation
- Historical peril analytics & FNOL attachments (PDF generator)
- SOC 2 controls, HA, observability (OTEL), queuing (Redis/RabbitMQ/Kafka)
- Multi-tenant auth, RBAC, and audit exports

---

**Note:** This scaffold demonstrates structure and working code for public feeds. Vendor integrations slot into `app/datasources/vendors/`.
