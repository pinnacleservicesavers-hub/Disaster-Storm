
"use client";
import { useState } from 'react';
import { api, API_BASE } from '@/lib/api';

type Item = { desc: string; qty: number; price: number };
type Media = { url: string; type: string };

export default function SubmitClaim(){
  const [jobId, setJobId] = useState('A1');
  const [items, setItems] = useState<Item[]>([{ desc: 'Tree removal', qty: 1, price: 1500 }]);
  const [notes, setNotes] = useState('Mitigate further damage; ingress/egress blocked.');
  const [story, setStory] = useState('Wind gusts snapped oak limb; impact damaged roof, fence, and blocked ingress/egress.');
  const [comparables, setComparables] = useState('Apples-to-apples: 12 crew hours; crane + chipper; local rates attached.');
  const [xact, setXact] = useState('Xactimate: Line items X, Y, Z; variance explained.');
  const [rebuttal, setRebuttal] = useState('Policy requires indemnification to pre-loss; safety mitigation was necessary.');
  const [weather, setWeather] = useState('Peak gust 72 mph; hail 1.25"; NWS event ID 12345; radar cell path attached.');
  const [media, setMedia] = useState<Media[]>([{ url: 'https://example.com/photo1.jpg', type: 'photo' }]);
  const [carrier, setCarrier] = useState('ABC Insurance');
  const [claimNumber, setClaimNumber] = useState('');
  const [policyNumber, setPolicyNumber] = useState('');
  const [coverage, setCoverage] = useState('A');
  const [custName, setCustName] = useState('Jane Homeowner');
  const [custEmail, setCustEmail] = useState('jane@example.com');
  const [custPhone, setCustPhone] = useState('555-0100');
  const [custAddress, setCustAddress] = useState('123 Main St, Springfield, FL 33333');
  const [aob, setAob] = useState(true);
  const [claimId, setClaimId] = useState<string | null>(null);
  const total = items.reduce((s, it)=> s + (it.qty||0)*(it.price||0), 0);

  const addItem = ()=> setItems(prev=> [...prev, { desc: '', qty: 1, price: 0 }]);
  const setItem = (i:number, key: keyof Item, val: any)=>{
    const next = [...items]; (next[i] as any)[key] = key==='desc' ? val : Number(val||0); setItems(next);
  };

  const prefill = async()=>{
    const j = await api(`/jobs/${encodeURIComponent(jobId)}/prefill`);
    if(j){
      setItems(j.invoice_items || []);
      setNotes(j.notes || '');
      if(j.customer){ setCustName(j.customer.name||''); setCustEmail(j.customer.email||''); setCustPhone(j.customer.phone||''); setCustAddress(j.customer.address||''); }
      if(j.policy){ setCarrier(j.policy.carrier||''); setClaimNumber(j.policy.claim_number||''); setPolicyNumber(j.policy.policy_number||''); setCoverage(j.policy.coverage||'A'); }
    }
  };

  const submit = async()=>{
    const r = await api('/claims/submit', {
      method: 'POST',
      body: JSON.stringify({
        job_id: jobId,
        invoice_items: items,
        invoice_total: total,
        notes,
        media,
        story,
        comparables_summary: comparables,
        xactimate_summary: xact,
        rebuttal_points: rebuttal,
        weather_summary: weather,
        policy: { carrier, claim_number: claimNumber, policy_number: policyNumber, coverage },
        customer: { name: custName, email: custEmail, phone: custPhone, address: custAddress },
        aob_present: aob
      })
    });
    if(r?.claim_id){ setClaimId(r.claim_id); }
  };

  const downloadPdf = ()=>{
    if(!claimId) return;
    const url = `${API_BASE}/claims/packet/${encodeURIComponent(claimId)}.pdf`;
    const a = document.createElement('a'); a.href = url; a.target = '_blank'; a.rel='noreferrer'; a.click();
  };

  return (
    <main className="p-8 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Submit to Insurance</h1>
      <section className="border rounded p-3 space-y-2">
        <div className="grid sm:grid-cols-3 gap-2 items-center">
          <label className="text-sm">Job ID<input className="border p-2 w-full" value={jobId} onChange={e=>setJobId(e.target.value)} /></label>
          <label className="text-sm inline-flex items-center gap-2"><input type="checkbox" checked={aob} onChange={e=>setAob(e.target.checked)} /> AOB in contract</label>
          <button className="px-3 py-1 border rounded" onClick={prefill}>Prefill from Job</button>
        </div>
      </section>

      <section className="border rounded p-3 space-y-2">
        <div className="font-semibold">Invoice</div>
        {items.map((it, i)=> (
          <div key={i} className="grid grid-cols-6 gap-2">
            <input className="border p-2 col-span-3" placeholder="Description" value={it.desc} onChange={e=>setItem(i,'desc',e.target.value)} />
            <input className="border p-2" type="number" value={it.qty} onChange={e=>setItem(i,'qty',e.target.value)} />
            <input className="border p-2" type="number" value={it.price} onChange={e=>setItem(i,'price',e.target.value)} />
            <div className="p-2 text-right">${(it.qty*it.price).toFixed(2)}</div>
          </div>
        ))}
        <button className="px-3 py-1 border rounded" onClick={addItem}>Add line</button>
        <div className="text-right font-semibold">Total: ${total.toFixed(2)}</div>
        <label className="text-sm block">Notes<textarea className="border p-2 w-full h-20" value={notes} onChange={e=>setNotes(e.target.value)} /></label>
      </section>

      <section className="border rounded p-3 grid sm:grid-cols-2 gap-2">
        <label className="text-sm">Story<textarea className="border p-2 w-full h-28" value={story} onChange={e=>setStory(e.target.value)} /></label>
        <label className="text-sm">Rebuttal points<textarea className="border p-2 w-full h-28" value={rebuttal} onChange={e=>setRebuttal(e.target.value)} /></label>
        <label className="text-sm">Comparables (apples-to-apples)<textarea className="border p-2 w-full h-28" value={comparables} onChange={e=>setComparables(e.target.value)} /></label>
        <label className="text-sm">Xactimate summary<textarea className="border p-2 w-full h-28" value={xact} onChange={e=>setXact(e.target.value)} /></label>
        <label className="text-sm sm:col-span-2">Weather summary<textarea className="border p-2 w-full h-28" value={weather} onChange={e=>setWeather(e.target.value)} /></label>
      </section>

      <section className="border rounded p-3 grid sm:grid-cols-2 gap-2">
        <div>
          <div className="font-semibold mb-1">Customer</div>
          <label className="text-sm block">Name<input className="border p-2 w-full" value={custName} onChange={e=>setCustName(e.target.value)} /></label>
          <label className="text-sm block">Email<input className="border p-2 w-full" value={custEmail} onChange={e=>setCustEmail(e.target.value)} /></label>
          <label className="text-sm block">Phone<input className="border p-2 w-full" value={custPhone} onChange={e=>setCustPhone(e.target.value)} /></label>
          <label className="text-sm block">Address<input className="border p-2 w-full" value={custAddress} onChange={e=>setCustAddress(e.target.value)} /></label>
        </div>
        <div>
          <div className="font-semibold mb-1">Insurance</div>
          <label className="text-sm block">Carrier<input className="border p-2 w-full" value={carrier} onChange={e=>setCarrier(e.target.value)} /></label>
          <label className="text-sm block">Claim #<input className="border p-2 w-full" value={claimNumber} onChange={e=>setClaimNumber(e.target.value)} /></label>
          <label className="text-sm block">Policy #<input className="border p-2 w-full" value={policyNumber} onChange={e=>setPolicyNumber(e.target.value)} /></label>
          <label className="text-sm block">Coverage<select className="border p-2 w-full" value={coverage} onChange={e=>setCoverage(e.target.value)}><option>A</option><option>B</option></select></label>
        </div>
      </section>

      <div className="flex items-center justify-end gap-2">
        <button className="px-4 py-2 border rounded" onClick={submit}>Submit to insurance</button>
        {claimId && <button className="px-4 py-2 border rounded" onClick={downloadPdf}>Download PDF Packet</button>}
      </div>
    </main>
  );
}
