
# Storm Disaster — Claims Prefill + PDF Packet

## Run
Backend:
```
pip install -r backend/requirements.txt
uvicorn backend.app.main:app --reload --port 8000
```
Frontend:
```
cd frontend
npm i
echo "NEXT_PUBLIC_API_BASE=http://localhost:8000" > .env.local
npm run dev
```

## Endpoints
- `GET /jobs/{job_id}/prefill` → returns customer/policy/invoice/notes
- `POST /claims/submit` → returns `{ claim_id }`
- `GET /claims/packet/{claim_id}.pdf` → generated PDF

## UI
- `/contractor/claims/submit` → Prefill from Job, submit, then download PDF packet.
