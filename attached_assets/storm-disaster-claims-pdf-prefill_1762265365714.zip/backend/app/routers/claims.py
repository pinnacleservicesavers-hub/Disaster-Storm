
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
from ..utils.store import store
from ..utils.security import get_ctx

router = APIRouter()

class LineItem(BaseModel):
    desc: str
    qty: float = 1
    price: float = 0

class MediaItem(BaseModel):
    url: str
    type: str = Field(default="photo")

class PolicyInfo(BaseModel):
    carrier: str
    claim_number: Optional[str] = None
    policy_number: Optional[str] = None
    coverage: Optional[str] = None

class CustomerInfo(BaseModel):
    name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    address: str

class ClaimSubmission(BaseModel):
    job_id: str
    invoice_items: List[LineItem]
    invoice_total: float
    notes: Optional[str] = None
    media: List[MediaItem] = []
    story: Optional[str] = None
    comparables_summary: Optional[str] = None
    xactimate_summary: Optional[str] = None
    rebuttal_points: Optional[str] = None
    weather_summary: Optional[str] = None
    policy: PolicyInfo
    customer: CustomerInfo
    aob_present: bool = True

@router.post("/claims/submit")
def submit_claim(body: ClaimSubmission, request: Request):
    ctx = get_ctx(request)
    if not body.invoice_items or body.invoice_total <= 0:
        raise HTTPException(status_code=400, detail="Invoice required")
    claims = store.settings.setdefault("claims", {})
    seq = claims.get("_seq", 1)
    claim_id = f"C{seq:06d}"
    claims["_seq"] = seq + 1
    claims[claim_id] = {
        "id": claim_id,
        "job_id": body.job_id,
        "contractor_id": ctx.get("user_id"),
        "payload": body.dict(),
        "status": "submitted",
        "history": [{"ts": __import__('datetime').datetime.utcnow().isoformat(), "event": "submitted"}]
    }
    return {"ok": True, "claim_id": claim_id, "status": "submitted"}

@router.get("/claims/status/{claim_id}")
def claim_status(claim_id: str, request: Request):
    claims = store.settings.get("claims", {})
    c = claims.get(claim_id)
    if not c: raise HTTPException(status_code=404, detail="Not found")
    return {"id": c["id"], "status": c["status"], "history": c.get("history", [])}

from reportlab.lib.pagesizes import LETTER
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from fastapi.responses import StreamingResponse
import io

@router.get("/claims/packet/{claim_id}.pdf")
def claim_packet_pdf(claim_id: str):
    claims = store.settings.get("claims", {})
    c = claims.get(claim_id)
    if not c: raise HTTPException(status_code=404, detail="Claim not found")
    p = c["payload"]
    buf = io.BytesIO()
    can = canvas.Canvas(buf, pagesize=LETTER)
    w, h = LETTER
    y = h - 1*inch
    def line(txt):
        nonlocal y
        can.drawString(1*inch, y, txt[:1000]); y -= 14
        if y < 1*inch:
            can.showPage(); y = h - 1*inch
    can.setFont("Helvetica-Bold", 14); line(f"Claim Packet — {claim_id}")
    can.setFont("Helvetica", 10)
    line(f"Job: {p.get('job_id')}  | Contractor: {c.get('contractor_id')}  | AOB: {p.get('aob_present')}")
    cust = p.get('customer',{}); pol = p.get('policy',{})
    line(f"Customer: {cust.get('name')}  {cust.get('email')}  {cust.get('phone')}")
    line(f"Address: {cust.get('address')}")
    line(f"Carrier: {pol.get('carrier')}  Claim#: {pol.get('claim_number')}  Policy#: {pol.get('policy_number')}  Coverage: {pol.get('coverage')}")
    line('')
    line('Invoice:')
    total = 0.0
    for it in p.get('invoice_items') or []:
        amt = float(it.get('qty',0))*float(it.get('price',0)); total += amt
        line(f"  - {it.get('desc')}  qty {it.get('qty')}  ${it.get('price')}  line ${amt:.2f}")
    line(f"Total: ${total:.2f}")
    if p.get('notes'): line(f"Notes: {p.get('notes')}")
    for k in ['story','weather_summary','comparables_summary','xactimate_summary','rebuttal_points']:
        if p.get(k): line(f"{k.replace('_',' ').title()}: {p.get(k)}")
    m = p.get('media') or []
    if m:
        line('Media:')
        for i, mitem in enumerate(m, start=1):
            line(f"  [{i}] {mitem.get('type')}: {mitem.get('url')}")
    can.showPage(); can.save()
    buf.seek(0)
    return StreamingResponse(buf, media_type='application/pdf', headers={'Content-Disposition': f'inline; filename=claim_{claim_id}.pdf'})
