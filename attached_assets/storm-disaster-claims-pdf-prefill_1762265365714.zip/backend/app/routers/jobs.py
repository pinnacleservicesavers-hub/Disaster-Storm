
from fastapi import APIRouter, HTTPException
from ..utils.store import store

router = APIRouter()

@router.get("/jobs/{job_id}/prefill")
def prefill(job_id: str):
    job = (store.jobs or {}).get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return {
        "job_id": job["job_id"],
        "customer": job["customer"],
        "policy": job["policy"],
        "invoice_items": job.get("invoice", []),
        "notes": job.get("notes","")
    }
