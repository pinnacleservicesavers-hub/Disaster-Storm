
from fastapi import FastAPI
from .routers import jobs, claims

app = FastAPI()
app.include_router(jobs.router)
app.include_router(claims.router)
