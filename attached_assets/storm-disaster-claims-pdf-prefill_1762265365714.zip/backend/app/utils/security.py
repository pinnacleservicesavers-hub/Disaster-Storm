
from fastapi import Request

def get_ctx(request: Request):
    # Demo context from headers
    return {
        "user_id": request.headers.get("X-User-Id", "demo-contractor"),
        "role": request.headers.get("X-User-Role", "contractor")
    }
