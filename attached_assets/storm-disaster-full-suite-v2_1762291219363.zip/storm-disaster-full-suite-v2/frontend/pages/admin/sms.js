import { useState } from "react";
const API = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";

export default function SMSAdmin() {
  const [to, setTo] = useState("");
  const [fromNum, setFromNum] = useState("");
  const [body, setBody] = useState("Claim submitted for Job A1.");
  const [status, setStatus] = useState("");

  const send = async () => {
    const res = await fetch(`${API}/hooks/sms/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ to, body, from_number: fromNum || undefined }),
    });
    const json = await res.json();
    setStatus(json.status || json.detail || JSON.stringify(json));
  };

  return (
    <div style={{ padding: 24 }}>
      <h2>SMS (Twilio)</h2>
      <p>Set server env: <code>TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM</code>.</p>
      <div style={{ display: "grid", gap: 8, maxWidth: 420 }}>
        <input placeholder="To (+1...)" value={to} onChange={e=>setTo(e.target.value)} />
        <input placeholder="From (optional overrides TWILIO_FROM)" value={fromNum} onChange={e=>setFromNum(e.target.value)} />
        <textarea rows={4} value={body} onChange={e=>setBody(e.target.value)} />
        <button onClick={send}>Send Test SMS</button>
        <div style={{ fontStyle: "italic" }}>{status}</div>
      </div>
    </div>
  );
}
