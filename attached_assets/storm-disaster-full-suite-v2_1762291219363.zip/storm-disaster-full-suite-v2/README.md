# Storm Disaster Full Suite (v2)

Adds:
- **Preloaded state lien/notice windows** (TX, FL, GA, NC, SC) with optional *counsel-approved* toggle via API.
- **SMS via Twilio** (`POST /hooks/sms/send`) — set `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM` on server.
- **Improved photo-damage heuristic** using filename keywords + simple image color hints (Pillow).

## Run
### Backend
```bash
cd backend
pip install -r requirements.txt
# set Twilio env if using SMS:
# export TWILIO_ACCOUNT_SID=ACxxxx
# export TWILIO_AUTH_TOKEN=xxxx
# export TWILIO_FROM=+15551234567
uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm i
echo "NEXT_PUBLIC_API_BASE=http://localhost:8000" > .env.local
npm run dev
```

## New/Updated Endpoints
- `GET /legal/preload/states`
- `POST /legal/preload/apply?mark_counsel_approved={true|false}`
- `POST /hooks/sms/send` (body: `{ "to": "+1...", "body": "text", "from_number": "+1..."? }`)
- `POST /hooks/photo/label` (now uses Pillow for simple image feature hints)

---
*Preload deadlines are illustrative — consult counsel for final, state-specific compliance.*
