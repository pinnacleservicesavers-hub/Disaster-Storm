from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import csv, io, os, json, smtplib, ssl, pathlib, datetime
from email.message import EmailMessage
from PIL import Image
import numpy as np

# Optional PDF generation with reportlab (installed via requirements)
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas

# Twilio (optional)
from twilio.rest import Client as TwilioClient

BASE_DIR = pathlib.Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

SMTP_FILE = DATA_DIR / "smtp.json"
CARRIERS_FILE = DATA_DIR / "carriers.json"
LEGAL_FILE = DATA_DIR / "legal.json"
PRELOAD_LEGAL_FILE = DATA_DIR / "preload_legal.json"

def read_json(path: pathlib.Path, default):
    if not path.exists():
        return default
    try:
        with open(path, "r") as f:
            return json.load(f)
    except Exception:
        return default

def write_json(path: pathlib.Path, payload):
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)

app = FastAPI(title="Storm Disaster Suite API (v2)", version="0.2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class SMTPSettings(BaseModel):
    host: str
    port: int
    username: str
    password: str
    from_email: str

@app.get("/health")
def health():
    return {"ok": True, "ts": datetime.datetime.utcnow().isoformat()}

# --- SMTP Settings ---
@app.get("/admin/settings/smtp")
def get_smtp():
    return read_json(SMTP_FILE, {})

@app.post("/admin/settings/smtp")
def set_smtp(settings: SMTPSettings):
    write_json(SMTP_FILE, settings.model_dump())
    return {"status": "saved"}

# --- Carriers Admin ---
@app.get("/admin/carriers")
def list_carriers():
    return read_json(CARRIERS_FILE, {"carriers": []})

class Carrier(BaseModel):
    name: str
    inbox_email: str
    portal_url: Optional[str] = None
    state_notes: Optional[Dict[str, str]] = None

@app.post("/admin/carriers")
def upsert_carrier(carrier: Carrier):
    db = read_json(CARRIERS_FILE, {"carriers": []})
    existing = [c for c in db["carriers"] if c["name"].lower() == carrier.name.lower()]
    if existing:
        idx = db["carriers"].index(existing[0])
        db["carriers"][idx] = carrier.model_dump()
    else:
        db["carriers"].append(carrier.model_dump())
    write_json(CARRIERS_FILE, db)
    return {"status": "ok", "carriers": db["carriers"]}

# --- Legal Guardrails ---
@app.get("/legal/state/{state}")
def get_legal_state(state: str):
    state = state.upper()
    db = read_json(LEGAL_FILE, {})
    return db.get(state, {"state": state, "deadlines": {}, "notes": "", "counsel_approved": False})

class LegalUpsert(BaseModel):
    state: str
    deadlines: Dict[str, str] = {}
    notes: str = ""
    counsel_approved: bool = False

@app.post("/legal/upsert")
def legal_upsert(payload: LegalUpsert):
    db = read_json(LEGAL_FILE, {})
    db[payload.state.upper()] = {
        "state": payload.state.upper(),
        "deadlines": payload.deadlines,
        "notes": payload.notes,
        "counsel_approved": payload.counsel_approved,
    }
    write_json(LEGAL_FILE, db)
    return {"status": "ok", "state": payload.state.upper()}

@app.get("/legal/preload/states")
def legal_preload_states():
    pre = read_json(PRELOAD_LEGAL_FILE, {})
    return {"states": list(pre.keys())}

@app.post("/legal/preload/apply")
def legal_preload_apply(states: Optional[List[str]] = None, mark_counsel_approved: bool = False):
    pre = read_json(PRELOAD_LEGAL_FILE, {})
    if not pre:
        raise HTTPException(status_code=404, detail="No preload dataset found.")
    db = read_json(LEGAL_FILE, {})
    target_states = states or list(pre.keys())
    for s in target_states:
        if s in pre:
            entry = pre[s]
            if mark_counsel_approved:
                entry["counsel_approved"] = True
            db[s] = entry
    write_json(LEGAL_FILE, db)
    return {"status": "ok", "applied": target_states, "counsel_approved": mark_counsel_approved}

# --- Invoice Import ---
@app.post("/invoice/import")
async def import_invoice(file: UploadFile = File(...)):
    content = await file.read()
    try:
        items = []
        with io.StringIO(content.decode("utf-8")) as s:
            reader = csv.DictReader(s)
            for row in reader:
                desc = row.get("desc") or row.get("description") or ""
                qty = float(row.get("qty", "1") or 1)
                price = float(row.get("price", "0") or 0)
                items.append({"desc": desc, "qty": qty, "price": price, "total": qty * price})
        return {"items": items, "count": len(items), "sum": sum(i["total"] for i in items)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid CSV: {e}")

# --- Xactimate Compare + Narrative ---
@app.post("/xactimate/compare")
async def xactimate_compare(file: UploadFile = File(...)):
    content = await file.read()
    try:
        x_items = []
        with io.StringIO(content.decode("utf-8")) as s:
            reader = csv.DictReader(s)
            for row in reader:
                desc = (row.get("desc") or row.get("description") or "").strip()
                qty = float(row.get("qty", "1") or 1)
                price = float(row.get("price", "0") or 0)
                x_items.append({"desc": desc, "qty": qty, "price": price, "total": qty * price})
        contractor_total = sum(i["total"] for i in x_items) * 1.15
        x_total = sum(i["total"] for i in x_items)
        variance = contractor_total - x_total
        pct = (variance / x_total * 100) if x_total else 0.0
        narrative = (
            f"Based on line-item review, contractor pricing reflects current market rates, "
            f"supply constraints, and scope-specific labor. Xactimate subtotal ${x_total:,.2f} "
            f"understates fair market replacement cost by ${variance:,.2f} ({pct:.1f}%). "
            f"Adjustments requested accordingly."
        )
        return {"xactimate_total": x_total, "contractor_total_est": contractor_total, "variance": variance, "variance_pct": pct, "narrative": narrative}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid CSV: {e}")

# --- Claim Packet PDF + Autopost ---
class ClaimPayload(BaseModel):
    job_id: str
    carrier_name: Optional[str] = None
    homeowner: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    summary: Optional[str] = None

def generate_pdf(payload: ClaimPayload, path: pathlib.Path):
    c = canvas.Canvas(str(path), pagesize=LETTER)
    width, height = LETTER
    y = height - 72
    c.setFont("Helvetica-Bold", 14)
    c.drawString(72, y, "Storm Disaster Claim Packet")
    y -= 24
    c.setFont("Helvetica", 11)
    for line in [
        f"Job ID: {payload.job_id}",
        f"Carrier: {payload.carrier_name or ''}",
        f"Homeowner: {payload.homeowner or ''}",
        f"Address: {payload.address or ''}",
        f"Phone: {payload.phone or ''}",
        f"Email: {payload.email or ''}",
        f"Summary: {payload.summary or ''}",
    ]:
        c.drawString(72, y, line)
        y -= 18
    y -= 12
    c.setFont("Helvetica-Oblique", 10)
    c.drawString(72, y, f"Generated: {datetime.datetime.utcnow().isoformat()}Z")
    c.showPage()
    c.save()

@app.post("/claims/packet")
def create_claim_packet(payload: ClaimPayload):
    out = DATA_DIR / f"claim_packet_{payload.job_id}.pdf"
    generate_pdf(payload, out)
    return {"status": "ok", "pdf_path": str(out)}

class AutoPost(BaseModel):
    job_id: str
    carrier_email: str
    subject: Optional[str] = "New Claim Packet"
    body: Optional[str] = "Please find the attached claim packet."

@app.post("/claims/autopost")
def autopost_to_carrier(data: AutoPost):
    smtp_cfg = read_json(SMTP_FILE, None)
    if not smtp_cfg:
        raise HTTPException(status_code=400, detail="SMTP not configured")
    pdf_path = DATA_DIR / f"claim_packet_{data.job_id}.pdf"
    if not pdf_path.exists():
        raise HTTPException(status_code=404, detail="Claim packet not found. Create it first.")
    msg = EmailMessage()
    msg["From"] = smtp_cfg["from_email"]
    msg["To"] = data.carrier_email
    msg["Subject"] = data.subject or "New Claim Packet"
    msg.set_content(data.body or "Please find the attached claim packet.")
    with open(pdf_path, "rb") as f:
        msg.add_attachment(f.read(), maintype="application", subtype="pdf", filename=pdf_path.name)
    try:
        context = ssl.create_default_context()
        with smtplib.SMTP(smtp_cfg["host"], int(smtp_cfg["port"])) as server:
            server.starttls(context=context)
            server.login(smtp_cfg["username"], smtp_cfg["password"])
            server.send_message(msg)
        return {"status": "sent", "to": data.carrier_email}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"SMTP error: {e}")

# --- SMS (Twilio) ---
class SMSPayload(BaseModel):
    to: str
    body: str
    from_number: Optional[str] = None

@app.post("/hooks/sms/send")
def sms_send(payload: SMSPayload):
    sid = os.getenv("TWILIO_ACCOUNT_SID")
    token = os.getenv("TWILIO_AUTH_TOKEN")
    default_from = os.getenv("TWILIO_FROM")
    if not (sid and token and (payload.from_number or default_from)):
        raise HTTPException(status_code=400, detail="Missing Twilio credentials or from number.")
    client = TwilioClient(sid, token)
    try:
        msg = client.messages.create(
            to=payload.to,
            from_=payload.from_number or default_from,
            body=payload.body
        )
        return {"status": "sent", "sid": msg.sid}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Twilio error: {e}")

# --- Photo-damage heuristic ---
KEYWORDS = {
    "roof": "roof-damage",
    "shingle": "roof-damage",
    "gutters": "gutter-damage",
    "soffit": "soffit-damage",
    "siding": "siding-damage",
    "water": "water-damage",
    "leak": "water-damage",
    "ceiling": "interior-ceiling",
    "drywall": "interior-drywall",
    "window": "fenestration",
}

def simple_image_hint(img: Image.Image) -> str:
    # crude color heuristic: water-ish (blue-ish), mold/drywall (beige), roof (gray/dark)
    arr = np.array(img.resize((64, 64))).astype("float32")
    mean = arr.mean(axis=(0,1))  # RGB means
    r,g,b = mean
    if b > r + 20 and b > g + 20:
        return "water-damage"
    if r > g + 15 and g > b and r > 150:
        return "interior-drywall"
    if max(r,g,b) < 90:
        return "roof-damage"
    return "general-damage"

@app.post("/hooks/photo/label")
async def photo_label(file: UploadFile = File(...)):
    name = (file.filename or "").lower()
    for k, v in KEYWORDS.items():
        if k in name:
            return {"label": v, "confidence": 0.7, "source": "filename"}
    try:
        content = await file.read()
        img = Image.open(io.BytesIO(content)).convert("RGB")
        hint = simple_image_hint(img)
        return {"label": hint, "confidence": 0.6, "source": "image_heuristic"}
    except Exception:
        return {"label": "general-damage", "confidence": 0.4, "source": "fallback"}
