import os

def create_invoice_checkout(amount_cents: int, job_id: str) -> str:
    """Create a Stripe Checkout Session (scaffold). Returns URL or placeholder."""
    try:
        import stripe
        stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")
        price_id = os.getenv("STRIPE_PRICE_INVOICE")  # optional: pre-created price
        if price_id:
            session = stripe.checkout.Session.create(
                mode="payment",
                line_items=[{"price": price_id, "quantity": 1}],
                success_url=os.getenv("STRIPE_SUCCESS_URL","http://localhost:3000/success"),
                cancel_url=os.getenv("STRIPE_CANCEL_URL","http://localhost:3000/cancel"),
                metadata={"job_id": job_id}
            )
            return session.url
        else:
            # ad-hoc amount using price_data
            session = stripe.checkout.Session.create(
                mode="payment",
                line_items=[{
                    "price_data": {
                        "currency": os.getenv("STRIPE_CURRENCY","usd"),
                        "unit_amount": amount_cents,
                        "product_data": {"name": f"Job {job_id} Invoice"}
                    },
                    "quantity": 1
                }],
                success_url=os.getenv("STRIPE_SUCCESS_URL","http://localhost:3000/success"),
                cancel_url=os.getenv("STRIPE_CANCEL_URL","http://localhost:3000/cancel"),
                metadata={"job_id": job_id}
            )
            return session.url
    except Exception:
        # fallback for dev
        return f"https://checkout.stripe.dev/pay/demo?amount_cents={amount_cents}&job_id={job_id}"
