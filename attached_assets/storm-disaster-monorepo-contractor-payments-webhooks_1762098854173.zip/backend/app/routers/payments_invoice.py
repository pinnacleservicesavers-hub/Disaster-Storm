from fastapi import APIRouter, Request, Header
from pydantic import BaseModel
from ..utils.store import store
from ..services.stripe_svc import create_invoice_checkout
import os, json

router = APIRouter()

class PayLinkBody(BaseModel):
    job_id: str

@router.post("/payments/invoice/checkout")
def invoice_checkout(body: PayLinkBody):
    job = store.jobs.get(body.job_id, {})
    inv = next((v for v in store.invoices.values() if v.get("job_id")==body.job_id), None)
    total = 0.0
    if inv:
        for v in inv.get("breakdown", {}).values():
            try: total += float(v)
            except: pass
    from ..services.stripe_svc import create_invoice_checkout
    url = create_invoice_checkout(int(total*100), body.job_id)
    job.setdefault("payments", {})["checkout_url"] = url
    job["payments"]["status"] = job.get("payments", {}).get("status", "unpaid")
    store.jobs[body.job_id] = job
    return {"checkout_url": url, "total": total, "status": job["payments"]["status"]}

class HostedInvoiceBody(BaseModel):
    job_id: str
    customer_email: str

@router.post("/payments/invoice/hosted")
def hosted_invoice(body: HostedInvoiceBody):
    # Creates a Stripe Customer + Invoice + InvoiceItem, finalizes, returns hosted_invoice_url (scaffold)
    try:
        import stripe, os
        stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")
        job = store.jobs.get(body.job_id, {})
        inv = next((v for v in store.invoices.values() if v.get("job_id")==body.job_id), None) or {"breakdown":{}}
        total = 0.0
        for v in inv.get("breakdown", {}).values():
            try: total += float(v)
            except: pass
        # Create or reuse customer
        cust = stripe.Customer.create(email=body.customer_email)
        # Create draft invoice + single invoice item
        stripe.InvoiceItem.create(customer=cust.id, amount=int(total*100), currency=os.getenv("STRIPE_CURRENCY","usd"), description=f"Job {body.job_id} Invoice")
        inv_obj = stripe.Invoice.create(customer=cust.id, collection_method="send_invoice", days_until_due=7, metadata={"job_id": body.job_id})
        inv_obj = stripe.Invoice.finalize_invoice(inv_obj.id)
        hosted = inv_obj.hosted_invoice_url
        job.setdefault("payments", {})["hosted_invoice_url"] = hosted
        store.jobs[body.job_id] = job
        return {"hosted_invoice_url": hosted, "total": total}
    except Exception as e:
        return {"ok": False, "error": str(e)}

@router.post("/payments/stripe/webhook")
async def stripe_webhook(request: Request, stripe_signature: str = Header(None)):
    payload = await request.body()
    wh_secret = os.getenv("STRIPE_WEBHOOK_SECRET")
    event = None
    try:
        import stripe
        stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")
        if wh_secret:
            event = stripe.Webhook.construct_event(payload, stripe_signature, wh_secret)
        else:
            event = json.loads(payload)
    except Exception as e:
        return {"ok": False, "error": f"Webhook error: {e}"}

    etype = event.get("type") if isinstance(event, dict) else getattr(event, "type", "")
    data = event.get("data", {}).get("object", {}) if isinstance(event, dict) else event.data.object

    job_id = None
    if etype == "checkout.session.completed":
        job_id = (data.get("metadata") or {}).get("job_id")
    elif etype in ("invoice.paid", "invoice.payment_succeeded"):
        job_id = (data.get("metadata") or {}).get("job_id")
        if not job_id and data.get("lines"):
            job_id = (data["lines"]["data"][0].get("metadata") or {}).get("job_id")

    if job_id:
        job = store.jobs.get(job_id, {})
        job.setdefault("payments", {})["status"] = "paid"
        store.jobs[job_id] = job

    return {"ok": True, "type": etype, "job_id": job_id}
