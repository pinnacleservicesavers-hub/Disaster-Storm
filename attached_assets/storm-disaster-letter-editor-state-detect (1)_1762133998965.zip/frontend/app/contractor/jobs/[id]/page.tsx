"use client";
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { api, API_BASE } from '@/lib/api';
import { useToast } from '@/app/admin/command-center/toast';

export default function JobDetail(){
  const id = (useParams().id as string) || 'A1';
  const [rem, setRem] = useState<any>({paused:false, reminders:[]});
  const load = async()=> setRem(await api(`/payments/reminders/list/${id}`));
  useEffect(()=>{ load(); },[]);
  const push = (msg:string)=>{ try{ (window as any).__toaster?.(msg); }catch(e){} };
  return (
    <main className="p-8 space-y-4">
      <h1 className="text-2xl font-semibold">Job {id}</h1>
      <div className="border rounded p-3 space-y-2">
        <div className="flex items-center gap-3">
          <div className={rem.paused?'text-red-600':'text-green-700'}>Reminders: {rem.paused ? 'Paused' : 'Active'}</div>
          <button onClick={async()=>{ await api(`/payments/reminders/${rem.paused?'resume':'pause'}/${id}`, { method:'POST' }); load(); }} className="px-3 py-1 rounded border">{rem.paused?'Resume':'Pause'}</button>
        </div>
        <div className="text-sm text-gray-600">Scheduled reminders</div>
        <div className="border rounded">{rem.reminders.map((r:any)=>(<div key={r.id} className="p-2 border-b flex justify-between"><div>{r.level} — {r.status}</div><div>due {r.due_at}</div></div>))}</div>
        <div className="mt-3 border-t pt-3">
          <div className="font-semibold text-sm">Schedule a reminder</div>
          <div className="flex flex-col md:flex-row gap-2 text-sm mt-2">
            <input id="schedEmails" className="border p-2 flex-1" placeholder="to emails (comma separated)" />
            <select id="schedLevel" className="border p-2">
              <option value="gentle">gentle</option>
              <option value="firm">firm</option>
              <option value="final">final</option>
            </select>
            <input id="schedFirst" className="border p-2 w-28" placeholder="first in (days)" />
            <button className="px-3 py-2 border rounded" onClick={async()=>{
              const to = (document.getElementById('schedEmails') as HTMLInputElement).value.split(',').map(x=>x.trim()).filter(Boolean);
              const level = (document.getElementById('schedLevel') as HTMLSelectElement).value;
              const first = parseInt((document.getElementById('schedFirst') as HTMLInputElement).value||'3',10);
              try{
                await api('/payments/reminders/schedule', { method:'POST', body: JSON.stringify({ job_id: id, to_emails: to, level, first_in_days: first }) });
                push('Reminder scheduled'); load();
              }catch(e){ push('Failed to schedule'); }
            }}>Schedule</button>
          </div>
        </div>
        <div className="text-right">
          <a className="underline text-sm" target="_blank" href={`${API_BASE}/payments/reminders/audit/${id}/csv`} onClick={()=>{ try{ (window as any).__toaster?.('Downloading CSV…'); }catch(e){} }}>Export audit CSV</a>
        
        <div className="mt-3 border-t pt-3">
          <div className="font-semibold text-sm">Letters</div>
          <div className="text-xs text-gray-500">(Letters auto-generate a 1-page PDF.)</div>
          <div className="flex flex-wrap items-center gap-2 text-sm mt-2">
            <button className="px-3 py-2 border rounded" onClick={async()=>{
              try{
                await api('/letters/schedule', { method:'POST', body: JSON.stringify({ job_id: id, kind:'late', to_emails: ['insured@example.com'], days_from_now: 1 }) });
                try{ (window as any).__toaster?.('Late letter scheduled'); }catch(e){}
              }catch(e){ try{ (window as any).__toaster?.('Failed to schedule late letter'); }catch(e){} }
            }}>Schedule Late Letter (+1 day)</button>
            <button className="px-3 py-2 border rounded" onClick={async()=>{
              try{
                await api('/letters/schedule', { method:'POST', body: JSON.stringify({ job_id: id, kind:'demand', to_emails: ['insured@example.com'], days_from_now: 60 }) });
                try{ (window as any).__toaster?.('Demand letter scheduled (+60d)'); }catch(e){}
              }catch(e){ try{ (window as any).__toaster?.('Failed to schedule demand letter'); }catch(e){} }
            }}>Schedule Demand Letter (+60 days)</button>
          </div>
        </div>

      </div>
    
      <section className="border rounded p-3 space-y-2">
        <h2 className="font-semibold">Letters</h2>
        {letters.length ? <div className="border rounded">
          {letters.map((L:any)=>(
            <div key={L.id} className="p-2 border-b flex items-center justify-between gap-3">
              <div className="text-sm">
                <div className="font-medium">{L.kind} — {L.status}</div>
                <div className="text-xs text-gray-600">Due: {L.due_at}</div>
              </div>
              <div className="flex items-center gap-2">
                <a className="underline text-sm" target="_blank" href={`${API_BASE}/letters/${id}/${L.id}.pdf`} onClick={()=>push('Generating PDF…')}>Download PDF</a>
              </div>
            </div>
          ))}
        </div> : <div className="text-sm text-gray-500">No letters yet.</div>}
      </section>

    
      <section className="border rounded p-3 space-y-2">
        <div className="font-semibold">State detection</div>
        <div className="text-sm text-gray-600">Zip: {stateGuess?.zip || '—'} | Detected: <span className="font-mono">{stateGuess?.guessed_state || '—'}</span> (confidence {Math.round((stateGuess?.confidence||0)*100)}%)</div>
        <div className="flex items-center gap-2 text-sm">
          <label>State</label>
          <input className="border p-2 w-24" value={stateVal} onChange={e=>setStateVal(e.target.value.toUpperCase())} placeholder="FL" />
          <button className="px-3 py-1 border rounded" onClick={async()=>{ try{ await api(`/jobs/${id}/state?state=${encodeURIComponent(stateVal)}`, { method:'POST' }); push?.('State saved'); }catch(e){ push?.('Failed to save state'); } }}>Save</button>
          <button className="px-3 py-1 border rounded" onClick={()=>detect()}>Re-detect</button>
        </div>
        <div className="text-xs text-gray-500">Letters will merge state boilerplate and citations when scheduled.</div>
      </section>

    
      <section className="border rounded p-3 space-y-2 mt-4">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">Letters</h2>
          <button className="px-3 py-1 border rounded text-sm" onClick={load}>Refresh</button>
        </div>
        {letters.length ? <div className="border rounded">
          {letters.map((L:any)=>(
            <div key={L.id} className="p-2 border-b grid grid-cols-1 md:grid-cols-3 gap-2 items-center">
              <div className="text-sm">
                <div className="font-medium">{L.kind} — {L.status}</div>
                <div className="text-xs text-gray-600">Due: {L.due_at}</div>
              </div>
              <div className="text-xs line-clamp-2">{L.subject}</div>
              <div className="flex items-center gap-2 justify-end">
                <a className="underline text-sm" target="_blank" href={`${API_BASE}/letters/${id}/${L.id}.pdf`} onClick={()=>push?.('Generating PDF…')}>Download PDF</a>
                <button className="px-2 py-1 border rounded text-sm" onClick={()=>{ setEditLetter(L); setEditSubject(L.subject||''); setEditBody(L.body||''); setEditorOpen(true); }}>Edit & Send</button>
              </div>
            </div>
          ))}
        </div> : <div className="text-sm text-gray-500">No letters yet.</div>}
      </section>

      {editorOpen && <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded p-4 w-full max-w-2xl space-y-3">
          <div className="text-lg font-semibold">Edit letter</div>
          <input className="border p-2 w-full" value={editSubject} onChange={e=>setEditSubject(e.target.value)} placeholder="Subject" />
          <textarea className="border p-2 w-full h-64" value={editBody} onChange={e=>setEditBody(e.target.value)} placeholder="Body (plain text)"></textarea>
          <div className="flex items-center justify-end gap-2">
            <button className="px-3 py-1 border rounded" onClick={()=>setEditorOpen(false)}>Cancel</button>
            <button className="px-3 py-1 border rounded" onClick={async()=>{ try{ await api(`/letters/${id}/${editLetter.id}`, { method:'PATCH', body: JSON.stringify({ subject: editSubject, body: editBody }) }); push?.('Letter saved'); setEditorOpen(false); load(); }catch(e){ push?.('Failed to save'); } }}>Save</button>
            <button className="px-3 py-1 border rounded" onClick={async()=>{ try{ await api('/letters/send_now', { method:'POST', body: JSON.stringify({ job_id: id, letter_id: editLetter.id }) }); push?.('Queued to send'); await api('/letters/run', { method:'POST' }); push?.('Sent (check timeline)'); setEditorOpen(false); load(); }catch(e){ push?.('Failed to send'); } }}>Send Now</button>
          </div>
        </div>
      </div>}

    </main>
  );
}
