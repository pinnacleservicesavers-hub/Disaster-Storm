
from fastapi import Request, HTTPException

def get_ctx(request: Request):
    role = request.headers.get("X-User-Role", "").lower() or "contractor"
    user_id = request.headers.get("X-User-Id", "") or "demo-contractor"
    from fastapi import Request
    return {"role": role, "user_id": user_id, "scopes": [s.strip() for s in (request.headers.get('X-Scopes','') or '').split(',') if s.strip()] }

def require_admin(ctx):
    if ctx.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

def require_job_access(ctx, job: dict):
    # Admins can always access; contractors only their own jobs
    if ctx.get("role") == "admin":
        return
    if job and job.get("contractor_id") == ctx.get("user_id"):
        return
    raise HTTPException(status_code=403, detail="Not allowed for this job")


def get_scopes(request):
    scopes = request.headers.get("X-Scopes", "") or ""
    return [s.strip() for s in scopes.split(",") if s.strip()]

def require_scope(ctx, scopes: list[str] | tuple[str, ...]):
    # Admins bypass scope checks
    if ctx.get("role") == "admin":
        return
    have = set(ctx.get("scopes") or [])
    need = set(scopes)
    if not need.issubset(have):
        from fastapi import HTTPException
        raise HTTPException(status_code=403, detail=f"Missing scope(s): {', '.join(sorted(need-have))}")
