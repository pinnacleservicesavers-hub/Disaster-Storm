
# Minimal single-page text PDF generator (no external deps).
# Not for complex layouts; good enough for letter text.

from datetime import datetime

def _escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")

def make_pdf(title: str, body: str) -> bytes:
    # Basic Helvetica 12pt; simple text wrapping at ~90 chars/line
    # Page size: 612x792 (US Letter). Margin ~72.
    width, height = 612, 792
    lines = []
    for para in (body or "").split("\n"):
        if not para:
            lines.append("")
            continue
        while len(para) > 90:
            cut = para.rfind(" ", 0, 90)
            if cut < 40: cut = 90
            lines.append(para[:cut])
            para = para[cut:].lstrip()
        lines.append(para)

    y = height - 72
    content_lines = []
    # Title
    content_lines.append("BT /F1 18 Tf 72 {} Td ({}) Tj ET".format(int(y), _escape(title or "Letter")))
    y -= 30
    # Date
    date_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    content_lines.append("BT /F1 10 Tf 72 {} Td (Generated: {}) Tj ET".format(int(y), _escape(date_str)))
    y -= 24
    # Body
    for ln in lines:
        if y < 72:
            break  # simple single-page
        content_lines.append("BT /F1 12 Tf 72 {} Td ({}) Tj ET".format(int(y), _escape(ln)))
        y -= 14

    stream = "\n".join(content_lines).encode("latin-1", "ignore")
    xref = []
    pdf = b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"
    def w(obj):
        pos = len(pdf)
        xref.append(pos)
        return pos
    objs = []

    # 1: Catalog
    w1 = w(pdf); pdf += b"1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n"
    # 2: Pages
    w2 = w(pdf); pdf += b"2 0 obj << /Type /Pages /Count 1 /Kids [3 0 R] >> endobj\n"
    # 3: Page
    w3 = w(pdf); pdf += f"3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 {width} {height}] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >> endobj\n".encode()
    # 4: Contents
    w4 = w(pdf)
    pdf += b"4 0 obj << /Length " + str(len(stream)).encode() + b" >> stream\n" + stream + b"\nendstream endobj\n"
    # 5: Font
    w5 = w(pdf); pdf += b"5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\n"

    xref_pos = len(pdf)
    pdf += b"xref\n0 6\n0000000000 65535 f \n"
    for off in [w1, w2, w3, w4, w5]:
        pdf += f"{off:010d} 00000 n \n".encode()
    pdf += b"trailer << /Size 6 /Root 1 0 R >>\nstartxref\n"
    pdf += str(xref_pos).encode() + b"\n%%EOF"
    return pdf
