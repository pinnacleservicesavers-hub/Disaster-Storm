
from fastapi import APIRouter, Request
from pydantic import BaseModel, Field
from ..utils.store import store
from ..utils.security import get_ctx, require_admin, require_job_access
from datetime import datetime, timedelta
import smtplib, ssl, os
from email.message import EmailMessage

router = APIRouter()

class LetterSchedule(BaseModel):
    job_id: str
    kind: str = Field(..., description="late|demand")
    to_emails: list[str]
    days_from_now: int = 0

TEMPLATES = {
    "late": {
        "subject": "Late notice — Job {job_id} per signed agreement",
        "body": "This is a friendly late notice for Job {job_id}. As agreed in the binding contract, payment is due upon completion. Please remit payment to avoid further steps."
    },
    "demand": {
        "subject": "60-day demand — Job {job_id}",
        "body": "This is a demand letter for Job {job_id}. Per the contract and applicable state law, we request payment in full. Failure to remit may result in a lien and further action. If already paid, thank you—please disregard."
    }
}

def _send_email(smtp_host,smtp_port,smtp_user,smtp_pass,to_list,subject,text):
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = smtp_user or "no-reply@stormdisaster.local"
    msg["To"] = ", ".join(to_list)
    msg.set_content(text)
    try:
        ctx = ssl.create_default_context()
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls(context=ctx)
            if smtp_user: server.login(smtp_user, smtp_pass)
            server.send_message(msg)
        return True, None
    except Exception as e:
        return False, str(e)

@router.post("/letters/schedule")
def schedule_letter(body: LetterSchedule, request: Request):
    job = store.jobs.setdefault(body.job_id, {})
    ctx = get_ctx(request)
    require_job_access(ctx, job)
    due_at = (datetime.utcnow() + timedelta(days=int(body.days_from_now))).isoformat()
    composed = _compose_body(body.job_id, job, body.kind, TEMPLATES[body.kind]["body"].format(job_id=body.job_id))
    item = {
        "id": store.new_id(),
        "kind": body.kind,
        "to_emails": body.to_emails,
        "subject": TEMPLATES[body.kind]["subject"].format(job_id=body.job_id),
        "body": composed,
        "due_at": due_at,
        "status": "scheduled"
    }
    job.setdefault("letters", []).append(item)
    job.setdefault("timeline", []).append({"job_id": body.job_id, "kind":"note", "message": f"Letter scheduled ({body.kind}) for {due_at}", "when": datetime.utcnow().isoformat()})
    store.jobs[body.job_id] = job
    return {"ok": True, "letter": item}

@router.post("/letters/run")
def run_letters(request: Request):
    # Anyone can trigger in demo; protect with admin in production
    ctx = get_ctx(request)
    # require_admin(ctx)  # Uncomment to admin-protect
    now = datetime.utcnow().isoformat()
    processed = []
    for job_id, job in store.jobs.items():
        for L in job.get("letters", []):
            if L["status"] == "scheduled" and L["due_at"] <= now:
                ok, err = _send_email(
                    os.getenv("SMTP_HOST","smtp.example.com"),
                    int(os.getenv("SMTP_PORT","587")),
                    os.getenv("SMTP_USER","user@example.com"),
                    os.getenv("SMTP_PASS","pass"),
                    L["to_emails"],
                    L["subject"],
                    L["body"]
                )
                L["status"] = "sent" if ok else f"error:{err}"
                job.setdefault("timeline", []).append({"job_id": job_id, "kind":"note", "message": f"Letter {L['id']} ({L['kind']}) {L['status']}", "when": datetime.utcnow().isoformat()})
                processed.append({"job_id": job_id, "letter_id": L["id"], "status": L["status"], "kind": L["kind"]})
        store.jobs[job_id] = job
    return {"processed": processed}


from fastapi import Response
from ..utils.pdfsimple import make_pdf

@router.get("/letters/{job_id}/{letter_id}")
def get_letter(job_id: str, letter_id: str, request: Request):
    job = store.jobs.get(job_id, {})
    ctx = get_ctx(request)
    require_job_access(ctx, job)
    for L in job.get("letters", []):
        if L.get("id") == letter_id:
            return {"letter": L}
    return {"error": "not found"}

@router.get("/letters/{job_id}/{letter_id}.pdf")
def get_letter_pdf(job_id: str, letter_id: str, request: Request):
    job = store.jobs.get(job_id, {})
    ctx = get_ctx(request)
    require_job_access(ctx, job)
    for L in job.get("letters", []):
        if L.get("id") == letter_id:
            title = L.get("subject") or f"Letter {letter_id}"
            body = L.get("body") or ""
            pdf = make_pdf(title, body)
            return Response(content=pdf, media_type="application/pdf",
                            headers={"Content-Disposition": f"attachment; filename=letter-{job_id}-{letter_id}.pdf"})
    return Response(content=b"Not found", media_type="text/plain", status_code=404)


def _job_state(job: dict) -> str:
    # Try several fields
    state = (job.get('state') or job.get('job_state') or (job.get('location') or {}).get('state') or '').strip()
    return (state or 'NA').upper()

def _compose_body(job_id: str, job: dict, kind: str, base_body: str) -> str:
    state = _job_state(job)
    legal = store.settings.get("legal") or {}
    boiler = ((legal.get("boilerplate_by_state") or {}).get(state) or {})
    cites = (legal.get("citations_by_state") or {}).get(state) or []
    require_aob = bool(legal.get("require_aob", False))
    has_aob = bool(((job.get("contract") or {}).get("aob")) or require_aob)

    parts = [base_body]
    # Append state-specific boilerplate
    bp_text = (boiler.get(f"{kind}_text") or "")
    if bp_text.strip():
        parts.append(bp_text.strip())

    # Demand letters: append AOB notice + citations if present
    if kind == "demand":
        if has_aob:
            parts.append("Assignment of Benefits (AOB): Work performed and billing under AOB; contractor empowered to communicate and negotiate directly with carrier per contract.")
        if cites:
            parts.append("References:")
            for c in cites:
                parts.append(f" - {c}")

    return "\n\n".join([p for p in parts if p.strip()])


@router.get("/letters/{job_id}")
def list_letters(job_id: str, request: Request):
    job = store.jobs.get(job_id, {})
    ctx = get_ctx(request)
    require_job_access(ctx, job)
    return {"letters": job.get("letters", [])}


from fastapi import Request
from datetime import datetime
from ..utils.security import get_ctx, require_job_access
from ..utils.store import store

@router.patch("/letters/{job_id}/{letter_id}")
def update_letter(job_id: str, letter_id: str, payload: dict, request: Request):
    job = store.jobs.get(job_id, {})
    ctx = get_ctx(request); require_job_access(ctx, job)
    for L in job.get("letters", []):
        if L.get("id") == letter_id:
            if "subject" in payload: L["subject"] = payload["subject"]
            if "body" in payload: L["body"] = payload["body"]
            store.jobs[job_id] = job
            return {"ok": True, "letter": L}
    return {"error": "not found"}

@router.post("/letters/send_now")
def send_now(job_id: str, letter_id: str, request: Request):
    # Set due_at to now for a specific letter; /letters/run will pick it up
    job = store.jobs.get(job_id, {})
    ctx = get_ctx(request); require_job_access(ctx, job)
    now = datetime.utcnow().isoformat()
    for L in job.get("letters", []):
        if L.get("id") == letter_id:
            L["due_at"] = now
            store.jobs[job_id] = job
            return {"ok": True, "letter": L}
    return {"error": "not found"}
