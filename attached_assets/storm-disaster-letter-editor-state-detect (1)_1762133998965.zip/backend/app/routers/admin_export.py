from fastapi import Request
# REQ_ADMIN_MARK
# EXPORT_SCOPE_MARK: these endpoints require admin today; alternatively, check scope 'exports:read'
from fastapi import APIRouter, Response
from ..utils.store import store
from ..utils.security import get_ctx, require_admin, require_scope
import io, zipfile, json
router=APIRouter()
@router.get('/admin/export/all.zip')
def export_all(request: Request, ):
    buf=io.BytesIO();
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('readme.txt','placeholder')
    buf.seek(0); return Response(content=buf.read(), media_type='application/zip', headers={'Content-Disposition':'attachment; filename=export.zip'})


from typing import Dict, Any
from datetime import datetime, timezone, timedelta
from fastapi import HTTPException

@router.get("/admin/export/shares")
def list_shares(request: Request):
    shares: Dict[str, Any] = (store.settings.get("shares") or {})
    out = []
    now = datetime.now(timezone.utc)
    for tok, meta in shares.items():
        try:
            exp = datetime.fromisoformat(meta["expires_at"])
        except Exception:
            exp = now - timedelta(seconds=1)
        out.append({
            "token": tok,
            "filename": meta.get("filename"),
            "expires_at": meta.get("expires_at"),
            "expired": exp < now
        })
    return {"shares": sorted(out, key=lambda r: r["expires_at"] or '')}

@router.post("/admin/export/shares/cleanup")
def cleanup_shares(request: Request):
    shares: Dict[str, Any] = store.settings.setdefault("shares", {})
    to_delete = []
    now = datetime.now(timezone.utc)
    for tok, meta in list(shares.items()):
        try:
            exp = datetime.fromisoformat(meta["expires_at"])
            if exp < now:
                to_delete.append(tok)
        except Exception:
            to_delete.append(tok)
    for tok in to_delete:
        shares.pop(tok, None)
    return {"removed": len(to_delete), "remaining": len(shares)}

@router.delete("/admin/export/shares/{token}")
def revoke_share(token: str, request: Request):
    shares: Dict[str, Any] = store.settings.setdefault("shares", {})
    if token not in shares:
        raise HTTPException(status_code=404, detail="Token not found")
    shares.pop(token, None)
    return {"ok": True}
