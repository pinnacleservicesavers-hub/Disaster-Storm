
from fastapi import APIRouter, Request
from pydantic import BaseModel
from ..utils.store import store
from ..utils.security import get_ctx, require_admin

router = APIRouter()

class Boilerplate(BaseModel):
    state: str
    late_text: str | None = None
    demand_text: str | None = None

@router.get("/admin/legal/boilerplate/{state}")
def get_boilerplate(state: str, request: Request):
    ctx = get_ctx(request); require_admin(ctx)
    bp = (store.settings.get("legal") or {}).get("boilerplate_by_state", {}).get(state.upper(), {})
    return {"state": state.upper(), "boilerplate": bp}

@router.post("/admin/legal/boilerplate")
def set_boilerplate(b: Boilerplate, request: Request):
    ctx = get_ctx(request); require_admin(ctx)
    store.settings.setdefault("legal", {}).setdefault("boilerplate_by_state", {})
    entry = store.settings["legal"]["boilerplate_by_state"].setdefault(b.state.upper(), {})
    if b.late_text is not None: entry["late_text"] = b.late_text
    if b.demand_text is not None: entry["demand_text"] = b.demand_text
    return {"ok": True, "state": b.state.upper(), "boilerplate": entry}


class Citations(BaseModel):
    state: str
    citations: list[str]

@router.get("/admin/legal/citations/{state}")
def get_citations(state: str, request: Request):
    ctx = get_ctx(request); require_admin(ctx)
    cites = (store.settings.get("legal") or {}).get("citations_by_state", {}).get(state.upper(), [])
    return {"state": state.upper(), "citations": cites}

@router.post("/admin/legal/citations")
def set_citations(c: Citations, request: Request):
    ctx = get_ctx(request); require_admin(ctx)
    store.settings.setdefault("legal", {}).setdefault("citations_by_state", {})
    store.settings["legal"]["citations_by_state"][c.state.upper()] = list(c.citations or [])
    return {"ok": True, "state": c.state.upper(), "citations": store.settings['legal']['citations_by_state'][c.state.upper()]}

class AOBSetting(BaseModel):
    required: bool

@router.get("/admin/legal/aob")
def get_aob(request: Request):
    ctx = get_ctx(request); require_admin(ctx)
    return {"required": bool((store.settings.get("legal") or {}).get("require_aob", False))}

@router.post("/admin/legal/aob")
def set_aob(a: AOBSetting, request: Request):
    ctx = get_ctx(request); require_admin(ctx)
    store.settings.setdefault("legal", {})["require_aob"] = bool(a.required)
    return {"ok": True, "required": bool(a.required)}
