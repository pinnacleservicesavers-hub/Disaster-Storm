
from fastapi import APIRouter, Request
from ..utils.store import store
from ..utils.security import get_ctx, require_job_access

router = APIRouter()

@router.post("/jobs/{job_id}/state")
def set_job_state(job_id: str, state: str, request: Request):
    job = store.jobs.setdefault(job_id, {})
    ctx = get_ctx(request); require_job_access(ctx, job)
    job["state"] = (state or "").upper()
    store.jobs[job_id] = job
    return {"ok": True, "job_id": job_id, "state": job["state"]}
