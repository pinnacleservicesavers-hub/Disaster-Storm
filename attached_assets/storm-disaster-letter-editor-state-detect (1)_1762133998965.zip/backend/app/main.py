import asyncio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
app=FastAPI()
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])

from .routers import admin_export
app.include_router(admin_export.router, tags=['admin'])


@app.on_event("startup")
async def _auto_cleanup_shares():
    try:
        from .routers.admin_export import cleanup_shares
        cleanup_shares()
    except Exception:
        # fail-safe: don't crash startup if cleanup isn't available yet
        pass


async def _hourly_cleanup_task():
    # Periodically call cleanup_shares() every hour
    try:
        from .routers.admin_export import cleanup_shares
    except Exception:
        cleanup_shares = None
    try:
        while True:
            try:
                if cleanup_shares:
                    cleanup_shares()
            except Exception:
                pass
            from .utils.store import store
                    interval = int((store.settings.get('shares') or {}).get('cleanup_interval_minutes', 60))
                    await asyncio.sleep(max(5, min(720, interval)) * 60)
    except asyncio.CancelledError:
        # Graceful shutdown
        return

@app.on_event("startup")
async def _start_cleanup_loop():
    # Launch hourly cleanup and store task handle
    app.state._cleanup_task = asyncio.create_task(_hourly_cleanup_task())

@app.on_event("shutdown")
async def _stop_cleanup_loop():
    # Cancel background task on shutdown
    task = getattr(app.state, "_cleanup_task", None)
    if task:
        task.cancel()

from .routers import admin_settings
app.include_router(admin_settings.router, tags=['admin'])

from .routers import letters
app.include_router(letters.router, tags=['letters'])

from .routers import admin_legal
app.include_router(admin_legal.router, tags=['admin'])

from .routers import admin_legal
app.include_router(admin_legal.router, tags=['admin'])

from .routers import utils_misc, jobs
app.include_router(utils_misc.router, tags=['utils'])
app.include_router(jobs.router, tags=['jobs'])
