from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store
router=APIRouter()
class Cadence(BaseModel):
    gentle_days:int=3
    firm_days:int=7
    final_days:int=7
@router.get('/admin/reminders/cadence')
def get_c():
    cfg=(store.settings.get('reminders') or {}).get('cadence',{})
    return {'cadence': {'gentle_days': cfg.get('gentle_days',3),'firm_days': cfg.get('firm_days',7),'final_days': cfg.get('final_days',7)}}
@router.post('/admin/reminders/cadence')
def set_c(c:Cadence):
    store.settings.setdefault('reminders',{})['cadence']=c.dict(); return {'ok':True,'cadence':c.dict()}
