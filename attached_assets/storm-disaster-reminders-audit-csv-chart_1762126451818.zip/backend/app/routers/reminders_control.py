from fastapi import APIRouter
from ..utils.store import store
from datetime import datetime
router=APIRouter()
@router.post('/payments/reminders/pause/{job_id}')
def pause(job_id:str):
    j=store.jobs.setdefault(job_id,{}); j.setdefault('reminders_meta',{})['paused']=True; j.setdefault('timeline',[]).append({'job_id':job_id,'kind':'note','message':'Reminders paused','when':datetime.utcnow().isoformat()}); store.jobs[job_id]=j; return {'ok':True,'paused':True}
@router.post('/payments/reminders/resume/{job_id}')
def resume(job_id:str):
    j=store.jobs.setdefault(job_id,{}); j.setdefault('reminders_meta',{})['paused']=False; j.setdefault('timeline',[]).append({'job_id':job_id,'kind':'note','message':'Reminders resumed','when':datetime.utcnow().isoformat()}); store.jobs[job_id]=j; return {'ok':True,'paused':False}
@router.get('/payments/reminders/list/{job_id}')
def lst(job_id:str):
    j=store.jobs.get(job_id,{}); return {'paused': (j.get('reminders_meta') or {}).get('paused',False), 'reminders': j.get('reminders',[])}
