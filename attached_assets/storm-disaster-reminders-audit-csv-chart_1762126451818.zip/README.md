## Cadence & Controls
- GET/POST /admin/reminders/cadence
- POST /payments/reminders/pause/{job_id}
- POST /payments/reminders/resume/{job_id}
- GET /payments/reminders/list/{job_id}


## Reminders — Next ETA, Per-job Overrides, Audit
- Next reminder ETA (org-wide): `GET /admin/reminders/next` → `{ next_due_at, scheduled_count, soonest:[{job_id, level, due_at}] }`
- Per-job cadence overrides:
  - `POST /payments/reminders/override_cadence { job_id, gentle_days?, firm_days?, final_days? }`
  - `GET /payments/reminders/override_cadence/{job_id}`
- Audit trail per job:
  - `GET /payments/reminders/audit/{job_id}`

UI:
- **Admin Command Center** shows next reminder ETA, count scheduled, and the top 5 soonest.
- **Job page** shows per-job cadence form and an audit trail list.
