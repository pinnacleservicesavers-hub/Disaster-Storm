"use client";
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import CadenceEditor from './cadence';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';

export default function AdminCenter(){
  const [nextInfo, setNextInfo] = useState<any>();
  const [series, setSeries] = useState<any[]>([]);
  useEffect(()=>{
    api('/admin/reminders/next').then(setNextInfo).catch(()=>{});
    api('/admin/reminders/audit/series').then(r=>setSeries(r.series)).catch(()=>{});
  },[]);

  return (
    <main className="p-8 max-w-6xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Admin Command Center</h1>

      <section className="grid grid-cols-3 gap-4">
        <div className="border rounded p-4">
          <div className="text-sm text-gray-600">Next reminder ETA</div>
          <div className="text-lg font-semibold">{nextInfo?.next_due_at || '—'}</div>
          <div className="text-xs text-gray-500">{nextInfo?.scheduled_count || 0} scheduled</div>
        </div>
        <div className="border rounded p-4 col-span-2">
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold mb-2">Reminders timeline (last 30 days)</div>
            <a className="underline text-sm" href="/admin/reminders/audit.csv" target="_blank">Download CSV</a>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={series}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Line type="monotone" dataKey="sent" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      <CadenceEditor />
    </main>
  );
}
