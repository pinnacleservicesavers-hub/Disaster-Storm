"use client";
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { api, API_BASE } from '@/lib/api';

export default function JobDetail(){
  const id = (useParams().id as string) || 'A1';
  const [rem, setRem] = useState<any>({paused:false, reminders:[]});
  const [cad, setCad] = useState<any>({ gentle_days: '', firm_days: '', final_days: '' });
  const [audit, setAudit] = useState<any[]>([]);

  const load = async ()=>{
    setRem(await api(`/payments/reminders/list/${id}`));
    const oc = await api(`/payments/reminders/override_cadence/${id}`);
    setCad(oc.cadence || {});
    const au = await api(`/payments/reminders/audit/${id}`);
    setAudit(au.audit || []);
  };

  useEffect(()=>{ load(); },[]);

  const saveOverride = async ()=>{
    await api('/payments/reminders/override_cadence', { method:'POST', body: JSON.stringify({ job_id: id, ...cad })});
    alert('Cadence override saved');
  };

  return (
    <main className="p-8 space-y-4">
      <h1 className="text-2xl font-semibold">Job {id}</h1>

      <section className="border rounded p-3 space-y-2">
        <h2 className="font-semibold">Reminders control</h2>
        <div className="flex items-center gap-3">
          <span className={rem.paused?'text-red-600':'text-green-700'}>Status: {rem.paused ? 'Paused' : 'Active'}</span>
          <button onClick={async()=>{ await api(`/payments/reminders/${rem.paused?'resume':'pause'}/${id}`, { method:'POST' }); setRem(await api(`/payments/reminders/list/${id}`)); }} className="px-3 py-1 rounded border">
            {rem.paused ? 'Resume' : 'Pause'}
          </button>
        </div>
        <div className="text-sm text-gray-600">Scheduled reminders</div>
        {rem.reminders?.length ? <div className="border rounded">
          {rem.reminders.map((r:any)=>(<div key={r.id} className="p-2 border-b flex justify-between"><div>{r.level} — {r.status}</div><div>due {r.due_at}</div></div>))}
        </div> : <div className="text-sm text-gray-500">No reminders yet.</div>}
      </section>

      <section className="border rounded p-3 space-y-2">
        <h2 className="font-semibold">Per-job cadence override</h2>
        <div className="grid grid-cols-3 gap-2">
          <label className="text-sm">Gentle<input className="border p-2 w-full" value={cad.gentle_days ?? ''} onChange={e=>setCad({...cad, gentle_days: e.target.value?parseInt(e.target.value,10):null})} /></label>
          <label className="text-sm">Firm<input className="border p-2 w-full" value={cad.firm_days ?? ''} onChange={e=>setCad({...cad, firm_days: e.target.value?parseInt(e.target.value,10):null})} /></label>
          <label className="text-sm">Final<input className="border p-2 w-full" value={cad.final_days ?? ''} onChange={e=>setCad({...cad, final_days: e.target.value?parseInt(e.target.value,10):null})} /></label>
        </div>
        <button onClick={saveOverride} className="px-4 py-2 rounded border">Save override</button>
      </section>

      <section className="border rounded p-3 space-y-2">
        <h2 className="font-semibold">Reminder audit trail</h2>
        {audit.length ? <div className="border rounded">
          {audit.map((a:any)=>(<div key={a.id + a.when} className="p-2 border-b">
            <div className="text-sm">{a.when} — {a.status}</div>
            <div className="text-xs text-gray-600">To: {a.to?.join(', ')}</div>
            <div className="text-xs">{a.subject}</div>
          </div>))}
        </div> : <div className="text-sm text-gray-500">No audit records yet.</div>}
      </section>

      <a className="underline" target="_blank" href={`${API_BASE}/claims/${id}/submission.zip`}>Download Submission ZIP</a>
    </main>
  );
}
