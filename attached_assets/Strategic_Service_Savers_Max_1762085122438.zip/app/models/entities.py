from sqlalchemy import Column, Integer, String, Float, DateTime, Text
from sqlalchemy.sql import func
from app.models.base import Base

class Contractor(Base):
    __tablename__ = "contractors"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    phone = Column(String, nullable=True)
    lat = Column(Float, nullable=False)
    lon = Column(Float, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Asset(Base):
    __tablename__ = "assets"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    ref_id = Column(String, nullable=True)
    lat = Column(Float, nullable=False)
    lon = Column(Float, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Alert(Base):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True)
    source = Column(String, nullable=False)  # e.g., 'NWS', 'USGS', 'NHC', 'FIRMS'
    title = Column(String, nullable=False)
    severity = Column(String, nullable=True)
    # geometry stored as WKT to stay SQLite-friendly; could switch to PostGIS later
    geom_wkt = Column(Text, nullable=True)
    properties_json = Column(Text, nullable=True)
    started_at = Column(DateTime(timezone=True), nullable=True)
    ended_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True)
    kind = Column(String, nullable=False)  # 'INGEST', 'RULE_MATCH', 'SMS', 'WEBHOOK'
    message = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Carrier(Base):
    __tablename__ = "carriers"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    naic = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Claim(Base):
    __tablename__ = "claims"
    id = Column(Integer, primary_key=True)
    carrier_id = Column(Integer, nullable=True)
    policy_number = Column(String, nullable=True)
    asset_id = Column(Integer, nullable=True)
    status = Column(String, nullable=False, default="open")  # open, in_progress, closed
    notes = Column(Text, nullable=True)
    last_update = Column(DateTime(timezone=True), server_default=func.now())
