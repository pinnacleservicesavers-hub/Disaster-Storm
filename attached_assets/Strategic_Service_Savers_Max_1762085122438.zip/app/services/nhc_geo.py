import httpx, zipfile, io, os, json
from datetime import datetime, timezone
from shapely.geometry import shape
from shapely import wkt as _wkt
from sqlalchemy.orm import Session
from app.models.entities import Alert, AuditLog

# This module prefers GeoJSON if available. If not, it can fall back to zipped shapefiles
# published by NHC. Many active-storm products are linked from the NHC GIS page.
#
# Strategy:
# 1) Fetch the "CurrentStorms.json" index to list active storms.
# 2) For each storm, probe known GeoJSON endpoints (cone, forecast track, wind radii).
# 3) If GeoJSON not present, attempt to follow the storm's "GIS" link to grab zipped shapefiles
#    and extract polygons. (Requires 'pyogrio' which in turn needs GDAL at runtime.)
#
# Notes:
# - Endpoints change rarely; keep code defensive and log gracefully if a product isn't present.
# - If NHC changes URLs, keep this module versioned so you can adjust paths quickly.

CURRENT_STORMS = "https://www.nhc.noaa.gov/CurrentStorms.json"

# Known product filename fragments we try to locate relative to storm resource roots
POSSIBLE_GEOJSON_NAMES = [
    "cone_latest.geojson",          # cone of uncertainty (latest)
    "forecast_line_latest.geojson", # forecast track line (latest)
    "wind_probs_latest.geojson",    # wind probability swaths
    "ww_areas_latest.geojson",      # watches/warnings areas
]

async def _get_json(url: str):
    async with httpx.AsyncClient(timeout=25) as client:
        r = await client.get(url, headers={"User-Agent":"S3/1.0 (ops@s3.example)"})
        r.raise_for_status()
        return r.json()

async def _try_fetch_geojson(url: str):
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(url, headers={"User-Agent":"S3/1.0"})
            if r.status_code == 200 and r.headers.get("content-type","").startswith(("application/geo+json","application/json")):
                return r.json()
    except Exception:
        return None
    return None

def _store_geojson_collection(db: Session, collection: dict, source_tag: str, title_prefix: str):
    count = 0
    for f in collection.get("features", []):
        geom = f.get("geometry")
        props = f.get("properties", {})
        try:
            shp = shape(geom)
            geom_w = shp.wkt
        except Exception:
            geom_w = None
        title = f"{title_prefix}: {props.get('name') or props.get('event') or source_tag}"
        a = Alert(
            source=source_tag,
            title=title,
            severity=str(props.get("severity") or props.get("probability") or ""),
            geom_wkt=geom_w,
            properties_json=json.dumps(props),
        )
        db.add(a); count += 1
    db.add(AuditLog(kind="INGEST", message=f"NHC {title_prefix} GeoJSON stored: {count}"))
    db.commit()

async def ingest_nhc_geojson(db: Session):
    """Fetch active storms and try to ingest cone/track GeoJSON layers."""
    try:
        storms = await _get_json(CURRENT_STORMS)
    except Exception as e:
        db.add(AuditLog(kind="INGEST", message=f"NHC list error: {e}"))
        db.commit()
        return

    # Each storm may expose a 'stormhref' or 'gis' root; defensively probe common paths.
    total = 0
    for s in storms:
        # Common root guesses from NHC site structure:
        roots = []
        for k in ("stormhref","stormURL","stormurl","gis"):
            v = s.get(k)
            if isinstance(v, str):
                roots.append(v.rstrip("/"))
        # fallback: a generic GIS root per basin could be used if needed
        for root in roots:
            for name in POSSIBLE_GEOJSON_NAMES:
                url = f"{root}/{name}"
                gj = await _try_fetch_geojson(url)
                if gj and isinstance(gj, dict) and gj.get("type") in ("FeatureCollection","Feature"):
                    if gj.get("type") == "Feature":
                        gj = {"type":"FeatureCollection","features":[gj]}
                    _store_geojson_collection(db, gj, source_tag="NHC", title_prefix=name.replace("_latest","").replace(".geojson",""))
                    total += len(gj.get("features",[]))
    if total == 0:
        db.add(AuditLog(kind="INGEST", message="NHC: no GeoJSON products found via guessed roots; check URLs."))
        db.commit()
