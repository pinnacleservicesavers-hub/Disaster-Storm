import io, httpx, gzip, numpy as np
from datetime import datetime, timedelta, timezone
from shapely.geometry import Polygon, mapping
from shapely import wkt as _wkt
from sqlalchemy.orm import Session
from app.models.entities import Alert, AuditLog
from skimage import measure
import rasterio
from rasterio.io import MemoryFile

# MRMS on AWS S3 public dataset commonly lives under https://noaa-mrms-pds.s3.amazonaws.com/
# Products include MESH, PrecipRate, QPE, etc. Files are often in GRIB2 or NetCDF formats.
# This module demonstrates:
#  - fetching a raster (given a full URL),
#  - thresholding it,
#  - extracting polygon contours,
#  - storing polygons as Alerts.
#
# Usage:
#   await ingest_mrms_contours(db, url_template="https://noaa-mrms-pds.s3.amazonaws.com/CONUS/MESH/MRMS_MESH_{ts}.grib2.gz",
#                              threshold=25.4, severity="hail")
#
# Where {ts} is like 20241102-120000 (nearest 5-min aligned timestamp).

def _nearest_5min(dt: datetime) -> datetime:
    minute = (dt.minute // 5) * 5
    return dt.replace(minute=minute, second=0, microsecond=0)

async def _fetch_bytes(url: str) -> bytes:
    async with httpx.AsyncClient(timeout=45) as client:
        r = await client.get(url, headers={"User-Agent":"S3/1.0"})
        r.raise_for_status()
        return r.content

def _open_raster_from_bytes(data: bytes):
    # Support .gz transparently
    try:
        if data[:2] == b"\x1f\x8b":
            data = gzip.decompress(data)
    except Exception:
        pass
    mem = MemoryFile(data)
    return mem.open()

def _contours_from_raster(dataset, threshold: float):
    # Read first band
    arr = dataset.read(1).astype(np.float32)
    # Mask fill values
    arr = np.where(np.isfinite(arr), arr, np.nan)
    # Simple threshold mask
    mask = np.where(arr >= threshold, 1, 0).astype(np.uint8)
    # Extract boundaries at 0.5 level
    contours = measure.find_contours(mask, 0.5)
    features = []
    for c in contours:
        # c is in pixel coords (row, col). Map to lon/lat using dataset transform
        lonlats = [dataset.transform * (pt[1], pt[0]) for pt in c]
        if len(lonlats) < 3:
            continue
        try:
            poly = Polygon(lonlats).buffer(0)
            if not poly.is_valid or poly.area == 0:
                continue
            features.append(poly)
        except Exception:
            continue
    return features

async def ingest_mrms_contours(db: Session, url_template: str, threshold: float, severity: str):
    ts = _nearest_5min(datetime.now(timezone.utc))
    ts_str = ts.strftime("%Y%m%d-%H%M00")
    url = url_template.format(ts=ts_str)

    try:
        data = await _fetch_bytes(url)
        ds = _open_raster_from_bytes(data)
    except Exception as e:
        db.add(AuditLog(kind="INGEST", message=f"MRMS fetch/open failed: {e} @ {url}"))
        db.commit()
        return

    try:
        polys = _contours_from_raster(ds, threshold)
    except Exception as e:
        db.add(AuditLog(kind="INGEST", message=f"MRMS contour failed: {e}"))
        db.commit()
        return

    count = 0
    for poly in polys:
        a = Alert(
            source="MRMS",
            title=f"MRMS {severity} threshold >= {threshold}",
            severity=severity,
            geom_wkt=poly.wkt,
            properties_json=json.dumps({"threshold": threshold, "product_url": url})
        )
        db.add(a); count += 1
    db.add(AuditLog(kind="INGEST", message=f"MRMS polygons stored: {count} from {url}"))
    db.commit()

# --- Upgrades: multi-thresholds, simplification, peril auto-select ---
from shapely.ops import unary_union
from shapely.geometry import MultiPolygon

MRMS_PERIL_TEMPLATES = {
    # hail proxy (MESH in mm; 25.4mm ~ 1 inch). Adjust to your preferred product.
    "hail": {
        "template": "https://noaa-mrms-pds.s3.amazonaws.com/CONUS/MESH/MRMS_MESH_{ts}.grib2.gz",
        "thresholds": [19.0, 25.4, 38.1],  # ~0.75\", 1\", 1.5\"
        "units": "mm"
    },
    # heavy precipitation rate (mm/hr)
    "heavy_precip": {
        "template": "https://noaa-mrms-pds.s3.amazonaws.com/CONUS/PrecipRate/MRMS_PrecipRate_{ts}.grib2.gz",
        "thresholds": [10.0, 25.0, 50.0],
        "units": "mm/hr"
    },
    # hourly QPE accumulation (mm)
    "flood_risk": {
        "template": "https://noaa-mrms-pds.s3.amazonaws.com/CONUS/QPE_01H/MRMS_QPE_01H_{ts}.grib2.gz",
        "thresholds": [12.7, 25.4, 50.8],  # 0.5\", 1\", 2\"
        "units": "mm"
    }
}

def simplify_polygons(polys, tolerance: float = 0.01):
    simp = []
    for p in polys:
        try:
            s = p.simplify(tolerance, preserve_topology=True)
            if s.is_empty:
                continue
            if isinstance(s, (MultiPolygon,)):
                simp.extend([g for g in s.geoms if g.area > 0])
            else:
                if s.area > 0:
                    simp.append(s)
        except Exception:
            continue
    return simp

async def ingest_mrms_multithreshold(db: Session, product_template: str, thresholds: list[float], severity: str, simplify_tolerance: float = 0.02):
    ts = _nearest_5min(datetime.now(timezone.utc))
    ts_str = ts.strftime("%Y%m%d-%H%M00")
    url = product_template.format(ts=ts_str)

    try:
        data = await _fetch_bytes(url)
        ds = _open_raster_from_bytes(data)
    except Exception as e:
        db.add(AuditLog(kind="INGEST", message=f"MRMS fetch/open failed: {e} @ {url}"))
        db.commit()
        return

    count_total = 0
    for thr in thresholds:
        try:
            polys = _contours_from_raster(ds, thr)
            polys = simplify_polygons(polys, tolerance=simplify_tolerance)
        except Exception as e:
            db.add(AuditLog(kind="INGEST", message=f"MRMS contour failed @ {thr}: {e}"))
            db.commit()
            continue

        for poly in polys:
            a = Alert(
                source="MRMS",
                title=f"MRMS {severity} >= {thr}",
                severity=severity,
                geom_wkt=poly.wkt,
                properties_json=json.dumps({"threshold": thr, "product_url": url})
            )
            db.add(a); count_total += 1
    db.add(AuditLog(kind="INGEST", message=f"MRMS multi stored: {count_total} @ {url} ({severity})"))
    db.commit()

async def ingest_mrms_for_peril(db: Session, peril: str, simplify_tolerance: float = 0.02):
    cfg = MRMS_PERIL_TEMPLATES.get(peril)
    if not cfg:
        db.add(AuditLog(kind="INGEST", message=f"MRMS unknown peril: {peril}"))
        db.commit(); return
    await ingest_mrms_multithreshold(
        db,
        product_template=cfg["template"],
        thresholds=cfg["thresholds"],
        severity=peril,
        simplify_tolerance=simplify_tolerance
    )
