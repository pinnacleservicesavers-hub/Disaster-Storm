import httpx, json
from shapely.geometry import shape, Polygon, mapping
from shapely import wkt
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.core.db import SessionLocal
from app.models.entities import Alert, AuditLog
from app.services.nhc_geo import ingest_nhc_geojson
from app.services.mrms import ingest_mrms_contours, ingest_mrms_for_peril

# Public feeds (no keys needed):
NWS_ALERTS = "https://api.weather.gov/alerts/active"
USGS_EARTHQUAKES = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson"
NHC_CONE = "https://www.nhc.noaa.gov/CurrentStorms.json"  # provides active storms; tracks via linked resources
FIRMS_VIIRS = "https://firms.modaps.eosdis.nasa.gov/geojson/country/USA/VIIRS_I_Global_24h.json"

async def fetch_json(url: str):
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(url, headers={"User-Agent":"S3/1.0 (contact@example.com)"})
        r.raise_for_status()
        return r.json()

async def ingest_nws(db: Session):
    data = await fetch_json(NWS_ALERTS)
    count = 0
    for f in data.get("features", []):
        props = f.get("properties", {})
        geom = f.get("geometry")
        title = props.get("event") or props.get("headline") or "NWS Alert"
        sev = props.get("severity") or props.get("certainty") or ""
        started = props.get("onset")
        ended = props.get("ends")
        geom_wkt = None
        if geom:
            try:
                shp = shape(geom)
                geom_wkt = shp.wkt
            except Exception:
                pass
        a = Alert(source="NWS", title=title, severity=sev, geom_wkt=geom_wkt,
                  properties_json=json.dumps(props),
                  started_at=datetime.fromisoformat(started.replace("Z","+00:00")) if started else None,
                  ended_at=datetime.fromisoformat(ended.replace("Z","+00:00")) if ended else None)
        db.add(a); count += 1
    db.add(AuditLog(kind="INGEST", message=f"NWS alerts ingested: {count}"))
    db.commit()

async def ingest_usgs(db: Session):
    data = await fetch_json(USGS_EARTHQUAKES)
    count = 0
    for f in data.get("features", []):
        props = f.get("properties", {})
        geom = f.get("geometry")
        title = f"Earthquake M{props.get('mag')} - {props.get('place')}"
        sev = "earthquake"
        geom_wkt = None
        if geom:
            try:
                shp = shape(geom)
                geom_wkt = shp.wkt
            except Exception:
                pass
        a = Alert(source="USGS", title=title, severity=sev, geom_wkt=geom_wkt,
                  properties_json=json.dumps(props),
                  started_at=datetime.fromtimestamp(props.get("time")/1000, tz=timezone.utc))
        db.add(a); count += 1
    db.add(AuditLog(kind="INGEST", message=f"USGS earthquakes ingested: {count}"))
    db.commit()

async def ingest_firms(db: Session):
    data = await fetch_json(FIRMS_VIIRS)
    count = 0
    for f in data.get("features", []):
        props = f.get("properties", {})
        geom = f.get("geometry")
        title = "Wildfire Hotspot"
        sev = "wildfire"
        geom_wkt = None
        if geom:
            try:
                shp = shape(geom)
                geom_wkt = shp.wkt
            except Exception:
                pass
        a = Alert(source="FIRMS", title=title, severity=sev, geom_wkt=geom_wkt,
                  properties_json=json.dumps(props))
        db.add(a); count += 1
    db.add(AuditLog(kind="INGEST", message=f"FIRMS hotspots ingested: {count}"))
    db.commit()

async def ingest_nhc(db: Session):
    # Basic: load storm list JSON; advanced: follow links to shape cones/tracks.
    try:
        data = await fetch_json(NHC_CONE)
        db.add(AuditLog(kind="INGEST", message=f"NHC storms listed: {len(data)}"))
        db.commit()
    except Exception as e:
        db.add(AuditLog(kind="INGEST", message=f"NHC ingest error: {e}"))
        db.commit()

async def run_all_ingestors():
    db = SessionLocal()
    try:
        await ingest_nws(db)
        await ingest_usgs(db)
        await ingest_firms(db)
        await ingest_nhc(db)
        await ingest_nhc_cones(db)
        await ingest_mrms_stub(db)
    finally:
        db.close()

# --- Extra Ingestors: MRMS + NHC Cone/Tracks ---
# MRMS access notes:
# Many MRMS products are hosted on AWS (no-auth) in S3. For simplicity, this ingestor
# demonstrates pulling NWS "alerts" plus adding pseudo-tiles for MRMS heavy precip areas
# via derived JSON feeds you can replace with a proper MRMS raster -> vector pipeline later.

MRMS_QPE_TILES_INFO = "https://mrms.ncep.noaa.gov/data/2D/PrecipRate/"  # placeholder doc URL
NHC_ATCF_ACTIVE = "https://www.nhc.noaa.gov/gtwo.php?basin=atlc&fdays=2"  # for metadata only; cone shapefiles linked per storm

async def ingest_nhc_cones(db: Session):
    # This function is a placeholder to show where you'd fetch shapefiles/geojson cones/tracks.
    # The NHC provides GIS resources per active storm, often as zipped shapefiles.
    # In production: list active storms -> follow "GIS" links -> parse polygons -> store as alerts.
    try:
        # For now, we just log that NHC cones would be fetched here.
        db.add(AuditLog(kind="INGEST", message="NHC cone/track ingest placeholder executed"))
        db.commit()
    except Exception as e:
        db.add(AuditLog(kind="INGEST", message=f"NHC cone ingest error: {e}"))
        db.commit()

async def ingest_mrms_stub(db: Session):
    # Placeholder that records a log; swap with real MRMS vectorization (e.g., threshold QPE/PrecipRate rasters).
    db.add(AuditLog(kind="INGEST", message="MRMS stub ingest executed (replace with raster->contour)"))
    db.commit()
