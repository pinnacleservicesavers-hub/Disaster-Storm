from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.db import init_db
from app.routers import health, contractors, assets, alerts, ingest, rules, ui, ai, claims, mrms, notify, reports

app = FastAPI(title="Strategic Service Savers — Disaster Intelligence")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="/api", tags=["health"])
app.include_router(contractors.router, prefix="/api", tags=["contractors"])
app.include_router(assets.router, prefix="/api", tags=["assets"])
app.include_router(alerts.router, prefix="/api", tags=["alerts"])
app.include_router(ingest.router, prefix="/api", tags=["ingest"])
app.include_router(rules.router, prefix="/api", tags=["rules"])
app.include_router(ui.router, prefix="/api", tags=["ui"])
app.include_router(ai.router, prefix="/api", tags=["ai"])
app.include_router(claims.router, prefix="/api", tags=["claims"])
app.include_router(mrms.router, prefix="/api", tags=["mrms"])
app.include_router(notify.router, prefix="/api", tags=["notify"])
app.include_router(reports.router, prefix="/api", tags=["reports"])

@app.on_event("startup")
async def startup_event():
    init_db()

@app.get("/", include_in_schema=False)
def index():
    # Serve a minimal HTML map from /web/static/index.html
    return {"message": "S3 API running. Open /web/static/index.html in Replit web view."}
