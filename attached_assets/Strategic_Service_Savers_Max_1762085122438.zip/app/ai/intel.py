from typing import List, Dict, Any, Tuple
from math import radians, sin, cos, asin, sqrt
from shapely import wkt
from shapely.geometry import Point, Polygon
from sqlalchemy.orm import Session
from app.models.entities import Alert, Contractor, Asset

def haversine(lat1, lon1, lat2, lon2):
    # kilometers
    R = 6371.0
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)
    a = sin(dlat/2)**2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    return R * c

def summarize_current_conditions(db: Session) -> Dict[str, Any]:
    """Produce a natural language summary of active hazards and top priorities."""
    alerts = db.query(Alert).order_by(Alert.id.desc()).limit(200).all()
    contractors = db.query(Contractor).all()
    assets = db.query(Asset).all()

    peril_counts = {}
    impacts = []

    for al in alerts:
        peril = al.source
        peril_counts[peril] = peril_counts.get(peril, 0) + 1
        # find nearest contractor and asset centroid approximation
        nearest_contractor = None
        nearest_asset = None
        if al.geom_wkt:
            try:
                geom = wkt.loads(al.geom_wkt)
                centroid = geom.centroid
                clat, clon = centroid.y, centroid.x
            except Exception:
                clat = clon = None
        else:
            clat = clon = None

        dmin_c = 1e9
        for c in contractors:
            d = haversine(c.lat, c.lon, clat, clon) if clat is not None else None
            if d is not None and d < dmin_c:
                dmin_c = d; nearest_contractor = (c.name, d)
        dmin_a = 1e9
        for a in assets:
            d = haversine(a.lat, a.lon, clat, clon) if clat is not None else None
            if d is not None and d < dmin_a:
                dmin_a = d; nearest_asset = (a.name, d)

        impacts.append({
            "alert_id": al.id,
            "title": al.title,
            "source": al.source,
            "severity": al.severity,
            "nearest_contractor_km": None if nearest_contractor is None else round(nearest_contractor[1],1),
            "nearest_asset_km": None if nearest_asset is None else round(nearest_asset[1],1)
        })

    # Basic narrative
    lines = []
    if not alerts:
        lines.append("No active hazards detected from the ingested feeds.")
    else:
        lines.append(f"{len(alerts)} active hazard objects are in the system.")
        pcs = ", ".join([f"{k}: {v}" for k,v in peril_counts.items()])
        lines.append(f"By source → {pcs}.")
        # highlight top-5 by proximity to any contractor/asset
        def score(i):
            a = i.get("nearest_contractor_km") or 1e9
            b = i.get("nearest_asset_km") or 1e9
            return min(a,b)
        top = sorted(impacts, key=score)[:5]
        for t in top:
            lines.append(f"- {t['title']} [{t['source']}] — nearest contractor ~{t['nearest_contractor_km']} km, nearest asset ~{t['nearest_asset_km']} km.")
        lines.append("Recommendation: run /api/rules/evaluate to produce targeted notifications and staging guidance.")
    return {"summary": " ".join(lines), "peril_counts": peril_counts, "highlights": impacts[:10]}

def suggest_staging_locations(db: Session, max_results: int = 5) -> Dict[str, Any]:
    """Suggest safe staging points ~20–60 km upwind/outside of hazard polygons."""
    alerts = db.query(Alert).order_by(Alert.id.desc()).limit(200).all()
    suggestions = []
    for al in alerts:
        if not al.geom_wkt:
            continue
        try:
            geom = wkt.loads(al.geom_wkt)
        except Exception:
            continue
        # pick a point just outside polygon buffer as naive staging (can be improved with roads)
        try:
            outer = geom.buffer(0.2)  # degrees ~ ~20km near mid-latitudes
            cand = list(outer.exterior.coords)[0]
            suggestions.append({
                "alert_id": al.id,
                "title": al.title,
                "source": al.source,
                "lat": cand[1],
                "lon": cand[0],
                "note": "Provisional staging point outside hazard envelope (~20km buffer)."
            })
        except Exception:
            continue

    return {"staging": suggestions[:max_results]}
