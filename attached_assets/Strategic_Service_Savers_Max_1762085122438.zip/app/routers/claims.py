from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.core.db import SessionLocal
from app.models.entities import Claim, Carrier, Asset, Alert
from shapely import wkt
from shapely.geometry import Point

router = APIRouter()
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class ClaimIn(BaseModel):
    carrier_name: str | None = None
    policy_number: str | None = None
    asset_id: int | None = None
    status: str = "open"
    notes: str | None = None

@router.get("/claims")
def list_claims(db: Session = Depends(get_db)):
    return db.query(Claim).all()

@router.post("/claims")
def create_claim(body: ClaimIn, db: Session = Depends(get_db)):
    carrier_id = None
    if body.carrier_name:
        c = db.query(Carrier).filter(Carrier.name==body.carrier_name).first()
        if not c:
            c = Carrier(name=body.carrier_name)
            db.add(c); db.commit(); db.refresh(c)
        carrier_id = c.id
    cl = Claim(carrier_id=carrier_id, policy_number=body.policy_number, asset_id=body.asset_id, status=body.status, notes=body.notes)
    db.add(cl); db.commit(); db.refresh(cl)
    return cl

@router.get("/align/summary")
def alignment_summary(db: Session = Depends(get_db)):
    """Join claims + assets + active alerts to show nearby hazards and a naive 'moratorium' flag."""
    assets = {a.id: a for a in db.query(Asset).all()}
    alerts = db.query(Alert).all()
    results = []

    for cl in db.query(Claim).all():
        a = assets.get(cl.asset_id)
        if not a:
            continue
        pt = Point(a.lon, a.lat)
        hazard_hits = []
        for al in alerts:
            if not al.geom_wkt:
                continue
            try:
                g = wkt.loads(al.geom_wkt)
                if g.buffer(0).intersects(pt):
                    hazard_hits.append({"alert_id": al.id, "title": al.title, "source": al.source, "severity": al.severity})
            except Exception:
                continue
        moratorium = any(h.get("source") in ("NWS","NHC","MRMS") for h in hazard_hits)
        results.append({
            "claim_id": cl.id,
            "policy_number": cl.policy_number,
            "asset_id": cl.asset_id,
            "status": cl.status,
            "hazards": hazard_hits,
            "moratorium": moratorium
        })
    return {"count": len(results), "items": results}
