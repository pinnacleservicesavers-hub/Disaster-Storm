from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.core.db import SessionLocal
from app.models.entities import Asset

router = APIRouter()
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class AssetIn(BaseModel):
    name: str
    lat: float
    lon: float
    ref_id: str | None = None

@router.get("/assets")
def list_assets(db: Session = Depends(get_db)):
    return db.query(Asset).all()

@router.post("/assets")
def add_asset(body: AssetIn, db: Session = Depends(get_db)):
    a = Asset(name=body.name, lat=body.lat, lon=body.lon, ref_id=body.ref_id)
    db.add(a); db.commit(); db.refresh(a)
    return a
