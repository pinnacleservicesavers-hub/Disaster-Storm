from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.db import SessionLocal
from app.ai.intel import summarize_current_conditions, suggest_staging_locations

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/ai/summary")
def ai_summary(db: Session = Depends(get_db)):
    return summarize_current_conditions(db)

@router.get("/ai/staging")
def ai_staging(db: Session = Depends(get_db)):
    return suggest_staging_locations(db)
