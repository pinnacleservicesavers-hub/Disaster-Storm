from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.db import SessionLocal
from app.models.entities import Alert

router = APIRouter()
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/ui")
def ui_layers(db: Session = Depends(get_db)):
    # exposes alerts as GeoJSON-like layers for a Leaflet client
    features = []
    for a in db.query(Alert).all():
        features.append({
            "type":"Feature",
            "geometry":"WKT:" + (a.geom_wkt or ""),
            "properties":{
                "id": a.id,
                "source": a.source,
                "title": a.title,
                "severity": a.severity
            }
        })
    return {"type":"FeatureCollection","features":features}
