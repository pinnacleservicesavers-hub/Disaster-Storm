import asyncio
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.db import SessionLocal
from app.services.ingest import run_all_ingestors

router = APIRouter()
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/ingest/run")
async def ingest_now():
    await run_all_ingestors()
    return {"status": "ingested"}
