from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from shapely import wkt
from shapely.geometry import Point, shape
from app.core.db import SessionLocal
from app.models.entities import Alert, Contractor, Asset, AuditLog
from app.utils.notify import send_webhook, send_sms
from app.core.config import settings

router = APIRouter()
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def intersects_point(geom_wkt: str, lat: float, lon: float) -> bool:
    try:
        g = wkt.loads(geom_wkt)
        p = Point(lon, lat)
        return g.buffer(0).contains(p) or g.buffer(0).intersects(p)
    except Exception:
        return False

@router.post("/rules/evaluate")
def run_rules(db: Session = Depends(get_db)):
    alerts = db.query(Alert).all()
    contractors = db.query(Contractor).all()
    assets = db.query(Asset).all()

    matches = []
    for al in alerts:
        if not al.geom_wkt:
            continue
        for c in contractors:
            if intersects_point(al.geom_wkt, c.lat, c.lon):
                matches.append({"type":"contractor","alert_id":al.id,"contractor_id":c.id,"title":al.title})
                # optional SMS/webhook
        for a in assets:
            if intersects_point(al.geom_wkt, a.lat, a.lon):
                matches.append({"type":"asset","alert_id":al.id,"asset_id":a.id,"title":al.title})

    # Example webhook push
    if settings.alert_webhook_url:
        send_webhook({"matches": matches})

    db.add(AuditLog(kind="RULE_MATCH", message=str(matches)))
    db.commit()
    return {"matches": matches, "count": len(matches)}
