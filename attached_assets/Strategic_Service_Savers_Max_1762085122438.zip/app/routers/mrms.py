from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.core.db import SessionLocal
from app.services.mrms import ingest_mrms_for_peril

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/mrms/run")
async def mrms_run(peril: str = Query(..., description="hail|heavy_precip|flood_risk"),
                   tolerance: float = Query(0.02, ge=0.0, le=0.2, description="polygon simplification tolerance"),
                   db: Session = Depends(get_db)):
    await ingest_mrms_for_peril(db, peril=peril, simplify_tolerance=tolerance)
    return {"status":"ok","peril":peril,"tolerance":tolerance}
