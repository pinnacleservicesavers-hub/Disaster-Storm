from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from app.core.db import SessionLocal
from app.models.entities import Contractor

router = APIRouter()
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class ContractorIn(BaseModel):
    name: str
    lat: float
    lon: float
    phone: str | None = None

@router.get("/contractors")
def list_contractors(db: Session = Depends(get_db)):
    return db.query(Contractor).all()

@router.post("/contractors")
def add_contractor(body: ContractorIn, db: Session = Depends(get_db)):
    c = Contractor(name=body.name, lat=body.lat, lon=body.lon, phone=body.phone)
    db.add(c); db.commit(); db.refresh(c)
    return c
