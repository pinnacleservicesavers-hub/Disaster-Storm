from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    database_url: str = Field(default="sqlite:///./s3.db")
    alert_webhook_url: str | None = None
    alert_webhook_token: str | None = None
    twilio_account_sid: str | None = None
    twilio_auth_token: str | None = None
    twilio_from: str | None = None

    class Config:
        env_file = ".env"

settings = Settings()
