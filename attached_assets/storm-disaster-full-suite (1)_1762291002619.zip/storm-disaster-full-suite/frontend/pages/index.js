import Link from "next/link";

export default function Home() {
  return (
    <div style={{ padding: 24, fontFamily: "system-ui" }}>
      <h1>Storm Disaster Contractor Suite</h1>
      <ul>
        <li><Link href="/admin/settings/smtp">/admin/settings/smtp</Link></li>
        <li><Link href="/admin/carriers">/admin/carriers</Link></li>
        <li><Link href="/contractor/claims/submit">/contractor/claims/submit</Link></li>
        <li><Link href="/legal">/legal</Link></li>
      </ul>
      <p>Set NEXT_PUBLIC_API_BASE in <code>.env.local</code> (default: http://localhost:8000)</p>
    </div>
  );
}
