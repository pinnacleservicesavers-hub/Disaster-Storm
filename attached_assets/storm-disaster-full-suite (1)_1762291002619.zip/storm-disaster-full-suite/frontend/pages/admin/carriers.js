import { useState, useEffect } from "react";
const API = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";

export default function Carriers() {
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ name: "", inbox_email: "", portal_url: "" });
  const reload = async () => {
    const res = await fetch(`${API}/admin/carriers`);
    const data = await res.json();
    setList(data.carriers || []);
  };
  useEffect(() => { reload(); }, []);
  const save = async () => {
    await fetch(`${API}/admin/carriers`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setForm({ name: "", inbox_email: "", portal_url: "" });
    reload();
  };
  return (
    <div style={{ padding: 24 }}>
      <h2>Carrier Directory</h2>
      <div style={{ display: "grid", gap: 8, maxWidth: 420 }}>
        <input placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
        <input placeholder="Inbox Email" value={form.inbox_email} onChange={e=>setForm({...form, inbox_email:e.target.value})} />
        <input placeholder="Portal URL" value={form.portal_url} onChange={e=>setForm({...form, portal_url:e.target.value})} />
        <button onClick={save}>Save/Update</button>
      </div>
      <h3>Current Carriers</h3>
      <ul>
        {list.map(c => <li key={c.name}>{c.name} — {c.inbox_email} {c.portal_url ? (<a href={c.portal_url} target="_blank" rel="noreferrer">(portal)</a>) : null}</li>)}
      </ul>
    </div>
  );
}
