import { useState, useEffect } from "react";

const API = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";

export default function SMTPSettings() {
  const [form, setForm] = useState({ host: "", port: 587, username: "", password: "", from_email: "" });
  const [status, setStatus] = useState("");

  useEffect(() => {
    fetch(`${API}/admin/settings/smtp`).then(r => r.json()).then(setForm).catch(()=>{});
  }, []);

  const save = async () => {
    const res = await fetch(`${API}/admin/settings/smtp`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setStatus(data.status || JSON.stringify(data));
  };

  return (
    <div style={{ padding: 24 }}>
      <h2>SMTP Settings</h2>
      {["host","port","username","password","from_email"].map(k => (
        <div key={k} style={{ marginBottom: 8 }}>
          <label style={{ display: "block" }}>{k}</label>
          <input type={k==="password"?"password":"text"} value={form[k]||""} onChange={e => setForm({ ...form, [k]: e.target.value })} />
        </div>
      ))}
      <button onClick={save}>Save</button>
      <div>{status}</div>
    </div>
  );
}
