import { useEffect, useState } from "react";

const API = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";

export default function SubmitClaim() {
  const [carriers, setCarriers] = useState([]);
  const [carrierEmail, setCarrierEmail] = useState("");
  const [jobId, setJobId] = useState("A1");
  const [status, setStatus] = useState("");
  const [packetPath, setPacketPath] = useState("");
  const [homeowner, setHomeowner] = useState("John Homeowner");
  const [address, setAddress] = useState("123 Main St");
  const [email, setEmail] = useState("homeowner@example.com");
  const [phone, setPhone] = useState("555-555-5555");
  const [summary, setSummary] = useState("Hail damage to roof and gutters.");

  useEffect(() => {
    fetch(`${API}/admin/carriers`).then(r=>r.json()).then(d=>setCarriers(d.carriers||[]));
  }, []);

  const importInvoice = async (file) => {
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch(`${API}/invoice/import`, { method: "POST", body: fd });
    return res.json();
  };

  const xactimateCompare = async (file) => {
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch(`${API}/xactimate/compare`, { method: "POST", body: fd });
    return res.json();
  };

  const onInvoice = async (e) => {
    const info = await importInvoice(e.target.files[0]);
    setStatus(`Imported ${info.count} items, subtotal $${(info.sum||0).toFixed(2)}`);
  };

  const onXact = async (e) => {
    const info = await xactimateCompare(e.target.files[0]);
    setStatus(`Variance ${info.variance_pct?.toFixed(1)}% — ${info.narrative}`);
  };

  const genPacket = async () => {
    const res = await fetch(`${API}/claims/packet`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ job_id: jobId, carrier_name: "", homeowner, address, phone, email, summary })
    });
    const data = await res.json();
    setPacketPath(data.pdf_path);
    setStatus("Packet generated");
  };

  const autopost = async () => {
    const res = await fetch(`${API}/claims/autopost`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ job_id: jobId, carrier_email: carrierEmail, subject: "Claim Packet", body: "See attached." })
    });
    const data = await res.json();
    setStatus(data.status || JSON.stringify(data));
  };

  return (
    <div style={{ padding: 24 }}>
      <h2>Submit Claim</h2>
      <div style={{ display:"grid", gap:8, maxWidth:520 }}>
        <label>Job ID <input value={jobId} onChange={e=>setJobId(e.target.value)} /></label>
        <label>Homeowner <input value={homeowner} onChange={e=>setHomeowner(e.target.value)} /></label>
        <label>Address <input value={address} onChange={e=>setAddress(e.target.value)} /></label>
        <label>Email <input value={email} onChange={e=>setEmail(e.target.value)} /></label>
        <label>Phone <input value={phone} onChange={e=>setPhone(e.target.value)} /></label>
        <label>Summary <input value={summary} onChange={e=>setSummary(e.target.value)} /></label>

        <div>
          <div>Import Invoice CSV</div>
          <input type="file" accept=".csv" onChange={onInvoice} />
        </div>
        <div>
          <div>Upload Xactimate CSV</div>
          <input type="file" accept=".csv" onChange={onXact} />
        </div>

        <button onClick={genPacket}>Download Packet</button>
        {packetPath && <div>Packet created on server: <code>{packetPath}</code></div>}

        <div>
          <div>Carrier</div>
          <select value={carrierEmail} onChange={e=>setCarrierEmail(e.target.value)}>
            <option value="">-- choose --</option>
            {carriers.map(c => <option key={c.name} value={c.inbox_email}>{c.name} ({c.inbox_email})</option>)}
          </select>
        </div>
        <button onClick={autopost} disabled={!carrierEmail}>Auto-post to carrier</button>

        <div style={{ marginTop: 8, fontStyle:"italic" }}>{status}</div>
      </div>
    </div>
  );
}
