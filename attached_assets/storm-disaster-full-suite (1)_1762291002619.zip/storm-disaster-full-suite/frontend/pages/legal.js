import { useState } from "react";
const API = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";

export default function Legal() {
  const [state, setState] = useState("TX");
  const [data, setData] = useState(null);
  const load = async () => {
    const res = await fetch(`${API}/legal/state/${state}`);
    const json = await res.json();
    setData(json);
  };
  const save = async () => {
    const res = await fetch(`${API}/legal/upsert`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    alert((await res.json()).status || "saved");
  };
  return (
    <div style={{ padding: 24 }}>
      <h2>State Legal Guardrails</h2>
      <input value={state} onChange={e=>setState(e.target.value.toUpperCase())} style={{ width: 80 }} />
      <button onClick={load}>Load</button>
      {data && (
        <div style={{ marginTop: 12 }}>
          <label>Notes</label>
          <textarea rows={6} cols={60} value={data.notes||""} onChange={e=>setData({...data, notes:e.target.value})} />
          <div>
            <label>
              <input type="checkbox" checked={!!data.counsel_approved} onChange={e=>setData({...data, counsel_approved:e.target.checked})} />
              Counsel Approved
            </label>
          </div>
          <button onClick={save}>Save</button>
        </div>
      )}
    </div>
  );
}
