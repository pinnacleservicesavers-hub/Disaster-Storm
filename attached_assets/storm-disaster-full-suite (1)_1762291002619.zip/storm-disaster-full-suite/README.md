# Storm Disaster Full Suite (Contractor-First)

This zip is a runnable scaffold implementing the features you described:

- Real email **autopost** to carriers
- **Invoice CSV import** (`POST /invoice/import`)
- **Xactimate compare** with generated narrative (`POST /xactimate/compare`)
- **State legal guardrails** (GET/POST)
- **Carrier directory admin**
- Claim packet PDF generation + **Auto-post via SMTP**

> This is a functional starter you can extend. Security/auth, persistence, and rich UI are intentionally minimal for fast local testing.

## How to Run

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm i
echo "NEXT_PUBLIC_API_BASE=http://localhost:8000" > .env.local
npm run dev
```

## Quick Test
1. Go to `http://localhost:3000/admin/settings/smtp` and enter SMTP credentials.
2. Add a carrier at `/admin/carriers`.
3. Visit `/contractor/claims/submit`:
   - Import an invoice CSV (columns: `desc,qty,price`).
   - (Optional) Upload Xactimate CSV to see variance + narrative.
   - Click **Download Packet** to generate a claim PDF on the server.
   - Choose a carrier and click **Auto-post to carrier** to email the PDF.

## Endpoints
- `GET /admin/settings/smtp`, `POST /admin/settings/smtp`
- `GET /admin/carriers`, `POST /admin/carriers`
- `GET /legal/state/{STATE}`
- `POST /legal/upsert`
- `POST /invoice/import` (CSV: `desc,qty,price`)
- `POST /xactimate/compare` (CSV: `desc,qty,price`)
- `POST /claims/packet`
- `POST /claims/autopost`

## Roadmap Hooks (stubs)
- `POST /hooks/sms/test` – integrate Twilio/AWS SNS.
- `POST /hooks/photo/label` – filename heuristic; replace with ML model.

---

**Note:** This scaffold writes data to `backend/data/*.json` and PDFs to the same folder. For production, swap to a database, add auth/roles, and harden SMTP handling.
