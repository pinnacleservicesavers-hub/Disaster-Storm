async function fetchJobs(){ const r = await fetch('/api/jobs'); return r.json(); }
function jobCard(j){
  return `<div class="group">
    <div><b>${j.customer_name||'Unnamed'}</b> — ${j.address||''} ${j.city||''}, ${j.state||''}</div>
    <div class="row" style="margin-top:6px;">
      <a href="/annotate?job=${j.id}" style="background:#2b3b64;color:#fff;padding:6px 8px;border-radius:6px;">Annotate</a>
      <a href="/media?job=${j.id}" style="background:#2b3b64;color:#fff;padding:6px 8px;border-radius:6px;">Media</a>
      <button onclick="exportPDF('${j.id}')">Export PDF</button>
      <button onclick="exportZIP('${j.id}')">Export ZIP</button>
      <button onclick="emailPacket('${j.id}')">Email Packet</button>
      <label style="margin-left:auto">Upload<input type="file" onchange="uploadFile('${j.id}', this.files[0])"></label>
    </div>
  </div>`;
}
async function exportPDF(id){ window.open('/api/jobs/'+id+'/export/packet.pdf','_blank'); }
async function exportZIP(id){ window.open('/api/jobs/'+id+'/export/packet.zip','_blank'); }
async function emailPacket(id){
  const to = prompt("Adjuster email (To:)");
  const cc = prompt("CC (comma-separated, optional)") || "";
  const includeZip = confirm("Attach ZIP with originals too?");
  const subject = prompt("Subject (optional)", "Emergency Tree Service — Claim Packet");
  const message = prompt("Message (optional)", "Please find the claim packet attached.");
  const r = await fetch('/api/jobs/'+id+'/email-claim-packet', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ to, cc: cc.split(',').map(s=>s.trim()).filter(Boolean), include_zip: includeZip, subject, message })
  });
  const data = await r.json();
  alert(data.ok ? "Sent." : JSON.stringify(data));
}
async function uploadFile(id, file){
  const fd = new FormData(); fd.append('file', file);
  const annotated = (file.name.toLowerCase().includes('annotated')) ? '?annotated=1' : '';
  const r = await fetch('/api/jobs/'+id+'/upload'+annotated, { method:'POST', body: fd });
  const data = await r.json(); if (data.ok) alert("Uploaded"); else alert(JSON.stringify(data));
}
async function createJob(){
  const body = {
    customer_name: document.getElementById('cname').value,
    phone: document.getElementById('cphone').value,
    email: document.getElementById('cemail').value,
    address: document.getElementById('caddr').value,
    city: document.getElementById('ccity').value,
    state: document.getElementById('cstate').value,
    zip: document.getElementById('czip').value,
    status: 'estimate'
  };
  const r = await fetch('/api/jobs', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const data = await r.json(); if (data.id) render(); else alert(JSON.stringify(data));
}
document.getElementById('createJob').addEventListener('click', createJob);
async function render(){ const jobs = await fetchJobs(); document.getElementById('jobs').innerHTML = jobs.map(jobCard).join(""); }
render();
