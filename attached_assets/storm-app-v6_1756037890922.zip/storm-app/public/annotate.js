const canvas = new fabric.Canvas('c', { isDrawingMode:false });
let drawing = false;

async function loadImage(){
  const url = document.getElementById('imgUrl').value;
  if (!url) return alert("Enter Image URL");
  fabric.Image.fromURL(url, img => {
    const scale = Math.min(900/img.width, 600/img.height);
    img.scale(scale);
    canvas.clear();
    canvas.add(img);
    canvas.sendToBack(img);
    canvas.renderAll();
  }, { crossOrigin: 'anonymous' });
}
function addText(){
  const text = prompt("Text");
  if (!text) return;
  const t = new fabric.Textbox(text, { left:50, top:50, fill:'#ffd23f', fontSize:20, fontWeight:'bold' });
  canvas.add(t).setActiveObject(t);
}
function toggleDraw(){
  drawing = !drawing;
  canvas.isDrawingMode = drawing;
  canvas.freeDrawingBrush.width = 4;
  canvas.freeDrawingBrush.color = '#ff4757';
}
async function save(){
  const jobId = new URLSearchParams(location.search).get('job') || document.getElementById('jobId').value;
  if (!jobId) return alert("Enter Job ID (or pass ?job=)");
  const dataUrl = canvas.toDataURL({ format:'png', quality: 0.92 });
  const blob = await (await fetch(dataUrl)).blob();
  const fd = new FormData(); fd.append('file', blob, 'annotated.png');
  const r = await fetch('/api/jobs/'+jobId+'/upload?annotated=1', { method:'POST', body: fd });
  const d = await r.json();
  if (d.ok) alert("Annotated image saved to job"); else alert(JSON.stringify(d));
}
window.loadImage = loadImage;
window.addText = addText;
window.toggleDraw = toggleDraw;
window.save = save;
