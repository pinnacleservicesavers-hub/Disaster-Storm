import express from "express";
import cors from "cors";
import axios from "axios";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import PDFDocument from "pdfkit";
import dayjs from "dayjs";
import archiver from "archiver";
import { createClient } from "@supabase/supabase-js";
import Stripe from "stripe";
import * as Sign from "@dropbox/sign";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
const stripe = new Stripe(process.env.STRIPE_SECRET || "", { apiVersion: "2023-10-16" });
const signClient = new Sign.SignatureRequestApi();
Sign.Configuration.username = process.env.DROPBOX_SIGN_KEY || "";

// ---------------- Basic -----------------
app.get("/health", (_, res) => res.json({ ok: true, time: new Date().toISOString() }));

// ---------------- Jobs ------------------
app.get("/api/jobs/:id", async (req, res) => {
  const id = req.params.id;
  const { data: job, error } = await supabase.from("jobs").select("*").eq("id", id).single();
  if (error) return res.status(404).json({ error: "Not found" });
  const { data: artifacts } = await supabase.from("artifacts").select("*").eq("job_id", id).order("created_at", { ascending:true });
  res.json({ ...job, artifacts: artifacts || [] });
});
app.get("/api/jobs", async (req, res) => {
  const { data, error } = await supabase.from("jobs").select("*").order("created_at", { ascending:false }).limit(200);
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});
app.post("/api/jobs", async (req, res) => {
  const { data, error } = await supabase.from("jobs").insert(req.body).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ---------------- Uploads ----------------
import * as exifr from "exifr";
const upload = multer({ storage: multer.memoryStorage() });
app.post("/api/jobs/:id/upload", upload.single("file"), async (req, res) => {
  try {
    const jobId = req.params.id;
    if (!req.file) return res.status(400).json({ error: "file required" });
    const bucket = process.env.SUPABASE_BUCKET || "artifacts";
    const ext = (req.file.originalname || "file").split(".").pop();
    const key = `${jobId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { error: upErr } = await supabase.storage.from(bucket).upload(key, req.file.buffer, { contentType: req.file.mimetype });
    if (upErr) return res.status(500).json({ error: upErr.message });
    const { data: pub } = await supabase.storage.from(bucket).getPublicUrl(key);

    // Decide kind
    let kind = req.file.mimetype.startsWith("video") ? "video" : "photo";
    if ((req.query.annotated === "1") || (req.file.originalname||"").toLowerCase().includes("annotated"))
      kind = "photo_annotated";

    // EXIF GPS
    let lat=null, lon=null;
    try {
      if (req.file.mimetype.startsWith("image/")) {
        const data = await exifr.parse(req.file.buffer, { gps: true });
        if (data && data.latitude && data.longitude) { lat=data.latitude; lon=data.longitude; }
      }
    } catch {}

    await supabase.from("artifacts").insert({ job_id: jobId, kind, url_or_text: pub.publicUrl, lat, lon });
    res.json({ ok:true, url: pub.publicUrl, kind, lat, lon });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------------- Media grouping ----------------
app.get("/api/jobs/:id/artifacts-by-location", async (req, res) => {
  const { data: arts, error } = await supabase.from("artifacts").select("id,kind,url_or_text,lat,lon,created_at").eq("job_id", req.params.id);
  if (error) return res.status(500).json({ error: error.message });
  const groups = {};
  for (const a of (arts||[])) {
    const lat = (a.lat==null) ? null : Math.round(a.lat*1000)/1000;
    const lon = (a.lon==null) ? null : Math.round(a.lon*1000)/1000;
    const key = (lat!=null && lon!=null) ? `${lat},${lon}` : "unknown";
    groups[key] = groups[key] || { key, lat, lon, items: [] };
    groups[key].items.push(a);
  }
  res.json(Object.values(groups));
});

// ---------------- AI helpers (stubs preserved) ----------------
app.post("/api/media/describe", async (req, res) => {
  // integrate your vision model here if desired (omitted for brevity in v6)
  res.json({ text: "Annotated: visible tree impact on roof decking, splintering at ridge, possible sheathing displacement." });
});

// ---------------- Claim Packet PDF ----------------
async function buildPacketPDF(jobId){
  const { data: job } = await supabase.from("jobs").select("*").eq("id", jobId).single();
  const { data: arts } = await supabase.from("artifacts").select("*").eq("job_id", jobId).order("created_at", { ascending:true });
  const photos = (arts||[]).filter(a => a.kind === "photo");
  const annotated = (arts||[]).filter(a => a.kind === "photo_annotated");
  const others = (arts||[]).filter(a => !["photo","photo_annotated"].includes(a.kind));

  const tmp = path.join(__dirname, `packet-${jobId}.pdf`);
  const doc = new PDFDocument({ margin: 36 });
  const stream = fs.createWriteStream(tmp);
  doc.pipe(stream);

  doc.fontSize(18).text("Emergency Tree Service — Claim Packet", { align: "center" });
  doc.moveDown();
  doc.fontSize(12).text(`Customer: ${job.customer_name||""}`);
  doc.text(`Address: ${job.address||""} ${job.city||""}, ${job.state||""} ${job.zip||""}`);
  doc.text(`Claim #: ${job.claim_number||"—"}`);
  if (job.completion_date) doc.text(`Completion: ${job.completion_date}`);

  doc.moveDown().fontSize(14).text("Timeline", { underline: true });
  (arts||[]).forEach((a,i)=>{
    const loc = (a.lat!=null && a.lon!=null) ? ` @ (${a.lat.toFixed(5)}, ${a.lon.toFixed(5)})` : "";
    doc.fontSize(11).text(`${i+1}. [${dayjs(a.created_at).format("YYYY-MM-DD HH:mm")}] ${a.kind}${loc}: ${a.url_or_text?.slice(0,140)}`);
  });

  // Annotated first
  if (annotated.length){
    doc.addPage().fontSize(16).text("Annotated Photos", { underline: true });
    for (const a of annotated){
      try {
        const r = await axios.get(a.url_or_text, { responseType:"arraybuffer" });
        const img = Buffer.from(r.data);
        doc.addPage().fontSize(10).text(`${dayjs(a.created_at).format("YYYY-MM-DD HH:mm")} — Annotated`, { align:"left" });
        doc.image(img, { fit:[520, 700], align:"center" });
      } catch {}
    }
  }

  // Original photos
  if (photos.length){
    doc.addPage().fontSize(16).text("Original Photos", { underline: true });
    for (const a of photos){
      try {
        const r = await axios.get(a.url_or_text, { responseType:"arraybuffer" });
        const img = Buffer.from(r.data);
        doc.addPage().fontSize(10).text(`${dayjs(a.created_at).format("YYYY-MM-DD HH:mm")}`, { align:"left" });
        doc.image(img, { fit:[520, 700], align:"center" });
      } catch {}
    }
  }

  doc.end();
  await new Promise(r => stream.on("finish", r));
  return tmp;
}

app.get("/api/jobs/:id/export/packet.pdf", async (req, res) => {
  try {
    const pdfPath = await buildPacketPDF(req.params.id);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename=claim-packet-${req.params.id}.pdf`);
    fs.createReadStream(pdfPath).pipe(res).on("finish", () => fs.unlink(pdfPath, ()=>{}));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------------- ZIP Export (PDF + originals) --------------
async function buildPacketZIP(jobId){
  const pdfPath = await buildPacketPDF(jobId);
  const { data: arts } = await supabase.from("artifacts").select("*").eq("job_id", jobId);
  const tmpZip = path.join(__dirname, `packet-${jobId}.zip`);
  const output = fs.createWriteStream(tmpZip);
  const archive = archiver("zip", { zlib: { level: 9 } });
  archive.pipe(output);

  // Add PDF
  archive.file(pdfPath, { name: `claim-packet-${jobId}.pdf` });

  // Add media
  let idx = 1;
  for (const a of (arts||[])){
    if (a.url_or_text && (a.kind === "photo" || a.kind === "photo_annotated" || a.kind === "video" || a.kind === "doc")){
      try {
        const r = await axios.get(a.url_or_text, { responseType:"arraybuffer" });
        const extGuess = a.kind === "video" ? "mp4" : (a.kind === "doc" ? "pdf" : "jpg");
        archive.append(Buffer.from(r.data), { name: `media/${String(idx).padStart(3,"0")}-${a.kind}.${extGuess}` });
        idx++;
      } catch {}
    }
  }

  await archive.finalize();
  await new Promise(r => output.on("close", r));
  try { fs.unlinkSync(pdfPath); } catch {}
  return tmpZip;
}

app.get("/api/jobs/:id/export/packet.zip", async (req, res) => {
  try {
    const zipPath = await buildPacketZIP(req.params.id);
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename=claim-packet-${req.params.id}.zip`);
    fs.createReadStream(zipPath).pipe(res).on("finish", () => fs.unlink(zipPath, ()=>{}));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------------- Email Claim Packet (SendGrid) -------------
app.post("/api/jobs/:id/email-claim-packet", async (req, res) => {
  try {
    const sgKey = process.env.SENDGRID_API_KEY;
    const fromEmail = process.env.SENDGRID_FROM || "no-reply@example.com";
    if (!sgKey) return res.status(400).json({ error: "SENDGRID_API_KEY not set" });
    const { to, cc = [], include_zip = false, subject, message } = req.body || {};
    if (!to) return res.status(400).json({ error: "to required" });

    // Build attachments
    const pdfPath = await buildPacketPDF(req.params.id);
    const pdfB64 = fs.readFileSync(pdfPath).toString("base64");
    const attachments = [{
      content: pdfB64,
      filename: `claim-packet-${req.params.id}.pdf`,
      type: "application/pdf",
      disposition: "attachment"
    }];
    let zipPath=null;
    if (include_zip){
      zipPath = await buildPacketZIP(req.params.id);
      const zipB64 = fs.readFileSync(zipPath).toString("base64");
      attachments.push({
        content: zipB64,
        filename: `claim-packet-${req.params.id}.zip`,
        type: "application/zip",
        disposition: "attachment"
      });
    }

    await axios.post("https://api.sendgrid.com/v3/mail/send", {
      personalizations: [{ to: [{ email: to }], cc: (cc||[]).map(e => ({ email: e })) }],
      from: { email: fromEmail, name: "Storm Claims" },
      subject: subject || "Emergency Tree Service — Claim Packet",
      content: [{ type: "text/plain", value: message || "Please find the claim packet attached." }],
      attachments
    }, { headers: { Authorization: `Bearer ${sgKey}` } });

    try { fs.unlinkSync(pdfPath); } catch {}
    if (zipPath) try { fs.unlinkSync(zipPath); } catch {}

    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------------- Pages ----------------
app.get("/", (_, res) => res.sendFile(path.join(__dirname, "..", "public", "dashboard.html")));
app.get("/jobs", (_, res) => res.sendFile(path.join(__dirname, "..", "public", "jobs.html")));
app.get("/annotate", (_, res) => res.sendFile(path.join(__dirname, "..", "public", "annotate.html")));
app.get("/media",   (_, res) => res.sendFile(path.join(__dirname, "..", "public", "media.html")));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Storm App v6 running on :"+PORT));
