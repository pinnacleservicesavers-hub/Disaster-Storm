# SLM Storm App v6 — Annotated-in-PDF, ZIP Export, Email Claim Packet

**New in v6**
- **Annotated photos appear in the Claim Packet PDF** (separate section before originals).
- **Export ZIP** with PDF + all media (photos, annotated photos, videos, docs).
- **Email Claim Packet** via **SendGrid**: `/api/jobs/:id/email-claim-packet` attaches the PDF (and ZIP, optional).

**New ENV vars**
```
SENDGRID_API_KEY=SG.xxxxxx
SENDGRID_FROM=claims@yourdomain.com
```
(Keep all env vars from earlier versions.)

**Endpoints**
- `GET /api/jobs/:id/export/packet.pdf` → PDF with **Annotated Photos** + **Original Photos**.
- `GET /api/jobs/:id/export/packet.zip` → PDF + all media files zipped.
- `POST /api/jobs/:id/email-claim-packet`
```json
{
  "to": "adjuster@example.com",
  "cc": ["pm@example.com"],
  "include_zip": true,
  "subject": "Emergency Tree Service — Claim Packet",
  "message": "Please find the claim packet attached."
}
```

**Jobs UI buttons** (in `/jobs`):
- **Export PDF**, **Export ZIP**, **Email Packet**

**Annotated photo detection**
- Uploads with filename containing `annotated` or `?annotated=1` are saved as kind=`photo_annotated`.
- PDF puts annotated images first.

**Notes**
- ZIP downloads each artifact by its public URL—make sure your Supabase Storage bucket allows public access for artifacts you want shared.
- For very large jobs, consider pruning image count or splitting ZIPs.
