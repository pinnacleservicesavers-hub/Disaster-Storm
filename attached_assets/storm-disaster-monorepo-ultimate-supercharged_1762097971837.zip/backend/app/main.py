from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Storm Disaster Agentic API", version="0.2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# Dummy includes will be appended when available

from .routers import export, claims_letters, contract_compose, admin
app.include_router(export.router, tags=["export"])
app.include_router(claims_letters.router, tags=["letters"])
app.include_router(contract_compose.router, tags=["contracts"])
app.include_router(admin.router, tags=["admin"])
