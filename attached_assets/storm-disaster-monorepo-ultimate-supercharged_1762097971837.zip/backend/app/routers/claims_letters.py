from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store
from datetime import datetime

router = APIRouter()

class LetterBody(BaseModel):
    job_id: str
    type: str  # 'late' or 'demand60'

def _gen_late(job_id: str):
    inv = next((v for v in store.invoices.values() if v.get("job_id")==job_id), None)
    total = 0.0
    if inv:
        for v in inv.get("breakdown", {}).values():
            try: total += float(v)
            except: pass
    return f"""Subject: Notice of Past Due Payment — Job {job_id}

Per the contract and completion of work, payment of ${total:,.2f} is past due. Please remit payment immediately.
If already paid, send confirmation.

Regards,
Storm Disaster Contractor Support
"""

def _gen_demand60(job_id: str):
    inv = next((v for v in store.invoices.values() if v.get("job_id")==job_id), None)
    total = 0.0
    if inv:
        for v in inv.get("breakdown", {}).values():
            try: total += float(v)
            except: pass
    return f"""Subject: 60-Day Demand — Intent to File Lien — Job {job_id}

Formal demand for payment of ${total:,.2f}. If not received within ten (10) days, Contractor may file a lien and pursue remedies.

Sincerely,
Storm Disaster Contractor Support
"""

@router.post("/claims/letters/generate")
def generate_letter(body: LetterBody):
    text = _gen_late(body.job_id) if body.type == "late" else _gen_demand60(body.job_id)
    event = {"job_id": body.job_id, "kind": "letter", "letter_type": body.type, "message": text, "when": datetime.utcnow().isoformat()}
    store.jobs.setdefault(body.job_id, {}).setdefault("timeline", []).append(event)
    store.jobs.setdefault(body.job_id, {}).setdefault("letters", []).append(event)
    return {"ok": True, "letter": event}

@router.get("/claims/{job_id}/letters")
def list_letters(job_id: str):
    return {"letters": store.jobs.get(job_id, {}).get("letters", [])}
