import io, json, zipfile
from fastapi import APIRouter, Response
from ..utils.pdf import html_to_pdf_bytes
from ..utils.store import store

router = APIRouter()

def build_report_html(job_id: str):
    inv = next((v for v in store.invoices.values() if v.get("job_id")==job_id), None)
    total = 0.0
    if inv:
        for v in inv.get("breakdown", {}).values():
            try: total += float(v)
            except: pass
    xact = (inv or {}).get("xactimate", {}).get("total", 0.0)
    var = total - xact
    return f"""<html><body><h1>Claim Report {job_id}</h1>
    <p>Total: ${total:,.2f} Xactimate: ${xact:,.2f} Variance: ${var:,.2f}</p></body></html>"""

@router.get("/claims/{job_id}/submission.zip")
async def submission_zip(job_id: str):
    html = build_report_html(job_id)
    pdf = html_to_pdf_bytes(html)
    manifest = {"job_id": job_id, "notes": "Auto-generated package", "letters_included": True}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"claim-report-{job_id}.pdf", pdf)
        z.writestr("manifest.json", json.dumps(manifest, indent=2))

        letters = (store.jobs.get(job_id, {}) or {}).get("letters", [])
        for i, lt in enumerate(letters, start=1):
            txt_name = f"letters/{i:02d}-{lt.get('letter_type','letter')}.txt"
            z.writestr(txt_name, lt.get("message",""))
            html_letter = f"""<html><body><pre style='white-space:pre-wrap;font-family:Arial'>{lt.get("message","")}</pre></body></html>"""
            z.writestr(f"letters/{i:02d}-{lt.get('letter_type','letter')}.pdf", html_to_pdf_bytes(html_letter))
    buf.seek(0)
    return Response(content=buf.read(), media_type="application/zip",
                    headers={"Content-Disposition": f"attachment; filename=submission-{job_id}.zip"})
