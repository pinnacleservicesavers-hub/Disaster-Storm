from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store
from datetime import datetime, timedelta
import smtplib, ssl, os
from email.message import EmailMessage

router = APIRouter()

class ScheduleBody(BaseModel):
    job_id: str
    to_emails: list[str]
    message: str | None = None
    first_in_days: int = 3
    repeat_days: int | None = 7

@router.post("/payments/reminders/schedule")
def schedule_reminder(body: ScheduleBody):
    job = store.jobs.setdefault(body.job_id, {})
    reminders = job.setdefault("reminders", [])
    due_at = (datetime.utcnow() + timedelta(days=body.first_in_days)).isoformat()
    item = {
        "id": store.new_id(),
        "to_emails": body.to_emails,
        "message": body.message or "Friendly reminder: your invoice is ready for payment.",
        "due_at": due_at,
        "repeat_days": body.repeat_days,
        "status": "scheduled"
    }
    reminders.append(item)
    job.setdefault("timeline", []).append({
        "job_id": body.job_id, "kind":"note", "message": f"Payment reminder scheduled for {due_at}", "when": datetime.utcnow().isoformat()
    })
    store.jobs[body.job_id] = job
    return {"ok": True, "reminder": item}

def _send_email(smtp_host, smtp_port, smtp_user, smtp_pass, to_list, subject, text):
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = smtp_user or "no-reply@stormdisaster.local"
    msg["To"] = ", ".join(to_list)
    msg.set_content(text)
    try:
        ctx = ssl.create_default_context()
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls(context=ctx)
            if smtp_user: server.login(smtp_user, smtp_pass)
            server.send_message(msg)
        return True, None
    except Exception as e:
        return False, str(e)

@router.post("/payments/reminders/run")
def run_reminders():
    now = datetime.utcnow().isoformat()
    sent = []
    for job_id, job in store.jobs.items():
        for r in job.get("reminders", []):
            if r["status"] == "scheduled" and r["due_at"] <= now:
                ok, err = _send_email(
                    smtp_host=os.getenv("SMTP_HOST","smtp.example.com"),
                    smtp_port=int(os.getenv("SMTP_PORT","587")),
                    smtp_user=os.getenv("SMTP_USER","user@example.com"),
                    smtp_pass=os.getenv("SMTP_PASS","pass"),
                    to_list=r["to_emails"],
                    subject=f"Payment Reminder — Job {job_id}",
                    text=r["message"]
                )
                r["status"] = "sent" if ok else f"error:{err}"
                job.setdefault("timeline", []).append({
                    "job_id": job_id, "kind":"note", "message": f"Reminder {r['id']} status: {r['status']}", "when": datetime.utcnow().isoformat()
                })
                sent.append({"job_id": job_id, "reminder_id": r["id"], "status": r["status"]})
                if r.get("repeat_days"):
                    r["due_at"] = (datetime.utcnow() + timedelta(days=r["repeat_days"])).isoformat()
                    r["status"] = "scheduled"
    return {"processed": sent}
