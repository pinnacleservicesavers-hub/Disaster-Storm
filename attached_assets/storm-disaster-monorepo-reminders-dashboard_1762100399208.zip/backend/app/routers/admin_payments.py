from fastapi import APIRouter
from ..utils.store import store

router = APIRouter()

@router.get("/admin/payments/summary")
def payments_summary():
    total_jobs=paid=unpaid=0
    total_amount=paid_amount=unpaid_amount=0.0
    rows=[]
    for job_id, job in store.jobs.items():
        total_jobs += 1
        inv = next((v for v in store.invoices.values() if v.get("job_id")==job_id), None)
        amount = 0.0
        if inv:
            for v in inv.get("breakdown", {}).values():
                try: amount += float(v)
                except: pass
        status = (job.get("payments") or {}).get("status", "unpaid")
        rows.append({"job_id": job_id, "amount": amount, "status": status})
        total_amount += amount
        if status == "paid":
            paid += 1; paid_amount += amount
        else:
            unpaid += 1; unpaid_amount += amount
    return {"totals":{"jobs":total_jobs,"amount":total_amount,"paid_jobs":paid,"paid_amount":paid_amount,"outstanding_jobs":unpaid,"outstanding_amount":unpaid_amount},"rows":rows}
