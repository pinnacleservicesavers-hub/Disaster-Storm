from fastapi import APIRouter
from pydantic import BaseModel
import smtplib, ssl, io
from email.message import EmailMessage
from ..utils.store import store
from .export import submission_zip

router = APIRouter()

class EmailBody(BaseModel):
    job_id: str
    to_email: str
    subject: str | None = None
    message: str | None = None

@router.post("/claims/submit/email")
async def send_claim_email(body: EmailBody):
    # Build ZIP in-memory
    # Reuse submission_zip to generate bytes
    resp = await submission_zip(body.job_id)
    content = resp.body if hasattr(resp, "body") else resp  # FastAPI Response has .body

    msg = EmailMessage()
    msg["Subject"] = body.subject or f"Claim Submission — Job {body.job_id}"
    msg["From"] = "no-reply@stormdisaster.local"
    msg["To"] = body.to_email
    msg.set_content(body.message or "Please find the claim submission attached.")

    msg.add_attachment(content, maintype="application", subtype="zip", filename=f"submission-{body.job_id}.zip")

    # SMTP scaffold (TLS). Replace host/user/pass with real values in your env.
    host = "smtp.example.com"; port = 587; user = "user"; password = "pass"
    context = ssl.create_default_context()
    try:
        with smtplib.SMTP(host, port) as server:
            server.starttls(context=context)
            server.login(user, password)
            server.send_message(msg)
        return {"ok": True}
    except Exception as e:
        # For development, just return ok:false
        return {"ok": False, "error": str(e)}


from pydantic import BaseModel
import smtplib, ssl, os
from email.message import EmailMessage
from ..utils.store import store
from .export import submission_zip

class EmailBothBody(BaseModel):
    job_id: str
    insurer_email: str | None = None
    homeowner_email: str | None = None
    subject: str | None = None
    message: str | None = None

@router.post("/claims/submit/email/both")
async def send_both(body: EmailBothBody):
    job = store.jobs.get(body.job_id, {})
    insurer = body.insurer_email or job.get("insurer_email")
    homeowner = body.homeowner_email or job.get("homeowner_email")
    recipients = [e for e in [insurer, homeowner] if e]
    if not recipients:
        return {"ok": False, "error": "No recipients found"}

    resp = await submission_zip(body.job_id)
    content = resp.body if hasattr(resp, "body") else resp

    ok_all = True
    errors = []
    for to in recipients:
        try:
            msg = EmailMessage()
            msg["Subject"] = body.subject or f"Claim Submission — Job {body.job_id}"
            msg["From"] = os.getenv("SMTP_USER","no-reply@stormdisaster.local")
            msg["To"] = to
            msg.set_content(body.message or "Please find the claim submission attached.")
            msg.add_attachment(content, maintype="application", subtype="zip", filename=f"submission-{body.job_id}.zip")
            host = os.getenv("SMTP_HOST","smtp.example.com"); port = int(os.getenv("SMTP_PORT","587"))
            user = os.getenv("SMTP_USER","user@example.com"); password = os.getenv("SMTP_PASS","pass")
            ctx = ssl.create_default_context()
            with smtplib.SMTP(host, port) as server:
                server.starttls(context=ctx)
                if user: server.login(user, password)
                server.send_message(msg)
        except Exception as e:
            ok_all = False
            errors.append(str(e))
    return {"ok": ok_all, "errors": errors}
