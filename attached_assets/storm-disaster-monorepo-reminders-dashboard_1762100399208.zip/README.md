

## Contractor-first Branding & Submission
- Edit branding at `/contractor/profile` (company name, logo URL, legal name, address, phone, email)
- Generated **letters** and the **cover letter** are rendered as branded PDFs (logo, contact block) and included in the Submission ZIP.
- Add `state` when generating a letter to include state-specific statutory notes: `POST /claims/letters/generate { job_id, type, state }`
- Submit package to insurer via email: `POST /claims/submit/email { job_id, to_email, subject?, message? }` (SMTP scaffold; configure your SMTP).



## Branded Invoice PDF + Pay Link
- Endpoint (create/fetch): `POST /payments/invoice/checkout { job_id }` → returns `checkout_url` (Stripe).
- Cover letter includes a **Pay now** line when a checkout URL is available.
- The **Submission ZIP** bundles **invoice-<job>.pdf**, **claim-report-<job>.pdf**, **cover-letter-<job>.pdf**, and any letters.
- UI: on the contractor job page, click **Create/Fetch Pay Link** to generate a Stripe-hosted checkout and display the URL.
- Env: `STRIPE_SECRET_KEY`, optional `STRIPE_PRICE_INVOICE`, `STRIPE_CURRENCY`, and `STRIPE_SUCCESS_URL`/`STRIPE_CANCEL_URL`.


## Stripe Hosted Invoices + Webhooks
- Create Checkout link: `POST /payments/invoice/checkout { job_id }` → returns `checkout_url`
- Create Hosted Invoice: `POST /payments/invoice/hosted { job_id, customer_email }` → returns `hosted_invoice_url`
- Webhook endpoint: `POST /payments/stripe/webhook`
  - Set env: `STRIPE_WEBHOOK_SECRET` (and `STRIPE_SECRET_KEY`, `STRIPE_CURRENCY`)
  - Marks job `payments.status = "paid"` on `checkout.session.completed` or `invoice.paid`
- Invoice PDFs automatically display a **PAID** badge when status is paid (via webhook or manual update).



## Payment Reminders
- Schedule: `POST /payments/reminders/schedule { job_id, to_emails:[...], first_in_days, repeat_days? }`
- Run (cron): `POST /payments/reminders/run` — sends emails and reschedules if repeat_days set.
  - SMTP env: `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`

## Email ZIP to insurer + homeowner
- `POST /claims/submit/email/both { job_id, insurer_email?, homeowner_email?, subject?, message? }`
- Uses job fields if emails omitted: `jobs[job_id].insurer_email` / `homeowner_email`.

## Admin Paid vs Outstanding Dashboard
- API: `GET /admin/payments/summary`
- UI: `/admin/command-center` shows totals and each job row with status.
