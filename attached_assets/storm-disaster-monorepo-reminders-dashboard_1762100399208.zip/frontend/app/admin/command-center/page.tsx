"use client";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";

export default function AdminCenter(){
  const [summary, setSummary] = useState<any>();
  useEffect(()=>{ api("/admin/payments/summary").then(setSummary); },[]);
  if(!summary) return <main className="p-8">Loading...</main>;
  const t = summary.totals;
  return (
    <main className="p-8 max-w-5xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Admin Command Center</h1>
      <section className="grid grid-cols-3 gap-4">
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Total $</div><div className="text-2xl font-semibold">${t.amount.toFixed(2)}</div></div>
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Paid $</div><div className="text-2xl font-semibold">${t.paid_amount.toFixed(2)}</div></div>
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Outstanding $</div><div className="text-2xl font-semibold">${t.outstanding_amount.toFixed(2)}</div></div>
      </section>
      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Payments</h2>
        <div className="border rounded">
          {summary.rows.map((r:any)=>(
            <div key={r.job_id} className="p-3 border-b flex items-center justify-between">
              <div>Job {r.job_id}</div>
              <div>${r.amount.toFixed(2)}</div>
              <div className={r.status==="paid"?"text-green-700":"text-yellow-700"}>{r.status}</div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
