import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import pino from 'pino';
import pinoHttp from 'pino-http';

import { reverseGeocode } from './services/geocode.js';
import { getParcelByPoint, getOwnerByAddress } from './services/parcel.js';
import { verifyContact } from './services/enrich.js';
import { getSupabase } from './services/supabase.js';
import { stringify } from 'fast-csv';
import { createPresignedUpload } from './services/upload.js';
import { startOptIn, confirmOptIn, sendIfOptedIn } from './services/sms.js';
import { getLineTemplate, getScopeNotes } from './services/xactimate.js';

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('tiny'));

const logger = pino();
app.use(pinoHttp({ logger }));

app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    message: 'Storm Owner Lookup Service',
    endpoints: ['/lookup?lat=..&lon=..', '/owner-by-address?address=..', '/verify-contact (POST)']
  });
});

// 1) GPS -> Address -> Parcel/Owner
app.get('/lookup', async (req, res) => {
  try {
    const { lat, lon } = req.query;
    if (!lat || !lon) return res.status(400).json({ error: 'lat and lon are required' });

    const geo = await reverseGeocode(lat, lon);
    if (!geo?.address) return res.status(404).json({ error: 'Address not found for provided coordinates', geo });

    // Try Regrid point lookup first
    let parcel = null;
    try {
      parcel = await getParcelByPoint(lat, lon);
    } catch (e) {
      req.log.warn({ err: e }, 'Regrid lookup failed');
    }

    // Fallback: ATTOM by address if no parcel/owner found
    let attomOwner = null;
    if (!parcel?.owner_name && process.env.ATTOM_API_KEY) {
      try {
        attomOwner = await getOwnerByAddress(geo.address);
      } catch (e) {
        req.log.warn({ err: e }, 'ATTOM lookup failed');
      }
    }

    const result = {
      input: { lat, lon },
      address: geo.address,
      geocode_meta: geo.meta,
      parcel: parcel ? {
        apn: parcel.apn,
        situs_address: parcel.situs_address,
        owner_name: parcel.owner_name,
        owner_mailing_address: parcel.owner_mailing_address,
        source: parcel.source
      } : null,
      attom_owner: attomOwner,
      retrieved_at: new Date().toISOString()
    };

    res.json(result);
  } catch (err) {
    req.log.error({ err }, 'Lookup error');
    res.status(500).json({ error: 'Internal error', details: err.message });
  }
});

// 2) Owner by address (direct ATTOM path)
app.get('/owner-by-address', async (req, res) => {
  try {
    const { address } = req.query;
    if (!address) return res.status(400).json({ error: 'address is required' });
    const attomOwner = await getOwnerByAddress(address);
    res.json({ address, attom_owner: attomOwner, retrieved_at: new Date().toISOString() });
  } catch (err) {
    res.status(500).json({ error: 'Internal error', details: err.message });
  }
});

// 3) Verify/append contact (Melissa). POST JSON: { name, address, phone, email }
app.post('/verify-contact', async (req, res) => {
  try {
    const payload = req.body || {};
    const verified = await verifyContact(payload);
    res.json({ input: payload, verified, retrieved_at: new Date().toISOString() });
  } catch (err) {
    res.status(500).json({ error: 'Internal error', details: err.message });
  }
});



// 4) Glide webhook: POST JSON { lat, lon, media: [{url,type}], notes, crew_id, verify:bool, address?:string }
app.post('/webhooks/glide', async (req, res) => {
  try {
    const { lat, lon, media = [], notes = '', crew_id = null, verify = false, address: addrOverride = null } = req.body || {};
    if (!lat || !lon) return res.status(400).json({ error: 'lat & lon required' });

    const supabase = getSupabase();

    // Reverse geocode and parcel/owner
    const geo = addrOverride ? { address: addrOverride, meta: { provider: 'client' } } : await reverseGeocode(lat, lon);
    const parcel = await getParcelByPoint(lat, lon).catch(() => null);
    let owner = parcel?.owner_name ? parcel : null;

    if (!owner && process.env.ATTOM_API_KEY) {
      owner = await getOwnerByAddress(geo.address).catch(() => null);
    }

    // Optional verify append
    let verified = null;
    if (verify && (process.env.MELISSA_API_KEY)) {
      const name = owner?.owner_name || null;
      verified = await verifyContact({ name, address: geo.address });
    }

    // Upsert into Supabase
    const leadPayload = {
      status: 'new',
      lat: parseFloat(lat),
      lon: parseFloat(lon),
      address: geo.address || null,
      notes,
      crew_id
    };
    const { data: leadRows, error: leadErr } = await supabase.from('leads').insert(leadPayload).select();
    if (leadErr) throw leadErr;
    const lead = leadRows[0];

    const propertyPayload = {
      lead_id: lead.id,
      apn: owner?.apn || parcel?.apn || null,
      situs_address: owner?.situs_address || parcel?.situs_address || geo.address || null,
      owner_name: owner?.owner_name || null,
      owner_mailing_address: owner?.owner_mailing_address || null,
      source: owner?.source?.provider || parcel?.source?.provider || geo?.meta?.provider || null
    };
    await supabase.from('properties').insert(propertyPayload);

    if (Array.isArray(media) && media.length) {
      const mediaRows = media.map((m) => ({
        lead_id: lead.id,
        url: m.url,
        kind: m.type || 'photo'
      }));
      await supabase.from('media').insert(mediaRows);
    }

    res.json({
      ok: true,
      lead_id: lead.id,
      address: geo.address,
      property: propertyPayload,
      verified: verified ? verified.parsed : null
    });
  } catch (err) {
    res.status(500).json({ error: 'Webhook error', details: err.message });
  }
});

// 5) Xactimate-friendly CSV export for a lead list. POST body: { leads: [ {address, owner_name, phone, email, notes, claim_number} ] }
app.post('/export/xactimate.csv', async (req, res) => {
  try {
    const leads = Array.isArray(req.body?.leads) ? req.body.leads : [];
    if (!leads.length) return res.status(400).json({ error: 'No leads provided' });

    // Map to simple claim/insured CSV that can be opened and copy-pasted into Claim Info
    const headers = [
      'ClaimNumber','InsuredFirstName','InsuredLastName','LossAddress','LossCity','LossState','LossZip',
      'PrimaryPhone','Email','LossDescription'
    ];

    const rows = leads.map((l) => {
      const nameParts = (l.owner_name || '').split(' ');
      const first = nameParts.slice(0, -1).join(' ') || '';
      const last = nameParts.slice(-1).join(' ') || '';
      const addr = (l.address || '').split(',');
      const line1 = addr[0] || '';
      const city = (addr[1] || '').trim();
      const stateZip = (addr[2] || '').trim().split(' ');
      const state = stateZip[0] || '';
      const zip = stateZip[1] || '';
      return [
        l.claim_number || '',
        first,
        last,
        line1,
        city,
        state,
        zip,
        l.phone || '',
        l.email || '',
        l.notes || ''
      ];
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="xactimate_export.csv"');

    // Stream CSV
    res.write(headers.join(',') + '\n');
    for (const r of rows) {
      // naive CSV escaping
      const esc = r.map(v => `"${String(v).replace(/"/g, '""')}"`);
      res.write(esc.join(',') + '\n');
    }
    res.end();
  } catch (err) {
    res.status(500).json({ error: 'Export error', details: err.message });
  }
});


// 6) Signed upload URL (S3/B2) for media: GET /uploads/signed-url?filename=&contentType=
app.get('/uploads/signed-url', async (req, res) => {
  try {
    const { filename, contentType } = req.query;
    if (!filename) return res.status(400).json({ error: 'filename required' });
    const key = `${new Date().toISOString().slice(0,10)}/${encodeURIComponent(filename)}`;
    const out = await createPresignedUpload({ key, contentType });
    res.json(out);
  } catch (err) {
    res.status(500).json({ error: 'Upload URL error', details: err.message });
  }
});

// 7) Leads read endpoints for Glide sync back
app.get('/leads/:id', async (req, res) => {
  try {
    const supabase = getSupabase();
    const { data, error } = await supabase.from('leads_with_owner').select('*').eq('id', req.params.id).limit(1);
    if (error) throw error;
    res.json(data?.[0] || null);
  } catch (err) {
    res.status(500).json({ error: 'Lead read error', details: err.message });
  }
});

app.get('/leads', async (req, res) => {
  try {
    const supabase = getSupabase();
    const { limit = 50, since } = req.query;
    let query = supabase.from('leads_with_owner').select('*').order('created_at', { ascending: false }).limit(Number(limit));
    if (since) query = query.gte('created_at', since);
    const { data, error } = await query;
    if (error) throw error;
    res.json({ results: data });
  } catch (err) {
    res.status(500).json({ error: 'Lead list error', details: err.message });
  }
});

// 8) TCPA-safe texting flow
app.post('/sms/optin/start', async (req, res) => {
  try {
    const { phone, address, owner_name } = req.body || {};
    if (!phone || !address) return res.status(400).json({ error: 'phone and address required' });
    const out = await startOptIn({ phone, address, owner_name });
    res.json(out);
  } catch (err) {
    res.status(500).json({ error: 'Opt-in start error', details: err.message });
  }
});

app.post('/sms/optin/confirm', async (req, res) => {
  try {
    const { phone, code } = req.body || {};
    if (!phone || !code) return res.status(400).json({ error: 'phone and code required' });
    const out = await confirmOptIn({ phone, code });
    res.json(out);
  } catch (err) {
    res.status(500).json({ error: 'Opt-in confirm error', details: err.message });
  }
});

app.post('/sms/send', async (req, res) => {
  try {
    const { phone, message } = req.body || {};
    if (!phone || !message) return res.status(400).json({ error: 'phone and message required' });
    const out = await sendIfOptedIn({ phone, message });
    res.json(out);
  } catch (err) {
    res.status(500).json({ error: 'SMS send error', details: err.message });
  }
});

// 9) Xactimate helpers
app.get('/export/xactimate-lines.csv', async (req, res) => {
  try {
    const type = (req.query.type || 'crane').toLowerCase();
    const rows = getLineTemplate(type);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="xactimate_lines_${type}.csv"`);
    for (const row of rows) {
      const esc = row.map(v => `"${String(v).replace(/"/g, '""')}"`);
      res.write(esc.join(',') + '\n');
    }
    res.end();
  } catch (err) {
    res.status(500).json({ error: 'Export lines error', details: err.message });
  }
});

app.get('/export/xactimate-scope.txt', async (req, res) => {
  try {
    const params = {
      type: (req.query.type || 'crane').toLowerCase(),
      dbh: req.query.dbh || '',
      species: req.query.species || '',
      impact: req.query.impact || 'roof',
      hazards: req.query.hazards || 'none',
      access: req.query.access || 'standard',
      crew: req.query.crew || '4',
      crane: req.query.crane || '90-ton',
      hours: req.query.hours || '3'
    };
    const txt = getScopeNotes(params);
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Content-Disposition', `attachment; filename="xactimate_scope_${params.type}.txt"`);
    res.end(txt);
  } catch (err) {
    res.status(500).json({ error: 'Export scope error', details: err.message });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Listening on http://localhost:${PORT}`));
