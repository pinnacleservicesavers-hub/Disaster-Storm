import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

let s3 = null;
function s3Client() {
  if (!s3) {
    if (!process.env.S3_BUCKET || !process.env.S3_REGION || !process.env.S3_ACCESS_KEY_ID || !process.env.S3_SECRET_ACCESS_KEY) {
      throw new Error('Missing S3 config: S3_BUCKET, S3_REGION, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY');
    }
    s3 = new S3Client({
      region: process.env.S3_REGION,
      credentials: {
        accessKeyId: process.env.S3_ACCESS_KEY_ID,
        secretAccessKey: process.env.S3_SECRET_ACCESS_KEY
      },
      forcePathStyle: !!process.env.S3_FORCE_PATH_STYLE,
      endpoint: process.env.S3_ENDPOINT || undefined
    });
  }
  return s3;
}

/**
 * Create a pre-signed PUT URL for direct browser/mobile upload.
 * Compatible with AWS S3 or Backblaze B2 (S3-compatible) when endpoint provided.
 */
export async function createPresignedUpload({ key, contentType }) {
  const client = s3Client();
  const command = new PutObjectCommand({
    Bucket: process.env.S3_BUCKET,
    Key: key,
    ContentType: contentType || 'application/octet-stream',
    ACL: process.env.S3_ACL || 'private'
  });
  const url = await getSignedUrl(client, command, { expiresIn: 60 * 10 }); // 10 minutes
  const publicUrlBase = process.env.S3_PUBLIC_BASE || null; // optional CDN/base URL
  return { url, key, publicUrl: publicUrlBase ? `${publicUrlBase}/${key}` : null };
}
