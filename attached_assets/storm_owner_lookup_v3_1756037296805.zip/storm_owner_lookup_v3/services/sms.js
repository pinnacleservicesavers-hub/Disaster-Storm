import twilio from 'twilio';
import { getSupabase } from './supabase.js';

let client = null;
function twilioClient() {
  if (!client) {
    if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_FROM) {
      throw new Error('Missing Twilio config');
    }
    client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
  }
  return client;
}

export async function startOptIn({ phone, address, owner_name }) {
  const supabase = getSupabase();
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const text = `SLM Alerts: Reply with code ${code} to confirm messages about storm damage at ${address}. Std msg/data rates may apply. Reply STOP to opt out.`;

  // Upsert opt-in record
  const { data, error } = await supabase.from('sms_optins').upsert(
    { phone, status: 'pending', code },
    { onConflict: 'phone' }
  ).select();
  if (error) throw error;

  const cli = twilioClient();
  await cli.messages.create({ to: phone, from: process.env.TWILIO_FROM, body: text });
  return { phone, status: 'pending', sent: true };
}

export async function confirmOptIn({ phone, code }) {
  const supabase = getSupabase();
  const { data: recs, error } = await supabase.from('sms_optins').select('*').eq('phone', phone).limit(1);
  if (error) throw error;
  const rec = recs?.[0];
  if (!rec || rec.code !== code) return { ok: false, status: 'invalid_code' };
  await supabase.from('sms_optins').update({ status: 'opted_in', code: null }).eq('phone', phone);
  return { ok: true, status: 'opted_in' };
}

export async function sendIfOptedIn({ phone, message }) {
  const supabase = getSupabase();
  const { data: recs, error } = await supabase.from('sms_optins').select('status').eq('phone', phone).limit(1);
  if (error) throw error;
  const rec = recs?.[0];
  if (!rec || rec.status !== 'opted_in') return { ok: false, status: 'not_opted_in' };

  const cli = twilioClient();
  const resp = await cli.messages.create({ to: phone, from: process.env.TWILIO_FROM, body: message });
  return { ok: true, sid: resp.sid };
}
