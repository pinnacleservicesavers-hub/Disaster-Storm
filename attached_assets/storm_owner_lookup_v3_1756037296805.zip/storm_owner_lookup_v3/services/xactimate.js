/**
 * Generate simple line-item templates and scope notes.
 * We avoid proprietary Verisk codes; we output a helper CSV for you to map to your price list.
 */
export function getLineTemplate(type = 'crane') {
  const base = [
    ['Category','Item','Description','Qty','Unit','InternalNotes'],
  ];
  if (type === 'crane') {
    base.push(
      ['EMR','Mobilization','After-hours emergency mobilization (crew + equipment)','1','ea','Document call time/arrival time'],
      ['SAF','Site safety','Scene safety setup: cones, signage, traffic control','1','ls','Include permit if required'],
      ['ACC','Access prep','Access prep and ground protection mats','8','ea','Adjust qty by mats used'],
      ['LFT','Crane setup','Crane setup and safety meeting','1','ea','Note crane tonnage/class'],
      ['LFT','Crane time','Crane time with operator','3','hr','Measure actual hours on site'],
      ['TRM','Tree dismantle','Technical dismantle of tree on structure (DBH ___")','1','ea','Species & DBH'],
      ['DEB','Debris handling','Chip/haul brush and logs','1','ls','Scale if multiple loads'],
      ['PRT','Protection','Roof/wall temporary protection (tarp/ply)','1','ls','Photos before/after'],
      ['STP','Stump grind','Stump grinding to ___" depth','1','ea','If included in scope'],
      ['CLN','Clean up','Final clean-up and rake','1','ls','']
    );
  } else {
    base.push(
      ['EMR','Mobilization','Emergency mobilization (crew + equipment)','1','ea',''],
      ['SAF','Site safety','Scene safety setup: cones, signage, traffic control','1','ls',''],
      ['TRM','Tree removal','Sectional removal of tree on structure (DBH ___")','1','ea',''],
      ['DEB','Debris handling','Chip/haul brush and logs','1','ls',''],
      ['PRT','Protection','Temporary protection (tarp/ply)','1','ls',''],
      ['CLN','Clean up','Final clean-up and rake','1','ls','']
    );
  }
  return base;
}

export function getScopeNotes({ type='crane', dbh='', species='', impact='roof', hazards='none', access='standard', crew='4', crane='90-ton', hours='3' } = {}) {
  return [
    `LOSS SCOPE – TREE ON ${impact.toUpperCase()}`,
    ``,
    `Tree: ${species || 'unknown species'}; DBH: ${dbh || '____'} inches.`,
    `Impact: ${impact}. Hazards: ${hazards}. Access: ${access}.`,
    type === 'crane' ? `Equipment: ${crane} crane with operator; estimated crane time ${hours} hours.` : `Equipment: rigging, saws, ladders; no crane.`,
    `Crew: ${crew} technicians; PPE per ANSI Z133.`,
    `Work includes: site safety, technical dismantle, debris handling, temporary protection, and final clean-up.`,
    `Reasonable & Necessary: tasks required to remove hazard and prevent further damage.`,
    `Photos captured: before/during/after; N/E/S/W.`
  ].join('\n');
}
