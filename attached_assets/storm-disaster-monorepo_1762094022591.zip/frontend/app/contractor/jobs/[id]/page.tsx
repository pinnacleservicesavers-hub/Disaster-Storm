"use client";
import { useParams } from "next/navigation";

export default function JobDetail() {
  const params = useParams();
  const id = params?.id as string;
  return (
    <main className="p-8 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-semibold">Job {id}</h1>
      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Upload Media</h2>
        <input type="file" multiple className="border p-2 w-full" />
      </section>
      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Cost Breakdown</h2>
        <textarea className="border p-2 w-full h-32" placeholder="labor, equipment, materials ..." />
        <button className="bg-black text-white px-4 py-2 rounded">Generate Invoice</button>
      </section>
      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Comparables</h2>
        <div className="border p-3 rounded">True comparable vs Xactimate — (stub)</div>
      </section>
    </main>
  );
}
