import Link from "next/link";
export default function ContractorDashboard() {
  const leads = [{ id: "1", scope: "Tree Removal", address: "123 Elm St" }];
  const jobs = [{ id: "A1", status: "in_progress", address: "456 Oak Ave" }];

  return (
    <main className="p-8 max-w-5xl mx-auto space-y-8">
      <h1 className="text-2xl font-bold">Contractor Dashboard</h1>

      <section>
        <h2 className="text-lg font-semibold mb-2">Open Leads</h2>
        <div className="border rounded">
          {leads.map(l => (
            <div key={l.id} className="p-3 border-b flex items-center justify-between">
              <div>
                <div className="font-medium">{l.scope}</div>
                <div className="text-sm text-gray-600">{l.address}</div>
              </div>
              <Link className="underline" href={`/contractor/leads/${l.id}`}>View</Link>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-lg font-semibold mb-2">Active Jobs</h2>
        <div className="border rounded">
          {jobs.map(j => (
            <div key={j.id} className="p-3 border-b flex items-center justify-between">
              <div>
                <div className="font-medium">#{j.id} — {j.status}</div>
                <div className="text-sm text-gray-600">{j.address}</div>
              </div>
              <Link className="underline" href={`/contractor/jobs/${j.id}`}>Open</Link>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
