"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function Signup() {
  const router = useRouter();
  const [role, setRole] = useState("contractor");
  return (
    <main className="p-8 max-w-md mx-auto space-y-4">
      <h1 className="text-xl font-semibold">Sign Up</h1>
      <div className="space-y-2">
        <select className="border p-2 w-full" value={role} onChange={e=>setRole(e.target.value)}>
          <option value="contractor">Contractor</option>
          <option value="homeowner">Homeowner</option>
        </select>
        <button onClick={()=>router.push("/login")} className="bg-black text-white px-4 py-2 rounded">Continue</button>
      </div>
    </main>
  );
}
