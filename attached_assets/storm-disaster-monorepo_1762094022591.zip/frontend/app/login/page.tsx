"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("contractor");
  const router = useRouter();

  const submit = async (e: any) => {
    e.preventDefault();
    // Stub auth; normally call backend /auth/login
    if (role === "contractor") router.push("/contractor/dashboard");
    else router.push("/homeowner/dashboard");
  };

  return (
    <main className="p-8 max-w-md mx-auto space-y-4">
      <h1 className="text-xl font-semibold">Login</h1>
      <form onSubmit={submit} className="space-y-4">
        <input className="border p-2 w-full" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="border p-2 w-full" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <select className="border p-2 w-full" value={role} onChange={e=>setRole(e.target.value)}>
          <option value="contractor">Contractor</option>
          <option value="homeowner">Homeowner</option>
        </select>
        <button className="bg-black text-white px-4 py-2 rounded">Login</button>
      </form>
    </main>
  );
}
