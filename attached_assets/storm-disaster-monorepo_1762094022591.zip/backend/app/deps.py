from typing import Any

class Deps:
    def __init__(self):
        self.llm = self._llm_client()
        self.db = self._db()
        self.msg = self._msg()
        self.storage = self._storage()
        self.xact = self._xact()

    def _llm_client(self):
        async def call(prompt: str):
            # Replace with real LLM client usage
            return "<llm-output>"
        return call

    def _db(self):
        class DB:
            def find_contractors_for_region(self, region, scopes):
                return []
        return DB()

    def _msg(self):
        from .services.twilio_svc import MessagingService
        return MessagingService("sid", "token", "+10000000000")

    def _storage(self):
        class Store: ...
        return Store()

    def _xact(self):
        class Xact:
            async def estimate(self, breakdown): return {"total": 0}
        return Xact()

def build_dependencies():
    return Deps()
