from fastapi import APIRouter
router = APIRouter()

@router.post("/{job_id}/invoice")
def create_invoice(job_id: str): return {"invoice_id": "inv_demo"}

@router.post("/{job_id}/submit")
def submit(job_id: str): return {"submitted": True}

@router.post("/{job_id}/negotiate")
def negotiate(job_id: str): return {"status": "in_progress"}

@router.post("/{job_id}/status/ping")
def ping(job_id: str): return {"ok": True}

@router.post("/{job_id}/letters")
def letters(job_id: str): return {"generated": ["reminder", "demand"]}
