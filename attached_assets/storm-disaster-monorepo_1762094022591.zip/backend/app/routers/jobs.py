from fastapi import APIRouter
router = APIRouter()

@router.post("/{job_id}/media")
def upload_media(job_id: str): return {"ok": True}

@router.post("/{job_id}/analyze")
def analyze(job_id: str): return {"labels": [], "measurements": {}}

@router.post("/{job_id}/comparables")
def comps(job_id: str): return {"true": {}, "xactimate": {}}

@router.post("/{job_id}/contract/sign")
def sign(job_id: str): return {"signed": True}
