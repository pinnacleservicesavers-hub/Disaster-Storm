from fastapi import APIRouter
router = APIRouter()

@router.post("/optout")
def optout(): return {"opted_out": True}
