from fastapi import APIRouter
router = APIRouter()

@router.post("/subscribe")
def subscribe(): return {"subscribed": True}

@router.post("/broadcast")
def broadcast(): return {"sent": 0}

@router.post("/accept/{lead_id}")
def accept(lead_id: str): return {"accepted": lead_id}
