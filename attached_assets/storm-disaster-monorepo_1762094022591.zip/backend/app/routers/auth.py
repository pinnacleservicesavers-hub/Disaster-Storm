from fastapi import APIRouter
router = APIRouter()

@router.post("/signup")
def signup(): return {"ok": True}

@router.post("/login")
def login(): return {"token": "demo"}
