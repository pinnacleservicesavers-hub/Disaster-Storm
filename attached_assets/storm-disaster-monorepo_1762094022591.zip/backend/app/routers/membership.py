from fastapi import APIRouter
router = APIRouter()

@router.post("/checkout")
def checkout(): return {"checkout": "stripe_session_url"}

@router.post("/webhook")
def webhook(): return {"ok": True}
