from fastapi import APIRouter
router = APIRouter()

@router.post("/profile")
def upsert_profile(): return {"ok": True}

@router.get("/profile")
def get_profile(): return {"profile": {}}

@router.post("/contracts/validate")
def validate_contract(): return {"action": "review", "result": {}}

@router.post("/contracts/generate")
def generate_contract(): return {"action": "generate", "contract": "<template>"}
