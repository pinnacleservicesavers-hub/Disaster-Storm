
from fastapi import APIRouter, Response
from ..utils.store import store
import io, zipfile, json, csv

router = APIRouter()

@router.get("/admin/export/all.zip")
def export_all():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        # JSON dumps
        z.writestr("users.json", json.dumps(store.users, indent=2, default=str))
        z.writestr("jobs.json", json.dumps(store.jobs, indent=2, default=str))
        z.writestr("invoices.json", json.dumps(store.invoices, indent=2, default=str))
        z.writestr("settings.json", json.dumps(store.settings, indent=2, default=str))

        # CSV audit (org-wide)
        out = "id,when,job_id,to,subject,status\n"
        for job_id, job in store.jobs.items():
            for r in job.get("reminder_audit", []):
                to_str = ";".join(r.get("to", [])) if isinstance(r.get("to"), list) else str(r.get("to"))
                subj = (r.get("subject") or "").replace('"','""')
                out += f"{r.get('id')},{r.get('when')},{job_id},"{to_str}","{subj}",{r.get('status')}\n"
        z.writestr("reminder-audit-all.csv", out)

    buf.seek(0)
    return Response(content=buf.read(), media_type="application/zip",
                    headers={"Content-Disposition": "attachment; filename=storm-disaster-export-all.zip"})
