# StormEvents API (NOAA → Contractors Portal)

This Replit project bundles:
- A pipeline that downloads and merges NOAA **Storm Events** data (1950–present) for **Tornado / Hurricane (Typhoon) / Tropical Storm**.
- A FastAPI service with endpoints for filtering, prioritizing, distance-aware next-job selection, summaries, and simple routing.
- A landing page with quickstart and API examples.

## One-click run (Replit)
1. Import/upload this folder to Replit.
2. Set a secret called `ADMIN_TOKEN` (e.g., `slm-ADMIN-2025!`).
   - Optional: set `MATRIX_PROVIDER` = `google` or `mapbox`, and the corresponding `GOOGLE_API_KEY` or `MAPBOX_TOKEN`.
3. Click **Run**. The startup script will:
   - Install dependencies (first boot may take a minute).
   - Build the parquet/CSVs (first boot only).
   - Launch the API on port 8000 and serve the landing page at `/`.

## Environment variables
- `ADMIN_TOKEN` (required for /admin/* endpoints)
- `MATRIX_PROVIDER` (optional): `google` or `mapbox`
- `GOOGLE_API_KEY` (optional): if using Google Distance Matrix
- `MAPBOX_TOKEN` (optional): if using Mapbox Matrix
- `NOAA_PARQUET` (optional): path to parquet file (default: `storm_events_filtered.parquet`)
- `NOAA_COUNTY_SUMMARY` (optional): path to county summary CSV
- `NOAA_EVENT_SUMMARY` (optional): path to event summary CSV

## Endpoints
- `GET /health` – status + which distance mode is active
- `GET /api/events` – filter by state/county/type/time; sort by priority/time/distance; distance-aware if you pass `near_lat/near_lon`
- `GET /api/next-job` – **single best next job** (priority → distance → recency)
- `GET /api/next-batch` – **top N jobs** by same ranking
- `POST /api/routes` – simple nearest-neighbor route from contractor to a list of stops
- `GET /api/summary/county` – per-county rollups
- `GET /api/summary/events` – per-year × type rollups
- `POST /admin/update` – runs pipeline (requires `X-Admin-Token` header)
- `POST /admin/reindex` – reload parquet without a pipeline run (requires token)

## Quick examples (after running)
- Health: `/health`
- GA urgent jobs near Columbus (40 mi): `/api/next-batch?near_lat=32.46098&near_lon=-84.98771&state=GA&max_miles=40&limit=25`
- Single next job: `/api/next-job?near_lat=32.46098&near_lon=-84.98771&state=GA&max_miles=40`
- County 2023 top 100: `/api/summary/county?state=GA&year=2023&top=100`

## Notes
- First run downloads ~75 years of annual CSVs (3 families: details, locations, fatalities). Subsequent refreshes are much faster.
- If NOAA regenerates files, the pipeline automatically finds the latest "cYYYYMMDD" file names.
