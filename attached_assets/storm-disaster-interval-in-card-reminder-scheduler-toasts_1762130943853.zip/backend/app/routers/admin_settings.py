
from fastapi import APIRouter
from pydantic import BaseModel, Field
from ..utils.store import store

router = APIRouter()

class ShareSettings(BaseModel):
    cleanup_interval_minutes: int = Field(60, ge=5, le=720)

@router.get("/admin/shares/settings")
def get_share_settings():
    s = (store.settings.get("shares") or {})
    return {"cleanup_interval_minutes": int(s.get("cleanup_interval_minutes", 60))}

@router.post("/admin/shares/settings")
def set_share_settings(cfg: ShareSettings):
    store.settings.setdefault("shares", {})["cleanup_interval_minutes"] = int(cfg.cleanup_interval_minutes)
    return {"ok": True, "cleanup_interval_minutes": int(cfg.cleanup_interval_minutes)}
