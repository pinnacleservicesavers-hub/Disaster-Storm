"use client";
import { createContext, useContext, useEffect, useState } from 'react';

type Toast = { id: number; text: string };
const ToastCtx = createContext<{ push: (text:string)=>void } | null>(null);

export function ToastProvider({ children }:{ children: React.ReactNode }){
  const [items, setItems] = useState<Toast[]>([]);
  const push = (text:string)=>{
    const id = Date.now() + Math.random();
    setItems(prev => [...prev, { id, text }]);
    setTimeout(()=> setItems(prev => prev.filter(i=>i.id!==id)), 3000);
  };
  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      <div className="fixed bottom-4 right-4 space-y-2 z-50">
        {items.map(i=> <div key={i.id} className="bg-black text-white px-3 py-2 rounded shadow">{i.text}</div>)}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast(){
  const ctx = useContext(ToastCtx);
  if(!ctx) throw new Error("useToast must be used within ToastProvider");
  return ctx.push;
}
