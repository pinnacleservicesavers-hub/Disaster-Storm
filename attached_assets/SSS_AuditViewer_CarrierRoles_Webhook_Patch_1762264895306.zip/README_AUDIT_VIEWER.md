# SSS Patch — Audit Viewer + Carrier-Scoped Analysts + Audit Webhook

## What's included
- `app/core/audit.py` — webhook export via `AUDIT_WEBHOOK_URL` env var (POST JSON).
- `app/core/carrier_access.py` — helpers to restrict analyst visibility by JWT `carriers` claim.
- `app/routers/claims.py` — carrier-aware claims list (audited).
- `app/routers/reports.py` — carrier-aware FNOL (audited; admin-only store).
- `app/routers/audit_admin.py` — admin-only: `GET /api/audit/list`, `GET /api/audit/export`.
- `web/admin/audits.html` — filterable audit table + CSV export.

## Env
- `AUDIT_WEBHOOK_URL` (optional) for sending audit events out.
- JWT example for a scoped analyst: `{"sub":"analyst1","role":"analyst","carriers":["Acme","Example Carrier"]}`.

## Wire
```python
from app.routers import audit_admin, claims, reports
app.include_router(audit_admin.router, prefix="/api", tags=["audit"])
app.include_router(claims.router, prefix="/api", tags=["claims"])
app.include_router(reports.router, prefix="/api", tags=["reports"])
```
Add a nav link to `/web/admin/audits.html` from your Admin UI.
