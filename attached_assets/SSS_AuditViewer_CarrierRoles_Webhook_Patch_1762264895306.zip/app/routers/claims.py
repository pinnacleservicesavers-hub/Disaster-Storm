from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session
from app.core.db import SessionLocal
from app.models.entities import Claim
from app.core.security import role_required
from app.core.carrier_access import claim_visible_to_payload
from app.core.audit import log_audit

router = APIRouter()
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

@router.get("/claims")
def list_claims(request: Request, db: Session = Depends(get_db), _: dict = Depends(role_required(["analyst","admin"]))):
    payload = getattr(request.state, "user", None) or {}
    items = []
    for cl in db.query(Claim).all():
        if claim_visible_to_payload(db, payload, cl):
            items.append({"id": cl.id, "policy_number": cl.policy_number, "carrier_id": cl.carrier_id, "asset_id": cl.asset_id, "status": cl.status})
    log_audit(db, actor=payload.get("sub"), role=payload.get("role"), action="list_claims", detail=f"returned={len(items)}", ip=(request.client.host if request.client else None))
    return {"count": len(items), "items": items}
