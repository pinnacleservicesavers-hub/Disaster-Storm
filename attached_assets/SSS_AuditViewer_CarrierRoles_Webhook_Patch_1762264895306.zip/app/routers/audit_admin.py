from fastapi import APIRouter, Depends, Request, Query, Response
from sqlalchemy.orm import Session
from datetime import datetime
import csv, io

from app.core.db import SessionLocal
from app.core.security import role_required

router = APIRouter()
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

@router.get("/audit/list")
def audit_list(
    request: Request,
    db: Session = Depends(get_db),
    _: dict = Depends(role_required(["admin"])),
    start: str | None = Query(None, description="ISO timestamp start"),
    end: str | None = Query(None, description="ISO timestamp end"),
    actor: str | None = Query(None),
    action: str | None = Query(None),
    limit: int = Query(200, ge=1, le=5000),
    offset: int = Query(0, ge=0),
):
    conn = db.connection()
    conn.execute("""CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL, actor TEXT, role TEXT, action TEXT NOT NULL, detail TEXT, ip TEXT);""")
    where = ["1=1"]
    params = {}
    if start:
        where.append("ts >= :start"); params["start"] = start
    if end:
        where.append("ts <= :end"); params["end"] = end
    if actor:
        where.append("actor = :actor"); params["actor"] = actor
    if action:
        where.append("action = :action"); params["action"] = action
    sql = f"SELECT id, ts, actor, role, action, detail, ip FROM audit_log WHERE {' AND '.join(where)} ORDER BY id DESC LIMIT :lim OFFSET :off"
    params["lim"] = limit; params["off"] = offset
    rows = conn.execute(sql, params).fetchall()
    items = [dict(row) if hasattr(row, "keys") else {"id": r[0], "ts": r[1], "actor": r[2], "role": r[3], "action": r[4], "detail": r[5], "ip": r[6]} for r in rows]
    return {"count": len(items), "items": items}

@router.get("/audit/export")
def audit_export_csv(
    request: Request,
    db: Session = Depends(get_db),
    _: dict = Depends(role_required(["admin"])),
    start: str | None = Query(None),
    end: str | None = Query(None),
    actor: str | None = Query(None),
    action: str | None = Query(None),
    limit: int = Query(10000, ge=1, le=100000),
):
    res = audit_list(request, db, {"role":"admin"}, start, end, actor, action, limit, 0)
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["id","ts","actor","role","action","detail","ip"])
    for it in res["items"]:
        w.writerow([it.get("id"), it.get("ts"), it.get("actor"), it.get("role"), it.get("action"), it.get("detail"), it.get("ip")])
    return Response(content=out.getvalue(), media_type="text/csv")
