from fastapi import APIRouter, Depends, Response, Query, Request, HTTPException
from sqlalchemy.orm import Session
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader
from reportlab.lib.colors import HexColor
from io import BytesIO
from datetime import datetime
import os

from app.core.db import SessionLocal
from app.models.entities import Claim, Carrier, Asset
from app.utils.maprender import render_claim_hazards_png
from app.core.security import role_required
from app.core.roles import can
from app.core.audit import log_audit
from app.core.carrier_access import claim_visible_to_payload

router = APIRouter()
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

def _pdf_text(c, x, y, text, size=10, bold=False, color="#111111"):
    c.setFillColor(HexColor(color))
    c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
    c.drawString(x, y, text)

def _brand_colors(theme: str|None):
    colors = {"primary":"#0F172A","accent":"#3B82F6","text":"#111827","muted":"#6B7280"}
    presets = {"example_carrier":{"primary":"#111827","accent":"#2563EB"}, "acme_insurance":{"primary":"#0B132B","accent":"#6FFFE9"}}
    if theme:
        key = theme.lower().replace(" ", "_")
        colors.update(presets.get(key, {}))
    return colors

@router.get("/reports/fnol/{claim_id}")
def fnol_report(
    claim_id: int,
    request: Request,
    db: Session = Depends(get_db),
    theme: str | None = Query(None),
    store: bool = Query(False, description="If true, store to object storage (admin-only)"),
    _: dict = Depends(role_required(["analyst", "admin"])),
):
    payload = getattr(request.state, "user", None) or {}
    role = payload.get("role", "analyst")
    cl = db.query(Claim).filter(Claim.id == claim_id).first()
    if not cl:
        raise HTTPException(status_code=404, detail="Claim not found")
    if not claim_visible_to_payload(db, payload, cl):
        raise HTTPException(status_code=403, detail="Insufficient carrier permission")

    colors = _brand_colors(theme)
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=LETTER)
    w, h = LETTER

    c.setFillColor(HexColor(colors["accent"]))
    c.rect(0, h-0.9*inch, w, 0.9*inch, fill=1, stroke=0)
    _pdf_text(c, 1*inch, h-0.6*inch, "First Notice of Loss (FNOL)", 16, True, "#FFFFFF")

    if theme:
        try:
            logo_path = os.path.join("web", "static", "logos", f"{theme.lower().replace(' ', '_')}.png")
            if os.path.exists(logo_path):
                img = ImageReader(logo_path)
                c.drawImage(img, w-2.2*inch, h-0.85*inch, width=1.8*inch, height=0.6*inch, preserveAspectRatio=True, mask='auto')
        except Exception:
            pass

    asset = db.query(Asset).filter(Asset.id == cl.asset_id).first()
    carrier = db.query(Carrier).filter(Carrier.id == cl.carrier_id).first()

    y = h - 1.2*inch
    _pdf_text(c, 1*inch, y, f"Generated: {datetime.utcnow().isoformat()}Z", 9, False, colors["muted"]); y -= 0.18*inch
    _pdf_text(c, 1*inch, y, "Claim Information", 12, True, colors["primary"]); y -= 0.24*inch
    _pdf_text(c, 1*inch, y, f"Claim ID: {cl.id} | Policy: {cl.policy_number or '-'} | Status: {cl.status}", 10, False, colors["text"]); y -= 0.18*inch
    _pdf_text(c, 1*inch, y, f"Carrier: {(carrier.name if carrier else '-')}", 10, False, colors["text"]); y -= 0.24*inch

    _pdf_text(c, 1*inch, y, "Map Snapshot", 12, True, colors["primary"]); y -= 0.24*inch
    try:
        img_bytes = render_claim_hazards_png(db, cl.id)
        img = ImageReader(BytesIO(img_bytes))
        c.drawImage(img, 1*inch, y-3.5*inch, width=4.8*inch, height=4.0*inch, preserveAspectRatio=True, mask='auto')
        y -= 4.3*inch
    except Exception as e:
        _pdf_text(c, 1*inch, y, f"(Map unavailable: {str(e)[:70]})", 10, False, colors["muted"]); y -= 0.2*inch

    _pdf_text(c, 1*inch, y, "Intersecting Hazards", 12, True, colors["primary"]); y -= 0.24*inch
    c.showPage(); c.save()
    pdf_bytes = buf.getvalue(); buf.close()

    ip = request.client.host if request.client else None
    log_audit(db, payload.get("sub"), role, "view_fnol_pdf", f"claim_id={cl.id}", ip)

    if store:
        if role != "admin":
            raise HTTPException(status_code=403, detail="Insufficient role to store")
        try:
            from app.utils.storage import store_pdf_and_get_url
            url = store_pdf_and_get_url(pdf_bytes, f"FNOL_{cl.id}.pdf")
            log_audit(db, payload.get("sub"), role, "store_fnol_pdf", f"claim_id={cl.id}->{url}", ip)
            return {"stored": True, "url": url}
        except Exception as e:
            log_audit(db, payload.get("sub"), role, "store_fnol_pdf_error", str(e)[:200], ip)
            raise

    return Response(content=pdf_bytes, media_type="application/pdf")
