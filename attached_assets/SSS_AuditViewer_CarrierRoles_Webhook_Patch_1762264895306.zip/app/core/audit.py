import os, json
from typing import Optional
from datetime import datetime

def _webhook_url() -> Optional[str]:
    return os.getenv("AUDIT_WEBHOOK_URL")

def _post_webhook(payload: dict):
    url = _webhook_url()
    if not url: return
    try:
        import requests
        requests.post(url, json=payload, timeout=3)
    except Exception:
        pass

def log_audit(db_session, actor: Optional[str], role: Optional[str], action: str, detail: str = "", ip: Optional[str] = None):
    ts = datetime.utcnow().isoformat() + "Z"
    sql_create = """
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL,
        actor TEXT,
        role TEXT,
        action TEXT NOT NULL,
        detail TEXT,
        ip TEXT
    );
    """
    sql_insert = "INSERT INTO audit_log (ts, actor, role, action, detail, ip) VALUES (:ts, :actor, :role, :action, :detail, :ip)"
    conn = db_session.connection()
    conn.execute(sql_create)
    conn.execute(sql_insert, {"ts": ts, "actor": actor, "role": role, "action": action, "detail": detail[:1000], "ip": ip or ""})
    _post_webhook({"ts": ts, "actor": actor, "role": role, "action": action, "detail": detail, "ip": ip})
