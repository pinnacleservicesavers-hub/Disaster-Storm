# Supabase Edge Function: upload-relay

Generates **pre-signed PUT URLs** so Glide/mobile clients can upload photos/videos directly to S3/Backblaze B2 without exposing your credentials.

## Deploy

```bash
supabase functions deploy upload-relay --project-ref <your-ref>
supabase secrets set --env-file ./edge.env --project-ref <your-ref>
```

## Required secrets (edge.env)

```
S3_BUCKET=your-bucket
S3_REGION=us-east-1
S3_ACCESS_KEY_ID=your_key
S3_SECRET_ACCESS_KEY=your_secret
# Optional:
S3_ENDPOINT=https://s3.us-east-005.backblazeb2.com
S3_FORCE_PATH_STYLE=true
S3_PUBLIC_BASE=https://cdn.yourdomain.com
```

## Usage (from Glide or your server)

- URL: `https://<PROJECT>.functions.supabase.co/upload-relay`
- Method: POST
- Body JSON: `{ "filename": "photo.jpg", "contentType": "image/jpeg" }`
- Response JSON: `{ "url": "<signed PUT>", "key": "2025-08-24/photo.jpg", "publicUrl": "https://cdn.yourdomain.com/2025-08-24/photo.jpg" }`
