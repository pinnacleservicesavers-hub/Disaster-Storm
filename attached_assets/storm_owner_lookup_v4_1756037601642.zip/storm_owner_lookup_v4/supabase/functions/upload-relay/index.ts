// Supabase Edge Function: upload-relay
// POST { filename, contentType } -> { url, key, publicUrl? }
import { S3Client, PutObjectCommand } from "npm:@aws-sdk/client-s3@3.645.0";
import { getSignedUrl } from "npm:@aws-sdk/s3-request-presigner@3.645.0";

const s3 = new S3Client({
  region: Deno.env.get("S3_REGION")!,
  endpoint: Deno.env.get("S3_ENDPOINT") || undefined,
  forcePathStyle: Deno.env.get("S3_FORCE_PATH_STYLE") === "true" ? true : false,
  credentials: {
    accessKeyId: Deno.env.get("S3_ACCESS_KEY_ID")!,
    secretAccessKey: Deno.env.get("S3_SECRET_ACCESS_KEY")!,
  },
});

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "POST only" }), { status: 405 });
  }
  try {
    const { filename, contentType } = await req.json();
    if (!filename) return new Response(JSON.stringify({ error: "filename required" }), { status: 400 });

    const key = `${new Date().toISOString().slice(0,10)}/${encodeURIComponent(filename)}`;
    const command = new PutObjectCommand({
      Bucket: Deno.env.get("S3_BUCKET")!,
      Key: key,
      ContentType: contentType || "application/octet-stream",
      ACL: Deno.env.get("S3_ACL") || "private"
    });
    const url = await getSignedUrl(s3, command, { expiresIn: 600 }); // 10 min
    const publicBase = Deno.env.get("S3_PUBLIC_BASE") || null;
    const publicUrl = publicBase ? `${publicBase.replace(/\/+$/,'')}/${key}` : null;

    return new Response(JSON.stringify({ url, key, publicUrl }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: "relay error", details: String(e) }), { status: 500 });
  }
});
