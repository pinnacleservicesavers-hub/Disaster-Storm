/**
 * Build a public URL for a given S3/B2 key.
 * If S3_PUBLIC_BASE is set (e.g., https://cdn.yourdomain.com), it will use that.
 * Otherwise, attempts to construct a Backblaze B2 public URL when endpoint is a B2 S3 endpoint.
 */
export function buildPublicUrlForKey(key) {
  const base = process.env.S3_PUBLIC_BASE;
  if (base) return `${base.replace(/\/+$/,'')}/${key}`;

  const ep = process.env.S3_ENDPOINT || '';
  const bucket = process.env.S3_BUCKET;
  if (ep.includes('backblazeb2.com')) {
    // Construct typical B2 public URL: https://f<NN>.backblazeb2.com/file/<bucket>/<key>
    // Many accounts expose a "friendly" fxxx host after enabling public access.
    const host = process.env.B2_PUBLIC_HOST || null; // e.g., https://f004.backblazeb2.com
    if (host) return `${host.replace(/\/+$/,'')}/file/${bucket}/${key}`;
  }
  return null; // caller can store key and resolve later
}
