import httpx
from app.core.config import settings

async def _async_post(url: str, json_data: dict, headers: dict | None = None):
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.post(url, json=json_data, headers=headers or {})
        return r.status_code

def send_webhook(payload: dict):
    if not settings.alert_webhook_url:
        return None
    headers = {"Authorization": f"Bearer {settings.alert_webhook_token}"} if settings.alert_webhook_token else {}
    import anyio
    return anyio.run(_async_post, settings.alert_webhook_url, payload, headers)

def send_sms(message: str, to_phone: str):
    if not (settings.twilio_account_sid and settings.twilio_auth_token and settings.twilio_from):
        return None
    try:
        from twilio.rest import Client
        client = Client(settings.twilio_account_sid, settings.twilio_auth_token)
        msg = client.messages.create(body=message, from_=settings.twilio_from, to=to_phone)
        return msg.sid
    except Exception as e:
        return str(e)
