import io, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from shapely import wkt
from shapely.geometry import Point, Polygon, MultiPolygon
from sqlalchemy.orm import Session
from app.models.entities import Alert, Asset, Claim

def _as_polygons(geom):
    if isinstance(geom, Polygon):
        return [geom]
    if isinstance(geom, MultiPolygon):
        return list(geom.geoms)
    return []

def _bounds(polys):
    minx=miny=1e9; maxx=maxy=-1e9
    for p in polys:
        x0,y0,x1,y1 = p.bounds
        minx=min(minx,x0); miny=min(miny,y0); maxx=max(maxx,x1); maxy=max(maxy,y1)
    return (minx, miny, maxx, maxy)

def render_claim_hazards_png(db: Session, claim_id: int) -> bytes:
    cl = db.query(Claim).filter(Claim.id==claim_id).first()
    asset = db.query(Asset).filter(Asset.id==cl.asset_id).first()
    polys = []
    for al in db.query(Alert).all():
        if not al.geom_wkt: continue
        try:
            g = wkt.loads(al.geom_wkt)
        except Exception:
            continue
        for p in _as_polygons(g.buffer(0)):
            polys.append(p)

    fig, ax = plt.subplots(figsize=(6,6), dpi=150)
    for p in polys:
        x,y = p.exterior.xy
        ax.fill(x,y, alpha=0.2); ax.plot(x,y, linewidth=0.5)
    if asset:
        ax.plot([asset.lon],[asset.lat], marker="o", markersize=5, color="#111827")

    if polys:
        minx,miny,maxx,maxy = _bounds(polys)
        dx=(maxx-minx) or 0.5; dy=(maxy-miny) or 0.5
        ax.set_xlim(minx-0.25*dx, maxx+0.25*dx); ax.set_ylim(miny-0.25*dy, maxy+0.25*dy)
    else:
        ax.set_xlim(asset.lon-0.5, asset.lon+0.5); ax.set_ylim(asset.lat-0.5, asset.lat+0.5)
    ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude"); ax.grid(True, linestyle=":", linewidth=0.5, alpha=0.4)
    fig.tight_layout()
    buf = io.BytesIO(); fig.savefig(buf, format="png"); plt.close(fig)
    return buf.getvalue()
