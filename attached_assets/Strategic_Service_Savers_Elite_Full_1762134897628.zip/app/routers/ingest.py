from fastapi import APIRouter
from app.services.ingest import run_all_ingestors
router = APIRouter()
@router.post('/ingest/run')
async def ingest_now():
    await run_all_ingestors(); return {'status':'ingested'}
