from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from shapely import wkt
from shapely.geometry import Point
from app.core.db import SessionLocal
from app.models.entities import Alert, Contractor, Asset, AuditLog
from app.utils.notify import send_webhook
from app.core.config import settings

router = APIRouter()
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

@router.post('/rules/evaluate')
def run_rules(db: Session=Depends(get_db)):
    alerts=db.query(Alert).all(); contractors=db.query(Contractor).all(); assets=db.query(Asset).all()
    matches=[]
    for al in alerts:
        if not al.geom_wkt: continue
        try: g=wkt.loads(al.geom_wkt)
        except Exception: continue
        for c in contractors:
            p=Point(c.lon,c.lat)
            if g.buffer(0).intersects(p): matches.append({'type':'contractor','alert_id':al.id,'contractor_id':c.id,'title':al.title})
        for a in assets:
            p=Point(a.lon,a.lat)
            if g.buffer(0).intersects(p): matches.append({'type':'asset','alert_id':al.id,'asset_id':a.id,'title':al.title})
    if settings.alert_webhook_url: send_webhook({'matches':matches})
    db.add(AuditLog(kind='RULE_MATCH', message=str(matches))); db.commit()
    return {'matches':matches,'count':len(matches)}
