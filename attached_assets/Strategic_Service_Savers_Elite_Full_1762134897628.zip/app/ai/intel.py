from typing import Dict, Any
from math import radians, sin, cos, asin, sqrt
from shapely import wkt
from sqlalchemy.orm import Session
from app.models.entities import Alert, Contractor, Asset

def haversine(lat1, lon1, lat2, lon2):
    R=6371.0; dlat=radians(lat2-lat1); dlon=radians(lon2-lon1)
    a=sin(dlat/2)**2+cos(radians(lat1))*cos(radians(lat2))*sin(dlon/2)**2; return 2*R*asin(sqrt(a))

def summarize_current_conditions(db: Session)->Dict[str,Any]:
    alerts=db.query(Alert).order_by(Alert.id.desc()).limit(200).all()
    contractors=db.query(Contractor).all(); assets=db.query(Asset).all()
    peril_counts={}; impacts=[]
    for al in alerts:
        peril_counts[al.source]=peril_counts.get(al.source,0)+1
        clat=clon=None
        if al.geom_wkt:
            try: centroid=wkt.loads(al.geom_wkt).centroid; clat,clon=centroid.y,centroid.x
            except Exception: pass
        dminc=dmina=1e9
        for c in contractors:
            if clat is None: break
            d=haversine(c.lat,c.lon,clat,clon); dminc=min(dminc,d)
        for a in assets:
            if clat is None: break
            d=haversine(a.lat,a.lon,clat,clon); dmina=min(dmina,d)
        impacts.append({'alert_id':al.id,'title':al.title,'source':al.source,'nearest_contractor_km':None if dminc==1e9 else round(dminc,1),'nearest_asset_km':None if dmina==1e9 else round(dmina,1)})
    lines=[]
    if not alerts: lines.append('No active hazards.')
    else:
        lines.append(f"{len(alerts)} active hazards. By source: {', '.join([f'{k}:{v}' for k,v in peril_counts.items()])}")
    return {'summary':' '.join(lines),'peril_counts':peril_counts,'highlights':impacts[:10]}

def suggest_staging_locations(db: Session, max_results:int=5)->Dict[str,Any]:
    alerts=db.query(Alert).order_by(Alert.id.desc()).limit(200).all()
    out=[]
    for al in alerts:
        if not al.geom_wkt: continue
        try:
            g=wkt.loads(al.geom_wkt); cand=list(g.buffer(0.2).exterior.coords)[0]
            out.append({'alert_id':al.id,'title':al.title,'source':al.source,'lat':cand[1],'lon':cand[0],'note':'Provisional staging ~20km outside'})
        except Exception: continue
    return {'staging':out[:max_results]}
