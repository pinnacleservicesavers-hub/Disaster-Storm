import httpx, json
from shapely.geometry import shape
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.core.db import SessionLocal
from app.models.entities import Alert, AuditLog

NWS_ALERTS = "https://api.weather.gov/alerts/active"
USGS_EQ = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson"
NHC_LIST = "https://www.nhc.noaa.gov/CurrentStorms.json"
FIRMS_VIIRS = "https://firms.modaps.eosdis.nasa.gov/geojson/country/USA/VIIRS_I_Global_24h.json"

async def fetch_json(url: str):
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(url, headers={"User-Agent":"S3/1.0 (contact@example.com)"})
        r.raise_for_status()
        return r.json()

async def ingest_nws(db: Session):
    data = await fetch_json(NWS_ALERTS)
    count = 0
    for f in data.get("features", []):
        props = f.get("properties", {})
        geom = f.get("geometry")
        title = props.get("event") or "NWS Alert"
        sev = props.get("severity") or ""
        geom_wkt = None
        if geom:
            try:
                shp = shape(geom); geom_wkt = shp.wkt
            except Exception: pass
        a = Alert(source="NWS", title=title, severity=sev, geom_wkt=geom_wkt, properties_json=json.dumps(props))
        db.add(a); count += 1
    db.add(AuditLog(kind="INGEST", message=f"NWS ingested: {count}")); db.commit()

async def ingest_usgs(db: Session):
    data = await fetch_json(USGS_EQ)
    count = 0
    for f in data.get("features", []):
        props = f.get("properties", {})
        geom = f.get("geometry")
        title = f"Earthquake M{props.get('mag')} - {props.get('place')}"
        geom_wkt = None
        if geom:
            try:
                shp = shape(geom); geom_wkt = shp.wkt
            except Exception: pass
        a = Alert(source="USGS", title=title, severity="earthquake", geom_wkt=geom_wkt, properties_json=json.dumps(props))
        db.add(a); count += 1
    db.add(AuditLog(kind="INGEST", message=f"USGS ingested: {count}")); db.commit()

async def ingest_firms(db: Session):
    data = await fetch_json(FIRMS_VIIRS)
    count = 0
    for f in data.get("features", []):
        geom = f.get("geometry")
        geom_wkt=None
        if geom:
            try: geom_wkt = shape(geom).wkt
            except Exception: pass
        a = Alert(source="FIRMS", title="Wildfire Hotspot", severity="wildfire", geom_wkt=geom_wkt, properties_json=json.dumps(f.get("properties",{})))
        db.add(a); count+=1
    db.add(AuditLog(kind="INGEST", message=f"FIRMS ingested: {count}")); db.commit()

async def ingest_nhc(db: Session):
    try:
        data = await fetch_json(NHC_LIST)
        db.add(AuditLog(kind="INGEST", message=f"NHC storms listed: {len(data)}")); db.commit()
    except Exception as e:
        db.add(AuditLog(kind="INGEST", message=f"NHC error: {e}")); db.commit()

async def run_all_ingestors():
    db = SessionLocal()
    try:
        await ingest_nws(db); await ingest_usgs(db); await ingest_firms(db); await ingest_nhc(db)
    finally:
        db.close()
