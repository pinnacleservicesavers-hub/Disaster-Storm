import httpx, json
from shapely.geometry import shape
from sqlalchemy.orm import Session
from app.models.entities import Alert, AuditLog

CURRENT_STORMS = "https://www.nhc.noaa.gov/CurrentStorms.json"
POSSIBLE = ["cone_latest.geojson","forecast_line_latest.geojson"]

async def _get_json(u):
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.get(u, headers={"User-Agent":"S3/1.0"}); r.raise_for_status(); return r.json()

async def _maybe(u):
    try:
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.get(u, headers={"User-Agent":"S3/1.0"})
            if r.status_code==200 and "json" in r.headers.get("content-type",""):
                return r.json()
    except Exception:
        return None

async def ingest_nhc_geojson(db: Session):
    try:
        storms = await _get_json(CURRENT_STORMS)
    except Exception as e:
        db.add(AuditLog(kind="INGEST", message=f"NHC list error: {e}")); db.commit(); return
    total=0
    for s in storms:
        roots=[s.get(k,"").rstrip("/") for k in ("stormhref","stormURL","stormurl","gis") if s.get(k)]
        for r in roots:
            for name in POSSIBLE:
                url=f"{r}/{name}"
                gj = await _maybe(url)
                if gj and gj.get("type") in ("FeatureCollection","Feature"):
                    feats = gj["features"] if gj["type"]=="FeatureCollection" else [gj]
                    for f in feats:
                        try:
                            g = shape(f.get("geometry")); wkt = g.wkt
                        except Exception:
                            wkt=None
                        db.add(Alert(source="NHC", title=name.replace('_latest',''), severity="", geom_wkt=wkt, properties_json=json.dumps(f.get("properties",{}))))
                        total+=1
    db.add(AuditLog(kind="INGEST", message=f"NHC geojson stored: {total}")); db.commit()
