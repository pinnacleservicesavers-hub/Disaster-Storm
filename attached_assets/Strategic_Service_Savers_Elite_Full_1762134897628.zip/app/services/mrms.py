import io, httpx, gzip, numpy as np, json
from datetime import datetime, timezone
from skimage import measure
import rasterio
from rasterio.io import MemoryFile
from shapely.geometry import Polygon, MultiPolygon
from shapely.ops import unary_union
from sqlalchemy.orm import Session
from app.models.entities import Alert, AuditLog

def _nearest_5min(dt): minute=(dt.minute//5)*5; return dt.replace(minute=minute, second=0, microsecond=0)

async def _fetch(u):
    async with httpx.AsyncClient(timeout=45) as c:
        r=await c.get(u, headers={"User-Agent":"S3/1.0"}); r.raise_for_status(); return r.content

def _open(data):
    try:
        if data[:2]==b"\x1f\x8b": data=gzip.decompress(data)
    except Exception: pass
    mem = MemoryFile(data); return mem.open()

def _contours(ds, thr):
    arr = ds.read(1).astype(np.float32)
    arr = np.where(np.isfinite(arr), arr, np.nan)
    mask = np.where(arr>=thr, 1, 0).astype(np.uint8)
    cs = measure.find_contours(mask, 0.5)
    polys=[]
    for c in cs:
        lonlats = [ds.transform * (pt[1], pt[0]) for pt in c]
        if len(lonlats)<3: continue
        try:
            p = Polygon(lonlats).buffer(0)
            if p.is_valid and p.area>0: polys.append(p)
        except Exception: pass
    return polys

MRMS_PERIL_TEMPLATES = {
    "hail": {"template":"https://noaa-mrms-pds.s3.amazonaws.com/CONUS/MESH/MRMS_MESH_{ts}.grib2.gz","thresholds":[19.0,25.4,38.1]},
    "heavy_precip": {"template":"https://noaa-mrms-pds.s3.amazonaws.com/CONUS/PrecipRate/MRMS_PrecipRate_{ts}.grib2.gz","thresholds":[10.0,25.0,50.0]},
    "flood_risk": {"template":"https://noaa-mrms-pds.s3.amazonaws.com/CONUS/QPE_01H/MRMS_QPE_01H_{ts}.grib2.gz","thresholds":[12.7,25.4,50.8]}
}

async def ingest_mrms_for_peril(db: Session, peril: str, simplify_tolerance: float = 0.02):
    cfg = MRMS_PERIL_TEMPLATES.get(peril)
    if not cfg:
        db.add(AuditLog(kind="INGEST", message=f"MRMS unknown peril {peril}")); db.commit(); return
    ts=_nearest_5min(datetime.now(timezone.utc)).strftime("%Y%m%d-%H%M00")
    url=cfg["template"].format(ts=ts)
    try:
        data = await _fetch(url); ds = _open(data)
    except Exception as e:
        db.add(AuditLog(kind="INGEST", message=f"MRMS fetch/open failed: {e} @ {url}")); db.commit(); return
    total=0
    for thr in cfg["thresholds"]:
        try:
            polys = _contours(ds, thr)
            polys = [p.simplify(simplify_tolerance, preserve_topology=True) for p in polys if p.area>0]
        except Exception as e:
            db.add(AuditLog(kind="INGEST", message=f"MRMS contour fail @ {thr}: {e}")); db.commit(); continue
        for p in polys:
            db.add(Alert(source="MRMS", title=f"MRMS {peril} >= {thr}", severity=peril, geom_wkt=p.wkt, properties_json=json.dumps({"threshold":thr,"product_url":url})))
            total+=1
    db.add(AuditLog(kind="INGEST", message=f"MRMS stored {total} polygons for {peril}")); db.commit()
