
# Storm Disaster — Carrier Directory + Policy Parser

Run backend:
```
pip install -r backend/requirements.txt
uvicorn backend.app.main:app --reload --port 8000
```

Run frontend:
```
cd frontend
npm i
echo "NEXT_PUBLIC_API_BASE=http://localhost:8000" > .env.local
npm run dev
```

New endpoints:
- `GET /carriers` — list directory
- `GET /carriers/lookup?name=ABC&state=FL` — best match + state note
- `POST /carriers` — admin upsert
- `POST /policy/parse` — upload PDF (multipart) or `text` to extract policy number, coverage A-D, deductible, and dates
- `POST /claims/email/{claim_id}?to=adjuster@carrier.com` — email packet via SMTP

UI:
- `/admin/carriers` — add/update carriers
- `/contractor/claims/submit` — “Use directory” fills carrier email; “Policy Parser” uploads a policy PDF to prefill basics.
