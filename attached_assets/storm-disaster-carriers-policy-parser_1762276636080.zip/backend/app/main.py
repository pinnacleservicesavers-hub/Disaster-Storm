
from fastapi import FastAPI
from .routers import jobs, claims, carriers, policy

app = FastAPI()
app.include_router(jobs.router)
app.include_router(claims.router)
app.include_router(carriers.router)
app.include_router(policy.router)
