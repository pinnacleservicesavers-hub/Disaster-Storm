
class _Store:
    def __init__(self):
        self.settings = {"claims": {"_seq": 1}, "smtp": {}}
        self.jobs = {"A1": {
            "job_id": "A1",
            "customer": {"name":"Jane Homeowner","email":"jane@example.com","phone":"555-0100","address":"123 Main St, Springfield, FL 33333"},
            "policy": {"carrier":"ABC Insurance","claim_number":"","policy_number":"","coverage":"A"},
            "invoice": [{"desc":"Tree removal","qty":1,"price":1500}],
            "notes": "Mitigate further damage; ingress/egress blocked."
        }}
        self.carriers = {
            "ABC Insurance": {
                "id": "abc",
                "name": "ABC Insurance",
                "claim_email": "claims@abcinsurance.com",
                "intake_url": "https://claims.abcinsurance.com/submit",
                "per_state_notes": {"FL": "Use CAT team email: cat@abcinsurance.com during hurricanes"}
            },
            "Acme Mutual": {
                "id": "acme",
                "name": "Acme Mutual",
                "claim_email": "newclaims@acmemutual.com",
                "intake_url": "https://portal.acmemutual.com/claims",
                "per_state_notes": {}
            }
        }
store = _Store()
