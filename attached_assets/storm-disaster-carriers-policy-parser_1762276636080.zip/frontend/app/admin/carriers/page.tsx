
"use client";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";

type Carrier = { id:string; name:string; claim_email?:string; intake_url?:string; per_state_notes?:Record<string,string> };

export default function CarriersAdmin(){
  const [list, setList] = useState<Carrier[]>([]);
  const [name, setName] = useState(""); const [email, setEmail] = useState(""); const [url, setUrl] = useState("");
  const [stateKey, setStateKey] = useState("FL"); const [stateNote, setStateNote] = useState("");

  const load = async()=>{ setList(await api("/carriers")); };
  useEffect(()=>{ load(); },[]);

  const add = async()=>{
    const body: Carrier = { id: "", name, claim_email: email, intake_url: url, per_state_notes: stateNote ? { [stateKey]: stateNote } : {} };
    await api("/carriers", { method: "POST", body: JSON.stringify(body) });
    setName(""); setEmail(""); setUrl(""); setStateNote("");
    load();
  };

  return (
    <main className="p-8 max-w-3xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold">Carrier Directory</h1>
      <div className="space-y-2 border rounded p-3">
        <div className="grid sm:grid-cols-2 gap-2">
          <input className="border p-2" placeholder="Carrier name" value={name} onChange={e=>setName(e.target.value)} />
          <input className="border p-2" placeholder="Claims email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="border p-2 sm:col-span-2" placeholder="Intake portal URL" value={url} onChange={e=>setUrl(e.target.value)} />
          <div className="flex gap-2">
            <input className="border p-2 w-24" value={stateKey} onChange={e=>setStateKey(e.target.value.toUpperCase())} />
            <input className="border p-2 flex-1" placeholder="Per-state note (optional)" value={stateNote} onChange={e=>setStateNote(e.target.value)} />
          </div>
        </div>
        <button className="px-3 py-1 border rounded" onClick={add} disabled={!name}>Add/Update</button>
      </div>

      <div className="border rounded">
        <table className="w-full text-sm">
          <thead className="bg-gray-50"><tr><th className="text-left p-2">Name</th><th className="text-left p-2">Claims Email</th><th className="text-left p-2">Portal</th></tr></thead>
          <tbody>
            {list.map(c => (
              <tr key={c.id} className="border-t">
                <td className="p-2">{c.name}</td>
                <td className="p-2">{c.claim_email || "—"}</td>
                <td className="p-2">{c.intake_url ? <a className="text-blue-600 underline" href={c.intake_url} target="_blank">Open</a> : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
