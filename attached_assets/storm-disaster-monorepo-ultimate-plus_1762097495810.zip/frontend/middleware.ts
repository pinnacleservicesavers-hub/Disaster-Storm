import { NextRequest, NextResponse } from "next/server";

export function middleware(req: NextRequest) {
  const url = req.nextUrl;
  if (url.pathname.startsWith("/insurer")) {
    const role = req.cookies.get("role")?.value || "";
    if (role !== "insurer" && role !== "admin") {
      url.pathname = "/login";
      return NextResponse.redirect(url);
    }
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/insurer/:path*"]
};
