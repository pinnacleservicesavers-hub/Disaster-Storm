"use client";
import { useState } from "react";
import { api } from "@/lib/api";

export default function Policy() {
  const [jobId, setJobId] = useState("A1");
  const [text, setText] = useState("");
  const [parsed, setParsed] = useState<any>();
  const [comment, setComment] = useState("");
  const [rebuttal, setRebuttal] = useState("");

  const parse = async ()=>{
    const r = await api("/policy/parse", { method:"POST", body: JSON.stringify({ job_id: jobId, policy_text: text })});
    setParsed(r.parsed);
  };

  const draftRebuttal = async ()=>{
    const r = await api(`/claims/${jobId}/rebuttal`, { method:"POST", body: JSON.stringify({ job_id: jobId, insurer_comment: comment })});
    setRebuttal(r.rebuttal);
  };

  return (
    <main className="p-8 max-w-4xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Policy Reader & Rebuttal</h1>
      <input className="border p-2 w-full" value={jobId} onChange={e=>setJobId(e.target.value)} placeholder="Job ID" />
      <textarea className="border p-2 w-full h-40" placeholder="Paste policy text here..." value={text} onChange={e=>setText(e.target.value)} />
      <button onClick={parse} className="bg-black text-white px-4 py-2 rounded">Parse Policy</button>
      {parsed && <div className="border rounded p-3">
        <div className="font-semibold mb-1">Parsed Excerpts</div>
        <pre className="text-sm whitespace-pre-wrap">{JSON.stringify(parsed, null, 2)}</pre>
      </div>}
      <div className="space-y-2">
        <input className="border p-2 w-full" placeholder="Insurer comment to rebut" value={comment} onChange={e=>setComment(e.target.value)} />
        <button onClick={draftRebuttal} className="bg-black text-white px-4 py-2 rounded">Draft Rebuttal</button>
      </div>
      {rebuttal && <div className="border rounded p-3 whitespace-pre-wrap">{rebuttal}</div>}
    </main>
  );
}
