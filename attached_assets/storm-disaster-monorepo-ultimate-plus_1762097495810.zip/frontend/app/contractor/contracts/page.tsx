"use client";
import { useState } from "react";
import { api } from "@/lib/api";

export default function Contracts() {
  const [trade, setTrade] = useState("tree_service");
  const [state, setState] = useState("FL");
  const [contract, setContract] = useState("... SIGN_HERE");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [signUrl, setSignUrl] = useState("");
  const [aob, setAob] = useState<any>();

  const generate = async () => {
    const r = await api("/contractor/contracts/generate", { method:"POST", body: JSON.stringify({ trade, state })});
    setContract(r.contract || "... SIGN_HERE");
  };

  const loadTemplate = async () => {
    const r = await api(`/contractor/contracts/template?state=${state}&trade=${trade}`);
    setContract(r.template || contract);
  };

  const checkAOB = async () => {
    const r = await api(`/legal/aob/check?state=${state}`);
    setAob(r);
  };

  const sign = async () => {
    const r = await api("/contracts/sign", { method:"POST", body: JSON.stringify({ contract_text: contract, signer_email: email, signer_name: name })});
    setSignUrl(r.sign_url);
  };

  return (
    <main className="p-8 max-w-3xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Contracts</h1>
      <div className="grid grid-cols-2 gap-2">
        <input className="border p-2" value={trade} onChange={e=>setTrade(e.target.value)} placeholder="Trade" />
        <input className="border p-2" value={state} onChange={e=>setState(e.target.value)} placeholder="State (e.g., FL)" />
      </div>
      <div className="flex gap-2">
        <button onClick={generate} className="bg-black text-white px-4 py-2 rounded">Generate AI Contract</button>
        <button onClick={checkAOB} className="bg-black text-white px-4 py-2 rounded">Check AOB</button>
        <button onClick={loadTemplate} className="px-4 py-2 rounded border">Load state template</button>
      </div>
      {aob && <div className="border rounded p-3">
        <div><b>State:</b> {aob.state}</div>
        <div><b>AOB allowed:</b> {String(aob.aob_allowed)}</div>
        <div className="text-sm text-gray-700">{aob.notes}</div>
      </div>}
      <textarea className="border p-2 w-full h-48" value={contract} onChange={e=>setContract(e.target.value)} />
      <div className="grid grid-cols-2 gap-2">
        <input className="border p-2" value={name} onChange={e=>setName(e.target.value)} placeholder="Signer name" />
        <input className="border p-2" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Signer email" />
      </div>
      <button onClick={sign} className="bg-black text-white px-4 py-2 rounded">Send for e‑signature</button>
      {signUrl && <div className="mt-2"><a className="underline" target="_blank" href={signUrl}>Open signing session</a></div>}
    </main>
  );
}
