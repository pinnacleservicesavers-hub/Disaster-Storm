"use client";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";

export default function Timeline({ jobId }: { jobId: string }) {
  const [items, setItems] = useState<any[]>([]);
  const [note, setNote] = useState("");

  useEffect(()=>{ api(`/claims/${jobId}/timeline`).then(r=>setItems(r.timeline)); }, [jobId]);

  const add = async () => {
    const evt = { job_id: jobId, kind: "note", message: note };
    await api(`/claims/${jobId}/timeline`, { method:"POST", body: JSON.stringify(evt) });
    const r = await api(`/claims/${jobId}/timeline`);
    setItems(r.timeline); setNote("");
  };

  const autopings = async ()=>{
    await api(`/claims/${jobId}/timeline/autoping`, { method:"POST" });
    const r = await api(`/claims/${jobId}/timeline`);
    setItems(r.timeline);
  };

  return (
    <section className="space-y-2">
      <h2 className="text-lg font-semibold">Timeline</h2>
      <div className="border rounded">
        {items.map((it, i)=> (
          <div key={i} className="p-2 border-b">
            <div className="text-sm text-gray-600">{it.when} — <b>{it.kind}</b></div>
            <div>{it.message}</div>
          </div>
        ))}
        {items.length === 0 && <div className="p-3 text-gray-600">No events yet.</div>}
      </div>
      <div className="flex gap-2">
        <input className="border p-2 flex-1" value={note} onChange={e=>setNote(e.target.value)} placeholder="Add note..." />
        <button onClick={add} className="bg-black text-white px-4 py-2 rounded">Add</button>
        <button onClick={autopings} className="px-4 py-2 rounded border">Auto‑ping this week</button>
      </div>
    </section>
  );
}
