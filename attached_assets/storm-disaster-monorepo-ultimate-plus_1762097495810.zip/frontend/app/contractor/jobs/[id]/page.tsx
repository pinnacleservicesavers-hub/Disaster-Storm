"use client";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { api, API_BASE } from "@/lib/api";
import Timeline from "./timeline";

type Label = { Name: string; Confidence: number; Parents: string[] };

export default function JobDetail() {
  const params = useParams();
  const id = params?.id as string;
  const [labor, setLabor] = useState("1000");
  const [equipment, setEquipment] = useState("2500");
  const [materials, setMaterials] = useState("300");
  const [result, setResult] = useState<any>();
  const [file, setFile] = useState<File|null>(null);
  const [s3key, setS3key] = useState(`jobs/${id}/upload-${Date.now()}.jpg`);
  const [labels, setLabels] = useState<Label[]>([]);
  const [msg, setMsg] = useState("");

  const generate = async () => {
    const breakdown = { labor, equipment, materials };
    const inv = await api(`/claims/${id}/invoice`, { method:"POST", body: JSON.stringify({ breakdown })});
    const comps = await api(`/jobs/${id}/comparables`, { method:"POST", body: JSON.stringify({ breakdown })});
    setResult({ inv, comps });
  };

  const uploadAndIngest = async () => {
    if (!file) return;
    setMsg("Uploading...");
    const pres = await api("/uploads/presign", { method:"POST", body: JSON.stringify({ key: s3key })});
    const putRes = await fetch(pres.url, { method:"PUT", body: file });
    if (!putRes.ok) throw new Error("Upload failed");
    setMsg("Uploaded. Analyzing...");
    const ing = await api("/media/ingest", { method:"POST", body: JSON.stringify({ job_id: id, key: s3key })});
    setLabels(ing.labels || []);
    setMsg("Labeled ✔");
  };

  return (
    <main className="p-8 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-semibold">Job {id}</h1>

      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Upload Media</h2>
        <input type="file" onChange={e=>setFile(e.target.files?.[0] || null)} />
        <input className="border p-2 w-full" value={s3key} onChange={e=>setS3key(e.target.value)} placeholder="S3 key" />
        <button onClick={uploadAndIngest} className="bg-black text-white px-4 py-2 rounded">Upload & Analyze</button>
        {msg && <div className="text-sm text-gray-700">{msg}</div>}
        {labels.length>0 && (
          <div className="border rounded p-3">
            <div className="font-semibold">Detected Labels</div>
            <ul className="list-disc pl-5">
              {labels.map((l, i)=> <li key={i}>{l.Name} ({Math.round(l.Confidence)}%)</li>)}
            </ul>
          </div>
        )}
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Cost Breakdown</h2>
        <div className="grid grid-cols-3 gap-2">
          <input className="border p-2" value={labor} onChange={e=>setLabor(e.target.value)} placeholder="Labor $" />
          <input className="border p-2" value={equipment} onChange={e=>setEquipment(e.target.value)} placeholder="Equipment $" />
          <input className="border p-2" value={materials} onChange={e=>setMaterials(e.target.value)} placeholder="Materials $" />
        </div>
        <button onClick={generate} className="bg-black text-white px-4 py-2 rounded">Generate Invoice & Comparables</button>
      </section>

      <Timeline jobId={id} />


      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Letters</h2>
        <div className="flex gap-2">
          <button onClick={async()=>{ await api('/claims/letters/generate',{ method:'POST', body: JSON.stringify({ job_id: id, type:'late' })}); }} className="px-4 py-2 rounded border">Generate Late Letter</button>
          <button onClick={async()=>{ await api('/claims/letters/generate',{ method:'POST', body: JSON.stringify({ job_id: id, type:'demand60' })}); }} className="px-4 py-2 rounded border">Generate 60-Day Demand</button>
          <a className="underline" target="_blank" href={`${API_BASE}/claims/${id}/submission.zip`}>Include in Submission ZIP</a>
        </div>
      </section>
    

      {result && (
        <section className="space-y-2">
          <h2 className="text-lg font-semibold">Results</h2>
          <div className="border rounded p-3">
            <div>Xactimate total: ${result.inv.xactimate.total}</div>
            <div>True vs Xactimate variance: {result.comps.variance}</div>
          </div>
          <div className="flex gap-4">
            <a className="underline" target="_blank" href={`${API_BASE}/claims/${id}/report.html`}>Open HTML Report</a>
            <a className="underline" target="_blank" href={`${API_BASE}/claims/${id}/report.pdf`}>Download PDF Report</a>
            <a className="underline" target="_blank" href={`${API_BASE}/claims/${id}/submission.zip`}>Download Submission ZIP</a>
          </div>
        </section>
      )}
    </main>
  );
}
