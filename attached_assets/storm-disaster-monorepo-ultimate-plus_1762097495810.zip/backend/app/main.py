from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .routers import auth, membership, contractor, leads, jobs, claims, payments, compliance, signing, uploads, export, insurer, media, legal, timeline, policy, claims_letters, contract_templates
from .utils.events import EventBus
from .agents.supervisor import Supervisor
from .services.twilio_inbound import router as twilio_router
from .deps import build_dependencies

app = FastAPI(title="Storm Disaster Agentic API", version="0.2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

deps = build_dependencies()
bus = EventBus()
supervisor = Supervisor(deps)

@app.on_event("startup")
async def startup():
    bus.subscribe(supervisor.handle_event)

app.state.bus = bus
app.state.deps = deps

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(membership.router, prefix="/membership", tags=["membership"])
app.include_router(contractor.router, prefix="/contractor", tags=["contractor"])
app.include_router(leads.router, prefix="/leads", tags=["leads"])
app.include_router(jobs.router, prefix="/jobs", tags=["jobs"])
app.include_router(claims.router, prefix="/claims", tags=["claims"])
app.include_router(payments.router, prefix="/payments", tags=["payments"])
app.include_router(compliance.router, prefix="/compliance", tags=["compliance"])
app.include_router(signing.router, tags=["signing"])\napp.include_router(twilio_router, tags=["twilio"])
