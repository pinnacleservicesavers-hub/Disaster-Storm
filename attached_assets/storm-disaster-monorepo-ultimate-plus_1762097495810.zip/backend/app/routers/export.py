import io, json, zipfile
from fastapi import APIRouter, Response
from ..dao import dao
from .claims import build_report_html
from ..utils.pdf import html_to_pdf_bytes

router = APIRouter()

@router.get("/claims/{job_id}/submission.zip")
async def submission_zip(job_id: str):
    inv = await dao.find_invoice_for_job(job_id)
    html = build_report_html(job_id)
    pdf = html_to_pdf_bytes(html) if html else b""
    manifest = {
        "job_id": job_id,
        "invoice": inv or {},
        "notes": "Include photos/videos as separate uploads via S3 in production.", "letters_included": true
    }
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
    # add letters if any
    letters = (store.jobs.get(job_id, {}) or {}).get("letters", [])
    for i, lt in enumerate(letters, start=1):
        name = f"letters/{i:02d}-{lt.get('letter_type','letter')}.txt"
        z.writestr(name, lt.get("message",""))

        z.writestr(f"claim-report-{job_id}.pdf", pdf)
        z.writestr("manifest.json", json.dumps(manifest, indent=2))
    buf.seek(0)
    return Response(content=buf.read(), media_type="application/zip",
                    headers={"Content-Disposition": f"attachment; filename=submission-{job_id}.zip"})
