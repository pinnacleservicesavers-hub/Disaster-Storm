from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store
import datetime

router = APIRouter()

class TimelineEvent(BaseModel):
    job_id: str
    kind: str   # note | letter | ping | status
    message: str
    when: str | None = None  # ISO8601

@router.get("/claims/{job_id}/timeline")
def get_timeline(job_id: str):
    tl = store.jobs.get(job_id, {}).get("timeline", [])
    return {"timeline": tl}

@router.post("/claims/{job_id}/timeline")
def add_timeline(job_id: str, evt: TimelineEvent):
    e = evt.dict()
    e["when"] = e.get("when") or datetime.datetime.utcnow().isoformat()
    store.jobs.setdefault(job_id, {}).setdefault("timeline", []).append(e)
    return {"ok": True, "event": e}

@router.post("/claims/{job_id}/timeline/autoping")
def schedule_auto_pings(job_id: str):
    # naive: record two future ping timestamps this week
    now = datetime.datetime.utcnow()
    p1 = (now + datetime.timedelta(days=3)).isoformat()
    p2 = (now + datetime.timedelta(days=7)).isoformat()
    store.jobs.setdefault(job_id, {}).setdefault("timeline", []).extend([
        {"job_id": job_id, "kind":"ping", "message":"Auto-ping insurer (planned)", "when": p1},
        {"job_id": job_id, "kind":"ping", "message":"Auto-ping insurer (planned)", "when": p2},
    ])
    return {"ok": True, "scheduled": [p1, p2]}
