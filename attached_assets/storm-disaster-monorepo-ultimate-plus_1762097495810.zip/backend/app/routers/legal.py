from fastapi import APIRouter, Query
import json, os

router = APIRouter()

RULES_PATH = os.path.join(os.path.dirname(__file__), "..", "legal_aob_rules.json")

@router.get("/legal/aob/check")
def aob_check(state: str = Query(..., min_length=2, max_length=2)):
    with open(RULES_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    st = state.upper()
    rule = data.get(st)
    if not rule:
        return {"state": st, "aob_allowed": False, "notes": "No rule found; default to caution and require legal review."}
    return {"state": st, **rule}
