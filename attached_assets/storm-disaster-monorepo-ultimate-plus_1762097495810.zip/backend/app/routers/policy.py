from fastapi import APIRouter
from pydantic import BaseModel
import re, json
from ..utils.store import store

router = APIRouter()

class PolicyBody(BaseModel):
    job_id: str
    policy_text: str

@router.post("/policy/parse")
def parse_policy(body: PolicyBody):
    text = body.policy_text
    def find(section):
        m = re.search(section, text, re.IGNORECASE | re.DOTALL)
        return m.group(0)[:1500] if m else ""
    coverage_a = find(r"coverage\s*a[\s\S]{0,2000}")
    coverage_b = find(r"coverage\s*b[\s\S]{0,2000}")
    deductibles = find(r"deductible[\s\S]{0,1000}")
    exclusions = find(r"exclusion[\s\S]{0,2000}")
    parsed = {
        "coverage_a_excerpt": coverage_a,
        "coverage_b_excerpt": coverage_b,
        "deductibles_excerpt": deductibles,
        "exclusions_excerpt": exclusions
    }
    store.jobs.setdefault(body.job_id, {})["policy"] = parsed
    return {"parsed": parsed}

class RebuttalBody(BaseModel):
    job_id: str
    insurer_comment: str

@router.post("/claims/{job_id}/rebuttal")
def rebuttal(job_id: str, body: RebuttalBody):
    job = store.jobs.get(job_id, {})
    pol = job.get("policy", {})
    comp = next((v for v in store.invoices.values() if v["job_id"] == job_id), None)
    true_total = 0.0
    if comp:
        for v in comp["breakdown"].values():
            try: true_total += float(v)
            except: pass
    xact_total = comp["xactimate"]["total"] if comp else 0.0

    # Simple template-based rebuttal; replace with LLM in production
    cover_ref = "Coverage A (Dwelling)" if pol.get("coverage_a_excerpt") else "Coverage B (Other Structures)"
    reasons = []
    if true_total > xact_total:
        reasons.append("Market surge pricing and safety constraints increased actual costs beyond generic line-item pricing.")
    if "mitigate" not in body.insurer_comment.lower():
        reasons.append("Mitigation to prevent further loss is a covered, necessary expense under the duty to mitigate.")

    text = f"""Re: Claim {job_id} — Contractor Rebuttal

Coverage: {cover_ref}
We acknowledge your comment: "{body.insurer_comment}".

Justification:
- Work was necessary to restore safe access and prevent further loss (duty to mitigate).
- Variance vs. Xactimate: ${true_total - xact_total:,.2f}. { ' '.join(reasons) }

Attached packet includes: invoice, comparables, media, and policy excerpts. Please re-evaluate and advise the updated payable amount.
"""
    store.jobs.setdefault(job_id, {}).setdefault("timeline", []).append({
        "job_id": job_id, "kind":"note", "message":"Rebuttal prepared", "when": __import__("datetime").datetime.utcnow().isoformat()
    })
    return {"rebuttal": text}
