from fastapi import APIRouter, Query
import json, os

router = APIRouter()
TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "..", "legal_contract_templates.json")

@router.get("/contractor/contracts/template")
def contract_template(state: str = Query(..., min_length=2, max_length=2), trade: str = Query(...)):
    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    st = state.upper()
    base = data.get(st) or data.get("default", "")
    text = base.replace("{STATE}", st).replace("{TRADE}", trade)
    return {"state": st, "trade": trade, "template": text}
