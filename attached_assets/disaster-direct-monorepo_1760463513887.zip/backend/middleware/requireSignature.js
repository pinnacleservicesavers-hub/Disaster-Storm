import { verifySignature } from "../helpers/signing.js";
const ENFORCE = process.env.ENFORCE_SIGNED_TILES === "1";
export function requireSignature(req, res, next) {
  if (!ENFORCE) return next();
  const originalPath = req.baseUrl + req.path;
  const sp = new URLSearchParams({ ...req.query });
  const sig = sp.get("sig"); const exp = sp.get("exp");
  sp.delete("sig"); sp.delete("exp");
  const pathWithQuery = sp.toString() ? `${originalPath}?${sp}` : originalPath;
  if (!verifySignature(pathWithQuery, sig, exp)) return res.status(403).json({ error: "Invalid or expired signature" });
  next();
}
export function maybeApplySignature(app, routePrefix, router) {
  if (ENFORCE) app.use(routePrefix, requireSignature, router); else app.use(routePrefix, router);
}
