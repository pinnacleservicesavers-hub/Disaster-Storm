import { fetchJson } from "../helpers/http.js";
import { makeCache } from "../helpers/cache.js";
const cache = makeCache(60_000);
function clamp01(x){ return Math.max(0, Math.min(1, x)); }
function norm(x,min,max){ return clamp01((x - min) / (max - min || 1)); }
function nWindGust(kts){ return norm(kts, 15, 55); }
function nHailCount(c){ return clamp01(c / 20); }
function nLightningCount(c){ return clamp01(c / 200); }
function nAlertSeverity(features){ const titles=(features||[]).map(f=>f?.properties?.event||""); const weights=titles.map(t=>/tornado/i.test(t)?1.0:/severe.*thunderstorm/i.test(t)?0.7:/high wind|wind advisory/i.test(t)?0.5:0); return clamp01(weights.reduce((a,b)=>Math.max(a,b),0)); }
export function mountImpactV2(app){
  app.get("/api/impact", async (req,res)=>{
    const { lat,lng,pollen } = req.query; if(!lat||!lng) return res.status(400).json({ error:"lat and lng required" });
    const key=`impact:${lat},${lng}:p=${pollen?"1":"0"}`; const hit=cache.get(key); if(hit) return res.json(hit);
    try{
      const ambee = await fetchJson(`https://api.ambeedata.com/weather/latest/by-lat-lng?lat=${lat}&lng=${lng}`, { headers:{ "x-api-key": process.env.AMBEE_API_KEY, Accept:"application/json" } });
      const [ lightning, hail, alerts ] = await Promise.all([
        fetchJson(`/api/xweather/v1/lightning/recent?lat=${lat}&lng=${lng}&radius=50`),
        fetchJson(`/api/xweather/v1/hail/reports?lat=${lat}&lng=${lng}&radius=50&hours=24`),
        fetchJson(`/api/nws/alerts?lat=${lat}&lng=${lng}`),
      ]);
      const gustKts = Number(ambee?.data?.[0]?.wind?.gust || ambee?.wind?.gust || 0);
      const lightningCount = Array.isArray(lightning?.events) ? lightning.events.length : 0;
      const hailCount = Array.isArray(hail?.reports) ? hail.reports.length : 0;
      const alertSeverity = nAlertSeverity(alerts?.features);
      const wGustN = nWindGust(gustKts), lN = nLightningCount(lightningCount), hN = nHailCount(hailCount), aN = alertSeverity;
      const weights = { wind:0.35, lightning:0.25, hail:0.25, alerts:0.15 };
      const impactScore = Math.round(100*(wGustN*weights.wind + lN*weights.lightning + hN*weights.hail + aN*weights.alerts));
      const body = { impactScore, components: {
          windGustKts: gustKts, windScore: Math.round(100*wGustN),
          lightningCount, lightningScore: Math.round(100*lN),
          hailCount, hailScore: Math.round(100*hN),
          alerts: alerts?.features?.map(f=>f?.properties?.event).filter(Boolean) || [],
          alertScore: Math.round(100*aN),
        }, sources:{ ambee:"weather/latest/by-lat-lng", xweather:["lightning/recent","hail/reports"], nws:["alerts/active"] }, meta:{ lat:Number(lat), lng:Number(lng), pollen:!!pollen, ts:new Date().toISOString() } };
      cache.set(key, body, 45_000); res.json(body);
    } catch(e){ res.status(e.status||502).json({ error:"Impact computation failed", details:e }); }
  });
}
