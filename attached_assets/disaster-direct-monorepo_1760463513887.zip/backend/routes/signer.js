import { withSignedParams } from "../helpers/signing.js";
const DEFAULT_TILE_TEMPLATE = "/api/impact/tiles/{z}/{x}/{y}.png";
export function mountSigner(app){
  app.get("/api/sign/tile", (req,res)=>{
    const { z,x,y, fmt="png", pollen="1", grid="6", scheme="viridis", ttl="180" } = req.query || {};
    if (![z,x,y].every(Boolean)) return res.status(400).json({ error:"z,x,y required" });
    const path = DEFAULT_TILE_TEMPLATE.replace("{z}",String(z)).replace("{x}",String(x)).replace("{y}",String(y)).replace(".png",`.${fmt}`);
    const sp = new URLSearchParams({ pollen:String(pollen), grid:String(grid), scheme:String(scheme), ttl:String(ttl) });
    const url = withSignedParams(path, sp); res.json({ url });
  });
  app.get("/api/sign/legend", (req,res)=>{
    const { scheme="viridis", width="256", height="48", bg="solid" } = req.query || {};
    const path = "/api/legend.png"; const sp = new URLSearchParams({ scheme, width, height, bg }); const url = withSignedParams(path, sp);
    res.json({ url });
  });
}
