import express from "express";
import { createCanvas } from "canvas";
import SphericalMercator from "@mapbox/sphericalmercator";
import { makeCache } from "../helpers/cache.js";
import { fetchJson } from "../helpers/http.js";
import { maybeApplySignature } from "../middleware/requireSignature.js";
const TILE_SIZE=256; const merc=new SphericalMercator({ size:TILE_SIZE }); const cache=makeCache(120_000);
function viridis(t){ const a=(1-t), b=t; const r=Math.round(255*(0.267*a+0.283*b)); const g=Math.round(255*(0.004*a+0.720*b)); const bl=Math.round(255*(0.329*a+0.228*b)); return [r,g,bl]; }
function clamp01(x){ return Math.max(0, Math.min(1, x)); }
async function sampleImpactGrid(z,x,y,grid=6,pollen=false,baseUrl=""){ const [w,s,e,n]=merc.bbox(x,y,z,false,"WGS84"); const rows=grid, cols=grid; const points=[];
  for(let r=0;r<rows;r++){ const lat=n+(s-n)*(r/(rows-1)); for(let c=0;c<cols;c++){ const lng=w+(e-w)*(c/(cols-1)); points.push({r,c,lat,lng}); } }
  const qs=(lat,lng)=>`/api/impact?lat=${lat}&lng=${lng}${pollen?"&pollen=1":""}`;
  const res=await Promise.all(points.map(p=>fetchJson(`${baseUrl}${qs(p.lat,p.lng)}`).catch(()=>({impactScore:0}))));
  const gridData=Array.from({length:rows},()=>Array(cols).fill(0)); for(let i=0;i<points.length;i++){ const {r,c}=points[i]; gridData[r][c]=clamp01((res[i]?.impactScore||0)/100) } return gridData; }
function bilinear(vg,u,v){ const rows=vg.length, cols=vg[0].length; const x=u*(cols-1), y=v*(rows-1); const x0=Math.floor(x), y0=Math.floor(y); const x1=Math.min(x0+1,cols-1), y1=Math.min(y0+1,rows-1);
  const q11=vg[y0][x0], q21=vg[y0][x1], q12=vg[y1][x0], q22=vg[y1][x1]; const tx=x-x0, ty=y-y0; const a=q11*(1-tx)+q21*tx; const b=q12*(1-tx)+q22*tx; return a*(1-ty)+b*ty; }
export function mountImpactTiles(app,{baseUrl=""}={}){
  const router = express.Router();
  router.get("/:z/:x/:y.png", async (req,res)=>{
    const { z,x,y } = req.params; const pollen = req.query.pollen==="1"||req.query.pollen==="true"; const grid = Math.max(3, Math.min(16, Number(req.query.grid)||6));
    const ttl = Math.max(30_000, Math.min(300_000, (Number(req.query.ttl)||120)*1000));
    const key=`tile:${z}/${x}/${y}:g=${grid}:p=${pollen}`; const hit=cache.get(key); if(hit){ res.setHeader("Content-Type","image/png"); return res.end(hit); }
    try{ const g=await sampleImpactGrid(Number(z),Number(x),Number(y),grid,pollen,baseUrl); const canvas=createCanvas(256,256); const ctx=canvas.getContext("2d"); const img=ctx.createImageData(256,256); const data=img.data; let idx=0;
      for(let py=0;py<256;py++){ const v=py/255; for(let px=0;px<256;px++){ const u=px/255; const t=clamp01(bilinear(g,u,v)); const [r,g_,b]=viridis(t); data[idx++]=r; data[idx++]=g_; data[idx++]=b; data[idx++]=Math.round(180+75*t); } }
      ctx.putImageData(img,0,0); const buf=canvas.toBuffer("image/png"); cache.set(key,buf,ttl); res.setHeader("Content-Type","image/png"); res.end(buf);
    } catch(e){ res.status(502).json({ error:"tile render failed", details:String(e) }); }
  });
  maybeApplySignature(app, "/api/impact/tiles", router);
  app.get("/api/legend.png", (req,res)=>{ const canvas=createCanvas(256,48); const ctx=canvas.getContext("2d"); for(let x=0;x<256;x++){ const t=x/255; const [r,g,b]=viridis(t); ctx.fillStyle=`rgb(${r},${g},${b})`; ctx.fillRect(x,0,1,32); }
    ctx.fillStyle="#333"; ctx.font="10px sans-serif"; ctx.fillText("0",2,44); ctx.fillText("50",120,44); ctx.fillText("100",232,44); res.setHeader("Content-Type","image/png"); res.end(canvas.toBuffer("image/png")); });
}
