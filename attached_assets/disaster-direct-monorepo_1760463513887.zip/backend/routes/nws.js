import { fetchJson } from "../helpers/http.js";
import { makeCache } from "../helpers/cache.js";
const cache = makeCache(60_000);
function ua(){ return process.env.NWS_USER_AGENT || "DisasterDirect/0.1 (email-required@nws.gov)"; }
export function mountNws(app){
  app.get("/api/nws/alerts", async (req,res)=>{
    const { lat, lng } = req.query; if(!lat || !lng) return res.status(400).json({ error:"lat and lng required" });
    const url=`https://api.weather.gov/alerts/active?status=actual&message_type=alert&point=${lat},${lng}&area=US&urgency=Immediate,Expected&region=US&limit=50`;
    const hit=cache.get(url); if(hit) return res.json(hit);
    try{ const data=await fetchJson(url,{ headers:{ "User-Agent": ua(), Accept:"application/geo+json" } }); cache.set(url,data,45_000); res.json(data); }
    catch(e){ res.status(e.status||502).json(e); }
  });
  app.get("/api/nws/forecast", async (req,res)=>{
    const { lat,lng } = req.query; if(!lat || !lng) return res.status(400).json({ error:"lat and lng required" });
    try{ const pts=await fetchJson(`https://api.weather.gov/points/${lat},${lng}`, { headers:{ "User-Agent": ua(), Accept:"application/geo+json" } });
      const url=pts?.properties?.forecast; if(!url) return res.status(502).json({ error:"No forecast URL for point" });
      const forecast=await fetchJson(url,{ headers:{ "User-Agent": ua(), Accept:"application/geo+json" } }); res.json(forecast);
    } catch(e){ res.status(e.status||502).json(e); }
  });
}
