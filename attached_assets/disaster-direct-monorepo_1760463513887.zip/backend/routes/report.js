import PDFDocument from "pdfkit";
import { fetchJson } from "../helpers/http.js";
export function mountReport(app,{baseUrl=""}={}){
  app.get("/api/report.pdf", async (req,res)=>{
    try{
      const lat = Number(req.query.lat), lng = Number(req.query.lng), hours = Number(req.query.hours||24);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) return res.status(400).json({ error:"lat and lng required" });
      const [impact, alerts, lightning, hail] = await Promise.all([
        fetchJson(`${baseUrl}/api/impact?lat=${lat}&lng=${lng}&pollen=1`).catch(()=>null),
        fetchJson(`${baseUrl}/api/nws/alerts?lat=${lat}&lng=${lng}`).catch(()=>({features:[]})),
        fetchJson(`${baseUrl}/api/xweather/v1/lightning/recent?lat=${lat}&lng=${lng}&radius=50`).catch(()=>null),
        fetchJson(`${baseUrl}/api/xweather/v1/hail/reports?lat=${lat}&lng=${lng}&radius=50&hours=${hours}`).catch(()=>null),
      ]);
      res.setHeader("Content-Type","application/pdf");
      const doc = new PDFDocument({ size:"LETTER", margin:40 }); doc.pipe(res);
      doc.fontSize(18).text("Disaster Direct – Incident Report"); doc.moveDown(0.5);
      doc.fontSize(10).fillColor("#555").text(`Generated: ${new Date().toISOString()}`).text(`Location: ${lat.toFixed(4)}, ${lng.toFixed(4)} | Window: last ${hours}h`);
      doc.moveDown(1).fillColor("#000");
      const score = impact?.impactScore ?? 0; const c = impact?.components || {};
      doc.fontSize(14).text(`Impact Score: ${score}/100`); doc.moveDown(0.25);
      doc.fontSize(10).text(`Wind: ${c.windScore ?? 0} (gust kt: ${c.windGustKts ?? "n/a"})`);
      doc.text(`Lightning: ${c.lightningScore ?? 0} (events: ${c.lightningCount ?? 0})`);
      doc.text(`Hail: ${c.hailScore ?? 0} (reports: ${c.hailCount ?? 0})`);
      doc.text(`Alerts: ${c.alertScore ?? 0} (${(c.alerts||[]).join(", ") || "none"})`);
      doc.moveDown(0.8).fontSize(12).text("NWS Alerts",{underline:true});
      const features = alerts?.features || [];
      if (features.length===0) doc.fontSize(10).text("No active alerts."); else features.slice(0,12).forEach(f=>{
        const p=f?.properties||{}; doc.fontSize(10).text(`• ${p.event || "Alert"} | ${p.severity || ""} | ${p.effective || ""}`);
      });
      const lCount = Array.isArray(lightning?.events) ? lightning.events.length : 0;
      const hCount = Array.isArray(hail?.reports) ? hail?.reports.length : 0;
      doc.moveDown(0.8).fontSize(12).text("Xweather Signals",{underline:true});
      doc.fontSize(10).text(`Lightning events (~1h): ${lCount}`); doc.text(`Hail reports (${hours}h): ${hCount}`);
      doc.moveDown(0.8).fontSize(12).text("Sources & Methods",{underline:true});
      doc.fontSize(10).text("• Ambee: weather/latest/by-lat-lng").text("• Xweather: lightning/recent, hail/reports").text("• NWS: alerts near point");
      doc.end();
    }catch(err){ res.status(502).json({ error:"report failed", details:String(err) }); }
  });
}
