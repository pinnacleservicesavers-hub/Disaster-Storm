import { fetchJson } from "../helpers/http.js";
import { makeCache } from "../helpers/cache.js";
const BASE = "https://api.xweather.com";
const cache = makeCache(60_000);
const ALLOWED = new Set(["v1/forecast","v1/lightning/recent","v1/severe/alerts","v1/hail/reports","v1/wind/reports"]);
function authHeader() { const id=process.env.XWEATHER_CLIENT_ID||""; const sec=process.env.XWEATHER_CLIENT_SECRET||""; const token=Buffer.from(`${id}:${sec}`).toString("base64"); return `Basic ${token}`; }
export function mountXweather(app){
  app.get("/api/xweather/*", async (req,res)=>{
    const endpoint=req.params[0]; if(!ALLOWED.has(endpoint)) return res.status(400).json({ error:"Endpoint not allowed", endpoint });
    const u=new URL(`/${endpoint}`, BASE); for(const [k,v] of Object.entries(req.query)) u.searchParams.set(k,String(v));
    const key=u.toString(); const hit=cache.get(key); if(hit) return res.json(hit);
    try{ const data=await fetchJson(u.toString(), { headers:{ Authorization: authHeader(), Accept:"application/json" } }); cache.set(key,data); res.json(data); }
    catch(e){ res.status(e.status||502).json(e); }
  });
}
