import express from "express";
import PDFDocument from "pdfkit";
import { makeQueue } from "../helpers/queue.js";
import { sendEmailWithAttachment } from "../helpers/mailer.js";
import { fetchJson } from "../helpers/http.js";
const BASE = process.env.PUBLIC_BASE_URL || "http://localhost:3001";
const queue = makeQueue({ concurrency: 2 });
async function buildReportPdf(lat,lng,hours=24){
  const [impact, alerts] = await Promise.all([
    fetchJson(`${BASE}/api/impact?lat=${lat}&lng=${lng}&pollen=1`).catch(()=>null),
    fetchJson(`${BASE}/api/nws/alerts?lat=${lat}&lng=${lng}`).catch(()=>({features:[]})),
  ]);
  return await new Promise((resolve,reject)=>{
    const doc=new PDFDocument({size:"LETTER",margin:40}); const chunks=[];
    doc.on("data",c=>chunks.push(c)); doc.on("end",()=>resolve(Buffer.concat(chunks))); doc.on("error",reject);
    doc.fontSize(18).text("Disaster Direct – Incident Report"); doc.moveDown(0.5);
    doc.fontSize(10).fillColor("#555").text(`Generated: ${new Date().toISOString()}`).text(`Location: ${lat.toFixed(4)}, ${lng.toFixed(4)} | Window: last ${hours}h`);
    doc.moveDown(1).fillColor("#000");
    const score = impact?.impactScore ?? 0; const c=impact?.components || {};
    doc.fontSize(14).text(`Impact Score: ${score}/100`); doc.moveDown(0.25);
    doc.fontSize(10).text(`Wind: ${c.windScore ?? 0} (gust kt: ${c.windGustKts ?? "n/a"})`);
    doc.text(`Lightning: ${c.lightningScore ?? 0} (events: ${c.lightningCount ?? 0})`);
    doc.text(`Hail: ${c.hailScore ?? 0} (reports: ${c.hailCount ?? 0})`);
    doc.text(`Alerts: ${c.alertScore ?? 0} (${(c.alerts||[]).join(", ") || "none"})`);
    doc.end();
  });
}
export function mountReportsQueue(app){
  app.use(express.json());
  app.post("/api/reports/enqueue", async (req,res)=>{
    const { lat,lng,hours=24,email } = req.body || {};
    if (!lat || !lng || !email) return res.status(400).json({ error:"lat, lng, email required" });
    queue.push(async ()=>{
      const pdf = await buildReportPdf(Number(lat),Number(lng),Number(hours));
      await sendEmailWithAttachment({ to: email, subject: "Disaster Direct – Incident Report", text: `Incident report for ${lat},${lng} (last ${hours}h) attached.`, filename: "incident-report.pdf", content: pdf });
      console.log("Report sent:", email, lat, lng);
    });
    res.json({ queued:true, email, lat, lng, hours });
  });
}
