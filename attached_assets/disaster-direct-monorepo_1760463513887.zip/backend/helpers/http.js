export const sleep = (ms) => new Promise(r => setTimeout(r, ms));
export const isRetryable = (s) => s === 429 || s >= 500;
export async function fetchJson(url, init = {}, { retries = 2, backoffBaseMs = 250, backoffCapMs = 3000 } = {}) {
  const once = async () => {
    const r = await fetch(url, init);
    const ct = r.headers.get("content-type") || "";
    const data = ct.includes("application/json") ? await r.json() : await r.text();
    if (!r.ok) {
      const retryAfter = Number(r.headers.get("Retry-After"));
      const err = typeof data === "object" ? data : { error: String(data) };
      err.status = r.status; err.retryAfterSec = Number.isFinite(retryAfter) ? retryAfter : undefined;
      throw err;
    }
    return data;
  };
  let attempt = 0;
  while (true) {
    try { return await once(); }
    catch (e) {
      attempt++;
      if (!isRetryable(e.status || 0) || attempt > retries) throw e;
      const jitter = Math.random() * backoffBaseMs;
      const waitMs = (e.retryAfterSec ? e.retryAfterSec * 1000 : backoffBaseMs * 2 ** (attempt - 1) + jitter);
      await sleep(Math.min(waitMs, backoffCapMs));
    }
  }
}
