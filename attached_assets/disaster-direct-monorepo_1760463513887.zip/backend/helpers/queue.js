export function makeQueue({ concurrency = 2 } = {}) {
  const q = [];
  let running = 0;
  async function runNext() {
    if (running >= concurrency) return;
    const job = q.shift();
    if (!job) return;
    running++;
    try { await job.fn(); } catch (e) {
      console.error("Queue job failed:", e);
      if (job.retries > 0) { job.retries--; setTimeout(() => { q.push(job); runNext(); }, 3000); }
    } finally { running--; runNext(); }
  }
  function push(fn, retries = 2) { q.push({ fn, retries }); runNext(); }
  return { push };
}
