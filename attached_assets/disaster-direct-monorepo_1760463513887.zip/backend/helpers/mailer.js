import nodemailer from "nodemailer";
const FROM = process.env.FROM_EMAIL || "Disaster Direct <noreply@example.com>";
export async function sendEmailWithAttachment({ to, subject, text, filename, content }) {
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: false,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  await transporter.sendMail({ from: FROM, to, subject, text, attachments: [{ filename, content }] });
}
