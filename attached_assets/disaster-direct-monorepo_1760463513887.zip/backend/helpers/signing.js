import crypto from "crypto";
const SECRET = process.env.TILE_SIGN_SECRET || "dev-secret";
const DEFAULT_TTL = Number(process.env.TILE_SIGN_TTL_SEC || 300);
export function signUrl(pathWithQuery, ttlSec = DEFAULT_TTL) {
  const exp = Math.floor(Date.now() / 1000) + ttlSec;
  const payload = `${pathWithQuery}|${exp}`;
  const sig = crypto.createHmac("sha256", SECRET).update(payload).digest("hex");
  return { sig, exp };
}
export function verifySignature(pathWithQuery, sig, exp) {
  if (!sig || !exp) return false;
  const payload = `${pathWithQuery}|${exp}`;
  const expected = crypto.createHmac("sha256", SECRET).update(payload).digest("hex");
  if (expected !== sig) return false;
  if (Number(exp) < Math.floor(Date.now() / 1000)) return false;
  return true;
}
export function withSignedParams(urlPath, searchParams = new URLSearchParams(), ttlSec = DEFAULT_TTL) {
  const pathWithQuery = searchParams.toString() ? `${urlPath}?${searchParams}` : urlPath;
  const { sig, exp } = signUrl(pathWithQuery, ttlSec);
  const sp = new URLSearchParams(searchParams);
  sp.set("sig", sig); sp.set("exp", String(exp));
  return `${urlPath}?${sp.toString()}`;
}
