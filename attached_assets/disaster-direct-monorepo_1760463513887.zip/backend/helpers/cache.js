export function makeCache(defaultTtlMs = 60_000) {
  const m = new Map();
  const get = (k) => {
    const v = m.get(k);
    if (!v) return null;
    if (Date.now() > v.expireAt) { m.delete(k); return null; }
    return v.data;
  };
  const set = (k, d, ttlMs = defaultTtlMs) => m.set(k, { data: d, expireAt: Date.now() + ttlMs });
  return { get, set };
}
