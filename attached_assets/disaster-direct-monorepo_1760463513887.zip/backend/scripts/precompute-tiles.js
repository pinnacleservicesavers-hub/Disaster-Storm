import fetch from "node-fetch";
const BASE = process.env.PUBLIC_BASE_URL || "http://localhost:3001";
const bbox = { west: -85.5, south: 32.8, east: -83.5, north: 34.2 };
const zooms = [8,9,10];
function lngLatToTile(lng,lat,z){
  const n = 2**z;
  const xtile = Math.floor(((lng + 180) / 360) * n);
  const ytile = Math.floor((1 - Math.log(Math.tan((lat*Math.PI)/180)+1/Math.cos((lat*Math.PI)/180))/Math.PI)/2 * n);
  return { x:xtile, y:ytile };
}
async function warm(){
  for (const z of zooms){
    const tl = lngLatToTile(bbox.west, bbox.north, z);
    const br = lngLatToTile(bbox.east, bbox.south, z);
    const xMin = Math.min(tl.x, br.x), xMax = Math.max(tl.x, br.x);
    const yMin = Math.min(tl.y, br.y), yMax = Math.max(tl.y, br.y);
    console.log(`Warm z=${z} tiles: x=${xMin}..${xMax}, y=${yMin}..${yMax}`);
    for (let x=xMin; x<=xMax; x++){
      for (let y=yMin; y<=yMax; y++){
        const url = `${BASE}/api/impact/tiles/${z}/${x}/${y}.png?pollen=1&grid=6&ttl=300`;
        try { const r = await fetch(url, { headers:{ Accept:"image/png" } }); console.log(`${z}/${x}/${y} -> ${r.status}`); }
        catch(e){ console.warn(`${z}/${x}/${y} error:`, String(e)); }
      }
    }
  }
  console.log("Done");
}
warm();
