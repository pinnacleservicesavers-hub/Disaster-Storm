import express from "express";
import dotenv from "dotenv";
import rateLimit from "express-rate-limit";
import cors from "cors";

import { mountXweather } from "./routes/xweather.js";
import { mountNws } from "./routes/nws.js";
import { mountImpactV2 } from "./routes/impact.js";
import { mountImpactTiles } from "./routes/tiles.js";
import { mountSigner } from "./routes/signer.js";
import { mountReport } from "./routes/report.js";
import { mountReportsQueue } from "./routes/reportsQueue.js";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors({ origin: true, credentials: true }));
app.use("/api/", rateLimit({ windowMs: 60_000, max: 120 }));

app.get("/health", (req, res) => res.json({ status: "OK" }));

mountXweather(app);
mountNws(app);
mountImpactV2(app);
mountImpactTiles(app, { baseUrl: "" });
mountSigner(app);
mountReport(app, { baseUrl: "" });
mountReportsQueue(app);

app.listen(PORT, () => console.log(`Disaster Direct API running on :${PORT}`));
