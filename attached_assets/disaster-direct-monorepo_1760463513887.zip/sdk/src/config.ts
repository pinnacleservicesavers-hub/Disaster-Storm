export const defaultBaseUrl = (() => {
  if (typeof window !== "undefined") {
    const origin = window.location.origin;
    if (origin.includes("repl.co")) return origin;
  }
  return "http://localhost:3001";
})();
