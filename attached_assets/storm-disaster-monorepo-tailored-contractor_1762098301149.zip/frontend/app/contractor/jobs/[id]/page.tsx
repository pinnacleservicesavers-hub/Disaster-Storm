"use client";
import { useParams } from "next/navigation";
import { useState } from "react";
import { api, API_BASE } from "@/lib/api";

export default function JobDetail(){
  const params = useParams();
  const id = params?.id as string;
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const submit = async () => {
    await api("/claims/submit/email", { method:"POST", body: JSON.stringify({ job_id: id, to_email: to, subject, message }) });
    alert("Sent (or attempted). Check backend logs.");
  };
  return (
    <main className="p-8 space-y-4">
      <h1 className="text-2xl font-semibold">Job {id}</h1>
      <div className="border rounded p-3 space-y-2">
        <div className="font-semibold">Submit to insurer</div>
        <input className="border p-2 w-full" placeholder="to@example.com" value={to} onChange={e=>setTo(e.target.value)} />
        <input className="border p-2 w-full" placeholder="Subject (optional)" value={subject} onChange={e=>setSubject(e.target.value)} />
        <textarea className="border p-2 w-full h-32" placeholder="Message (optional)" value={message} onChange={e=>setMessage(e.target.value)} />
        <div className="flex gap-4">
          <a className="underline" target="_blank" href={`${API_BASE}/claims/${id}/submission.zip`}>Download ZIP</a>
          <button onClick={submit} className="bg-black text-white px-4 py-2 rounded">Submit via email</button>
        </div>
      </div>
    </main>
  );
}
