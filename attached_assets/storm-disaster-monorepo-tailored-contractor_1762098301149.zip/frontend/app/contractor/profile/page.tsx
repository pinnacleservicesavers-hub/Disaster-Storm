"use client";
import { useState } from "react";
import { api } from "@/lib/api";

export default function ContractorProfile() {
  const [userId, setUserId] = useState("");
  const [company_name, setCompany] = useState("");
  const [logo_url, setLogo] = useState("");
  const [legal_name, setLegal] = useState("");
  const [address, setAddr] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState("");

  const save = async () => {
    await api("/contractor/profile", { method:"POST", body: JSON.stringify({ user_id: userId, company_name, logo_url, legal_name, address, phone, email })});
    setMsg("Saved ✔");
  };

  return (
    <main className="p-8 max-w-2xl mx-auto space-y-3">
      <h1 className="text-2xl font-semibold">Contractor Branding</h1>
      <input className="border p-2 w-full" placeholder="Your user_id" value={userId} onChange={e=>setUserId(e.target.value)} />
      <input className="border p-2 w-full" placeholder="Company name" value={company_name} onChange={e=>setCompany(e.target.value)} />
      <input className="border p-2 w-full" placeholder="Logo URL (https://...)" value={logo_url} onChange={e=>setLogo(e.target.value)} />
      <input className="border p-2 w-full" placeholder="Legal name" value={legal_name} onChange={e=>setLegal(e.target.value)} />
      <input className="border p-2 w-full" placeholder="Address" value={address} onChange={e=>setAddr(e.target.value)} />
      <div className="grid grid-cols-2 gap-2">
        <input className="border p-2 w-full" placeholder="Phone" value={phone} onChange={e=>setPhone(e.target.value)} />
        <input className="border p-2 w-full" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      </div>
      <button onClick={save} className="bg-black text-white px-4 py-2 rounded">Save branding</button>
      {msg && <div className="text-green-700">{msg}</div>}
    </main>
  );
}
