"use client";
import { useState } from "react";
import { api } from "@/lib/api";

export default function Contracts() {
  const [trade, setTrade] = useState("tree_service");
  const [state, setState] = useState("FL");
  const [contract, setContract] = useState("... SIGN_HERE");

  return (
    <main className="p-8 max-w-3xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Contracts</h1>
      <div className="grid grid-cols-2 gap-2">
        <input className="border p-2" value={trade} onChange={e=>setTrade(e.target.value)} placeholder="Trade" />
        <input className="border p-2" value={state} onChange={e=>setState(e.target.value)} placeholder="State (e.g., FL)" />
      </div>
      <div className="flex gap-2">
        <button onClick={async()=>{ const r = await api(`/contractor/contracts/template?state=${state}&trade=${trade}`); setContract(r.template); }} className="px-4 py-2 rounded border">Load state template</button>
        <button onClick={async()=>{ const r = await api(`/contractor/contracts/compose?state=${state}&trade=${trade}`); setContract(r.contract); }} className="px-4 py-2 rounded border">Compose (state-aware)</button>
      </div>
      <textarea className="border p-2 w-full h-48" value={contract} onChange={e=>setContract(e.target.value)} />
    </main>
  );
}
