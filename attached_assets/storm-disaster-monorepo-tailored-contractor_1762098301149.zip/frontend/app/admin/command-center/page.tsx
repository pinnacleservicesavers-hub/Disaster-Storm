"use client";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";

export default function AdminCenter() {
  const [data, setData] = useState<any>();
  const [err, setErr] = useState("");

  useEffect(()=>{
    api("/admin/overview").then(setData).catch(()=>setErr("Admin only."));
  },[]);

  if (err) return <main className="p-8">{err}</main>;
  if (!data) return <main className="p-8">Loading...</main>;

  const { totals, leads, jobs, invoices, memberships } = data;
  return (
    <main className="p-8 max-w-6xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Admin Command Center</h1>
      <section className="grid grid-cols-4 gap-4">
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Jobs</div><div className="text-2xl font-semibold">{totals.jobs}</div></div>
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Leads</div><div className="text-2xl font-semibold">{totals.leads}</div></div>
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Invoices</div><div className="text-2xl font-semibold">{totals.invoices}</div></div>
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Invoiced $</div><div className="text-2xl font-semibold">${totals.invoiced_amount.toFixed(2)}</div></div>
      </section>
      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Recent Jobs</h2>
        <div className="border rounded">
          {jobs.map((j:any)=> (
            <div key={j.id} className="p-3 border-b">
              <div className="font-medium">#{j.id} — {j.status}</div>
              <div className="text-sm text-gray-600">{j.address}</div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
