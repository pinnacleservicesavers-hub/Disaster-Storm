

## Contractor-first Branding & Submission
- Edit branding at `/contractor/profile` (company name, logo URL, legal name, address, phone, email)
- Generated **letters** and the **cover letter** are rendered as branded PDFs (logo, contact block) and included in the Submission ZIP.
- Add `state` when generating a letter to include state-specific statutory notes: `POST /claims/letters/generate { job_id, type, state }`
- Submit package to insurer via email: `POST /claims/submit/email { job_id, to_email, subject?, message? }` (SMTP scaffold; configure your SMTP).

