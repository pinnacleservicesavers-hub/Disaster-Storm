from fastapi import APIRouter
from ..utils.store import store

router = APIRouter()

@router.get("/admin/overview")
def overview():
    leads = list(store.leads.values())
    jobs = list(store.jobs.values())
    invoices = list(store.invoices.values())
    memberships = list(store.memberships.values())
    totals = {
        "jobs": len(jobs),
        "leads": len(leads),
        "invoices": len(invoices),
        "memberships": len(memberships),
        "invoiced_amount": sum([float(v) for inv in invoices for v in inv.get("breakdown", {}).values() if str(v).replace('.','',1).isdigit()]),
    }
    return {"totals": totals, "leads": leads, "jobs": jobs, "invoices": invoices, "memberships": memberships}
