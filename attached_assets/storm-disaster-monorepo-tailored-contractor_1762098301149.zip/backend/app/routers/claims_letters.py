from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store
from datetime import datetime
import json, os

router = APIRouter()

RULES_PATH = os.path.join(os.path.dirname(__file__), "..", "legal_aob_rules.json")
def get_state_notes(state: str|None):
    if not state: return ""
    try:
        with open(RULES_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return (data.get(state.upper()) or {}).get("statutory_notes","")
    except Exception:
        return ""

class LetterBody(BaseModel):
    job_id: str
    type: str  # 'late' or 'demand60'
    state: str | None = None

def _gen(job_id: str, kind: str):
    inv = next((v for v in store.invoices.values() if v.get("job_id")==job_id), None)
    total = 0.0
    if inv:
        for v in inv.get("breakdown", {}).values():
            try: total += float(v)
            except: pass
    if kind == "late":
        subject = f"Notice of Past Due Payment — Job {job_id}"
        body = f"""Per the binding contract and completion of work, payment for Job {job_id} in the amount of ${total:,.2f} is past due. 
Please remit payment immediately to avoid additional remedies. If payment has already been sent, please reply with confirmation.

Regards,
Contractor Billing Team
"""
    else:
        subject = f"60-Day Demand — Intent to File Lien — Job {job_id}"
        body = f"""This is a formal demand for payment in the amount of ${total:,.2f} for services rendered under Job {job_id}. 
If full payment is not received within ten (10) days, Contractor reserves the right to file a lien and pursue all legal remedies available.

Sincerely,
Contractor Billing Team
"""
    return subject, body

@router.post("/claims/letters/generate")
def generate_letter(body: LetterBody):
    subject, msg = _gen(body.job_id, body.type)
    event = {"job_id": body.job_id, "kind": "letter", "letter_type": body.type, "subject": subject, "message": msg, "state": (body.state or "").upper(), "when": datetime.utcnow().isoformat()}
    store.jobs.setdefault(body.job_id, {}).setdefault("timeline", []).append(event)
    store.jobs.setdefault(body.job_id, {}).setdefault("letters", []).append(event)
    return {"ok": True, "letter": event}

@router.get("/claims/{job_id}/letters")
def list_letters(job_id: str):
    return {"letters": store.jobs.get(job_id, {}).get("letters", [])}
