from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store

router = APIRouter()

class Profile(BaseModel):
    user_id: str
    company_name: str|None = None
    logo_url: str|None = None
    legal_name: str|None = None
    address: str|None = None
    phone: str|None = None
    email: str|None = None

@router.post("/contractor/profile")
def upsert_profile(body: Profile):
    u = store.users.get(body.user_id) or {}
    u.setdefault("profile", {})
    u["profile"].update({k:v for k,v in body.dict().items() if k!="user_id" and v is not None})
    store.users[body.user_id] = u
    return {"ok": True, "profile": u["profile"]}

@router.get("/contractor/profile/{user_id}")
def get_profile(user_id: str):
    u = store.users.get(user_id) or {}
    return {"profile": u.get("profile", {})}
