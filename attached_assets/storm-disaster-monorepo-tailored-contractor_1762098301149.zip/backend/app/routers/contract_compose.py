from fastapi import APIRouter, Query
from ..services.contract_composer import compose

router = APIRouter()

@router.get("/contractor/contracts/compose")
def compose_contract(state: str = Query(..., min_length=2, max_length=2), trade: str = Query(...)):
    return compose(state, trade)
