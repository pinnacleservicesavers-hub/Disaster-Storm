import io, json, zipfile
from fastapi import APIRouter, Response
from ..utils.pdf import html_to_pdf_bytes
from ..utils.store import store
from ..services.branding import render_letter_pdf
import os

router = APIRouter()

RULES_PATH = os.path.join(os.path.dirname(__file__), "..", "legal_aob_rules.json")
def state_notes(st: str|None):
    if not st: return ""
    try:
        with open(RULES_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return (data.get(st.upper()) or {}).get("statutory_notes","")
    except Exception:
        return ""

def build_report_html(job_id: str):
    inv = next((v for v in store.invoices.values() if v.get("job_id")==job_id), None)
    total = 0.0
    if inv:
        for v in inv.get("breakdown", {}).values():
            try: total += float(v)
            except: pass
    xact = (inv or {}).get("xactimate", {}).get("total", 0.0)
    var = total - xact
    return f"""<html><body><h1>Claim Report {job_id}</h1>
    <p>Total: ${total:,.2f} Xactimate: ${xact:,.2f} Variance: ${var:,.2f}</p></body></html>"""

def build_cover_letter(job_id: str, profile: dict):
    subject = f"Submission of Claim Package — Job {job_id}"
    body = f"""Please find attached the complete claim package for Job {job_id} including invoice, comparables, documentation, and letters.
We request prompt review and payment. Direct any questions to the contact below.

Thank you,
{profile.get('company_name') or 'Contractor'}
"""
    return {"subject": subject, "body": body}

@router.get("/claims/{job_id}/submission.zip")
async def submission_zip(job_id: str):
    # Contractor profile: look up by contractor on job if present, or a default
    job = store.jobs.get(job_id, {})
    contractor_id = job.get("contractor_id")
    profile = {}
    if contractor_id and contractor_id in store.users:
        profile = store.users[contractor_id].get("profile", {})
    html = build_report_html(job_id)
    pdf = html_to_pdf_bytes(html)
    cover_letter = build_cover_letter(job_id, profile)

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"claim-report-{job_id}.pdf", pdf)
        # Cover letter PDF
        cover_pdf = render_letter_pdf({"subject": cover_letter["subject"], "body": cover_letter["body"]}, profile, "")
        z.writestr(f"cover-letter-{job_id}.pdf", cover_pdf)
        # Letters: txt + PDF with state notes
        letters = (store.jobs.get(job_id, {}) or {}).get("letters", [])
        for i, lt in enumerate(letters, start=1):
            txt_name = f"letters/{i:02d}-{lt.get('letter_type','letter')}.txt"
            z.writestr(txt_name, (lt.get("subject","Letter") + "\n\n" + lt.get("message","")))
            statutory = state_notes(lt.get("state"))
            pdf_blob = render_letter_pdf({"subject": lt.get("subject","Letter"), "body": lt.get("message","")}, profile, statutory)
            z.writestr(f"letters/{i:02d}-{lt.get('letter_type','letter')}.pdf", pdf_blob)

        z.writestr("manifest.json", json.dumps({
            "job_id": job_id,
            "letters_included": True,
            "contractor_profile": profile
        }, indent=2))

    buf.seek(0)
    return Response(content=buf.read(), media_type="application/zip",
                    headers={"Content-Disposition": f"attachment; filename=submission-{job_id}.zip"})
