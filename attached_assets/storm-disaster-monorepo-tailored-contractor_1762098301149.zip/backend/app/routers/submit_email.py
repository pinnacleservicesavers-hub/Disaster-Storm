from fastapi import APIRouter
from pydantic import BaseModel
import smtplib, ssl, io
from email.message import EmailMessage
from ..utils.store import store
from .export import submission_zip

router = APIRouter()

class EmailBody(BaseModel):
    job_id: str
    to_email: str
    subject: str | None = None
    message: str | None = None

@router.post("/claims/submit/email")
async def send_claim_email(body: EmailBody):
    # Build ZIP in-memory
    # Reuse submission_zip to generate bytes
    resp = await submission_zip(body.job_id)
    content = resp.body if hasattr(resp, "body") else resp  # FastAPI Response has .body

    msg = EmailMessage()
    msg["Subject"] = body.subject or f"Claim Submission — Job {body.job_id}"
    msg["From"] = "no-reply@stormdisaster.local"
    msg["To"] = body.to_email
    msg.set_content(body.message or "Please find the claim submission attached.")

    msg.add_attachment(content, maintype="application", subtype="zip", filename=f"submission-{body.job_id}.zip")

    # SMTP scaffold (TLS). Replace host/user/pass with real values in your env.
    host = "smtp.example.com"; port = 587; user = "user"; password = "pass"
    context = ssl.create_default_context()
    try:
        with smtplib.SMTP(host, port) as server:
            server.starttls(context=context)
            server.login(user, password)
            server.send_message(msg)
        return {"ok": True}
    except Exception as e:
        # For development, just return ok:false
        return {"ok": False, "error": str(e)}
