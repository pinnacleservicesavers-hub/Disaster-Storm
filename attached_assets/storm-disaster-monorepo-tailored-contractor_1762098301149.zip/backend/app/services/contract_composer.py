import json, os

RULES_PATH = os.path.join(os.path.dirname(__file__), "..", "legal_aob_rules.json")
TPL_PATH = os.path.join(os.path.dirname(__file__), "..", "legal_contract_templates.json")

DEFAULT_CLAUSES = {
    "AOB_ALLOWED": "Assignment of Benefits: Customer assigns post-loss benefits to Contractor to the extent permitted by {STATE} law. Customer acknowledges required disclosures and right to rescind as applicable.",
    "AOB_DISALLOWED": "Direction-to-Pay & Authorization: Customer authorizes Contractor to communicate with Insurer and directs payment for covered work to Contractor. No assignment of benefits is made.",
    "DUTY_TO_MITIGATE": "Mitigation: Customer authorizes necessary measures to mitigate further damage in compliance with policy obligations.",
    "SAFETY_ACCESS": "Access & Safety: Customer acknowledges temporary closures or safety measures may be required to restore safe ingress/egress during work."
}

def compose(state: str, trade: str):
    st = (state or '').upper()
    with open(RULES_PATH, "r", encoding="utf-8") as f:
        rules = json.load(f)
    with open(TPL_PATH, "r", encoding="utf-8") as f:
        tpls = json.load(f)

    rule = rules.get(st, {"aob_allowed": False, "notes": "No rule found; default to caution."})
    tpl = tpls.get(st) or tpls.get("default", "")

    text = tpl.replace("{STATE}", st).replace("{TRADE}", trade)

    clauses = []
    if rule.get("aob_allowed"):
        clauses.append(DEFAULT_CLAUSES["AOB_ALLOWED"].replace("{STATE}", st))
    else:
        clauses.append(DEFAULT_CLAUSES["AOB_DISALLOWED"])
    clauses.append(DEFAULT_CLAUSES["DUTY_TO_MITIGATE"])
    clauses.append(DEFAULT_CLAUSES["SAFETY_ACCESS"])

    composed = text + "\n\n---\nCLAUSES:\n- " + "\n- ".join(clauses) + "\n"
    return {"state": st, "trade": trade, "aob_allowed": rule.get("aob_allowed"), "notes": rule.get("notes"), "contract": composed}
