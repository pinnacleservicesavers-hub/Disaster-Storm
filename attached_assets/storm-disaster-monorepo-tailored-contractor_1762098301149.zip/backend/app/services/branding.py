from jinja2 import Template
from ..utils.pdf import html_to_pdf_bytes

def render_letter_pdf(letter: dict, profile: dict, statutory_notes: str|None=None) -> bytes:
    # Load inline template content (in a real app load from file system)
    tpl = '''<!doctype html><html><head><meta charset="utf-8"><style>
  body { font-family: Arial, sans-serif; padding: 40px; color: #111; }
  .header { display: flex; align-items: center; gap: 16px; border-bottom: 2px solid #111; padding-bottom: 12px; margin-bottom: 20px; }
  .logo { height: 56px; width: 56px; object-fit: contain; border-radius: 8px; }
  .brand { font-size: 18px; font-weight: 700; }
  .meta { font-size: 12px; color: #555; }
  h1 { font-size: 20px; margin: 18px 0 6px; }
  .statute { background: #f6f6f6; border-left: 3px solid #222; padding: 10px 12px; font-size: 12px; color: #333; }
  .footer { border-top: 1px dashed #bbb; margin-top: 28px; padding-top: 10px; font-size: 12px; color: #555; }
  pre { white-space: pre-wrap; font-family: inherit; }
</style></head><body>
  <div class="header">
    {% if logo_url %}<img class="logo" src="{{ logo_url }}">{% endif %}
    <div>
      <div class="brand">{{ company_name or "Contractor" }}</div>
      <div class="meta">
        {{ legal_name or "" }}{% if legal_name %} · {% endif %}
        {{ address or "" }}{% if address %} · {% endif %}
        {{ phone or "" }}{% if phone %} · {% endif %}
        {{ email or "" }}
      </div>
    </div>
  </div>
  <h1>{{ subject }}</h1>
  <pre>{{ body_text }}</pre>
  {% if statutory_notes %}<div class="statute"><b>State notes:</b> {{ statutory_notes }}</div>{% endif %}
  <div class="footer">Generated on behalf of the contractor.</div>
</body></html>'''
    t = Template(tpl)
    html = t.render(
        subject=letter.get("subject","Letter"),
        body_text=letter.get("body",""),
        logo_url=profile.get("logo_url"),
        company_name=profile.get("company_name"),
        legal_name=profile.get("legal_name"),
        address=profile.get("address"),
        phone=profile.get("phone"),
        email=profile.get("email"),
        statutory_notes=statutory_notes or ""
    )
    return html_to_pdf_bytes(html)
