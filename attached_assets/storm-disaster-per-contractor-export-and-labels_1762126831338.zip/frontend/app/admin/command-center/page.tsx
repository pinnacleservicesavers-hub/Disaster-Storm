"use client";
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import CadenceEditor from './cadence';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';

export default function AdminCenter(){
  const [nextInfo, setNextInfo] = useState<any>();
  const [series, setSeries] = useState<any[]>([]);
  const [onlyUnpaid, setOnlyUnpaid] = useState(false);
  const [contractors, setContractors] = useState<any[]>([]);
  const [contractor, setContractor] = useState('');

  const load = async ()=>{
    setNextInfo(await api('/admin/reminders/next').catch(()=>null));
    const qs = new URLSearchParams();
    if (onlyUnpaid) qs.set('only_unpaid','true');
    if (contractor) qs.set('contractor_id', contractor);
    const r = await api('/admin/reminders/audit/series' + (qs.toString()?`?${qs.toString()}`:''));
    setSeries(r.series);
  };

  useEffect(()=>{ load(); },[]);
  useEffect(()=>{ const h=()=>setContractors([])||load(); window.addEventListener('onlyActiveContractorsChange', h); return ()=>window.removeEventListener('onlyActiveContractorsChange', h); },[]);
  useEffect(()=>{ const qs = new URLSearchParams(); if (onlyUnpaid){}; if ((window as any).__ONLY_ACTIVE_CONTRACTORS__) qs.set('only_active','true'); api('/admin/contractors' + (qs.toString()?`?${qs.toString()}`:'' )).then(r=>setContractors(r.contractors||[])).catch(()=>{}); },[ (window as any).__ONLY_ACTIVE_CONTRACTORS__ ])
  useEffect(()=>{ load(); },[onlyUnpaid, contractor]);

  return (
    <main className="p-8 max-w-6xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Admin Command Center</h1>

      <section className="grid grid-cols-3 gap-4">
        <div className="border rounded p-4">
          <div className="text-sm text-gray-600">Next reminder ETA</div>
          <div className="text-lg font-semibold">{nextInfo?.next_due_at || '—'}</div>
          <div className="text-xs text-gray-500">{nextInfo?.scheduled_count || 0} scheduled</div>
        </div>
        <div className="border rounded p-4 col-span-2">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-semibold">Reminders timeline (last 30 days)</div>
            <div className="flex items-center gap-3">
              <a className="underline text-sm" href="/admin/reminders/audit.csv" target="_blank">Download CSV</a>
              <label className="text-sm flex items-center gap-1"><input type="checkbox" id="scrubpii" /> Scrub PII</label>
              <a className="underline text-sm" href="#" onClick={(e)=>{ e.preventDefault(); const s=(document.getElementById('scrubpii') as HTMLInputElement)?.checked; window.open(`/admin/export/all.zip${s?'?scrub=true':''}`, '_blank'); }}>Export All (ZIP)</a>
            </div>
          </div>

          <div className="flex items-center gap-3 mb-3">
            <a className="underline text-sm" href="#" onClick={(e)=>{ e.preventDefault(); if(!contractor){ alert('Select a contractor first'); return; } window.open(`/admin/export/contractor/${contractor}.zip`, '_blank'); }}>Export contractor</a>
            <label className="text-sm flex items-center gap-2">
              <input type="checkbox" onChange={e=>{ (window as any).__ONLY_ACTIVE_CONTRACTORS__ = e.target.checked; const event = new Event("onlyActiveContractorsChange"); window.dispatchEvent(event); }} />
              Only active memberships
            </label>
            <label className="text-sm flex items-center gap-2">
              <input type="checkbox" checked={onlyUnpaid} onChange={e=>setOnlyUnpaid(e.target.checked)} />
              Only unpaid jobs
            </label>
            <select className="border p-2 text-sm" value={contractor} onChange={e=>setContractor(e.target.value)}>
              <option value="">All contractors</option>
              {contractors.map((c:any)=> { const status=(c.membership?.status||'unknown'); const label = `${c.company_name || c.id} — ${status}`; return <option key={c.id} value={c.id}>{label}</option>; })}
            </select>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={series}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Line type="monotone" dataKey="sent" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      <CadenceEditor />
    </main>
  );
}
