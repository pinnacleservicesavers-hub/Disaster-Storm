from fastapi import FastAPI
app=FastAPI()

from .routers import utils_misc, jobs, letters
app.include_router(utils_misc.router)
app.include_router(jobs.router)
app.include_router(letters.router)

from .routers import admin_legal
app.include_router(admin_legal.router, tags=['admin'])
