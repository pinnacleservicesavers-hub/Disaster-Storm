# SSS Sample Data Seed Patch

## Adds
- **POST `/api/dev/seed`** (admin-only): wipes & seeds demo data
- **`app/seed/sample_seed.py`**: standalone script for seeding

## Data created
- Carriers: Acme, Example Carrier, Atlas Mutual
- Contractors: 5 demo locations
- Assets: 5 properties
- Alerts: NWS watch, NHC cone, MRMS hail (1.0" & 1.5")
- Claims: linked to assets & carriers

## Use (server running)
```
curl -X POST http://localhost:8000/api/dev/seed   -H "Authorization: Bearer <ADMIN_JWT>"
```
Or run from shell:
```
python -m app.seed.sample_seed
```
