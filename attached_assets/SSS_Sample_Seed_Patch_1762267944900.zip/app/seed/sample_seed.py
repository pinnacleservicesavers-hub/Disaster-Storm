from sqlalchemy.orm import Session
from sqlalchemy import text
from datetime import datetime
import random

from app.core.db import Base, engine, SessionLocal
from app.models.entities import Carrier, Contractor, Asset, Claim, Alert

def _square_wkt(lon, lat, dlon=0.5, dlat=0.5):
    p = [(lon-dlon,lat-dlat),(lon+dlon,lat-dlat),(lon+dlon,lat+dlat),(lon-dlon,lat+dlat),(lon-dlon,lat-dlat)]
    pts = ", ".join([f"{x} {y}" for x,y in p])
    return f"POLYGON(({pts}))"

def wipe_and_seed():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)

    db: Session = SessionLocal()
    try:
        carriers = ["Acme", "Example Carrier", "Atlas Mutual"]
        carrier_objs = []
        for name in carriers:
            c = Carrier(name=name)
            db.add(c); carrier_objs.append(c)
        db.flush()

        contr_data = [
            ("Strategic Service Savers — TX", 29.7604, -95.3698, "+1-281-555-0100"),
            ("Strategic Service Savers — FL", 27.9506, -82.4572, "+1-727-555-0101"),
            ("Strategic Service Savers — NC", 35.7796, -78.6382, "+1-919-555-0102"),
            ("Strategic Service Savers — OK", 35.4676, -97.5164, "+1-405-555-0103"),
            ("Strategic Service Savers — CO", 39.7392, -104.9903, "+1-720-555-0104"),
        ]
        contr_objs = []
        for name, lat, lon, phone in contr_data:
            cc = Contractor(name=name, lat=lat, lon=lon, phone=phone)
            db.add(cc); contr_objs.append(cc)
        db.flush()

        assets_data = [
            ("Houston HQ", 29.7604, -95.3698, "HOU-HQ"),
            ("Tampa Retail", 27.9506, -82.4572, "TPA-RT"),
            ("Raleigh Warehouse", 35.7796, -78.6382, "RDU-WH"),
            ("OKC Plant", 35.4676, -97.5164, "OKC-PL"),
            ("Denver DC", 39.7392, -104.9903, "DEN-DC"),
        ]
        asset_objs = []
        for name, lat, lon, ref in assets_data:
            a = Asset(name=name, lat=lat, lon=lon, ref_id=ref)
            db.add(a); asset_objs.append(a)
        db.flush()

        alerts = []
        alerts.append(Alert(source="NWS", title="Severe Thunderstorm Watch", severity="watch",
                            geom_wkt=_square_wkt(-95.5, 29.7, 1.0, 0.7),
                            properties_json='{"type":"thunderstorm"}'))
        alerts.append(Alert(source="NHC", title="Tropical Storm Cone", severity="ts",
                            geom_wkt=_square_wkt(-83.0, 28.2, 1.2, 0.9),
                            properties_json='{"advisory":"ALxx"}'))
        alerts.append(Alert(source="MRMS", title="Hail ≥ 1 in", severity="elevated",
                            geom_wkt=_square_wkt(-78.8, 35.7, 0.8, 0.6),
                            properties_json='{"threshold":25.4}'))
        alerts.append(Alert(source="MRMS", title="Hail ≥ 1.5 in", severity="high",
                            geom_wkt=_square_wkt(-97.5, 35.5, 0.8, 0.6),
                            properties_json='{"threshold":38.1}'))
        for al in alerts:
            db.add(al)
        db.flush()

        statuses = ["open", "investigating", "closed"]
        claims = []
        for i, a in enumerate(asset_objs, start=1):
            cl = Claim(carrier_id=random.choice(carrier_objs).id,
                       policy_number=f"POL-{1000+i}",
                       asset_id=a.id,
                       status=random.choice(statuses),
                       notes="Seeded claim")
            db.add(cl); claims.append(cl)
        db.commit()
        return {
            "carriers": [c.name for c in carrier_objs],
            "contractors": [c.name for c in contr_objs],
            "assets": [a.name for a in asset_objs],
            "alerts": [a.title for a in alerts],
            "claims": [c.policy_number for c in claims],
        }
    finally:
        db.close()

if __name__ == "__main__":
    res = wipe_and_seed()
    print("Seeded:", res)
