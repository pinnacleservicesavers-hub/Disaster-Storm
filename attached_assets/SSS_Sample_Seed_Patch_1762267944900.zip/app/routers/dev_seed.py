from fastapi import APIRouter, Depends, Query
from app.core.security import role_required
from app.seed.sample_seed import wipe_and_seed

router = APIRouter()

@router.post("/dev/seed")
def dev_seed(wipe: bool = Query(True, description="Drop & recreate tables"), _: dict = Depends(role_required(["admin"]))):
    result = wipe_and_seed()
    return {"ok": True, "seeded": result}
