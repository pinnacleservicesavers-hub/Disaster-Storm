# Storm Risk API Starter Kit

This bundle gives you:
- **node-proxy/**: Express server that normalizes NOAA/NHC/MRMS/OSM/USGS/SCAN endpoints under `/api/*`.
- **python-risk-api/**: FastAPI skeleton providing a `/v1/risk` endpoint you can replace with your model.

## Typical Replit Setup

1) Create a new Repl (Node.js) → upload `node-proxy` folder, run:
```
cd node-proxy
cp .env.example .env
npm install
npm run dev
```
Visit `/healthz` to confirm.

2) Optionally add a second Repl (Python) for the model API, run:
```
cd python-risk-api
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Frontend usage (example fetch)

```js
// NHC forecast cone (GeoJSON)
const res = await fetch('/api/nhc/query?layer=7&where=1%3D1&outFields=*&f=geojson');
const cone = await res.json();

// MRMS file (binary)
const mrms = await fetch('/api/mrms/proxy?path=2D/SeamlessHSR/Latest/SeamlessHSR_00.50_YYYYMMDD-HHMM00.grib2.gz');

// NEXRAD list
const list = await fetch('/api/nexrad/list?level=L2&prefix=2025/09/10/KTLX/').then(r => r.json());

// Overpass
const overpass = await fetch('/api/overpass', {
  method: 'POST',
  headers: {'content-type': 'application/json'},
  body: JSON.stringify({ query: '[out:json];node["power"="pole"](32.3,-85.1,32.7,-84.8);out;' })
}).then(r => r.json());
```

## Notes
- For **NLCD/USFS canopy** (GeoTIFF rasters), pre-download & preprocess (COG/tiles) rather than live-API.
- **EarthDefine TreeMap** is commercial; contact vendor for API/token.
- Keep queries small on Overpass; consider caching results.
