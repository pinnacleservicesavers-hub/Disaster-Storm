// Storm Risk Node Proxy
// Normalizes external APIs behind /api/* for easy frontend access (CORS-friendly).
// Node >=18 recommended (uses global fetch).

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const { parseStringPromise } = require('xml2js');

const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(morgan('dev'));

const NEXRAD_L2_HTTP = process.env.NEXRAD_L2_HTTP;
const NEXRAD_L3_HTTP = process.env.NEXRAD_L3_HTTP;
const MRMS_BASE = process.env.MRMS_BASE;
const NHC_BASE = process.env.NHC_BASE;
const EPQS_URL = process.env.EPQS_URL;
const OVERPASS_URL = process.env.OVERPASS_URL;
const DROUGHT_GCS_PREFIX = process.env.DROUGHT_GCS_PREFIX;
const SCAN_API_BASE = process.env.SCAN_API_BASE;

app.get('/healthz', (req, res) => res.json({ ok: true }));

// ---------- NHC GIS: generic /query wrapper (GeoJSON) ----------
// Example: /api/nhc/query?layer=7&where=1%3D1&outFields=*&f=geojson
app.get('/api/nhc/query', async (req, res) => {
  try {
    const layer = req.query.layer || '7';
    const params = new URLSearchParams({
      where: req.query.where || '1=1',
      outFields: req.query.outFields || '*',
      f: req.query.f || 'geojson'
    });
    const url = `${NHC_BASE}/${layer}/query?${params.toString()}`;
    const r = await fetch(url);
    if (!r.ok) return res.status(r.status).send(await r.text());
    res.set('content-type', r.headers.get('content-type') || 'application/json');
    const buf = await r.arrayBuffer();
    res.send(Buffer.from(buf));
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'NHC query failed', details: String(e) });
  }
});

// ---------- MRMS proxy (GRIB2/GeoTIFF/etc.) ----------
// Example: /api/mrms/proxy?path=2D/SeamlessHSR/Latest/SeamlessHSR_00.50_20250911-205400.grib2.gz
app.get('/api/mrms/proxy', async (req, res) => {
  try {
    const path = req.query.path;
    if (!path) return res.status(400).json({ error: 'missing ?path=' });
    const url = `${MRMS_BASE}/${path.replace(/^\/+/, '')}`;
    const r = await fetch(url);
    if (!r.ok) return res.status(r.status).send(await r.text());
    // Pass through content type & encoding
    if (r.headers.get('content-type')) res.set('content-type', r.headers.get('content-type'));
    if (r.headers.get('content-encoding')) res.set('content-encoding', r.headers.get('content-encoding'));
    res.send(Buffer.from(await r.arrayBuffer()));
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'MRMS proxy failed', details: String(e) });
  }
});

// ---------- NEXRAD S3 HTTP XML listing -> JSON ----------
// Example: /api/nexrad/list?level=L2&prefix=2025/09/10/KTLX/
app.get('/api/nexrad/list', async (req, res) => {
  try {
    const level = req.query.level || 'L2'; // L2 or L3
    const base = level === 'L3' ? NEXRAD_L3_HTTP : NEXRAD_L2_HTTP;
    const prefix = req.query.prefix || '';
    const params = new URLSearchParams({
      'list-type': '2',
      'max-keys': req.query.max || '1000',
      'prefix': prefix
    });
    const url = `${base}/?${params.toString()}`;
    const r = await fetch(url);
    if (!r.ok) return res.status(r.status).send(await r.text());
    const xml = await r.text();
    const parsed = await parseStringPromise(xml, { explicitArray: false, ignoreAttrs: false });
    const items = (parsed?.ListBucketResult?.Contents || []);
    const out = Array.isArray(items) ? items : [items];
    const files = out.filter(Boolean).map(o => ({
      key: o.Key,
      size: Number(o.Size || 0),
      lastModified: o.LastModified
    }));
    res.json({ bucket: base, prefix, count: files.length, files });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'NEXRAD list failed', details: String(e) });
  }
});

// ---------- USGS EPQS elevation (point query) ----------
// Example: /api/epqs?lat=32.46&lon=-84.99&units=Feet
app.get('/api/epqs', async (req, res) => {
  try {
    const { lat, lon } = req.query;
    if (!lat or !lon) return res.status(400).json({ error: 'lat & lon required' });
    const units = req.query.units || 'Feet';
    const params = new URLSearchParams({ x: lon, y: lat, units, output: 'json' });
    const url = `${EPQS_URL}?${params.toString()}`;
    const r = await fetch(url);
    if (!r.ok) return res.status(r.status).send(await r.text());
    res.set('content-type', 'application/json');
    res.send(await r.text());
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'EPQS failed', details: String(e) });
  }
});

// ---------- Overpass passthrough ----------
// POST { "query": "...Overpass QL..." }
app.post('/api/overpass', async (req, res) => {
  try {
    const q = req.body?.query;
    if (!q) return res.status(400).json({ error: 'missing JSON body .query' });
    const r = await fetch(OVERPASS_URL, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: `data=${encodeURIComponent(q)}`
    });
    if (!r.ok) return res.status(r.status).send(await r.text());
    res.set('content-type', r.headers.get('content-type') || 'application/json');
    res.send(await r.text());
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Overpass failed', details: String(e) });
  }
});

// ---------- SCAN proxy (AWDB REST) ----------
// Example: /api/scan/getStations?state=GA
app.get('/api/scan/:method', async (req, res) => {
  try {
    const method = req.params.method;
    const qs = new URLSearchParams(req.query).toString();
    const url = `${SCAN_API_BASE}/${method}?${qs}`;
    const r = await fetch(url);
    if (!r.ok) return res.status(r.status).send(await r.text());
    res.set('content-type', r.headers.get('content-type') || 'application/json');
    res.send(await r.text());
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'SCAN proxy failed', details: String(e) });
  }
});

// ---------- Drought.gov tiles (pattern) ----------
// This endpoint simply echoes the correct GCS prefix so your frontend can build tile URLs.
app.get('/api/drought/prefix', (req, res) => {
  res.json({ prefix: DROUGHT_GCS_PREFIX });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Node proxy listening on :${port}`));
