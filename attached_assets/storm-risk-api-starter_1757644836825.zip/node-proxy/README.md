# Storm Risk Node Proxy

Normalize multiple external datasets behind stable `/api/*` routes so your frontend doesn't have to fight CORS or weird query formats.

## Quick start (Replit or local)

```bash
cd node-proxy
cp .env.example .env
# (edit .env as needed)
npm install
npm run dev
# open https://<repl-url>/healthz
```

## Endpoints

- **NHC GeoJSON**: `/api/nhc/query?layer=7&where=1%3D1&outFields=*&f=geojson`
- **MRMS proxy**: `/api/mrms/proxy?path=2D/SeamlessHSR/Latest/...grib2.gz`
- **NEXRAD list**: `/api/nexrad/list?level=L2&prefix=2025/09/10/KTLX/`
- **EPQS**: `/api/epqs?lat=32.46&lon=-84.99&units=Feet`
- **Overpass**: `POST /api/overpass` with JSON body `{ "query": "..." }`
- **SCAN (AWDB)**: `/api/scan/getStations?state=GA` (any AWDB method)
- **Drought tiles prefix**: `/api/drought/prefix` → `{ "prefix": "https://storage.googleapis.com/noaa-nidis-drought-gov-data" }`

> For NLCD/USFS canopy, pre-download GeoTIFFs (build-time) or serve from your own bucket.
