# Python Risk API (FastAPI)

A minimal risk endpoint you can expand with real features (soil moisture, canopy, MRMS, etc.).

## Quick start (Replit or local)

```bash
cd python-risk-api
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export EPQS_URL="https://apps.nationalmap.gov/epqs/pqs.php"
uvicorn main:app --host 0.0.0.0 --port 8000
```

Test:
```
curl "http://localhost:8000/v1/risk?lat=32.46&lon=-84.99"
```

You will replace the dummy risk formula with features you fetch from MRMS/CPC/NLCD, etc.
