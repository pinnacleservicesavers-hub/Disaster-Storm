# FastAPI skeleton for /v1/risk
# - Demonstrates fetching external services and returning a risk score.
# - Replace the dummy model with your ML model or heuristics.

import os, math
import httpx
from fastapi import FastAPI, HTTPException, Query

EPQS_URL = os.getenv("EPQS_URL", "https://apps.nationalmap.gov/epqs/pqs.php")

app = FastAPI(title="Storm Risk API", version="0.1.0")

@app.get("/healthz")
def health():
    return {"ok": True}

@app.get("/v1/risk")
async def risk(lat: float = Query(...), lon: float = Query(...)):
    # Example: use EPQS elevation as an input and combine with a dummy wind proxy
    async with httpx.AsyncClient(timeout=20) as client:
        params = {"x": lon, "y": lat, "units": "Feet", "output": "json"}
        r = await client.get(EPQS_URL, params=params)
        if r.status_code != 200:
            raise HTTPException(r.status_code, f"EPQS error: {r.text}")
        j = r.json()
        elevation_ft = j.get("USGS_Elevation_Point_Query_Service", {})                         .get("Elevation_Query", {})                         .get("Elevation", 0.0) or 0.0

    # Dummy risk formula: higher risk at lower elevation (flood/wind channeling proxy)
    # Replace with: MRMS wind/rain + CPC soil moisture + canopy density + slope, etc.
    risk_score = max(0.0, min(1.0, 1.0 - (elevation_ft / 3000.0)))

    return {
        "lat": lat,
        "lon": lon,
        "features": {
            "elevation_ft": elevation_ft
        },
        "risk_score": risk_score,
        "explain": "Demo: risk increases at lower elevation. Replace with your real model."
    }

# Run with: uvicorn main:app --host 0.0.0.0 --port 8000
