
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from ..utils.store import store
from ..utils.security import get_ctx
router = APIRouter()
class SMTPSettings(BaseModel):
    host: str
    port: int = 587
    user: str | None = None
    password: str | None = None
    use_tls: bool = True
    from_email: str | None = None
@router.get("/settings/smtp")
def get_smtp(): return store.settings.get("smtp", {})
@router.post("/settings/smtp")
def set_smtp(body: SMTPSettings, request: Request):
    ctx = get_ctx(request)
    if ctx.get("role") != "admin": raise HTTPException(status_code=403, detail="admin only")
    store.settings["smtp"] = body.dict()
    return {"ok": True, "smtp": store.settings["smtp"]}
