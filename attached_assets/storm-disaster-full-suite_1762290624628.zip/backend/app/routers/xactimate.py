
from fastapi import APIRouter, UploadFile, File, HTTPException, Form
from typing import Dict, Any, List
import csv, io, json
router = APIRouter()
def parse_csv(data: bytes)->List[Dict[str,Any]]:
    f=io.StringIO(data.decode('utf-8', errors='ignore')); reader=csv.DictReader(f); out=[]
    for r in reader:
        out.append({"code": (r.get("Code") or r.get("Item") or "").strip(),"desc": (r.get("Description") or r.get("Desc") or "").strip(),"qty": float((r.get("Qty") or r.get("Quantity") or 0) or 0),"unit_price": float((r.get("Unit Price") or r.get("UnitPrice") or 0) or 0),"total": float((r.get("Total") or 0) or 0)})
    return out
@router.post("/xactimate/compare")
async def xactimate_compare(file: UploadFile = File(...), apples: str = Form("[]")):
    try: apples_items=json.loads(apples or "[]")
    except Exception: apples_items=[]
    raw=await file.read()
    try: xa=parse_csv(raw)
    except Exception as e: raise HTTPException(status_code=400, detail=f"CSV parse error: {e}")
    def k(it): return (it.get("desc") or "").strip().lower()
    a_map={k(i): i for i in apples_items}; x_map={k(i): i for i in xa}; keys=set(a_map)|set(x_map)
    rows=[]; a_total=0.0; x_total=0.0
    for key in sorted(keys):
        a=a_map.get(key); x=x_map.get(key)
        av=(a.get("qty",0)*a.get("price",0)) if a else 0.0; xv=(x.get("total",0)) if x else 0.0
        a_total+=av; x_total+=xv
        rows.append({"item": key or "(unmatched)","apples_total": round(av,2),"xact_total": round(xv,2),"variance": round(av-xv,2)})
    summary={"apples_total": round(a_total,2),"xact_total": round(x_total,2),"variance_total": round(a_total-x_total,2)}
    narrative=f"Contractor apples-to-apples total ${summary['apples_total']:.2f} vs Xactimate ${summary['xact_total']:.2f} (variance ${summary['variance_total']:.2f}). Variance driven by crew hours, specialty equipment, and site safety mitigation not fully represented in Xactimate."
    return {"ok": True, "rows": rows, "summary": summary, "narrative": narrative}
