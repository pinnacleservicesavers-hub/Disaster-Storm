
from fastapi import APIRouter
router = APIRouter()
LEGAL_RULES = {
  "FL": {"demand_wait_days":10,"lien_notice_window_days":45,"lien_record_window_days":90,"statute_ref":"Example: §713 (verify)","late_fee_lang":"Interest may accrue per contract or statute.","aob_note":"AOB must comply with Florida requirements."},
  "TX": {"demand_wait_days":10,"lien_notice_window_days":15,"lien_record_window_days":90,"statute_ref":"Example: Tex. Prop. Code (verify)","late_fee_lang":"Late fees subject to Texas limits.","aob_note":"Verify assignment allowances."}
}
@router.get("/legal/state/{state}")
def legal_state(state: str): return LEGAL_RULES.get(state.upper(), {})
@router.post("/legal/upsert")
def legal_upsert(state: str, demand_wait_days: int | None = None, lien_notice_window_days: int | None = None, lien_record_window_days: int | None = None, statute_ref: str | None = None, late_fee_lang: str | None = None, aob_note: str | None = None):
    st = state.upper(); rec = LEGAL_RULES.get(st, {})
    if demand_wait_days is not None: rec["demand_wait_days"] = demand_wait_days
    if lien_notice_window_days is not None: rec["lien_notice_window_days"] = lien_notice_window_days
    if lien_record_window_days is not None: rec["lien_record_window_days"] = lien_record_window_days
    if statute_ref is not None: rec["statute_ref"] = statute_ref
    if late_fee_lang is not None: rec["late_fee_lang"] = late_fee_lang
    if aob_note is not None: rec["aob_note"] = aob_note
    LEGAL_RULES[st] = rec
    return {"ok": True, "state": st, "rules": rec}
