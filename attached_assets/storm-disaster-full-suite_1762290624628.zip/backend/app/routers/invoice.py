
from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import List, Dict, Any
import csv, io
router = APIRouter()
@router.post("/invoice/import")
async def invoice_import(file: UploadFile = File(...)):
    data = await file.read()
    try:
        f = io.StringIO(data.decode('utf-8', errors='ignore'))
        reader = csv.DictReader(f)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"CSV parse error: {e}")
    items: List[Dict[str, Any]] = []
    for r in reader:
        desc = (r.get("Description") or r.get("Item") or r.get("desc") or "").strip()
        try: qty = float((r.get("Qty") or r.get("Quantity") or r.get("qty") or "1") or "1")
        except: qty = 1.0
        try: price = float((r.get("Price") or r.get("Unit Price") or r.get("UnitPrice") or r.get("price") or "0") or "0")
        except: price = 0.0
        if desc: items.append({"desc": desc, "qty": qty, "price": price})
    if not items: raise HTTPException(status_code=400, detail="No items found in CSV")
    return {"ok": True, "items": items}
