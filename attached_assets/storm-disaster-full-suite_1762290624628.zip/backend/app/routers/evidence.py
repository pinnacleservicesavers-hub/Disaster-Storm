
from fastapi import APIRouter
from typing import List, Dict, Any
import re
router = APIRouter()
def infer_tags_from_url(url: str)->Dict[str,Any]:
    tags=[]; lower=(url or '').lower()
    m=re.search(r'(?P<size>(\d+(?:\.\d+)?)\s?)(in|inch|inches)', lower)
    if 'hail' in lower and m: tags.append({"type":"hail_size_in","value": float(m.group('size'))})
    if 'gust' in lower:
        g=re.search(r'(\d+)[ ]?mph', lower)
        if g: tags.append({"type":"wind_gust_mph","value": int(g.group(1))})
    if any(k in lower for k in ['tree','oak','pine']): tags.append({"type":"tree_damage"})
    if any(k in lower for k in ['roof','shingle','ridge']): tags.append({"type":"roof_damage"})
    return {"url": url, "tags": tags}
@router.post("/evidence/tag")
def evidence_tag(body: Dict[str,Any]):
    media: List[Dict[str,Any]] = body.get("media") or []
    out=[infer_tags_from_url(m.get("url","")) for m in media]; summary=[]
    hail=[t["value"] for m in out for t in m["tags"] if t["type"]=="hail_size_in"]
    if hail: summary.append(f"Detected hail in filenames: up to {max(hail):.2f} in")
    gusts=[t["value"] for m in out for t in m["tags"] if t["type"]=="wind_gust_mph"]
    if gusts: summary.append(f"Wind gust mention: up to {max(gusts)} mph")
    if any(any(t["type"]=="tree_damage" for t in m["tags"]) for m in out): summary.append("Probable tree damage evidence.")
    if any(any(t["type"]=="roof_damage" for t in m["tags"]) for m in out): summary.append("Probable roof damage evidence.")
    return {"ok": True, "by_media": out, "summary": summary}
