
from fastapi import APIRouter, HTTPException, Form
from typing import Optional
from ..utils.store import store
import smtplib, ssl
from email.message import EmailMessage
import requests
router = APIRouter()
@router.post("/intake/autopost")
def intake_autopost(claim_id: str = Form(...), portal_url: Optional[str] = Form(None), email_to: Optional[str] = Form(None)):
    c = store.settings.get("claims", {}).get(claim_id)
    if not c: raise HTTPException(status_code=404, detail="Claim not found")
    posted = {"claim_id": claim_id, "portal_url": portal_url or "(carrier-portal-placeholder)", "email_to": email_to or "(claims@carrier.example)", "packet": f"/claims/packet/{claim_id}.pdf"}
    c.setdefault("history", []).append({"event":"autopost_requested","data": posted})
    s = store.settings.get("smtp") or {}
    host=s.get("host"); port=int(s.get("port",587)); user=s.get("user"); password=s.get("password"); use_tls=bool(s.get("use_tls",True)); from_email=s.get("from_email") or (user or "no-reply@stormdisaster.local")
    if not host:
        return {"ok": True, "posted": posted, "email": "skipped (smtp not configured)"}
    packet_url = f"http://localhost:8000{posted['packet']}" if not posted['packet'].startswith("http") else posted['packet']
    pdf_bytes = None
    try:
        r = requests.get(packet_url, timeout=20)
        if r.ok: pdf_bytes = r.content
    except Exception:
        pdf_bytes = None
    msg = EmailMessage(); msg["Subject"]=f"Claim Packet {claim_id}"; msg["From"]=from_email; msg["To"]=posted["email_to"]
    msg.set_content("Attached is the claim packet for your review.")
    if pdf_bytes:
        msg.add_attachment(pdf_bytes, maintype="application", subtype="pdf", filename=f"claim_{claim_id}.pdf")
    try:
        with smtplib.SMTP(host, port, timeout=20) as server:
            if use_tls:
                context = ssl.create_default_context()
                server.starttls(context=context)
            if user: server.login(user, password or "")
            server.send_message(msg)
        return {"ok": True, "posted": posted, "email": "sent"}
    except Exception as e:
        return {"ok": True, "posted": posted, "email": f"error: {e}"}
