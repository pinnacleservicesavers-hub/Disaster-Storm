from fastapi import Request
def get_ctx(request: Request):
    return {"user_id": request.headers.get("X-User-Id","demo-contractor"), "role": request.headers.get("X-User-Role","admin")}
