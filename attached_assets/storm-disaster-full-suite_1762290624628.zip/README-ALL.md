
# Storm Disaster — Contractor-first Agentic Claims Tools

Backend:
```
pip install -r backend/requirements.txt
uvicorn backend.app.main:app --reload --port 8000
```

Frontend (Next.js-style file layout included):
```
cd frontend
npm i
echo "NEXT_PUBLIC_API_BASE=http://localhost:8000" > .env.local
npm run dev
```

Highlights:
- Carrier directory + presets (state/peril)
- Policy parser + rule-based summary
- Evidence auto-tagging (heuristics)
- Xactimate CSV compare → variance + narrative
- Invoice CSV import → fills invoice lines
- Demand / Lien PDFs with per-state legal placeholders
- SMTP settings + **autopost email** (sends packet PDF to carrier inbox)

Admin UI:
- `/admin/carriers`
- `/admin/settings/smtp` (enter SMTP to enable real email sending)

Contractor UI:
- `/contractor/claims/submit` end-to-end claim → packet → letters → email autopost
