
export const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "";
export async function api(path: string, opts: RequestInit = {}){
  const res = await fetch(`${API_BASE}${path}`, { headers: { 'Content-Type': 'application/json', 'X-User-Id': 'demo-contractor', 'X-User-Role': 'admin' }, ...opts });
  if(!res.ok){ let t=''; try{ t=await res.text(); }catch(e){}; throw new Error(t || `HTTP ${res.status}`); }
  try { return await res.json(); } catch { return {}; }
}
