
"use client";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";
export default function SMTPSettingsPage(){
  const [host,setHost]=useState(""); const [port,setPort]=useState(587);
  const [user,setUser]=useState(""); const [password,setPassword]=useState("");
  const [useTLS,setUseTLS]=useState(true); const [fromEmail,setFromEmail]=useState("");
  useEffect(()=>{ (async()=>{ const s = await api("/settings/smtp"); setHost(s.host||""); setPort(s.port||587); setUser(s.user||""); setFromEmail(s.from_email||""); setUseTLS(s.use_tls!==false); })(); },[]);
  const save = async()=>{ await api("/settings/smtp", { method:"POST", body: JSON.stringify({ host, port, user, password, use_tls: useTLS, from_email: fromEmail }) }); alert("Saved"); };
  return (
    <main className="p-8 max-w-xl mx-auto space-y-3">
      <h1 className="text-2xl font-bold">SMTP Settings</h1>
      <input className="border p-2 w-full" placeholder="SMTP Host" value={host} onChange={e=>setHost(e.target.value)} />
      <input className="border p-2 w-full" type="number" placeholder="Port" value={port} onChange={e=>setPort(Number(e.target.value))} />
      <input className="border p-2 w-full" placeholder="User (optional)" value={user} onChange={e=>setUser(e.target.value)} />
      <input className="border p-2 w-full" type="password" placeholder="Password (optional)" value={password} onChange={e=>setPassword(e.target.value)} />
      <input className="border p-2 w-full" placeholder="From email (optional)" value={fromEmail} onChange={e=>setFromEmail(e.target.value)} />
      <label className="inline-flex items-center gap-2"><input type="checkbox" checked={useTLS} onChange={e=>setUseTLS(e.target.checked)} /> Use TLS</label>
      <div><button className="px-3 py-1 border rounded" onClick={save}>Save</button></div>
    </main>
  );
}
