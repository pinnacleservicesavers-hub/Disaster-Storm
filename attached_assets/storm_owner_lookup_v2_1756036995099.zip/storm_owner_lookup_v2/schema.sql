-- Supabase SQL schema for storm owner lookups

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamp with time zone default now(),
  status text default 'new',
  lat double precision,
  lon double precision,
  address text,
  notes text,
  crew_id text
);

create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  created_at timestamp with time zone default now(),
  lead_id uuid references public.leads(id) on delete cascade,
  apn text,
  situs_address text,
  owner_name text,
  owner_mailing_address text,
  source text
);

create table if not exists public.media (
  id uuid primary key default gen_random_uuid(),
  created_at timestamp with time zone default now(),
  lead_id uuid references public.leads(id) on delete cascade,
  url text,
  kind text check (kind in ('photo','video','other')) default 'photo'
);

-- Helpful views
create view public.leads_with_owner as
select l.*, p.owner_name, p.owner_mailing_address, p.apn, p.situs_address
from public.leads l
left join public.properties p on p.lead_id = l.id;
