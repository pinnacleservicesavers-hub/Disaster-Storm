import axios from 'axios';

/**
 * Melissa Personator/Global (Contact Verify & Append)
 * Docs: https://www.melissa.com/developer
 * You must enable the services you need on your license (name/address/phone/email).
 */
export async function verifyContact({ name, address, phone, email }) {
  if (!process.env.MELISSA_API_KEY) throw new Error('Missing MELISSA_API_KEY');

  const params = new URLSearchParams({
    id: process.env.MELISSA_API_KEY,
    format: 'json'
  });

  if (name) params.append('full', name);
  if (address) params.append('a1', address);
  if (phone) params.append('p1', phone);
  if (email) params.append('e1', email);

  const url = `https://personator.melissadata.net/v3/WEB/ContactVerify/doContactVerify?${params.toString()}`;
  const resp = await axios.get(url, { timeout: 10000 });

  // Minimal normalization of likely fields:
  const rec = resp.data?.Records?.[0] || {};
  return {
    result_codes: rec.Results,
    parsed: {
      full_name: rec.FullName,
      address: rec.Address,
      city: rec.City,
      state: rec.State,
      postal_code: rec.PostalCode,
      phone: rec.Phone,
      email: rec.EmailAddress,
      deliverability: rec.AddressDeliverability
    },
    raw: resp.data
  };
}
