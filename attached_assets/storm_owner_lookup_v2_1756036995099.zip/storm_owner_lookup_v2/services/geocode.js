import axios from 'axios';

/**
 * Reverse geocode with Smarty US Reverse Geocoding or Google Maps as fallback.
 * Configure one (or both) in .env
 */
export async function reverseGeocode(lat, lon) {
  // 1) Try Smarty (recommended)
  if (process.env.SMARTY_AUTH_ID && process.env.SMARTY_AUTH_TOKEN) {
    try {
      const url = `https://us-reverse-geo.api.smarty.com/lookup?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}&source=all`;
      const resp = await axios.get(url, {
        headers: {
          'Accept': 'application/json',
          'Authorization': `Basic ${Buffer.from(process.env.SMARTY_AUTH_ID + ':' + process.env.SMARTY_AUTH_TOKEN).toString('base64')}`
        },
        timeout: 8000
      });
      const candidate = resp.data?.results?.[0]?.address || resp.data?.[0]?.address;
      if (candidate) {
        const address = `${candidate.deliveryLine1}, ${candidate.lastLine}`;
        return { address, meta: { provider: 'smarty', raw: candidate } };
      }
    } catch (e) {
      // continue to fallback
    }
  }

  // 2) Fallback: Google Maps Geocoding
  if (process.env.GOOGLE_MAPS_API_KEY) {
    try {
      const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lon}&key=${process.env.GOOGLE_MAPS_API_KEY}`;
      const resp = await axios.get(url, { timeout: 8000 });
      const formatted = resp.data?.results?.[0]?.formatted_address;
      if (formatted) return { address: formatted, meta: { provider: 'google', raw: resp.data.results[0] } };
    } catch (e) {
      // ignore
    }
  }

  return { address: null, meta: { error: 'No geocoder configured or no match found' } };
}
