import axios from 'axios';

/**
 * Regrid: point-in-parcel lookup to get APN, situs, and (if you have the add-on) owner mailing details.
 */
export async function getParcelByPoint(lat, lon) {
  if (!process.env.REGRID_API_KEY) throw new Error('Missing REGRID_API_KEY');

  const url = `https://api.regrid.com/api/v1/parcels/point?lat=${encodeURIComponent(lat)}&lng=${encodeURIComponent(lon)}&format=json`;
  const resp = await axios.get(url, {
    headers: { Authorization: `Token ${process.env.REGRID_API_KEY}` },
    timeout: 10000
  });

  const feat = resp.data?.features?.[0];
  const props = feat?.properties || {};
  const owner_name = props.owner || props.owner1 || props.owner_name || null;
  const owner_mailing_address = props.mail_addres || props.mail_address || props.mail_add || null;
  const situs_address = props.situs_full_address || props.address || null;
  const apn = props.apn || props.parcelnumb || props.parcel_number || null;

  return {
    apn, situs_address, owner_name, owner_mailing_address,
    source: { provider: 'regrid', layer: props.layer, county: props.county }
  };
}

/**
 * ATTOM: owner by address. Requires ATTOM_API_KEY.
 * We call the Property Detail endpoint (address search).
 */
export async function getOwnerByAddress(address) {
  if (!process.env.ATTOM_API_KEY) throw new Error('Missing ATTOM_API_KEY');

  const url = `https://api.gateway.attomdata.com/propertyapi/v1.0.0/property/detail?address=${encodeURIComponent(address)}`;
  const resp = await axios.get(url, {
    headers: { apikey: process.env.ATTOM_API_KEY },
    timeout: 10000
  });

  const rec = resp.data?.property?.[0];
  if (!rec) return null;

  const ownerArr = rec?.owner ?? rec?.owner1 ?? [];
  const owner = Array.isArray(ownerArr) ? ownerArr[0] : ownerArr;
  const fullName = [owner?.firstname, owner?.middlename, owner?.lastname].filter(Boolean).join(' ') || owner?.ownerfullname || null;

  const situs = rec?.address?.oneLine || [rec?.address?.house, rec?.address?.street, rec?.address?.city, rec?.address?.state, rec?.address?.zip].filter(Boolean).join(' ');

  const mailAddr = rec?.mailingaddress?.oneLine || [
    rec?.mailingaddress?.street,
    rec?.mailingaddress?.city,
    rec?.mailingaddress?.state,
    rec?.mailingaddress?.zip
  ].filter(Boolean).join(' ');

  return {
    apn: rec?.identifier?.apn || null,
    situs_address: situs || null,
    owner_name: fullName || null,
    owner_mailing_address: mailAddr || null,
    source: { provider: 'attom' }
  };
}
