
"use client";
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';

type Health = {
  issuer?: string;
  audience?: string;
  jwks_loaded?: boolean;
  jwks_keys?: number;
  jwks_meta?: any;
  enforce?: boolean;
  token?: { provided: boolean; unverified?: any; verified_ok?: boolean; error?: string | null };
};

export default function OIDCDiagnostics(){
  const [h, setH] = useState<Health|null>(null);
  const [token, setToken] = useState('');
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const load = async (tkn?: string)=>{
    setLoading(true);
    setErr(null);
    try{
      const qs = tkn ? `?token=${encodeURIComponent(tkn)}` : '';
      const j = await api(`/health/auth${qs}`);
      setH(j);
    }catch(e:any){
      setErr(e?.message || 'Failed to load health');
    }finally{
      setLoading(false);
    }
  };

  useEffect(()=>{ load(); },[]);

  const verify = async()=> load(token);
  const refreshJWKS = async()=>{
    try{
      const j = await api('/admin/oidc/refresh_jwks', { method:'POST' });
      if(j.ok){ alert(`JWKS refreshed: ${j.keys} key(s)`); load(); } else { alert(j.error || 'Failed'); }
    }catch(e:any){ alert(e?.message || 'Failed'); }
  };

  const Badge = ({ok}:{ok?:boolean}) => <span className={`px-2 py-0.5 rounded text-xs ${ok ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{ok ? 'OK' : 'ERROR'}</span>;

  return (
    <main className="p-8 space-y-4 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold">OIDC Diagnostics</h1>
      <div className="flex items-center gap-2">
        <button className="px-3 py-1 border rounded" onClick={()=>load()} disabled={loading}>Reload</button>
        <button className="px-3 py-1 border rounded" onClick={refreshJWKS}>Refresh JWKS</button>
      </div>
      {err && <div className="p-2 bg-red-50 border text-sm text-red-700">{err}</div>}
      <section className="border rounded p-3 space-y-2">
        <div className="font-semibold">Status</div>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div>Issuer: <b>{h?.issuer || '—'}</b></div>
          <div>Audience: <b>{h?.audience || '—'}</b></div>
          <div>JWKS: <Badge ok={!!h?.jwks_loaded} /> <span className="ml-2 text-xs text-gray-600">{h?.jwks_keys ?? 0} key(s)</span></div>
          <div>Enforce: <b>{String(h?.enforce ?? false)}</b></div>
        </div>
        <pre className="text-xs bg-gray-50 p-2 rounded overflow-auto">{JSON.stringify(h?.jwks_meta || {}, null, 2)}</pre>
      </section>
      <section className="border rounded p-3 space-y-2">
        <div className="font-semibold">Verify a token</div>
        <textarea className="border p-2 w-full h-36" placeholder="Paste ID token or access token..." value={token} onChange={e=>setToken(e.target.value)} />
        <div className="flex items-center gap-2">
          <button className="px-3 py-1 border rounded" onClick={verify} disabled={!token || loading}>Verify</button>
          {h?.token?.provided && (<span>Verified: <Badge ok={!!h?.token?.verified_ok} /></span>)}
          {h?.token?.error && <span className="text-xs text-red-600">Error: {h?.token?.error}</span>}
        </div>
        {h?.token?.unverified && <pre className="text-xs bg-gray-50 p-2 rounded overflow-auto">{JSON.stringify(h?.token?.unverified, null, 2)}</pre>}
      </section>
    </main>
  );
}
