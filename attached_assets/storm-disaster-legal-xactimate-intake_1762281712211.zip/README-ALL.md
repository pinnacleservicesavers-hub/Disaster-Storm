
# Storm Disaster — Legal Guardrails + Xactimate + Autopost

Backend:
```
pip install -r backend/requirements.txt
uvicorn backend.app.main:app --reload --port 8000
```

Frontend:
```
cd frontend
npm i
echo "NEXT_PUBLIC_API_BASE=http://localhost:8000" > .env.local
npm run dev
```

New:
- `/legal/state/{state}` → per-state placeholders; **letters pull these values**.
- `/xactimate/compare` → CSV vs contractor apples; returns variance + narrative.
- `/intake/autopost` → records intent to auto-post packet (stub).

UI:
- On **/contractor/claims/submit**: Xactimate CSV upload, “Auto‑post to carrier”, and per-state **Demand/Lien** PDFs.
