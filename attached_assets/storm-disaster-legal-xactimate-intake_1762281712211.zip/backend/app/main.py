
from fastapi import FastAPI
from .routers import legal, jobs, claims, carriers, policy, evidence, xactimate, intake
app = FastAPI()
app.include_router(legal.router)
app.include_router(jobs.router)
app.include_router(claims.router)
app.include_router(carriers.router)
app.include_router(policy.router)
app.include_router(evidence.router)
app.include_router(xactimate.router)
app.include_router(intake.router)
