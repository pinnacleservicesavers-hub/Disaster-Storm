
from fastapi import APIRouter, UploadFile, File, HTTPException, Form
from typing import Optional, Dict, Any
from io import BytesIO
from pdfminer.high_level import extract_text
import re
router = APIRouter()
def parse_policy_text(text: str)->Dict[str,Any]:
    out={}
    def grab(pat,key):
        m=re.search(pat, text, flags=re.IGNORECASE|re.MULTILINE)
        if m: out[key]=m.group(1).strip()
    grab(r'policy\s*number\s*[:#]?\s*([A-Z0-9-]+)','policy_number')
    grab(r'named\s*insured\s*[:#]?\s*([\w\s,&.]+)','named_insured')
    for letter,key in [('A','coverage_a'),('B','coverage_b'),('C','coverage_c'),('D','coverage_d')]:
        m=re.search(rf'coverage\s*{letter}[^\n]*\$?\s*([0-9,]+)', text, flags=re.IGNORECASE); 
        if m: out[key]=m.group(1).replace(',','')
    grab(r'deductible[^\n]*\$?\s*([0-9,]+)','deductible')
    grab(r'policy\s*period[^\n]*from[^0-9]*([0-9/\-]{8,10})','policy_start')
    grab(r'policy\s*period[^\n]*to[^0-9]*([0-9/\-]{8,10})','policy_end')
    return out
@router.post("/policy/parse")
async def policy_parse(file: Optional[UploadFile]=File(None), text: Optional[str]=Form(None)):
    if not file and not text: raise HTTPException(status_code=400, detail="Provide a PDF file or raw text")
    if file:
        data=await file.read()
        try: txt=extract_text(BytesIO(data))
        except Exception as e: raise HTTPException(status_code=400, detail=f"PDF parse error: {e}")
    else: txt=text or ""
    parsed=parse_policy_text(txt or ""); return {"ok": True, "parsed": parsed, "chars": len(txt or "")}
@router.post("/policy/summarize")
def policy_summarize(payload: dict):
    p=payload or {}; bullets=[]
    if p.get('coverage_a'): bullets.append(f"Coverage A (Dwelling): ${p['coverage_a']} limit.")
    if p.get('coverage_b'): bullets.append(f"Coverage B (Other Structures): ${p['coverage_b']} limit.")
    if p.get('deductible'): bullets.append(f"Deductible: ${p['deductible']} (per occurrence unless noted).")
    if p.get('policy_start') and p.get('policy_end'): bullets.append(f"Policy period: {p['policy_start']} to {p['policy_end']}.")
    if 'named_insured' in p: bullets.append(f"Named insured: {p['named_insured']}.")
    bullets.append("Insurer owes to restore to pre-loss condition when damage is caused by a covered peril.")
    bullets.append("Mitigation to prevent further damage is generally covered when reasonable and necessary.")
    return {"ok": True, "summary": bullets}
