
from fastapi import APIRouter, HTTPException, Request
from typing import Optional, Dict, Any
from ..utils.store import store
from ..utils.security import get_ctx
router = APIRouter()
def _norm(s: str)->str: return (s or '').strip().lower()
@router.get("/carriers") def list_carriers(): return sorted([v for v in store.carriers.values()], key=lambda x: x["name"].lower())
@router.get("/carriers/lookup")
def lookup(name: str, state: Optional[str] = None):
    name_n=_norm(name); best=None
    for k,v in store.carriers.items():
        if name_n in _norm(k) or _norm(k) in name_n: best=v; break
    if not best:
        for k,v in store.carriers.items():
            if any(tok in _norm(k) for tok in name_n.split() if tok): best=v; break
    if not best: raise HTTPException(status_code=404, detail="Carrier not found")
    note=None
    if state: note=(best.get("per_state_notes") or {}).get(state.upper())
    return {**best, "state_note": note}
@router.post("/carriers")
def upsert_carrier(body: Dict[str, Any], request: Request):
    ctx=get_ctx(request); if ctx.get("role")!="admin": raise HTTPException(status_code=403, detail="admin only")
    name=(body.get("name") or "").strip(); if not name: raise HTTPException(status_code=400, detail="name required")
    cid=body.get("id") or _norm(name).replace(" ","-")[:24]
    obj={"id":cid,"name":name,"claim_email":body.get("claim_email"),"intake_url":body.get("intake_url"),"per_state_notes":body.get("per_state_notes") or {}}
    store.carriers[name]=obj; return {"ok": True, "carrier": obj}
@router.get("/carriers/presets/{state}")
def carrier_presets(state: str): return store.carrier_presets.get(state.upper(), {})
@router.get("/carriers/presets/{state}/{peril}")
def carrier_preset_for(state: str, peril: str): return (store.carrier_presets.get(state.upper(), {}) or {}).get(peril.lower(), {})
