
from fastapi import APIRouter
router = APIRouter()
LEGAL_RULES = {
  "FL": {"demand_wait_days":10,"lien_notice_window_days":45,"lien_record_window_days":90,"statute_ref":"Example: §713 (verify)","late_fee_lang":"Interest may accrue per contract or statute.","aob_note":"AOB must comply with Florida requirements."},
  "TX": {"demand_wait_days":10,"lien_notice_window_days":15,"lien_record_window_days":90,"statute_ref":"Example: Tex. Prop. Code (verify)","late_fee_lang":"Late fees subject to Texas limits.","aob_note":"Verify assignment allowances."}
}
@router.get("/legal/state/{state}")
def legal_state(state: str): return LEGAL_RULES.get(state.upper(), {})
