
from fastapi import APIRouter, HTTPException, Form
from typing import Optional
from ..utils.store import store
router = APIRouter()
@router.post("/intake/autopost")
def intake_autopost(claim_id: str = Form(...), portal_url: Optional[str] = Form(None), email_to: Optional[str] = Form(None)):
    c = store.settings.get("claims", {}).get(claim_id)
    if not c: raise HTTPException(status_code=404, detail="Claim not found")
    posted = {"claim_id": claim_id, "portal_url": portal_url or "(carrier-portal-placeholder)", "email_to": email_to or "(claims@carrier.example)", "packet": f"/claims/packet/{claim_id}.pdf"}
    c.setdefault("history", []).append({"event":"autopost_requested","data": posted})
    return {"ok": True, "posted": posted}
