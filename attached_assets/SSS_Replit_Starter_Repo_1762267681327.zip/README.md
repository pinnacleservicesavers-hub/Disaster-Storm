# Strategic Service Savers — Replit Starter (FastAPI)

This repo boots a FastAPI app with:
- JWT RBAC (admin/analyst)
- Role Matrix + Carrier-scoped access
- Audit logs (DB table) + webhook queue w/ retry + FTS search
- Admin UI: login, archive, audit viewer (FTS), queue monitor
- Dashboard UI: JWT-aware, role-based controls
- Storage adapters: S3/GCS/Azure (presigned links), SendGrid inbound stub
- SQLite by default (works in Replit)

## Run (Replit)
1) Import this ZIP into Replit
2) Add a `.env` with at least:
```
ADMIN_JWT_SECRET=change-me-to-something-long
ADMIN_TOKEN=admin-default-password
# Optional scoped users:
USERS_JSON={"admin":{"password":"secret","role":"admin"},"analyst":{"password":"demo","role":"analyst","carriers":["Acme","Example Carrier"]}}
DATABASE_URL=sqlite:///./data.db
STORAGE_PROVIDER=s3  # or gcs/azure (configure vars accordingly)
S3_BUCKET=your-bucket
S3_REGION=us-east-1
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
# Optional outbound audit webhook
AUDIT_WEBHOOK_URL=https://example.com/collect
```
3) Click **Run**. Open the webview:
- Admin login: `/web/admin/login.html` (then `/web/admin/index.html`, `/web/admin/audits.html`, `/web/admin/queue.html`)
- Dashboard: `/web/dashboard/index.html`

## Notes
- This is a working scaffold with safe **stubs** for ingest/MRMS/SMS/map rendering. Replace stubs with live integrations.
- All admin-only endpoints require a JWT issued by `/api/auth/login`.
