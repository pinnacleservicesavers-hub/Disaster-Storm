async def run_all_ingestors():
    return True
