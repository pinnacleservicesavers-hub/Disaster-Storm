async def ingest_mrms_for_peril(db, peril: str, simplify_tolerance: float):
    return True
