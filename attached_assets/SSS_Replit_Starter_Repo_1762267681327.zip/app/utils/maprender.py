from PIL import Image, ImageDraw
def render_claim_hazards_png(db, claim_id: int) -> bytes:
    # Stub image; replace with real map rendering
    img = Image.new("RGB", (960, 720), (245, 247, 250))
    d = ImageDraw.Draw(img)
    d.rectangle((50,50,910,670), outline=(30,30,30), width=4)
    d.text((60,60), f"Claim {claim_id} — Hazard Snapshot (stub)", fill=(0,0,0))
    import io
    buf = io.BytesIO(); img.save(buf, format="PNG")
    return buf.getvalue()
