def send_sms(message: str, phone: str) -> str:
    # Stub: integrate with Twilio or your provider
    return f"stub:{phone}"
