from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from shapely import wkt
from shapely.geometry import Point
from app.core.db import SessionLocal
from app.models.entities import Contractor, Alert
from app.utils.notify import send_sms
from app.core.security import role_required

router=APIRouter()
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

class MoratoriumSMSIn(BaseModel):
    message:str; only_hazard_contractors: bool=True

@router.post('/notify/moratorium-sms')
def moratorium_sms(body: MoratoriumSMSIn, db: Session=Depends(get_db), _: dict = Depends(role_required(["admin"]))):
    hazard_ids=set()
    if body.only_hazard_contractors:
        alerts=db.query(Alert).all(); contractors=db.query(Contractor).all()
        for c in contractors:
            if not c.phone: continue
            p=Point(c.lon,c.lat)
            for al in alerts:
                if not al.geom_wkt: continue
                try:
                    g=wkt.loads(al.geom_wkt)
                    if g.buffer(0).intersects(p): hazard_ids.add(c.id); break
                except Exception: continue
    targets=[]
    for c in db.query(Contractor).all():
        if not c.phone: continue
        if body.only_hazard_contractors and c.id not in hazard_ids: continue
        targets.append((c.id,c.phone))
    results=[{'contractor_id':cid,'phone':phone,'result':send_sms(body.message, phone)} for cid, phone in targets]
    return {'sent':len(results),'results':results}
