from fastapi import APIRouter, Request, Depends
from sqlalchemy.orm import Session
from typing import Optional
import re
from app.core.db import SessionLocal
from app.models.entities import Claim, Carrier, Asset

router = APIRouter()
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

def _parse_policy(text: str) -> Optional[str]:
    m = re.search(r"policy[:\s]+([A-Za-z0-9\-]+)", text or "", re.IGNORECASE)
    return m.group(1) if m else None

def _parse_asset_ref(text: str) -> Optional[str]:
    m = re.search(r"asset[_\s-]*id[:\s]+([A-Za-z0-9\-]+)", text or "", re.IGNORECASE)
    return m.group(1) if m else None

@router.post("/email/inbound/sendgrid")
async def inbound_sendgrid(request: Request, db: Session = Depends(get_db)):
    form = await request.form()
    from_email: str = str(form.get("from") or form.get("from_email") or "")
    subject: str = str(form.get("subject") or "")
    text: str = str(form.get("text") or "")
    attachments = int(form.get("attachments") or 0)

    carrier_name = from_email.split("@")[-1].split(".")[0].title() if "@" in from_email else "Unknown"
    carrier = db.query(Carrier).filter(Carrier.name == carrier_name).first()
    if not carrier:
        carrier = Carrier(name=carrier_name); db.add(carrier); db.commit(); db.refresh(carrier)

    policy = _parse_policy(text) or subject.strip() or "(unknown)"
    asset_ref = _parse_asset_ref(text)
    asset = db.query(Asset).filter(Asset.ref_id == asset_ref).first() if asset_ref else None

    cl = Claim(carrier_id=carrier.id, policy_number=policy, asset_id=(asset.id if asset else None), status="open", notes=f"Inbound from {from_email}: {subject}")
    db.add(cl); db.commit(); db.refresh(cl)

    stored_links=[]  # storage wiring optional
    return {"ok": True, "created_claim_id": cl.id, "attachments": stored_links}
