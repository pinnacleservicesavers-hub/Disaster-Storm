from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session
from shapely import wkt
from shapely.geometry import Point
from app.core.db import SessionLocal
from app.models.entities import Claim, Carrier, Asset, Alert
from app.core.security import role_required
from app.core.carrier_access import claim_visible_to_payload
from app.core.audit import log_audit

router=APIRouter()
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

@router.get('/claims')
def list_claims(request: Request, db: Session=Depends(get_db), _: dict = Depends(role_required(["analyst","admin"]))):
    payload = getattr(request.state, "user", None) or {}
    items = []
    assets={a.id:a for a in db.query(Asset).all()}
    alerts=db.query(Alert).all()
    for cl in db.query(Claim).all():
        if not claim_visible_to_payload(db, payload, cl): continue
        a=assets.get(cl.asset_id); haz=[]
        if a:
            pt=Point(a.lon,a.lat)
            for al in alerts:
                if not al.geom_wkt: continue
                try:
                    g=wkt.loads(al.geom_wkt)
                    if g.buffer(0).intersects(pt):
                        haz.append({'alert_id':al.id,'title':al.title,'source':al.source,'severity':al.severity})
                except Exception: pass
        items.append({'claim_id':cl.id,'policy_number':cl.policy_number,'asset_id':cl.asset_id,'status':cl.status,'hazards':haz})
    log_audit(db, payload.get("sub"), payload.get("role"), "list_claims", f"returned={len(items)}", request.client.host if request.client else None)
    return {'count':len(items),'items':items}
