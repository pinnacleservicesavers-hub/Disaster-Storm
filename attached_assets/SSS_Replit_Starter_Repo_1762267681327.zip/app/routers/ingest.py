from fastapi import APIRouter, Depends
from app.services.ingest import run_all_ingestors
from app.core.security import role_required
router=APIRouter()
@router.post('/ingest/run')
async def ingest_now(_: dict = Depends(role_required(["admin"]))):
    await run_all_ingestors(); return {'status':'ingested'}
