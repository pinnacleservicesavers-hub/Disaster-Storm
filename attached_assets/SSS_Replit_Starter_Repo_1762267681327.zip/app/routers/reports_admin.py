from fastapi import APIRouter, Depends, Query, Request
from app.utils.storage import list_prefix, sign_url_for_key
from app.core.security import role_required
from app.core.audit import log_audit

router = APIRouter()

@router.get("/reports/fnol/list")
def list_fnol(request: Request, _: dict = Depends(role_required(["admin"]))):
    items = list_prefix("fnol/")
    payload = getattr(request.state, "user", None) or {}
    log_audit(request.app.state.db if hasattr(request.app.state,'db') else request.state.db if hasattr(request.state,'db') else request, payload.get("sub"), payload.get("role"), "list_fnol", f"count={len(items)}", request.client.host if request.client else None)
    return {"items": items}

@router.get("/reports/sign")
def sign_key(key: str = Query(...), request: Request = None, _: dict = Depends(role_required(["admin"]))):
    url = sign_url_for_key(key, days=7)
    payload = getattr(request.state, "user", None) or {}
    log_audit(request.app.state.db if hasattr(request.app.state,'db') else request.state.db if hasattr(request.state,'db') else request, payload.get("sub"), payload.get("role"), "sign_storage_url", f"key={key}", request.client.host if request and request.client else None)
    return {"url": url}
