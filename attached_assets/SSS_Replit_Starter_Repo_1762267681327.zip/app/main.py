from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app.core.db import engine, Base, SessionLocal
from app.routers import auth, reports_admin, audit_admin, audit_search, audit_queue_admin, alerts, assets, contractors, ui, claims, ingest, mrms, notify, reports, email_inbound_sendgrid

app = FastAPI(title="Strategic Service Savers")
Base.metadata.create_all(bind=engine)

app.state.db = SessionLocal()

# Static web
app.mount("/web", StaticFiles(directory="web", html=True), name="web")

# Routers
app.include_router(auth.router, prefix="/api", tags=["auth"])
app.include_router(reports_admin.router, prefix="/api", tags=["reports-admin"])
app.include_router(audit_admin.router, prefix="/api", tags=["audit"])
app.include_router(audit_search.router, prefix="/api", tags=["audit-search"])
app.include_router(audit_queue_admin.router, prefix="/api", tags=["audit-queue"])
app.include_router(alerts.router, prefix="/api", tags=["alerts"])
app.include_router(assets.router, prefix="/api", tags=["assets"])
app.include_router(contractors.router, prefix="/api", tags=["contractors"])
app.include_router(ui.router, prefix="/api", tags=["ui"])
app.include_router(claims.router, prefix="/api", tags=["claims"])
app.include_router(ingest.router, prefix="/api", tags=["ingest"])
app.include_router(mrms.router, prefix="/api", tags=["mrms"])
app.include_router(notify.router, prefix="/api", tags=["notify"])
app.include_router(reports.router, prefix="/api", tags=["reports"])
app.include_router(email_inbound_sendgrid.router, prefix="/api", tags=["email"])

@app.get("/")
def root():
    return {"ok": True, "app": "Strategic Service Savers"}
