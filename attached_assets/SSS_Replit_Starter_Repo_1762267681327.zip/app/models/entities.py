from sqlalchemy import Integer, String, Float, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.db import Base

class Carrier(Base):
    __tablename__ = "carrier"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(120), unique=True)

class Contractor(Base):
    __tablename__ = "contractor"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(200))
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)

class Asset(Base):
    __tablename__ = "asset"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(200))
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    ref_id: Mapped[str | None] = mapped_column(String(120), nullable=True)

class Claim(Base):
    __tablename__ = "claim"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    carrier_id: Mapped[int | None] = mapped_column(ForeignKey("carrier.id"), nullable=True)
    policy_number: Mapped[str | None] = mapped_column(String(120), nullable=True)
    asset_id: Mapped[int | None] = mapped_column(ForeignKey("asset.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(40), default="open")
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

class Alert(Base):
    __tablename__ = "alert"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source: Mapped[str] = mapped_column(String(40))
    title: Mapped[str] = mapped_column(String(200))
    severity: Mapped[str | None] = mapped_column(String(40), nullable=True)
    geom_wkt: Mapped[str | None] = mapped_column(Text, nullable=True)
    properties_json: Mapped[str | None] = mapped_column(Text, nullable=True)

class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[str] = mapped_column(String(40))
    actor: Mapped[str | None] = mapped_column(String(120), nullable=True)
    role: Mapped[str | None] = mapped_column(String(40), nullable=True)
    action: Mapped[str] = mapped_column(String(120))
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
