import os, time, typing as t, jwt
from fastapi import Header, HTTPException

JWT_ALG = "HS256"
def _secret() -> str:
    return os.getenv("ADMIN_JWT_SECRET") or os.getenv("ADMIN_TOKEN") or "change-me"

def create_token(sub: str, role: str, ttl_seconds: int = 3600, carriers: list[str] | None = None) -> str:
    now = int(time.time())
    payload = {"sub": sub, "role": role, "iat": now, "exp": now + ttl_seconds}
    if carriers: payload["carriers"] = carriers
    return jwt.encode(payload, _secret(), algorithm=JWT_ALG)

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, _secret(), algorithms=[JWT_ALG])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

def role_required(roles: t.List[str] | None = None):
    roles = roles or ["admin"]
    def _guard(authorization: t.Optional[str] = Header(default=None, alias="Authorization")) -> dict:
        if not authorization or not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Missing Bearer token")
        token = authorization.split(" ", 1)[1].strip()
        payload = decode_token(token)
        if payload.get("role") not in roles:
            raise HTTPException(status_code=403, detail="Insufficient role")
        # expose payload for audit in request.state if present
        try:
            import inspect
            for frame in inspect.stack():
                loc = frame.frame.f_locals
                req = loc.get("request")
                if req is not None:
                    req.state.user = payload
                    break
        except Exception:
            pass
        return payload
    return _guard
