import os, json, time, threading, queue, requests
from typing import Optional
from datetime import datetime, timedelta

class AuditWebhookQueue:
    def __init__(self, db_session_factory, url_env="AUDIT_WEBHOOK_URL"):
        self.db_session_factory = db_session_factory
        self.url_env = url_env
        self.q = queue.Queue()
        self._ensure_table()
        self._load_pending_into_memory()
        self.worker = threading.Thread(target=self._worker_loop, daemon=True)
        self.worker.start()

    def _ensure_table(self):
        db = self.db_session_factory()
        try:
            conn = db.connection()
            conn.execute("""CREATE TABLE IF NOT EXISTS audit_webhook_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                payload TEXT NOT NULL,
                next_attempt_ts TEXT NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0
            );""")
        finally:
            db.close()

    def _load_pending_into_memory(self):
        db = self.db_session_factory()
        try:
            conn = db.connection()
            rows = conn.execute("SELECT id, payload, next_attempt_ts, attempts FROM audit_webhook_queue").fetchall()
            for r in rows:
                item = {"id": r[0], "payload": r[1], "next_attempt_ts": r[2], "attempts": r[3]}
                self.q.put(item)
        finally:
            db.close()

    def enqueue(self, payload: dict):
        db = self.db_session_factory()
        try:
            conn = db.connection()
            ts = datetime.utcnow().isoformat() + "Z"
            conn.execute("INSERT INTO audit_webhook_queue (payload, next_attempt_ts, attempts) VALUES (:p, :ts, 0)",
                         {"p": json.dumps(payload), "ts": ts})
            rowid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            self.q.put({"id": rowid, "payload": json.dumps(payload), "next_attempt_ts": ts, "attempts": 0})
        finally:
            db.close()

    def _worker_loop(self):
        while True:
            try:
                item = self.q.get()
                if not item:
                    time.sleep(1); continue
                self._attempt_send(item)
            except Exception:
                time.sleep(2)

    def _attempt_send(self, item):
        url = os.getenv(self.url_env)
        if not url:
            return
        payload = json.loads(item["payload"]);
        now = datetime.utcnow()
        try:
            due = datetime.fromisoformat(item["next_attempt_ts"].replace("Z",""))
        except Exception:
            due = now
        if due > now:
            time.sleep((due - now).total_seconds())
        try:
            requests.post(url, json=payload, timeout=5)
            db = self.db_session_factory()
            try:
                db.connection().execute("DELETE FROM audit_webhook_queue WHERE id = :id", {"id": item["id"]})
            finally:
                db.close()
        except Exception:
            attempts = int(item.get("attempts", 0)) + 1
            backoff = min(60*30, 2 ** attempts)
            next_ts = (datetime.utcnow() + timedelta(seconds=backoff)).isoformat() + "Z"
            db = self.db_session_factory()
            try:
                db.connection().execute("UPDATE audit_webhook_queue SET next_attempt_ts=:ts, attempts=:a WHERE id=:id",
                    {"ts": next_ts, "a": attempts, "id": item["id"]})
            finally:
                db.close()
            item["attempts"] = attempts; item["next_attempt_ts"] = next_ts; self.q.put(item)

_queue_singleton: Optional[AuditWebhookQueue] = None
def get_audit_queue(db_session_factory):
    global _queue_singleton
    if _queue_singleton is None:
        _queue_singleton = AuditWebhookQueue(db_session_factory=db_session_factory)
    return _queue_singleton
