import os

class Settings:
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./data.db")
    admin_token: str | None = os.getenv("ADMIN_TOKEN")
    storage_provider: str | None = os.getenv("STORAGE_PROVIDER")

    # S3
    s3_bucket: str | None = os.getenv("S3_BUCKET")
    s3_region: str | None = os.getenv("S3_REGION")
    aws_access_key_id: str | None = os.getenv("AWS_ACCESS_KEY_ID")
    aws_secret_access_key: str | None = os.getenv("AWS_SECRET_ACCESS_KEY")

    # GCS
    gcs_bucket: str | None = os.getenv("GCS_BUCKET")

    # Azure
    azure_connection_string: str | None = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    azure_container: str | None = os.getenv("AZURE_CONTAINER")

settings = Settings()
