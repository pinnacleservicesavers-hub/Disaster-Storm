from typing import Optional
from sqlalchemy.orm import Session
from app.models.entities import Claim, Carrier

def payload_allowed_carriers(payload: Optional[dict]) -> set[str]:
    if not payload: return set()
    carriers = payload.get("carriers") or []
    return set([str(c) for c in carriers])

def claim_visible_to_payload(db: Session, payload: Optional[dict], claim: Claim) -> bool:
    role = (payload or {}).get("role", "analyst")
    if role == "admin":
        return True
    allowed = payload_allowed_carriers(payload)
    if not allowed:
        return True
    if claim.carrier_id is None:
        return False
    car = db.query(Carrier).filter(Carrier.id == claim.carrier_id).first()
    return bool(car and car.name in allowed)
