from typing import Dict, Set

ROLE_MATRIX: Dict[str, Set[str]] = {
    "view_dashboard": {"analyst", "admin"},
    "view_alerts": {"analyst", "admin"},
    "view_claims": {"analyst", "admin"},
    "view_assets": {"analyst", "admin"},
    "view_contractors": {"analyst", "admin"},
    "view_alignment": {"analyst", "admin"},
    "view_fnol_pdf": {"analyst", "admin"},
    "ingest_all": {"admin"},
    "ingest_mrms": {"admin"},
    "bulk_sms": {"admin"},
    "create_claim": {"admin"},
    "create_asset": {"admin"},
    "create_contractor": {"admin"},
    "store_fnol_pdf": {"admin"},
    "sign_storage_url": {"admin"},
}
def can(role: str, action: str) -> bool:
    return role in ROLE_MATRIX.get(action, set())
