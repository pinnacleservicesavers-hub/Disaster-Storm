
import asyncio, requests
from fastapi import FastAPI
from .routers import health, admin_oidc
from .utils.store import store

app = FastAPI()
app.include_router(health.router)
app.include_router(admin_oidc.router, tags=['admin'])

# Background refresher (simplified, no alerts here for brevity)
async def _jwks_refresher():
    while True:
        try:
            cfg = store.settings.get("oidc") or {}
            issuer = cfg.get("issuer")
            if issuer:
                url = issuer.rstrip("/") + "/.well-known/jwks.json"
                r = requests.get(url, timeout=10)
                if r.status_code == 200:
                    store.settings.setdefault("oidc", {})["jwks"] = r.json()
                    store.settings["oidc"]["jwks_meta"] = {"last_status": 200}
        except Exception:
            pass
        await asyncio.sleep(3600)

@app.on_event("startup")
async def _start():
    app.state._jwks_ref = asyncio.create_task(_jwks_refresher())
