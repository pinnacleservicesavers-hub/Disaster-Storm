import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE;

export const supa = (SUPABASE_URL && SUPABASE_SERVICE_ROLE)
  ? createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE, { auth: { persistSession: false } })
  : null;

export async function createSubscription({ user_id, watch_type, code, notify_sms, notify_push_token }) {
  if (!supa) throw new Error('Supabase not configured');
  const { data, error } = await supa.from('subscriptions').insert({
    user_id, watch_type, code, notify_sms, notify_push_token
  }).select().single();
  if (error) throw error;
  return data;
}

export async function listUserSubscriptions(user_id) {
  if (!supa) return [];
  const { data, error } = await supa.from('subscriptions').select('*').eq('user_id', user_id).order('created_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function deleteSubscription(id) {
  if (!supa) throw new Error('Supabase not configured');
  const { error } = await supa.from('subscriptions').delete().eq('id', id);
  if (error) throw error;
}

export async function listSubscriptionsByState(stateCode) {
  if (!supa) return [];
  const { data, error } = await supa.from('subscriptions').select('*').eq('watch_type','state').eq('code', stateCode);
  if (error) throw error;
  return data || [];
}

export async function upsertAlert(alert) {
  if (!supa) return null;
  const { data, error } = await supa.from('alerts').insert(alert).select().single();
  if (error) throw error;
  return data;
}
