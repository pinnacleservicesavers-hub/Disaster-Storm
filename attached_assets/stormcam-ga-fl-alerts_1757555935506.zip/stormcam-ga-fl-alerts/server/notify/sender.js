import twilio from 'twilio';
import admin from 'firebase-admin';

let twilioClient = null;
if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
  twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
}

// Initialize Firebase Admin if credentials provided
if (!admin.apps.length) {
  let svcJSON = process.env.FCM_SERVICE_ACCOUNT_JSON;
  const svcB64 = process.env.FCM_SERVICE_ACCOUNT_JSON_B64;
  if (!svcJSON && svcB64) {
    svcJSON = Buffer.from(svcB64, 'base64').toString('utf-8');
  }
  if (svcJSON) {
    try {
      admin.initializeApp({
        credential: admin.credential.cert(JSON.parse(svcJSON))
      });
    } catch (e) {
      console.warn('FCM init failed:', e.message);
    }
  }
}

export async function sendCombinedNotifications(items) {
  let count = 0;
  for (const it of items) {
    const parts = [];
    if (twilioClient && it.sms) {
      try {
        await twilioClient.messages.create({
          to: it.sms,
          from: process.env.TWILIO_FROM,
          body: it.message
        });
        count++; parts.push('sms');
      } catch(e) { console.warn('Twilio SMS error:', e.message); }
    }
    if (admin.apps.length && it.push) {
      try {
        await admin.messaging().send({
          token: it.push,
          notification: { title: 'StormCam Alert', body: it.message },
          data: {
            lat: it.lat ? String(it.lat) : '',
            lon: it.lon ? String(it.lon) : ''
          }
        });
        count++; parts.push('push');
      } catch(e) { console.warn('FCM push error:', e.message); }
    }
    if (!parts.length) {
      // No endpoints configured; skip silently
    }
  }
  return count;
}
