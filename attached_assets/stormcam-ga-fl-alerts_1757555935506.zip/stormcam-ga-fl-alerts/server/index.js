import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';
import { fetchGA } from './providers/ga-511.js';
import { fetchFL } from './providers/fl-511.js';
import { supa, upsertAlert, listSubscriptionsByState, createSubscription, listUserSubscriptions, deleteSubscription } from './notify/supabase.js';
import { sendCombinedNotifications } from './notify/sender.js';

const app = express();
app.use(cors());
app.use(express.json());

// In-memory caches (swap with DB when ready)
const cache = {
  cameras: new Map(),   // key: "GA" -> Array
  incidents: new Map(), // key: "GA" -> Array
};

// States wired up in this starter
const STATES = ["GA","FL"];

// Map of fetchers
const STATE_HANDLERS = {
  "GA": fetchGA,
  "FL": fetchFL
};

// Admin: refresh one state now, then emit basic alerts to state subscribers
app.post('/admin/refresh/:state', async (req, res) => {
  const state = (req.params.state || '').toUpperCase();
  if (!STATE_HANDLERS[state]) return res.status(404).json({ ok:false, error: 'Unknown state' });
  try {
    const { cameras, incidents } = await STATE_HANDLERS[state]();
    cache.cameras.set(state, cameras);
    cache.incidents.set(state, incidents);

    // Notify subscribers who watch this *state* (simple starter)
    const subs = await listSubscriptionsByState(state);
    const notifications = [];
    for (const inc of incidents) {
      // Only tree/debris/blocked types for alerts
      const t = `${inc.type||''}`.toLowerCase();
      const isInteresting = /(tree|debris|blocked|power|structure)/.test(t);
      if (!isInteresting) continue;

      const message = `[${state}] ${inc.type || 'Incident'} — ${inc.description || ''} ${inc.road ? ' @ '+inc.road : ''}`.trim();
      const alert = {
        jurisdiction_code: state,
        camera_id: null,
        incident_id: inc.id,
        kind: 'Incident',
        score: 0.7,
        message,
        lat: inc.lat, lon: inc.lon,
        snapshot_url: null
      };
      const saved = await upsertAlert(alert);

      for (const sub of subs) {
        notifications.push({
          user_id: sub.user_id,
          sms: sub.notify_sms,
          push: sub.notify_push_token,
          message,
          lat: inc.lat, lon: inc.lon
        });
      }
    }

    if (notifications.length) {
      await sendCombinedNotifications(notifications);
    }

    res.json({ ok:true, cameras: cameras.length, incidents: incidents.length, notified: notifications.length });
  } catch (err) {
    console.error('Refresh error', state, err);
    res.status(500).json({ ok:false, error: String(err) });
  }
});

// Public API
app.get('/api/states', (req,res)=> res.json(STATES));

app.get('/api/cameras/:state', (req,res)=> {
  const s = (req.params.state || '').toUpperCase();
  res.json(cache.cameras.get(s) || []);
});

app.get('/api/incidents/:state', (req,res)=> {
  const s = (req.params.state || '').toUpperCase();
  res.json(cache.incidents.get(s) || []);
});

// Subscriptions API
app.get('/api/subscriptions', async (req,res)=>{
  const user = req.query.user;
  if (!user) return res.status(400).json({ ok:false, error: 'user required' });
  try {
    const subs = await listUserSubscriptions(user);
    res.json(subs);
  } catch (e) {
    res.status(500).json({ ok:false, error: String(e) });
  }
});

app.post('/api/subscriptions', async (req,res)=>{
  const { user_id, watch_type, code, notify_sms, notify_push_token } = req.body || {};
  if (!user_id || !watch_type || !code) return res.status(400).json({ ok:false, error: 'user_id, watch_type, code required' });
  try {
    const row = await createSubscription({ user_id, watch_type, code, notify_sms, notify_push_token });
    res.json({ ok:true, subscription: row });
  } catch (e) {
    res.status(500).json({ ok:false, error: String(e) });
  }
});

app.delete('/api/subscriptions/:id', async (req,res)=>{
  const id = req.params.id;
  try {
    await deleteSubscription(id);
    res.json({ ok:true });
  } catch (e) {
    res.status(500).json({ ok:false, error: String(e) });
  }
});

// Manual test-notify
app.post('/admin/notify/test', async (req,res)=>{
  const { user_id, message, lat, lon } = req.body || {};
  if (!user_id || !message) return res.status(400).json({ ok:false, error: 'user_id and message required' });
  try {
    // lookup user's subscriptions to get notify endpoints
    const subs = await listUserSubscriptions(user_id);
    const endpoints = subs.map(s=> ({ user_id, sms: s.notify_sms, push: s.notify_push_token, message, lat, lon }));
    const count = await sendCombinedNotifications(endpoints);
    res.json({ ok:true, sent: count });
  } catch (e) {
    res.status(500).json({ ok:false, error: String(e) });
  }
});

// Simple health
app.get('/api/health', (req,res)=> res.json({ ok:true, states: STATES }));

const port = process.env.PORT || 3000;
app.listen(port, async () => {
  console.log(`StormCam server on :${port}`);
  // initial warmup
  for (const s of STATES) {
    try {
      await fetch(`http://localhost:${port}/admin/refresh/${s}`, { method:'POST' });
    } catch (e) {
      console.warn('Warmup failed for', s, e);
    }
  }
});
