# StormCam GA+FL + Alerts (Replit)

**Everything in the basic starter**, plus:
- Supabase schema for **subscriptions** (watchlists) and **alerts logs**
- Server routes to **save subscriptions** (state/county/camera)
- **Twilio SMS** + **Firebase Cloud Messaging** scaffolding to notify on incidents
- Hook points to trigger notifications after each refresh

## Quick start
```bash
npm run setup
npm run dev
```

Then open the client on port **5173**. Use the **Watchlist** panel to add subscriptions.

## Env (.env)
```
# Optional 511 endpoints
GA_CAMERAS_URL=
GA_INCIDENTS_URL=
FL_CAMERAS_URL=
FL_INCIDENTS_URL=

# Supabase (Service Role is required server-side to write)
SUPABASE_URL=
SUPABASE_SERVICE_ROLE=

# Twilio SMS (optional)
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_FROM=+1xxxxxxxxxx

# Firebase Admin (optional push). Put the *entire* service account JSON as one line
# or base64-encode it and use the _B64 variant.
FCM_SERVICE_ACCOUNT_JSON=
FCM_SERVICE_ACCOUNT_JSON_B64=
```

> You can start without Twilio/FCM; the server will skip those senders if not configured.

## Supabase schema
Upload `supabase/schema.sql` as a migration in Supabase. It creates:
- `subscriptions` — user watch areas (state/county/camera)
- `alerts` — notification log
(You can add tables for `jurisdictions`, `cameras`, `incidents` later.)

## Routes
- `GET  /api/states` → ["GA","FL"]
- `GET  /api/cameras/:state`
- `GET  /api/incidents/:state`
- `GET  /api/subscriptions?user=<id>`
- `POST /api/subscriptions` `{ user_id, watch_type: "state"|"county"|"camera", code, notify_sms?, notify_push_token? }`
- `DELETE /api/subscriptions/:id`
- `POST /admin/refresh/:state` → refresh cache and **emit alerts** from latest incidents
- `POST /admin/notify/test` → send a test alert to a user `{ user_id, message, lat?, lon? }`
