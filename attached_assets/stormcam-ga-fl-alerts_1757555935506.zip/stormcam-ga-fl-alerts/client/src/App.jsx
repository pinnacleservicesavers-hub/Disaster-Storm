import React from 'react'
import Cameras from './pages/Cameras.jsx'
import Watchlist from './pages/Watchlist.jsx'

export default function App(){
  return (
    <div style={{fontFamily:'system-ui, sans-serif', padding:16, display:'grid', gap:16}}>
      <h2>StormCam — Live Cameras, Incidents & Alerts</h2>
      <div style={{display:'grid', gap:16, gridTemplateColumns:'2fr 1fr'}}>
        <Cameras />
        <Watchlist />
      </div>
      <footer style={{marginTop:24, fontSize:12, opacity:0.7}}>
        Demo streams are placeholders. Replace provider URLs to go live.
      </footer>
    </div>
  )
}
