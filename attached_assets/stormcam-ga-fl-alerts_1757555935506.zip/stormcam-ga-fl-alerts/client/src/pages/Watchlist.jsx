import React, { useEffect, useState } from 'react'

export default function Watchlist(){
  const [userId, setUserId] = useState('demo-user')
  const [states, setStates] = useState([])
  const [state, setState] = useState('GA')
  const [subs, setSubs] = useState([])
  const [phone, setPhone] = useState('')
  const [pushToken, setPushToken] = useState('')

  useEffect(()=>{ fetch('/api/states').then(r=>r.json()).then(setStates) },[])
  useEffect(()=>{
    if (!userId) return
    fetch(`/api/subscriptions?user=${encodeURIComponent(userId)}`).then(r=>r.json()).then(data=>{
      setSubs(Array.isArray(data) ? data : [])
    })
  },[userId])

  const addState = async () => {
    const res = await fetch('/api/subscriptions', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ user_id: userId, watch_type:'state', code: state, notify_sms: phone || null, notify_push_token: pushToken || null })
    })
    const js = await res.json()
    if (js.ok) {
      setSubs([js.subscription, ...subs])
      setPhone(''); setPushToken('')
    } else {
      alert(js.error || 'Error')
    }
  }

  const remove = async (id) => {
    const res = await fetch(`/api/subscriptions/${id}`, { method:'DELETE' })
    const js = await res.json()
    if (js.ok) setSubs(subs.filter(s=> s.id !== id))
  }

  const sendTest = async () => {
    const msg = prompt('Test alert message?', 'Test: Tree down near your watch area')
    if (!msg) return
    const res = await fetch('/admin/notify/test', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ user_id: userId, message: msg })
    })
    const js = await res.json()
    alert(js.ok ? `Sent: ${js.sent}` : js.error)
  }

  return (
    <div style={{border:'1px solid #eee', borderRadius:12, padding:12}}>
      <h3>Watchlist & Alerts</h3>
      <div style={{display:'grid', gap:8}}>
        <label>User ID
          <input value={userId} onChange={e=>setUserId(e.target.value)} placeholder="user-123" style={{width:'100%'}}/>
        </label>
        <label>Phone for SMS (optional)
          <input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="+17065551234" style={{width:'100%'}}/>
        </label>
        <label>Push token (optional)
          <input value={pushToken} onChange={e=>setPushToken(e.target.value)} placeholder="FCM device token" style={{width:'100%'}}/>
        </label>
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <select value={state} onChange={e=>setState(e.target.value)}>
            {states.map(s=> <option key={s} value={s}>{s}</option>)}
          </select>
          <button onClick={addState}>Follow State</button>
          <button onClick={sendTest}>Send Test Alert</button>
        </div>
      </div>

      <h4 style={{marginTop:16}}>Your Subscriptions ({subs.length})</h4>
      <ul>
        {subs.map(s=> (
          <li key={s.id}>
            {s.watch_type}:{' '}{s.code}{' '}
            {s.notify_sms ? `SMS:${s.notify_sms} ` : ''}{s.notify_push_token ? `Push:✔` : ''}
            <button onClick={()=>remove(s.id)} style={{marginLeft:8}}>Remove</button>
          </li>
        ))}
      </ul>
      <p style={{fontSize:12, opacity:0.7}}>
        County & camera-level watchers can be added next. This starter demonstrates state-level alerts first.
      </p>
    </div>
  )
}
