
-- Minimal tables for watchlists and alerts

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id text not null,
  watch_type text not null check (watch_type in ('state','county','camera')),
  code text not null, -- e.g. 'GA', 'GA-Harris', or camera id
  notify_sms text null,
  notify_push_token text null,
  created_at timestamptz default now()
);

create index if not exists subs_user_idx on public.subscriptions(user_id);
create index if not exists subs_type_code_idx on public.subscriptions(watch_type, code);

create table if not exists public.alerts (
  id uuid primary key default gen_random_uuid(),
  jurisdiction_code text not null,
  camera_id text null,
  incident_id text null,
  kind text not null, -- 'Incident'|'SnapshotAnomaly'|'Corroborated'
  score numeric null,
  message text not null,
  lat double precision null,
  lon double precision null,
  snapshot_url text null,
  created_at timestamptz default now()
);
