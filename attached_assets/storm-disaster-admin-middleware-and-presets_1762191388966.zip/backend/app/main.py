from fastapi import FastAPI
app=FastAPI()

from .middleware.admin_enforce import AdminVerifiedTokenMiddleware
app.add_middleware(AdminVerifiedTokenMiddleware)
