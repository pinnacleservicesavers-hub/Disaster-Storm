from fastapi import APIRouter
router=APIRouter()


from fastapi import Request
from pydantic import BaseModel
from ..utils.store import store
from ..utils.security import get_ctx, require_admin

class PresetBody(BaseModel):
    provider: str
    domain_or_project: str
    audience: str
    enforce: bool = True

@router.post("/admin/oidc/preset")
def set_oidc_preset(body: PresetBody, request: Request):
    ctx = get_ctx(request); require_admin(ctx)
    p = (body.provider or "").lower()
    iss = ""
    if p == "auth0":
        iss = f"https://{body.domain_or_project.strip().strip('/')}/"
    elif p == "supabase":
        iss = f"https://{body.domain_or_project.strip().strip('/')}.supabase.co/auth/v1"
    elif p == "clerk":
        dom = body.domain_or_project.strip().strip('/')
        if not dom.startswith("http"): dom = "https://" + dom
        iss = dom
    else:
        return {"ok": False, "error": "Unknown provider. Use auth0|clerk|supabase."}
    store.settings.setdefault("oidc", {})
    store.settings["oidc"].update({"issuer": iss, "audience": body.audience, "enforce": bool(body.enforce)})
    return {"ok": True, "oidc": store.settings["oidc"]}
