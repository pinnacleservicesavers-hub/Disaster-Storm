
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from ..utils import security

class AdminVerifiedTokenMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        path = request.url.path or ""
        if path.startswith("/admin"):
            authz = request.headers.get("Authorization") or request.headers.get("authorization") or ""
            if not authz.lower().startswith("bearer "):
                return JSONResponse({"detail": "Admin routes require Bearer token"}, status_code=401)
            token = authz.split(" ",1)[1].strip()
            try:
                _ = security._verify_with_jwks(token)
            except Exception as e:
                return JSONResponse({"detail": f"Invalid admin token: {e}"}, status_code=401)
        return await call_next(request)
