from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
app=FastAPI()
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])

from .routers import admin_export
app.include_router(admin_export.router, tags=['admin'])


@app.on_event("startup")
async def _auto_cleanup_shares():
    try:
        from .routers.admin_export import cleanup_shares
        cleanup_shares()
    except Exception:
        # fail-safe: don't crash startup if cleanup isn't available yet
        pass
