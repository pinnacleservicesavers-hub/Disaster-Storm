

## Contractor-first Branding & Submission
- Edit branding at `/contractor/profile` (company name, logo URL, legal name, address, phone, email)
- Generated **letters** and the **cover letter** are rendered as branded PDFs (logo, contact block) and included in the Submission ZIP.
- Add `state` when generating a letter to include state-specific statutory notes: `POST /claims/letters/generate { job_id, type, state }`
- Submit package to insurer via email: `POST /claims/submit/email { job_id, to_email, subject?, message? }` (SMTP scaffold; configure your SMTP).



## Branded Invoice PDF + Pay Link
- Endpoint (create/fetch): `POST /payments/invoice/checkout { job_id }` → returns `checkout_url` (Stripe).
- Cover letter includes a **Pay now** line when a checkout URL is available.
- The **Submission ZIP** bundles **invoice-<job>.pdf**, **claim-report-<job>.pdf**, **cover-letter-<job>.pdf**, and any letters.
- UI: on the contractor job page, click **Create/Fetch Pay Link** to generate a Stripe-hosted checkout and display the URL.
- Env: `STRIPE_SECRET_KEY`, optional `STRIPE_PRICE_INVOICE`, `STRIPE_CURRENCY`, and `STRIPE_SUCCESS_URL`/`STRIPE_CANCEL_URL`.
