from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store
from ..services.stripe_svc import create_invoice_checkout

router = APIRouter()

class PayLinkBody(BaseModel):
    job_id: str

@router.post("/payments/invoice/checkout")
def invoice_checkout(body: PayLinkBody):
    job = store.jobs.get(body.job_id, {})
    inv = next((v for v in store.invoices.values() if v.get("job_id")==body.job_id), None)
    total = 0.0
    if inv:
        for v in inv.get("breakdown", {}).values():
            try: total += float(v)
            except: pass
    url = create_invoice_checkout(int(total*100), body.job_id)
    # store on job for reuse
    job.setdefault("payments", {})["checkout_url"] = url
    store.jobs[body.job_id] = job
    return {"checkout_url": url, "total": total}
