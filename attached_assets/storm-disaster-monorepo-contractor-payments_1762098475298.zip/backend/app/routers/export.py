import io, json, zipfile, os
from fastapi import APIRouter, Response
from ..utils.pdf import html_to_pdf_bytes
from ..utils.store import store
from ..services.branding import render_letter_pdf
from ..services.invoice_pdf import render_invoice_pdf

router = APIRouter()

def build_report_html(job_id: str):
    inv = next((v for v in store.invoices.values() if v.get("job_id")==job_id), None)
    total = 0.0
    if inv:
        for v in inv.get("breakdown", {}).values():
            try: total += float(v)
            except: pass
    xact = (inv or {}).get("xactimate", {}).get("total", 0.0)
    var = total - xact
    return f"""<html><body><h1>Claim Report {job_id}</h1>
    <p>Total: ${total:,.2f} Xactimate: ${xact:,.2f} Variance: ${var:,.2f}</p></body></html>"""

def build_cover_letter(job_id: str, profile: dict, pay_url: str|None):
    subject = f"Submission of Claim Package — Job {job_id}"
    pay_line = f"Pay now: {pay_url}\n" if pay_url else ""
    body = f"""Please find attached the completed claim package for Job {job_id}: invoice, comparables, documentation, and letters.
{pay_line}
We request prompt review and payment. Direct any questions to the contact below.

Thank you,
{profile.get('company_name') or 'Contractor'}
"""
    return {"subject": subject, "body": body}

@router.get("/claims/{job_id}/submission.zip")
async def submission_zip(job_id: str):
    job = store.jobs.get(job_id, {})
    contractor_id = job.get("contractor_id")
    profile = {}
    if contractor_id and contractor_id in store.users:
        profile = store.users[contractor_id].get("profile", {})

    inv = next((v for v in store.invoices.values() if v.get("job_id")==job_id), None) or {"breakdown": {}, "xactimate": {}}
    breakdown = inv.get("breakdown", {})
    xact_total = inv.get("xactimate", {}).get("total")
    pay_url = (job.get("payments") or {}).get("checkout_url")

    # PDFs
    report_html = build_report_html(job_id)
    report_pdf = html_to_pdf_bytes(report_html)
    invoice_pdf = render_invoice_pdf(job_id, breakdown, profile, xact_total=xact_total, pay_url=pay_url)

    cover = build_cover_letter(job_id, profile, pay_url)
    cover_pdf = render_letter_pdf({"subject": cover["subject"], "body": cover["body"]}, profile, "")

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"claim-report-{job_id}.pdf", report_pdf)
        z.writestr(f"invoice-{job_id}.pdf", invoice_pdf)
        z.writestr(f"cover-letter-{job_id}.pdf", cover_pdf)

        # Letters (txt+pdf) if any
        letters = (store.jobs.get(job_id, {}) or {}).get("letters", [])
        for i, lt in enumerate(letters, start=1):
            txt_name = f"letters/{i:02d}-{lt.get('letter_type','letter')}.txt"
            text = (lt.get("subject","Letter") + "\n\n" + lt.get("message",""))
            z.writestr(txt_name, text)
            # Render branded PDF for letter
            from ..services.branding import render_letter_pdf as _rlp
            z.writestr(f"letters/{i:02d}-{lt.get('letter_type','letter')}.pdf", _rlp({"subject": lt.get("subject","Letter"), "body": lt.get("message","")}, profile, ""))

        # Manifest
        z.writestr("manifest.json", json.dumps({
            "job_id": job_id,
            "has_invoice_pdf": True,
            "has_cover_letter_pdf": True,
            "pay_link": pay_url
        }, indent=2))

    buf.seek(0)
    return Response(content=buf.read(), media_type="application/zip",
                    headers={"Content-Disposition": f"attachment; filename=submission-{job_id}.zip"})
