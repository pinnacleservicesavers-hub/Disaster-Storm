from jinja2 import Template
from ..utils.pdf import html_to_pdf_bytes

TPL = '''<!doctype html><html><head><meta charset="utf-8"><style>
body{font-family:Arial, sans-serif; padding:40px;}
.header{display:flex;align-items:center;gap:16px;border-bottom:2px solid #111;padding-bottom:12px;margin-bottom:18px}
.logo{height:56px;width:56px;object-fit:contain;border-radius:8px}
.brand{font-weight:700;font-size:18px}
.meta{font-size:12px;color:#555}
h1{font-size:20px;margin:18px 0 6px}
table{width:100%;border-collapse:collapse;margin-top:10px}
th,td{border-bottom:1px solid #eee;padding:8px;text-align:left}
.total{font-weight:700}
.note{font-size:12px;color:#555;margin-top:10px}
</style></head><body>
<div class="header">
  {% if profile.logo_url %}<img class="logo" src="{{ profile.logo_url }}">{% endif %}
  <div>
    <div class="brand">{{ profile.company_name or "Contractor" }}</div>
    <div class="meta">{{ profile.legal_name or "" }}{% if profile.legal_name %} · {% endif %}{{ profile.address or "" }}{% if profile.address %} · {% endif %}{{ profile.phone or "" }}{% if profile.phone %} · {% endif %}{{ profile.email or "" }}</div>
  </div>
</div>
<h1>Invoice — Job {{ job_id }}</h1>
<div>Bill To: {{ bill_to or "Homeowner/Insured" }}</div>
<table>
  <tr><th>Description</th><th>Amount</th></tr>
  {% for k, v in breakdown.items() %}
  <tr><td>{{ k }}</td><td>${{ '%.2f'|format(v|float) }}</td></tr>
  {% endfor %}
  <tr class="total"><td>Total</td><td>${{ '%.2f'|format(total|float) }}</td></tr>
  {% if xact_total is not none %}
  <tr><td>Xactimate Comparable</td><td>${{ '%.2f'|format(xact_total|float) }}</td></tr>
  <tr><td><b>Variance</b></td><td><b>${{ '%.2f'|format((total - xact_total)|float) }}</b></td></tr>
  {% endif %}
</table>
{% if pay_url %}
<p class="note">Pay online: <a href="{{ pay_url }}">{{ pay_url }}</a></p>
{% endif %}
<p class="note">Thank you for your business.</p>
</body></html>'''

def render_invoice_pdf(job_id: str, breakdown: dict, profile: dict, xact_total: float|None=None, pay_url: str|None=None, bill_to: str|None=None) -> bytes:
    total = 0.0
    for v in breakdown.values():
        try: total += float(v)
        except: pass
    html = Template(TPL).render(job_id=job_id, breakdown=breakdown, total=total, xact_total=xact_total, pay_url=pay_url or "", profile=profile or {}, bill_to=bill_to or "")
    return html_to_pdf_bytes(html)
