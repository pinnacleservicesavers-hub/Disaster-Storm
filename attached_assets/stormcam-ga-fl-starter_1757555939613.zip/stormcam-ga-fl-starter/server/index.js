import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';
import { fetchGA } from './providers/ga-511.js';
import { fetchFL } from './providers/fl-511.js';

const app = express();
app.use(cors());
app.use(express.json());

// In-memory caches (swap with DB when ready)
const cache = {
  cameras: new Map(),   // key: "GA" -> Array
  incidents: new Map(), // key: "GA" -> Array
};

// States wired up in this starter
const STATES = ["GA","FL"];

// Map of fetchers
const STATE_HANDLERS = {
  "GA": fetchGA,
  "FL": fetchFL
};

// Admin: refresh one state now
app.post('/admin/refresh/:state', async (req, res) => {
  const state = (req.params.state || '').toUpperCase();
  if (!STATE_HANDLERS[state]) return res.status(404).json({ ok:false, error: 'Unknown state' });
  try {
    const { cameras, incidents } = await STATE_HANDLERS[state]();
    cache.cameras.set(state, cameras);
    cache.incidents.set(state, incidents);
    res.json({ ok:true, cameras: cameras.length, incidents: incidents.length });
  } catch (err) {
    console.error('Refresh error', state, err);
    res.status(500).json({ ok:false, error: String(err) });
  }
});

// Public API
app.get('/api/states', (req,res)=> res.json(STATES));

app.get('/api/cameras/:state', (req,res)=> {
  const s = (req.params.state || '').toUpperCase();
  res.json(cache.cameras.get(s) || []);
});

app.get('/api/incidents/:state', (req,res)=> {
  const s = (req.params.state || '').toUpperCase();
  res.json(cache.incidents.get(s) || []);
});

// Simple health
app.get('/api/health', (req,res)=> res.json({ ok:true, states: STATES }));

const port = process.env.PORT || 3000;
app.listen(port, async () => {
  console.log(`StormCam server on :${port}`);
  // initial warmup
  for (const s of STATES) {
    try {
      await fetch(`http://localhost:${port}/admin/refresh/${s}`, { method:'POST' });
    } catch (e) {
      console.warn('Warmup failed for', s, e);
    }
  }
});
