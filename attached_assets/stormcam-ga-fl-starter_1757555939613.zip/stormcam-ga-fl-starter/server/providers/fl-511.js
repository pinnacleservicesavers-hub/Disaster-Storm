import fetch from 'node-fetch';

const FL_CAMERAS_URL = process.env.FL_CAMERAS_URL || ''; // set real endpoint
const FL_INCIDENTS_URL = process.env.FL_INCIDENTS_URL || ''; // set real endpoint

const demoCameras = [
  {
    id: "FL_DEMO_SNAP",
    name: "FL Snapshot Only (placeholder)",
    lat: 30.3322, lon: -81.6557,
    type: "JPEG",
    stream_url: null,
    snapshot_url: "https://placehold.co/800x450?text=FL+Camera+Snapshot",
    jurisdiction: "FL",
    meta: { road: "I-95", dir: "SB" }
  }
];

const demoIncidents = [
  {
    id: "FL_INC_DEMO1",
    jurisdiction: "FL",
    type: "Debris",
    description: "Debris on roadway, shoulder blocked",
    lat: 30.33, lon: -81.66,
    road: "I-95",
    starts_at: new Date().toISOString(),
    ends_at: null,
    source: { provider: "demo" }
  }
];

async function safeJson(url) {
  if (!url) return null;
  try {
    const res = await fetch(url, { timeout: 8000 });
    if (!res.ok) throw new Error(`Bad status ${res.status}`);
    return await res.json();
  } catch (e) {
    console.warn('FL safeJson fallback:', e.message);
    return null;
  }
}

function inferType(stream, img) {
  if (stream && stream.endsWith('.m3u8')) return 'HLS';
  if (stream && /mjpeg|mjpg|action=stream/i.test(stream)) return 'MJPEG';
  if (img) return 'JPEG';
  return null;
}

export async function fetchFL() {
  // If you have real FL endpoints, fetch and normalize here.
  // const camsRaw = await safeJson(FL_CAMERAS_URL);
  // const incRaw = await safeJson(FL_INCIDENTS_URL);

  const cams = demoCameras.map(c => ({
    id: c.id, name: c.name, lat: c.lat, lon: c.lon,
    type: c.type, stream_url: c.stream_url, snapshot_url: c.snapshot_url,
    jurisdiction: "FL", meta: c.meta
  }));

  const incidents = demoIncidents;

  return { cameras: cams, incidents };
}
