import fetch from 'node-fetch';

const GA_CAMERAS_URL = process.env.GA_CAMERAS_URL || ''; // set real endpoint
const GA_INCIDENTS_URL = process.env.GA_INCIDENTS_URL || ''; // set real endpoint

// Fallback demo data (edit/remove after wiring real endpoints)
const demoCameras = [
  {
    id: "GA_DEMO_HLS",
    name: "GA Demo HLS (Mux test stream)",
    lat: 33.7490, lon: -84.3880,
    type: "HLS",
    stream_url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
    snapshot_url: null,
    jurisdiction: "GA",
    meta: { road: "I-75", dir: "NB" }
  },
  {
    id: "GA_DEMO_SNAP",
    name: "GA Snapshot Only (placeholder)",
    lat: 32.4609, lon: -84.9877,
    type: "JPEG",
    stream_url: null,
    snapshot_url: "https://placehold.co/800x450?text=GA+Camera+Snapshot",
    jurisdiction: "GA",
    meta: { road: "US-27", dir: "SB" }
  }
];

const demoIncidents = [
  {
    id: "GA_INC_DEMO1",
    jurisdiction: "GA",
    type: "TreeDown",
    description: "Tree reported down, right lane blocked",
    lat: 32.46, lon: -84.99,
    road: "US-27",
    starts_at: new Date().toISOString(),
    ends_at: null,
    source: { provider: "demo" }
  }
];

async function safeJson(url) {
  if (!url) return null;
  try {
    const res = await fetch(url, { timeout: 8000 });
    if (!res.ok) throw new Error(`Bad status ${res.status}`);
    return await res.json();
  } catch (e) {
    console.warn('GA safeJson fallback:', e.message);
    return null;
  }
}

function inferType(stream, img) {
  if (stream && stream.endsWith('.m3u8')) return 'HLS';
  if (stream && /mjpeg|mjpg|action=stream/i.test(stream)) return 'MJPEG';
  if (img) return 'JPEG';
  return null;
}

export async function fetchGA() {
  // If you have real GA endpoints, fetch and normalize here.
  // Example (pseudo - adapt to real field names):
  // const camsRaw = await safeJson(GA_CAMERAS_URL);
  // const incRaw = await safeJson(GA_INCIDENTS_URL);

  // If missing or failed, use demo
  const cams = demoCameras.map(c => ({
    id: c.id, name: c.name, lat: c.lat, lon: c.lon,
    type: c.type, stream_url: c.stream_url, snapshot_url: c.snapshot_url,
    jurisdiction: "GA", meta: c.meta
  }));

  const incidents = demoIncidents;

  return { cameras: cams, incidents };
}
