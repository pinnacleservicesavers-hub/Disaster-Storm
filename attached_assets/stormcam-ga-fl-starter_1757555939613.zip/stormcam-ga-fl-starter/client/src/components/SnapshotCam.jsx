import React, { useEffect, useState } from 'react'
export default function SnapshotCam({ src, intervalMs=3000 }){
  const [url, setUrl] = useState(src)
  useEffect(()=>{
    const id = setInterval(()=> setUrl(`${src}${src.includes('?')?'&':'?'}t=${Date.now()}`), intervalMs)
    return ()=> clearInterval(id)
  },[src, intervalMs])
  return <img src={url} alt="Camera snapshot" style={{width:'100%'}} />
}
