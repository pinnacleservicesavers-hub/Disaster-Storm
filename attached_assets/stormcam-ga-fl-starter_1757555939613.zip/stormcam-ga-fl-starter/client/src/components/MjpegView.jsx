import React from 'react'
export default function MjpegView({ src }){
  return <img src={src} alt="Live camera" style={{width:'100%'}} />
}
