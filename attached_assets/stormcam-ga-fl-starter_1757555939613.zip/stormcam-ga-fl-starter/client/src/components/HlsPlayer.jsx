import React, { useEffect, useRef } from 'react'
import Hls from 'hls.js'

export default function HlsPlayer({ src, autoPlay=true, muted=true }){
  const ref = useRef(null)
  useEffect(()=>{
    const v = ref.current
    if (!v) return
    if (Hls.isSupported()) {
      const hls = new Hls({ enableWorker: true, lowLatencyMode: true })
      hls.loadSource(src); hls.attachMedia(v)
      return ()=> hls.destroy()
    } else if (v.canPlayType('application/vnd.apple.mpegurl')) {
      v.src = src
    }
  },[src])
  return <video ref={ref} autoPlay={autoPlay} muted={muted} controls playsInline style={{width:'100%'}}/>
}
