import React, { useEffect, useState } from 'react'
import Cameras from './pages/Cameras.jsx'

export default function App(){
  return (
    <div style={{fontFamily:'system-ui, sans-serif', padding:16}}>
      <h2>StormCam — Live Cameras & Incidents</h2>
      <Cameras />
      <footer style={{marginTop:24, fontSize:12, opacity:0.7}}>
        Demo streams are placeholders. Replace provider URLs to go live.
      </footer>
    </div>
  )
}
