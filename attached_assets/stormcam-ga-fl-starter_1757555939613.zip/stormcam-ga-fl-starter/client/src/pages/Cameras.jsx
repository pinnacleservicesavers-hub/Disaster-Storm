import React, { useEffect, useState } from 'react'
import HlsPlayer from '../components/HlsPlayer.jsx'
import MjpegView from '../components/MjpegView.jsx'
import SnapshotCam from '../components/SnapshotCam.jsx'

export default function Cameras(){
  const [states, setStates] = useState([])
  const [state, setState] = useState('GA')
  const [cams, setCams] = useState([])
  const [incidents, setIncidents] = useState([])

  useEffect(()=>{ fetch('/api/states').then(r=>r.json()).then(setStates) },[])
  useEffect(()=>{
    fetch(`/api/cameras/${state}`).then(r=>r.json()).then(setCams)
    fetch(`/api/incidents/${state}`).then(r=>r.json()).then(setIncidents)
  },[state])

  return (
    <div style={{display:'grid', gap:16}}>
      <div style={{display:'flex', gap:12, alignItems:'center'}}>
        <label>State:&nbsp;
          <select value={state} onChange={e=>setState(e.target.value)}>
            {states.map(s=> <option key={s} value={s}>{s}</option>)}
          </select>
        </label>
      </div>

      <div>
        <h3>Incidents ({incidents.length})</h3>
        <ul>
          {incidents.map(x=> <li key={x.id}><b>{x.type}</b> — {x.description}</li>)}
        </ul>
      </div>

      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(320px,1fr))', gap:16}}>
        {cams.map(c => (
          <div key={c.id} style={{border:'1px solid #eee', borderRadius:12, padding:12}}>
            <div style={{fontWeight:600, marginBottom:8}}>{c.name} <span style={{opacity:0.6}}>({c.jurisdiction})</span></div>
            {c.type==='HLS' && c.stream_url ? <HlsPlayer src={c.stream_url}/> :
             c.type==='MJPEG' && c.stream_url ? <MjpegView src={c.stream_url}/> :
             c.snapshot_url ? <SnapshotCam src={c.snapshot_url}/> :
             <div>No video available</div>}
          </div>
        ))}
      </div>
    </div>
  )
}
