# StormCam GA+FL Starter (Replit)

A minimal, copy‑paste starter that shows **live/near‑live traffic cameras** by state
with a server proxy and a React (Vite) UI. It includes **Georgia** and **Florida**
provider stubs and is designed so you can add more states quickly.

## What you get
- **server/**: Express API with provider fetchers and in‑memory cache
- **client/**: Vite + React app with HLS/MJPEG/JPEG viewers and a simple camera grid
- **Admin refresh** route to pull/normalize cameras & incidents
- Works on Replit with one command via `concurrently`

## Quick start on Replit
1) Upload this zip and click “Unzip here” (or drag the folder into the Repl).
2) In the Shell, run:
   ```bash
   npm run setup
   npm run dev
   ```
3) Replit will start **server (3000)** and **client (5173)** together.
   - If the preview opens the server port, click the “Open in new tab” arrow and choose the **5173** URL for the UI.
4) In the UI, you’ll see demo GA/FL cameras (one HLS demo stream + snapshot placeholders).
   Replace the provider URLs with real 511 endpoints to go live (see notes in `server/providers/*`).

## Environment variables (optional)
Create a `.env` at the repo root if you have *real* endpoints:
```
GA_CAMERAS_URL=<GA 511 cameras endpoint>
GA_INCIDENTS_URL=<GA 511 incidents endpoint>
FL_CAMERAS_URL=<FL 511 cameras endpoint>
FL_INCIDENTS_URL=<FL 511 incidents endpoint>
```

## Add more states
- Duplicate a provider file in `server/providers/` (e.g., `tx-511.js`), export `fetchTX()` returning `{ cameras, incidents }`.
- Wire it in `server/index.js` (`STATE_HANDLERS`) and into the `/api/states` list.

## Terms of use
Always check each provider’s terms. Show only permitted streams and do not restream unless the license allows it.
