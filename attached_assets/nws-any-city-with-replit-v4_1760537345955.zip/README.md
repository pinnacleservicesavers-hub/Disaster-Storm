# NWS Any-City (Replit ready)

Node/Express backend + simple frontend to fetch **National Weather Service (weather.gov)** forecasts & alerts for **any city**.

## Features
- Any-city by name (geocoded with OpenStreetMap Nominatim)
- NWS `/points` discovery → Daily + Hourly forecasts
- Active alerts filtered by **point=lat,lon**
- **Zone lookup** endpoint for quick zone IDs (forecast/county/fire)
- Units toggle (°F/°C) with wind units conversion
- Zone/County IDs + public NWS deep-links (office, MapClick, hourly graph, zone page)
- LRU-style in-memory cache with TTL + periodic sweep
- HTTP caching: `Cache-Control`, `ETag`, `Last-Modified` + 304 support
- Reverse geocoding for GPS to show friendly place names
- Frontend: autocomplete, “Use my location”, spinner/skeletons, retries, hourly temp chart, Copy IDs

## Quickstart (Replit)
1. Create a **Node.js** Repl.
2. Upload/extract this folder (or the ZIP).
3. Click **Run**. Replit installs deps and launches the server at `PORT` (default 3000).
4. Open the webview to use the UI at `/`.

## Endpoints
- `GET /api/geo/search?q=miami` → `[ {label, lat, lon}, ... ]` (cached 5m)
- `GET /api/nws/city?q=Miami, FL&units=imperial|metric` → `{ location, coords, units, daily[], hourly[], alerts[], zones{}, publicLinks{} }` (cached 90s)
- `GET /api/nws/point?lat=25.77&lon=-80.19&units=imperial|metric` → same shape + `locationDisplay`
- `GET /api/alerts?zone=GAZ021[,GAC089]` → active alerts for zone IDs (cached 60s)
- `GET /api/zone-lookup?lat=33.75&lon=-84.39` → office/grid + zone IDs for chaining to `/api/alerts` (cached 5m)
- `GET /health` → cache & memory stats (3s cache)
- `GET /api/version` → build metadata (10s cache)

## Headers / Identity
All upstream requests include:
```
User-Agent: DisasterDirectApp (support@strategiclandmgmt.com)
Accept: application/geo+json
```
> NWS **requires** a meaningful User-Agent.

## Environment
- Node 18+ (Replit `replit.nix` pins Node 18 + npm)
- PORT: `3000` by default

## Frontend
- City autocomplete (`/api/geo/search`), °F/°C toggle, “Use my location”
- Alerts, daily cards, hourly chart (Chart.js)
- Zone/office meta with links and “Copy IDs” button
