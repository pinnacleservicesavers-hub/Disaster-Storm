// server.js — NWS Any-City API (Node/Express, CommonJS)
const express = require("express");
const cors = require("cors");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;

// ---------- Identity ----------
const UA = "DisasterDirectApp (support@strategiclandmgmt.com)";
const NWS_HEADERS = { "User-Agent": UA, "Accept": "application/geo+json" };

// ---------- LRU-ish in-memory cache ----------
const CACHE = new Map(); // key -> { at:number, ttl:number, data:any }
const CACHE_LIMIT = 500;
const SWEEP_EVERY_MS = 60 * 1000;
const now = () => Date.now();

const STATS = { cacheHits:0, cacheMisses:0, evictions:0, sweeps:0, startedAt: Date.now() };

function setCache(key, data, ttlMs) {
  while (CACHE.size >= CACHE_LIMIT) {
    const oldestKey = CACHE.keys().next().value;
    CACHE.delete(oldestKey);
    STATS.evictions++;
  }
  CACHE.set(key, { at: now(), ttl: ttlMs, data });
}
function getFreshEntry(key) {
  const v = CACHE.get(key);
  if (!v) return null;
  if (now() - v.at > v.ttl) { CACHE.delete(key); STATS.evictions++; return null; }
  CACHE.delete(key); CACHE.set(key, v); // LRU bump
  return v;
}
setInterval(() => {
  const t = now();
  let removed = 0;
  for (const [k,v] of CACHE.entries()) {
    if (t - v.at > v.ttl) { CACHE.delete(k); removed++; }
  }
  if (removed) STATS.evictions += removed;
  STATS.sweeps++;
}, SWEEP_EVERY_MS).unref?.();

// ---------- HTTP cache helpers ----------
function jsonETag(obj) {
  const str = JSON.stringify(obj);
  const hash = crypto.createHash("sha1").update(str).digest("hex");
  return `W/"${hash}"`;
}
function sendCachedJSON(req, res, body, clientMaxAgeSec = 60, lastModifiedMs = Date.now()) {
  const etag = jsonETag(body);
  const inm = req.headers["if-none-match"];
  const ims = req.headers["if-modified-since"];
  const lastModStr = new Date(lastModifiedMs).toUTCString();

  res.setHeader("Cache-Control", `public, max-age=${clientMaxAgeSec}`);
  res.setHeader("ETag", etag);
  res.setHeader("Last-Modified", lastModStr);
  res.setHeader("Content-Type", "application/json; charset=utf-8");

  if (inm && inm === etag) return res.status(304).end();
  if (ims && Date.parse(ims) >= lastModifiedMs) return res.status(304).end();
  return res.status(200).end(JSON.stringify(body));
}

// ---------- Unit helpers ----------
function fToC(f) { return Math.round(((f - 32) * 5) / 9); }
function mphToKmh(m) { return Math.round(m * 1.60934); }
function convertWindString(str, toMetric=false) {
  if (!str || !toMetric) return str || "";
  return str.replace(/\d+(\.\d+)?/g, num => mphToKmh(parseFloat(num))).replace(/mph/g, "km/h");
}

// ---------- Upstream helpers ----------
async function geocodeCity(city) {
  const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(city)}`;
  const res = await fetch(url, { headers: { "User-Agent": UA } });
  if (!res.ok) throw new Error("Geocoding failed");
  const arr = await res.json();
  if (!arr.length) throw new Error("No match for city");
  return { lat: parseFloat(arr[0].lat), lon: parseFloat(arr[0].lon), display: arr[0].display_name };
}
// Reverse geocode (5m cache)
async function reverseGeocode(lat, lon) {
  const key = `rev:${lat.toFixed(4)},${lon.toFixed(4)}`;
  const v = getFreshEntry(key);
  if (v) return v.data;
  const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}`;
  const res = await fetch(url, { headers: { "User-Agent": UA } });
  let display = `${lat.toFixed(4)}, ${lon.toFixed(4)}`;
  if (res.ok) { const j = await res.json(); if (j?.display_name) display = j.display_name; }
  setCache(key, display, 5 * 60 * 1000);
  return display;
}

async function getNwsForPoint(lat, lon, units="imperial") {
  const pts = await fetch(`https://api.weather.gov/points/${lat},${lon}`, { headers: NWS_HEADERS }).then(r => r.json());
  const dailyUrl  = pts?.properties?.forecast;
  const hourlyUrl = pts?.properties?.forecastHourly;
  if (!dailyUrl || !hourlyUrl) throw new Error("NWS points lookup did not return forecast URLs");

  const [daily, hourly, alerts] = await Promise.all([
    fetch(dailyUrl,  { headers: NWS_HEADERS }).then(r => r.json()),
    fetch(hourlyUrl, { headers: NWS_HEADERS }).then(r => r.json()),
    fetch(`https://api.weather.gov/alerts/active?point=${lat},${lon}`, { headers: NWS_HEADERS }).then(r => r.json())
  ]);

  const toMetric = units === "metric";
  const dailyOut = (daily?.properties?.periods ?? []).map(p => ({
    ...p, temperature: toMetric ? fToC(p.temperature) : p.temperature,
    temperatureUnit: toMetric ? "C" : (p.temperatureUnit || "F"),
    windSpeed: convertWindString(p.windSpeed, toMetric)
  }));
  const hourlyOut = (hourly?.properties?.periods ?? []).map(p => ({
    ...p, temperature: toMetric ? fToC(p.temperature) : p.temperature,
    temperatureUnit: toMetric ? "C" : (p.temperatureUnit || "F"),
    windSpeed: convertWindString(p.windSpeed, toMetric)
  }));

  const props = pts?.properties || {};
  const office = props.cwa || null;
  const latNum = Number(lat), lonNum = Number(lon);

  return {
    units,
    relativeLocation: props?.relativeLocation?.properties || null,
    zones: {
      forecastZone: props.forecastZone || null,
      county: props.county || null,
      fireWeatherZone: props.fireWeatherZone || null,
      office,
      grid: { id: props.gridId || null, x: props.gridX ?? null, y: props.gridY ?? null },
      radarStation: props.radarStation || null,
      observationStations: props.observationStations || null
    },
    publicLinks: {
      office: office ? `https://www.weather.gov/${office}` : null,
      mapClick: `https://forecast.weather.gov/MapClick.php?lat=${latNum}&lon=${lonNum}`,
      hourlyGraph: `https://forecast.weather.gov/MapClick.php?lat=${latNum}&lon=${lonNum}&FcstType=graphical`,
      zonePage: props.forecastZone ? `https://forecast.weather.gov/MapClick.php?zoneid=${String(props.forecastZone).split("/").pop()}` : null
    },
    daily: dailyOut,
    hourly: hourlyOut,
    alerts: alerts?.features ?? []
  };
}

// ---------- Express ----------
app.use(cors());
app.use(express.static("public"));

// --- /api/geo/search (5m cache) ---
app.get("/api/geo/search", async (req, res) => {
  try {
    const q = (req.query.q || "").trim();
    if (!q) return sendCachedJSON(req, res, [], 300, now());
    const key = `geo:${q.toLowerCase()}`;
    const v = getFreshEntry(key);
    if (v) { STATS.cacheHits++; return sendCachedJSON(req, res, v.data, 300, v.at); }
    STATS.cacheMisses++;
    const url = `https://nominatim.openstreetmap.org/search?format=json&limit=5&q=${encodeURIComponent(q)}`;
    const r = await fetch(url, { headers: { "User-Agent": UA } });
    if (!r.ok) throw new Error("Geocoding search failed");
    const rows = await r.json();
    const results = rows.map(x => ({ label: x.display_name, lat: parseFloat(x.lat), lon: parseFloat(x.lon) }));
    setCache(key, results, 5 * 60 * 1000);
    return sendCachedJSON(req, res, results, 300, now());
  } catch (e) { res.status(500).json({ error: e.message || "search failed" }); }
});

// --- /api/nws/city (90s cache) ---
app.get("/api/nws/city", async (req, res) => {
  try {
    const q = (req.query.q || "").trim();
    const units = (req.query.units || "imperial").toLowerCase();
    if (!q) return res.status(400).json({ error: "Missing ?q=City" });
    const key = `nws:city:${units}:${q.toLowerCase()}`;
    const v = getFreshEntry(key);
    if (v) { STATS.cacheHits++; return sendCachedJSON(req, res, v.data, 90, v.at); }
    STATS.cacheMisses++;
    const { lat, lon, display } = await geocodeCity(q);
    const payload = await getNwsForPoint(lat, lon, units);
    const body = { location: display, coords: { lat, lon }, ...payload };
    setCache(key, body, 90 * 1000);
    return sendCachedJSON(req, res, body, 90, now());
  } catch (e) { res.status(500).json({ error: e.message || "Server error" }); }
});

// --- /api/nws/point (90s cache) ---
app.get("/api/nws/point", async (req, res) => {
  try {
    const lat = Number(req.query.lat), lon = Number(req.query.lon);
    const units = (req.query.units || "imperial").toLowerCase();
    if (Number.isNaN(lat) || Number.isNaN(lon)) return res.status(400).json({ error: "lat and lon are required numbers" });
    const key = `nws:point:${units}:${lat.toFixed(4)},${lon.toFixed(4)}`;
    const v = getFreshEntry(key);
    if (v) { STATS.cacheHits++; return sendCachedJSON(req, res, v.data, 90, v.at); }
    STATS.cacheMisses++;
    const payload = await getNwsForPoint(lat, lon, units);
    let locationDisplay = null;
    if (payload.relativeLocation?.city && payload.relativeLocation?.state) {
      locationDisplay = `${payload.relativeLocation.city}, ${payload.relativeLocation.state}`;
    } else {
      locationDisplay = await reverseGeocode(lat, lon);
    }
    const body = { locationDisplay, ...payload };
    setCache(key, body, 90 * 1000);
    return sendCachedJSON(req, res, body, 90, now());
  } catch (e) { res.status(500).json({ error: e.message || "Server error" }); }
});

// --- /api/alerts?zone=GAZ021[,GAC089] (60s cache) ---
app.get("/api/alerts", async (req, res) => {
  try {
    const raw = (req.query.zone || "").toString().trim();
    if (!raw) return res.status(400).json({ error: "Missing ?zone=ZONEID[,ZONEID]" });
    const zones = raw.split(",").map(s => s.trim().toUpperCase()).filter(Boolean);
    const valid = zones.every(z => /^[A-Z]{3}\d{3}$/.test(z));
    if (!valid) return res.status(400).json({ error: "Invalid zone format. Use like GAZ021 or GAC089 (AAAddd)." });

    const key = `alerts:zone:${zones.join(",")}`;
    const v = getFreshEntry(key);
    if (v) { STATS.cacheHits++; return sendCachedJSON(req, res, v.data, 60, v.at); }
    STATS.cacheMisses++;

    const url = `https://api.weather.gov/alerts/active?zone=${encodeURIComponent(zones.join(","))}`;
    const j = await fetch(url, { headers: NWS_HEADERS }).then(r => r.json());
    const feats = Array.isArray(j?.features) ? j.features : [];
    const items = feats.map(f => ({
      id: f.id, event: f.properties?.event, headline: f.properties?.headline,
      severity: f.properties?.severity, urgency: f.properties?.urgency,
      areas: f.properties?.areaDesc, sent: f.properties?.sent,
      effective: f.properties?.effective, onset: f.properties?.onset,
      expires: f.properties?.expires, ends: f.properties?.ends,
      status: f.properties?.status, category: f.properties?.category
    }));
    const body = { zone: zones, count: feats.length, items, features: feats };
    setCache(key, body, 60 * 1000);
    return sendCachedJSON(req, res, body, 60, now());
  } catch (e) { res.status(500).json({ error: e.message || "Server error" }); }
});

// --- /api/zone-lookup?lat=..&lon=.. (5m cache) ---
app.get("/api/zone-lookup", async (req, res) => {
  try {
    const lat = Number(req.query.lat), lon = Number(req.query.lon);
    if (Number.isNaN(lat) || Number.isNaN(lon)) return res.status(400).json({ error: "lat and lon are required numbers" });
    const key = `zone:lookup:${lat.toFixed(4)},${lon.toFixed(4)}`;
    const v = getFreshEntry(key);
    if (v) { STATS.cacheHits++; return sendCachedJSON(req, res, v.data, 300, v.at); }
    STATS.cacheMisses++;

    const pts = await fetch(`https://api.weather.gov/points/${lat},${lon}`, { headers: NWS_HEADERS }).then(r => r.json());
    const p = pts?.properties || {};
    const fzUrl = p.forecastZone || null;
    const czUrl = p.county || null;
    const fwzUrl = p.fireWeatherZone || null;
    const body = {
      coords: { lat, lon },
      office: p.cwa || null,
      grid: { id: p.gridId || null, x: p.gridX ?? null, y: p.gridY ?? null },
      forecastUrl: p.forecast || null,
      forecastHourlyUrl: p.forecastHourly || null,
      forecastZone: fzUrl, forecastZoneId: fzUrl ? String(fzUrl).split("/").pop() : null,
      countyZone: czUrl, countyZoneId: czUrl ? String(czUrl).split("/").pop() : null,
      fireWeatherZone: fwzUrl, fireWeatherZoneId: fwzUrl ? String(fwzUrl).split("/").pop() : null,
      relativeLocation: p?.relativeLocation?.properties || null,
      publicLinks: {
        office: p.cwa ? `https://www.weather.gov/${p.cwa}` : null,
        mapClick: `https://forecast.weather.gov/MapClick.php?lat=${lat}&lon=${lon}`,
        hourlyGraph: `https://forecast.weather.gov/MapClick.php?lat=${lat}&lon=${lon}&FcstType=graphical`,
        zonePage: fzUrl ? `https://forecast.weather.gov/MapClick.php?zoneid=${String(fzUrl).split("/").pop()}` : null
      }
    };
    setCache(key, body, 5 * 60 * 1000);
    return sendCachedJSON(req, res, body, 300, now());
  } catch (e) { res.status(500).json({ error: e.message || "Server error" }); }
});

// --- /api/version ---
app.get("/api/version", (req, res) => {
  const body = {
    name: "nws-any-city",
    version: "1.0.0",
    node: process.version,
    uptimeSec: Math.round(process.uptime()),
    endpoints: ["/", "/api/geo/search", "/api/nws/city", "/api/nws/point", "/api/alerts", "/api/zone-lookup", "/health", "/api/version"]
  };
  sendCachedJSON(req, res, body, 10, now());
});

// --- /health ---
app.get("/health", (req, res) => {
  const mem = process.memoryUsage();
  const body = {
    status: "ok",
    uptimeSec: Math.round(process.uptime()),
    startedAt: new Date(STATS.startedAt).toISOString(),
    cache: { size: CACHE.size, limit: CACHE_LIMIT, hits: STATS.cacheHits, misses: STATS.cacheMisses, evictions: STATS.evictions, sweeps: STATS.sweeps },
    memory: { rss: mem.rss, heapTotal: mem.heapTotal, heapUsed: mem.heapUsed, external: mem.external },
    now: new Date().toISOString()
  };
  sendCachedJSON(req, res, body, 3, now());
});

// ---------- Start ----------
app.listen(PORT, () => {
  console.log(`Listening on http://localhost:${PORT}`);
});
