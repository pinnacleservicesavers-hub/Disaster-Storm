# SLM Storm App v5 — Media by Location, Annotation, Speech-to-Text, AI Captions

**New**
- Group **photos/videos by location**: `GET /api/jobs/:id/artifacts-by-location` and UI at `/media`.
- **Photo annotation page** at `/annotate`: draw (pen), add text, **AI caption** (image analysis), and **voice-to-text** notes. Saves the annotated PNG back to the job.
- Uploads now attempt **EXIF GPS extraction** to auto-tag lat/lon (if present).
- Keeps v4: claim packet PDF, Twilio voice with consent, polished dashboard, Stripe, Dropbox Sign, lien reminders, alerts, SPC pins.

**New Secrets (still need previous ones)**
- `OPENAI_API_KEY` (used for transcription and image caption).

**Schema change**
Add location columns to artifacts:
```sql
alter table artifacts add column if not exists lat double precision;
alter table artifacts add column if not exists lon double precision;
```
(Include in your Supabase SQL once.)

**Endpoints**
- `POST /api/media/transcribe` (file: audio/video) → `{ text }`
- `POST /api/media/describe` `{ image_url, context }` → `{ text }`
- `GET /api/jobs/:id/artifacts-by-location` → grouped media

**Front-end pages**
- `/media` view: enter Job ID → see photos grouped by approx GPS.
- `/annotate` editor: load image URL → draw/text/AI caption/speech-to-text → Save to Job.

**Notes**
- Transcription uses Whisper; common audio/video formats are supported.
- Image captions call a vision model to generate objective, claim-ready notes.
- Annotation happens on the browser using Fabric.js; saved images upload as new artifacts.
