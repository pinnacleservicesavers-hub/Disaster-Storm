import express from "express";
import cors from "cors";
import axios from "axios";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import PDFDocument from "pdfkit";
import dayjs from "dayjs";
import archiver from "archiver";
import { createClient } from "@supabase/supabase-js";
import Stripe from "stripe";
import * as Sign from "@dropbox/sign";
import Twilio from "twilio";
import cron from "node-cron";
import * as exifr from "exifr";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

// --- Clients ---
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
const stripe = new Stripe(process.env.STRIPE_SECRET || "", { apiVersion: "2023-10-16" });
const signClient = new Sign.SignatureRequestApi();
Sign.Configuration.username = process.env.DROPBOX_SIGN_KEY || "";
const twilio = Twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);

// ---------- Basic endpoints ----------
app.get("/health", (_, res) => res.json({ ok: true, time: new Date().toISOString() }));

// ---------- Reports ----------
app.get("/api/reports", async (req, res) => {
  const hours = Number(req.query.hours || 48);
  const since = new Date(Date.now() - hours*3600*1000).toISOString();
  const { data, error } = await supabase.from("damage_reports").select("*").gte("created_at", since).order("created_at", { ascending:false }).limit(500);
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post("/api/report-damage", async (req, res) => {
  try {
    const { lat, lon, notes = "", photo_urls = [] } = req.body;
    if (typeof lat !== "number" || typeof lon !== "number") return res.status(400).json({ error: "lat/lon required" });
    let address=null, city=null, state=null, zip=null;
    try {
      const r = await axios.get("https://us1.locationiq.com/v1/reverse", { params: { key: process.env.LOCATIONIQ_KEY, lat, lon, format: "json" }});
      const a = r.data?.address || {};
      address = r.data?.display_name || null; city=a.city||a.town||a.village||null; state=a.state||null; zip=a.postcode||null;
    } catch {}
    const { data, error } = await supabase.from("damage_reports").insert({ lat, lon, address, city, state, zip, notes, source:"public", photos: photo_urls }).select().single();
    if (error) return res.status(500).json({ error: error.message });
    res.json({ ok:true, report:data });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------- Jobs ----------
app.get("/api/jobs", async (req, res) => {
  const { data, error } = await supabase.from("jobs").select("*").order("created_at", { ascending:false }).limit(200);
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.get("/api/jobs/:id", async (req, res) => {
  const id = req.params.id;
  const { data: job, error } = await supabase.from("jobs").select("*").eq("id", id).single();
  if (error) return res.status(404).json({ error: "Not found" });
  const { data: artifacts } = await supabase.from("artifacts").select("*").eq("job_id", id).order("created_at", { ascending:true });
  res.json({ ...job, artifacts: artifacts || [] });
});

app.post("/api/jobs", async (req, res) => {
  const body = req.body || {};
  const { data, error } = await supabase.from("jobs").insert(body).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.patch("/api/jobs/:id", async (req, res) => {
  const { data, error } = await supabase.from("jobs").update(req.body).eq("id", req.params.id).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ---------- Uploads to Supabase Storage ----------
const upload = multer({ storage: multer.memoryStorage() });
app.post("/api/jobs/:id/upload", upload.single("file"), async (req, res) => {
  try {
    const jobId = req.params.id;
    if (!req.file) return res.status(400).json({ error: "file required" });
    const bucket = process.env.SUPABASE_BUCKET || "artifacts";
    const ext = (req.file.originalname || "file").split(".").pop();
    const key = `${jobId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { error: upErr } = await supabase.storage.from(bucket).upload(key, req.file.buffer, { contentType: req.file.mimetype });
    if (upErr) return res.status(500).json({ error: upErr.message });
    const { data: pub } = await supabase.storage.from(bucket).getPublicUrl(key);

    // Try EXIF GPS extraction for photos
    let lat=null, lon=null;
    try {
      if (req.file.mimetype.startsWith("image/")) {
        const data = await exifr.parse(req.file.buffer, { gps: true });
        if (data && data.latitude && data.longitude) { lat = data.latitude; lon = data.longitude; }
      }
    } catch {}

    await supabase.from("artifacts").insert({ job_id: jobId, kind: req.file.mimetype.startsWith("video") ? "video" : "photo", url_or_text: pub.publicUrl, lat, lon });
    res.json({ ok:true, url: pub.publicUrl, lat, lon });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------- Organize media by location for a job ----------
app.get("/api/jobs/:id/artifacts-by-location", async (req, res) => {
  const { data: arts, error } = await supabase.from("artifacts").select("id,kind,url_or_text,lat,lon,created_at").eq("job_id", req.params.id);
  if (error) return res.status(500).json({ error: error.message });
  const groups = {}; // key: rounded lat,lon
  for (const a of (arts||[])) {
    const lat = (a.lat==null) ? null : Math.round(a.lat*1000)/1000; // ~110m
    const lon = (a.lon==null) ? null : Math.round(a.lon*1000)/1000;
    const key = (lat!=null && lon!=null) ? `${lat},${lon}` : "unknown";
    groups[key] = groups[key] || { key, lat, lon, items: [] };
    groups[key].items.push(a);
  }
  res.json(Object.values(groups));
});

// ---------- Speech-to-Text (audio/video) ----------
const audioUpload = multer({ storage: multer.memoryStorage() });
app.post("/api/media/transcribe", audioUpload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "file required" });
    // Whisper can handle common types including mp3/mp4/mpeg/wav/webm
    const form = new FormData();
    form.append("file", new Blob([req.file.buffer]), req.file.originalname || "audio.mp4");
    form.append("model", "whisper-1");
    const r = await fetch("https://api.openai.com/v1/audio/transcriptions", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: form
    });
    const data = await r.json();
    if (data.error) return res.status(500).json({ error: data.error?.message });
    res.json({ text: data.text || "" });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------- AI Image Description for claim captions ----------
app.post("/api/media/describe", async (req, res) => {
  try {
    const { image_url, context = "" } = req.body || {};
    if (!image_url) return res.status(400).json({ error: "image_url required" });
    const payload = {
      model: "gpt-5-thinking",
      messages: [{
        role: "user",
        content: [
          { type: "text", text: `Describe storm-related damage in this image for an insurance claim. Be objective, precise, and note hazards. Context: ${context}` },
          { type: "image_url", image_url: { url: image_url } }
        ]
      }],
      temperature: 0.2
    };
    const r = await axios.post("https://api.openai.com/v1/chat/completions", payload, {
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` }
    });
    res.json({ text: r.data.choices?.[0]?.message?.content || "" });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------- Claim packet export (PDF) ----------
async function buildPacketPDF(jobId){
  const { data: job } = await supabase.from("jobs").select("*").eq("id", jobId).single();
  const { data: artifacts } = await supabase.from("artifacts").select("*").eq("job_id", jobId).order("created_at", { ascending:true });
  const PDFKit = (await import("pdfkit")).default;
  const doc = new PDFKit({ margin: 36 });
  const tmp = path.join(__dirname, `packet-${jobId}.pdf`);
  const stream = fs.createWriteStream(tmp);
  doc.pipe(stream);

  doc.fontSize(18).text("Emergency Tree Service — Claim Packet", { align: "center" });
  doc.moveDown();
  doc.fontSize(12).text(`Customer: ${job.customer_name||""}`);
  doc.text(`Address: ${job.address||""} ${job.city||""}, ${job.state||""} ${job.zip||""}`);
  doc.text(`Claim #: ${job.claim_number||"—"}`);
  if (job.completion_date) doc.text(`Completion: ${job.completion_date}`);
  doc.moveDown().text("Timeline:", { underline: true });

  (artifacts||[]).forEach((a, i) => {
    const loc = (a.lat!=null && a.lon!=null) ? ` @ (${a.lat.toFixed(5)}, ${a.lon.toFixed(5)})` : "";
    doc.text(`${i+1}. [${dayjs(a.created_at).format("YYYY-MM-DD HH:mm")}] ${a.kind}${loc}: ${a.url_or_text?.slice(0, 120)}`);
  });

  doc.addPage().fontSize(14).text("Photos", { underline: true });
  for (const a of (artifacts||[])) {
    if (a.kind === "photo" && a.url_or_text) {
      try {
        const r = await axios.get(a.url_or_text, { responseType: "arraybuffer" });
        const img = Buffer.from(r.data);
        doc.addPage().fontSize(10).text(`${dayjs(a.created_at).format("YYYY-MM-DD HH:mm")}`);
        doc.image(img, { fit: [520, 700], align: "center" });
      } catch {}
    }
  }
  doc.end();
  await new Promise(r => stream.on("finish", r));
  return tmp;
}
app.get("/api/jobs/:id/export/packet.pdf", async (req, res) => {
  try {
    const pdfPath = await buildPacketPDF(req.params.id);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename=claim-packet-${req.params.id}.pdf`);
    fs.createReadStream(pdfPath).pipe(res).on("finish", () => fs.unlink(pdfPath, ()=>{}));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------- Pages ----------
app.get("/", (_, res) => res.sendFile(path.join(__dirname, "..", "public", "dashboard.html")));
app.get("/jobs", (_, res) => res.sendFile(path.join(__dirname, "..", "public", "jobs.html")));
app.get("/annotate", (_, res) => res.sendFile(path.join(__dirname, "..", "public", "annotate.html")));
app.get("/media", (_, res) => res.sendFile(path.join(__dirname, "..", "public", "media.html")));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Storm App v5 running on :"+PORT));
