async function fetchJobs(){ const r = await fetch('/api/jobs'); return r.json(); }
function jobCard(j){
  return `<div class="group">
    <div><b>${j.customer_name||'Unnamed'}</b> — ${j.address||''} ${j.city||''}, ${j.state||''}</div>
    <div class="row" style="margin-top:6px;">
      <a href="/annotate?job=${j.id}" style="background:#2b3b64;color:#fff;padding:6px 8px;border-radius:6px;">Annotate</a>
      <a href="/media?job=${j.id}" style="background:#2b3b64;color:#fff;padding:6px 8px;border-radius:6px;">Media</a>
      <button onclick="exportPacket('${j.id}')">Export Claim Packet (PDF)</button>
      <label style="margin-left:auto">Upload<input type="file" onchange="uploadFile('${j.id}', this.files[0])"></label>
    </div>
  </div>`;
}
async function exportPacket(id){ window.open('/api/jobs/'+id+'/export/packet.pdf','_blank'); }
async function uploadFile(id, file){
  const fd = new FormData(); fd.append('file', file);
  const r = await fetch('/api/jobs/'+id+'/upload', { method:'POST', body: fd });
  const data = await r.json(); if (data.ok) alert("Uploaded"); else alert(JSON.stringify(data));
}
async function createJob(){
  const body = {
    customer_name: document.getElementById('cname').value,
    phone: document.getElementById('cphone').value,
    email: document.getElementById('cemail').value,
    address: document.getElementById('caddr').value,
    city: document.getElementById('ccity').value,
    state: document.getElementById('cstate').value,
    zip: document.getElementById('czip').value,
    assigned_sub_id: document.getElementById('subid').value || null,
    status: 'estimate'
  };
  const r = await fetch('/api/jobs', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const data = await r.json(); if (data.id) render(); else alert(JSON.stringify(data));
}
document.getElementById('createJob').addEventListener('click', createJob);
async function render(){ const jobs = await fetchJobs(); document.getElementById('jobs').innerHTML = jobs.map(jobCard).join(""); }
render();
