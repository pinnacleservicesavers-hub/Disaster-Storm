const map = L.map('map').setView([32.46,-84.99], 6);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);

async function loadReports(){
  const r = await fetch('/api/reports?hours=48');
  const reps = await r.json();
  reps.forEach(rep => {
    L.marker([rep.lat, rep.lon]).addTo(map)
      .bindPopup(`<b>${rep.address || 'Unverified address'}</b><br/>${rep.notes || ''}<br/><i>${rep.source}</i>`);
  });
}
loadReports();

document.getElementById('reportBtn').addEventListener('click', ()=>{
  if (!navigator.geolocation) return alert("GPS not available");
  navigator.geolocation.getCurrentPosition(async pos => {
    const notes = prompt('Describe the damage (optional)') || '';
    const body = { lat: pos.coords.latitude, lon: pos.coords.longitude, notes };
    const r = await fetch('/api/report-damage', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
    const data = await r.json();
    if (data.ok) { alert('Report received.'); location.reload(); } else { alert(JSON.stringify(data)); }
  }, err => alert(err.message), { enableHighAccuracy:true });
});

async function openCheckout(){
  const job = prompt("Job ID");
  const name = prompt("Line item", "Emergency Tree Service");
  const amt = parseFloat(prompt("Amount (USD)", "1500")||"0");
  const email = prompt("Customer email (optional)");
  const r = await fetch('/api/pay/checkout-session', { method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ job_id: job, customer_email: email || undefined, line_items: [{ name, amount_cents: Math.round(amt*100), qty:1 }] })
  });
  const data = await r.json();
  if (data.url) window.open(data.url,'_blank'); else alert(JSON.stringify(data));
}
async function openSign(){
  const job = prompt("Job ID");
  const email = prompt("Customer email");
  const name = prompt("Customer name");
  const contractUrl = prompt("Contract PDF URL");
  const aobUrl = prompt("AOB PDF URL (optional)");
  const r = await fetch('/api/sign/send', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({
    job_id: job, customer_email: email, customer_name: name, contract_pdf_url: contractUrl, aob_pdf_url: aobUrl, subject: "Emergency Tree Service Agreement"
  })});
  const data = await r.json();
  alert(data.ok ? "Sent for signature" : JSON.stringify(data));
}
