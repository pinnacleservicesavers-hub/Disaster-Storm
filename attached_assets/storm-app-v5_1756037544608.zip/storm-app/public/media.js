async function load(){
  const job = new URLSearchParams(location.search).get('job') || document.getElementById('job').value;
  if (!job) return alert("Enter Job ID or pass ?job=<id>");
  const r = await fetch('/api/jobs/'+job+'/artifacts-by-location');
  const groups = await r.json();
  const el = document.getElementById('groups');
  el.innerHTML = groups.map(g => {
    const title = g.key === 'unknown' ? 'Unknown location' : `~ ${g.lat}, ${g.lon}`;
    const items = g.items.map(i => i.kind==='photo' ? `<img src="${i.url_or_text}" style="max-height:120px;border-radius:6px;margin:4px">` : `<a href="${i.url_or_text}" target="_blank">${i.kind}</a>`).join("");
    return `<div class="group"><div><b>${title}</b></div><div>${items}</div></div>`;
  }).join("");
}
