const canvas = new fabric.Canvas('c', { isDrawingMode:false });
let drawing = false;

async function loadImage(){
  const url = document.getElementById('imgUrl').value;
  if (!url) return alert("Enter Image URL");
  fabric.Image.fromURL(url, img => {
    const scale = Math.min(900/img.width, 600/img.height);
    img.scale(scale);
    canvas.clear();
    canvas.add(img);
    canvas.sendToBack(img);
    canvas.renderAll();
  }, { crossOrigin: 'anonymous' });
}

function addText(){
  const text = prompt("Text");
  if (!text) return;
  const t = new fabric.Textbox(text, { left:50, top:50, fill:'#ffd23f', fontSize:20, fontWeight:'bold' });
  canvas.add(t).setActiveObject(t);
}

function toggleDraw(){
  drawing = !drawing;
  canvas.isDrawingMode = drawing;
  canvas.freeDrawingBrush.width = 4;
  canvas.freeDrawingBrush.color = '#ff4757';
}

async function aiDescribe(){
  const url = document.getElementById('imgUrl').value;
  const ctx = prompt("Optional claim context (e.g., roof tree impact, live wires)");
  const r = await fetch('/api/media/describe', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ image_url:url, context:ctx||'' }) });
  const data = await r.json();
  if (data.text){
    const t = new fabric.Textbox(data.text, { left:30, top:30, width:840, fill:'#e6edf3', fontSize:16, backgroundColor:'rgba(0,0,0,0.4)' });
    canvas.add(t).setActiveObject(t);
  } else alert("No result");
}

// Speech to text note → adds as text box
let mediaRecorder, chunks=[];
async function recordNote(){
  const stream = await navigator.mediaDevices.getUserMedia({ audio:true });
  chunks = [];
  mediaRecorder = new MediaRecorder(stream);
  mediaRecorder.ondataavailable = e => chunks.push(e.data);
  mediaRecorder.onstop = async () => {
    const blob = new Blob(chunks, { type:'audio/webm' });
    const fd = new FormData(); fd.append('file', blob, 'note.webm');
    const r = await fetch('/api/media/transcribe', { method:'POST', body: fd });
    const data = await r.json();
    if (data.text){
      const t = new fabric.Textbox(data.text, { left:50, top:80, width:800, fill:'#e6edf3', fontSize:18, backgroundColor:'rgba(0,0,0,0.4)' });
      canvas.add(t).setActiveObject(t);
    } else alert("Transcription failed");
  };
  mediaRecorder.start();
  setTimeout(()=> mediaRecorder.stop(), 6000); // 6s note
  alert("Recording 6s voice note…");
}

async function save(){
  const jobId = new URLSearchParams(location.search).get('job') || document.getElementById('jobId').value;
  if (!jobId) return alert("Enter Job ID (or pass ?job=)");
  const dataUrl = canvas.toDataURL({ format:'png', quality: 0.92 });
  const blob = await (await fetch(dataUrl)).blob();
  const fd = new FormData(); fd.append('file', blob, 'annotated.png');
  const r = await fetch('/api/jobs/'+jobId+'/upload', { method:'POST', body: fd });
  const d = await r.json();
  if (d.ok) alert("Annotated image saved to job"); else alert(JSON.stringify(d));
}

window.loadImage = loadImage;
window.addText = addText;
window.toggleDraw = toggleDraw;
window.aiDescribe = aiDescribe;
window.recordNote = recordNote;
window.save = save;
