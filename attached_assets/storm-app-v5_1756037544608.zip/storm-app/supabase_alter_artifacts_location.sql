-- include prior schema then add location columns
alter table if exists artifacts add column if not exists lat double precision;
alter table if exists artifacts add column if not exists lon double precision;
