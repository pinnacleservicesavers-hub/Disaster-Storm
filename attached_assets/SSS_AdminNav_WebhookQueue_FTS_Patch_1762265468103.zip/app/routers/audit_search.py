from fastapi import APIRouter, Depends, Request, Query
from sqlalchemy.orm import Session

from app.core.db import SessionLocal
from app.core.security import role_required

router = APIRouter()

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

def _ensure_schema(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL, actor TEXT, role TEXT, action TEXT NOT NULL, detail TEXT, ip TEXT
    );""")
    conn.execute("""CREATE VIRTUAL TABLE IF NOT EXISTS audit_log_fts USING fts5(
        ts, actor, role, action, detail, ip, content='audit_log', content_rowid='id'
    );""")
    # triggers to keep FTS in sync
    conn.execute("""CREATE TRIGGER IF NOT EXISTS audit_log_ai AFTER INSERT ON audit_log BEGIN
        INSERT INTO audit_log_fts(rowid, ts, actor, role, action, detail, ip)
        VALUES (new.id, new.ts, new.actor, new.role, new.action, new.detail, new.ip);
    END;""")
    conn.execute("""CREATE TRIGGER IF NOT EXISTS audit_log_ad AFTER DELETE ON audit_log BEGIN
        INSERT INTO audit_log_fts(audit_log_fts, rowid, ts, actor, role, action, detail, ip)
        VALUES('delete', old.id, old.ts, old.actor, old.role, old.action, old.detail, old.ip);
    END;""")
    conn.execute("""CREATE TRIGGER IF NOT EXISTS audit_log_au AFTER UPDATE ON audit_log BEGIN
        INSERT INTO audit_log_fts(audit_log_fts, rowid, ts, actor, role, action, detail, ip)
        VALUES('delete', old.id, old.ts, old.actor, old.role, old.action, old.detail, old.ip);
        INSERT INTO audit_log_fts(rowid, ts, actor, role, action, detail, ip)
        VALUES (new.id, new.ts, new.actor, new.role, new.action, new.detail, new.ip);
    END;""")

@router.post("/audit/fts/rebuild")
def audit_fts_rebuild(db: Session = Depends(get_db), _: dict = Depends(role_required(["admin"]))):
    conn = db.connection()
    _ensure_schema(conn)
    conn.execute("DELETE FROM audit_log_fts")
    conn.execute("""INSERT INTO audit_log_fts(rowid, ts, actor, role, action, detail, ip)
                    SELECT id, ts, actor, role, action, detail, ip FROM audit_log""")
    return {"ok": True}

@router.get("/audit/search")
def audit_fts_search(q: str = Query(..., description="FTS5 query, e.g. detail:FNOL AND action:view_fnol_pdf"),
                     limit: int = Query(200, ge=1, le=5000),
                     db: Session = Depends(get_db),
                     _: dict = Depends(role_required(["admin"]))):
    conn = db.connection()
    _ensure_schema(conn)
    rows = conn.execute("""SELECT rowid, ts, actor, role, action, detail, ip
                           FROM audit_log_fts
                           WHERE audit_log_fts MATCH :q
                           ORDER BY rowid DESC
                           LIMIT :lim""", {"q": q, "lim": limit}).fetchall()
    items = [ {"id": r[0], "ts": r[1], "actor": r[2], "role": r[3], "action": r[4], "detail": r[5], "ip": r[6]}
              for r in rows ]
    return {"count": len(items), "items": items}
