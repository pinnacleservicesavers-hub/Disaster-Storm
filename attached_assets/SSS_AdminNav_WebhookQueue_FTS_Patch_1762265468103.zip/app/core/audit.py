import os
from typing import Optional
from datetime import datetime
from app.core.audit_queue import get_audit_queue
from app.core.db import SessionLocal  # assumes SessionLocal is your session factory

def log_audit(db_session, actor: Optional[str], role: Optional[str], action: str, detail: str = "", ip: Optional[str] = None):
    ts = datetime.utcnow().isoformat() + "Z"
    sql_create = """
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL,
        actor TEXT,
        role TEXT,
        action TEXT NOT NULL,
        detail TEXT,
        ip TEXT
    );
    """
    sql_insert = "INSERT INTO audit_log (ts, actor, role, action, detail, ip) VALUES (:ts, :actor, :role, :action, :detail, :ip)"
    conn = db_session.connection()
    conn.execute(sql_create)
    conn.execute(sql_insert, {"ts": ts, "actor": actor, "role": role, "action": action, "detail": (detail or "")[:1000], "ip": ip or ""})

    # Enqueue webhook (retries with backoff in background worker)
    q = get_audit_queue(SessionLocal)
    q.enqueue({"ts": ts, "actor": actor, "role": role, "action": action, "detail": detail or "", "ip": ip or ""})
