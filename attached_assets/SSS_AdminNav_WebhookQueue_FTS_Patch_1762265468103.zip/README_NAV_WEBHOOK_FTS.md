# SSS Patch — Admin Side Nav + Audit Webhook Retry Queue + Audit FTS Search

## What's included
- `web/admin/index.html` — adds a **Audit Viewer** link in the header.
- `app/core/audit_queue.py` — persistent webhook queue with **exponential backoff** and background worker.
- `app/core/audit.py` — now **enqueues webhooks** instead of best-effort POST.
- `app/routers/audit_search.py` — admin-only:
  - `POST /api/audit/fts/rebuild` to build/sync FTS index
  - `GET /api/audit/search?q=...` to run FTS5 searches over audits

## Env
- `AUDIT_WEBHOOK_URL` — where audit events are POSTed (optional). Retries until success.

## Wiring
In `app/main.py`:
```python
from app.routers import audit_search
app.include_router(audit_search.router, prefix="/api", tags=["audit-search"])
```
Ensure your app imports `SessionLocal` in `app/core/audit.py` (as in this patch).

## Notes
- Queue persists in SQLite table `audit_webhook_queue` and survives restarts.
- Backoff doubles per attempt, capped at 30 minutes.
- FTS5 requires SQLite compiled with fts5 (Replit and most Linux distros have it).
