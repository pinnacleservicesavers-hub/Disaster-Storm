import os, subprocess, time, sys

PARQUET = os.getenv("NOAA_PARQUET", "storm_events_filtered.parquet")

def ensure_dataset():
    if not os.path.exists(PARQUET):
        print("[startup] Parquet not found, running pipeline once...")
        subprocess.check_call([sys.executable, "noaa_stormevents_pipeline.py"])
    else:
        print("[startup] Parquet found:", PARQUET)

if __name__ == "__main__":
    ensure_dataset()
    # Launch API
    subprocess.check_call([sys.executable, "-m", "uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"])
