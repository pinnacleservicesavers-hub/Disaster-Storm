import os
import json
import subprocess
import requests
import pandas as pd
import numpy as np
from fastapi import FastAPI, Query, HTTPException, Header, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from typing import List, Optional, Literal, Dict, Any, Tuple

# ---------- CONFIG ----------
PARQUET_PATH = os.getenv("NOAA_PARQUET", "storm_events_filtered.parquet")
COUNTY_SUMMARY_CSV = os.getenv("NOAA_COUNTY_SUMMARY", "storm_events_county_summary.csv")
EVENT_SUMMARY_CSV = os.getenv("NOAA_EVENT_SUMMARY", "storm_events_event_summary.csv")

DEFAULT_LIMIT = 100
MAX_LIMIT = 1000

ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")

API_KEY = os.getenv("API_KEY", "")

def _check_api_key(x_api_key: str | None):
    if not API_KEY:
        return  # open if not configured
    if x_api_key != API_KEY:
        raise HTTPException(401, detail="Invalid or missing API key. Set header X-API-Key.")


MATRIX_PROVIDER = os.getenv("MATRIX_PROVIDER", "").lower().strip()  # "google" | "mapbox" | ""
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "")
MAPBOX_TOKEN = os.getenv("MAPBOX_TOKEN", "")

GOOGLE_DM_URL = "https://maps.googleapis.com/maps/api/distancematrix/json"
MAPBOX_DM_URL = "https://api.mapbox.com/directions-matrix/v1/mapbox/driving"

GOOGLE_MAX_DEST = 25
MAPBOX_MAX_COORDS = 25  # includes origin

# ---------- APP ----------
app = FastAPI(title="StormEvents API", version="1.2")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static landing page
app.mount("/", StaticFiles(directory="static", html=True), name="static")

# ---------- DATA LOADING / CACHE ----------
_df_cache = {"events": None, "mtime": None}

def _load_events() -> pd.DataFrame:
    if not os.path.exists(PARQUET_PATH):
        raise FileNotFoundError(f"Data file not found: {PARQUET_PATH}")
    mtime = os.path.getmtime(PARQUET_PATH)
    if _df_cache["events"] is None or _df_cache["mtime"] != mtime:
        df = pd.read_parquet(PARQUET_PATH)
        if "STATE" in df.columns:
            df["STATE"] = df["STATE"].astype(str).str.upper()
        if "CZ_NAME" in df.columns:
            df["CZ_NAME"] = df["CZ_NAME"].astype(str).str.title()
        if "BEGIN_TS" in df.columns and not np.issubdtype(df["BEGIN_TS"].dtype, np.datetime64):
            df["BEGIN_TS"] = pd.to_datetime(df["BEGIN_TS"], errors="coerce")
        if "EVENT_PRIORITY" not in df.columns and "EVENT_TYPE" in df.columns:
            def priority_label(s: str) -> int:
                s = (s or "").upper()
                if s in ("TORNADO", "HURRICANE (TYPHOON)"):
                    return 1
                if s == "TROPICAL STORM":
                    return 2
                return 3
            df["EVENT_PRIORITY"] = df["EVENT_TYPE"].map(priority_label)
        _df_cache["events"] = df
        _df_cache["mtime"] = mtime
    return _df_cache["events"]

def _force_reload():
    _df_cache["events"] = None
    _df_cache["mtime"] = None
    _load_events()

# ---------- GEO ----------
def _haversine_miles(lat1, lon1, lat2, lon2):
    import numpy as _np
    R = 3958.7613
    lat1, lon1, lat2, lon2 = map(_np.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = _np.sin(dlat/2.0)**2 + _np.cos(lat1)*_np.cos(lat2)*_np.sin(dlon/2.0)**2
    c = 2 * _np.arcsin(_np.sqrt(a))
    return R * c

def _pick_latlon_cols(df: pd.DataFrame) -> Tuple[Optional[str], Optional[str]]:
    for a, b in (("BEGIN_LAT", "BEGIN_LON"), ("LAT", "LON"), ("BEGIN_LATITUDE","BEGIN_LONGITUDE")):
        if a in df.columns and b in df.columns:
            return a, b
    return None, None

# ---------- MATRIX ----------
def _google_dm_single(origin: Tuple[float, float], dests: List[Tuple[float, float]]) -> List[Optional[float]]:
    if not GOOGLE_API_KEY:
        return [None] * len(dests)
    if not dests:
        return []
    origins = f"{origin[0]},{origin[1]}"
    destinations = "|".join(f"{lat},{lon}" for lat, lon in dests)
    params = {
        "origins": origins,
        "destinations": destinations,
        "units": "imperial",
        "key": GOOGLE_API_KEY
    }
    r = requests.get(GOOGLE_DM_URL, params=params, timeout=30)
    r.raise_for_status()
    data = r.json()
    out = []
    try:
        elements = data["rows"][0]["elements"]
        for e in elements:
            if e.get("status") == "OK" and "distance" in e:
                meters = e["distance"]["value"]
                out.append(float(meters) / 1609.344)
            else:
                out.append(None)
    except Exception:
        out = [None]*len(dests)
    return out

def _mapbox_dm_single(origin: Tuple[float, float], dests: List[Tuple[float, float]]) -> List[Optional[float]]:
    if not MAPBOX_TOKEN:
        return [None] * len(dests)
    if not dests:
        return []
    coords = [f"{origin[1]},{origin[0]}"] + [f"{lon},{lat}" for lat, lon in dests]
    url = f"{MAPBOX_DM_URL}/" + ";".join(coords)
    params = {"annotations": "distance", "access_token": MAPBOX_TOKEN}
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    data = r.json()
    out = []
    try:
        distances = data.get("distances", [])
        row0 = distances[0] if distances and len(distances) > 0 else []
        for d in row0[1:]:
            if d is None:
                out.append(None)
            else:
                out.append(float(d) / 1609.344)
    except Exception:
        out = [None]*len(dests)
    return out

def _matrix_distances(origin: Tuple[float, float], dests: List[Tuple[float, float]]) -> List[Optional[float]]:
    if not dests:
        return []
    if MATRIX_PROVIDER not in ("google","mapbox"):
        return [_haversine_miles(origin[0], origin[1], lat, lon) for (lat, lon) in dests]

    dists = [None] * len(dests)
    if MATRIX_PROVIDER == "google":
        if not GOOGLE_API_KEY:
            return [_haversine_miles(origin[0], origin[1], lat, lon) for (lat, lon) in dests]
        for i in range(0, len(dests), 25):
            chunk = dests[i:i+25]
            try:
                out = _google_dm_single(origin, chunk)
            except Exception:
                out = [None]*len(chunk)
            for j, val in enumerate(out):
                if val is None:
                    lat, lon = chunk[j]
                    out[j] = _haversine_miles(origin[0], origin[1], lat, lon)
            dists[i:i+25] = out

    elif MATRIX_PROVIDER == "mapbox":
        if not MAPBOX_TOKEN:
            return [_haversine_miles(origin[0], origin[1], lat, lon) for (lat, lon) in dests]
        max_dests = 24
        for i in range(0, len(dests), max_dests):
            chunk = dests[i:i+max_dests]
            try:
                out = _mapbox_dm_single(origin, chunk)
            except Exception:
                out = [None]*len(chunk)
            for j, val in enumerate(out):
                if val is None:
                    lat, lon = chunk[j]
                    out[j] = _haversine_miles(origin[0], origin[1], lat, lon)
            dists[i:i+max_dests] = out
    return dists

# ---------- HELPERS ----------
def _rank_events(df: pd.DataFrame) -> pd.DataFrame:
    by = []; asc = []
    if "EVENT_PRIORITY" in df.columns:
        by.append("EVENT_PRIORITY"); asc.append(True)
    if "DIST_MILES" in df.columns:
        by.append("DIST_MILES"); asc.append(True)
    if "BEGIN_TS" in df.columns:
        by.append("BEGIN_TS"); asc.append(False)
    if not by: return df
    return df.sort_values(by=by, ascending=asc)

def _pick_latlon_cols(df: pd.DataFrame) -> Tuple[Optional[str], Optional[str]]:
    for a, b in (("BEGIN_LAT", "BEGIN_LON"), ("LAT", "LON"), ("BEGIN_LATITUDE","BEGIN_LONGITUDE")):
        if a in df.columns and b in df.columns:
            return a, b
    return None, None

# ---------- ROUTES ----------
@app.get("/health")
def health():
    return {
        "ok": True,
        "parquet": PARQUET_PATH,
        "loaded": os.path.exists(PARQUET_PATH),
        "matrix_provider": MATRIX_PROVIDER if MATRIX_PROVIDER else "local-haversine"
    }

@app.get("/api/events")
def get_events(
    x_api_key: str | None = Header(default=None),
    state: Optional[str] = Query(None),
    county: Optional[str] = Query(None),
    event_types: Optional[List[str]] = Query(None),
    start: Optional[str] = Query(None),
    end: Optional[str] = Query(None),
    near_lat: Optional[float] = Query(None),
    near_lon: Optional[float] = Query(None),
    max_miles: Optional[float] = Query(None),
    sort: Optional[Literal["priority","time","distance"]] = Query("priority"),
    ascending: bool = Query(False),
    limit: int = Query(DEFAULT_LIMIT, ge=1, le=MAX_LIMIT),
    offset: int = Query(0, ge=0),
):
    _check_api_key(x_api_key)
    df = _load_events()
    q = df

    if state:
        q = q[q["STATE"] == state.upper()]

    if county:
        needle = county.strip().lower()
        q = q[q["CZ_NAME"].str.lower().str.contains(needle, na=False)]

    if event_types:
        upper_types = [e.upper() for e in event_types]
        q = q[q["EVENT_TYPE"].str.upper().isin(upper_types)]

    if start:
        try:
            start_ts = pd.to_datetime(start)
            q = q[q["BEGIN_TS"] >= start_ts]
        except Exception:
            raise HTTPException(400, detail="Invalid 'start' date format")

    if end:
        try:
            end_ts = pd.to_datetime(end)
            q = q[q["BEGIN_TS"] <= end_ts]
        except Exception:
            raise HTTPException(400, detail="Invalid 'end' date format")

    if near_lat is not None and near_lon is not None:
        lat_col, lon_col = _pick_latlon_cols(q)
        q = q.copy()
        if lat_col:
            dests = list(zip(q[lat_col].astype(float), q[lon_col].astype(float)))
            q["DIST_MILES"] = _matrix_distances((near_lat, near_lon), dests)
            if max_miles is not None:
                q = q[(q["DIST_MILES"].notna()) & (q["DIST_MILES"] <= max_miles)]
        else:
            q["DIST_MILES"] = np.nan

    if sort == "priority":
        by = ["EVENT_PRIORITY", "BEGIN_TS"]
    elif sort == "time":
        by = ["BEGIN_TS"]
    else:
        if "DIST_MILES" not in q.columns:
            raise HTTPException(400, detail="Distance sort requires near_lat and near_lon")
        by = ["DIST_MILES", "EVENT_PRIORITY", "BEGIN_TS"]

    q = q.sort_values(by=by, ascending=ascending).reset_index(drop=True)

    total = int(q.shape[0])
    q = q.iloc[offset: offset + limit]

    cols = [c for c in [
        "EVENT_ID","EPISODE_ID","STATE","CZ_NAME","EVENT_TYPE",
        "BEGIN_TS","END_TS","EVENT_PRIORITY",
        "WFO","SOURCE","MAGNITUDE","TOR_F_SCALE",
        "FATALITIES_TOTAL","FATALITIES_DIRECT","FATALITIES_INDIRECT",
        "DIST_MILES",
        "BEGIN_LAT","BEGIN_LON","LAT","LON",
        "BEGIN_DATE_TIME","END_DATE_TIME","BEGIN_DATE","BEGIN_TIME","END_DATE","END_TIME",
        "INJURIES_DIRECT","INJURIES_INDIRECT","DAMAGE_PROPERTY","DAMAGE_CROPS","CZ_TYPE"
    ] if c in q.columns]

    records = q[cols].to_dict(orient="records")

    return {
        "count": len(records),
        "total": total,
        "offset": offset,
        "limit": limit,
        "sort": sort,
        "ascending": ascending,
        "items": records,
    }

@app.get("/api/summary/county")
def county_summary(
    x_api_key: str | None = Header(default=None),
    state: Optional[str] = Query(None),
    year: Optional[int] = Query(None, ge=1950, le=2100),
    event_types: Optional[List[str]] = Query(None),
    top: int = Query(50, ge=1, le=500),
):
    _check_api_key(x_api_key)
    if not os.path.exists(COUNTY_SUMMARY_CSV):
        raise HTTPException(404, detail="County summary CSV not found. Run the pipeline first.")
    df = pd.read_csv(COUNTY_SUMMARY_CSV)
    df["STATE"] = df["STATE"].astype(str).str.upper()
    df["CZ_NAME"] = df["CZ_NAME"].astype(str).str.title()
    if state:
        df = df[df["STATE"] == state.upper()]
    if year:
        df = df[df["YEAR"] == year]
    if event_types:
        df = df[df["EVENT_TYPE"].str.upper().isin([e.upper() for e in event_types])]
    df = df.sort_values(["YEAR","EVENTS"], ascending=[True, False]).head(top)
    return {"items": df.to_dict(orient="records")}

@app.get("/api/summary/events")
def event_summary(
    x_api_key: str | None = Header(default=None),
    start_year: Optional[int] = Query(None, ge=1950, le=2100),
    end_year: Optional[int] = Query(None, ge=1950, le=2100),
):
    _check_api_key(x_api_key)
    if not os.path.exists(EVENT_SUMMARY_CSV):
        raise HTTPException(404, detail="Event summary CSV not found. Run the pipeline first.")
    df = pd.read_csv(EVENT_SUMMARY_CSV)
    if start_year:
        df = df[df["YEAR"] >= start_year]
    if end_year:
        df = df[df["YEAR"] <= end_year]
    df = df.sort_values(["YEAR","EVENT_TYPE"])
    return {"items": df.to_dict(orient="records")}

@app.post("/admin/update")
def admin_update(x_admin_token: str = Header(default="")):
    if not ADMIN_TOKEN:
        raise HTTPException(500, detail="ADMIN_TOKEN not configured on server.")
    if x_admin_token != ADMIN_TOKEN:
        raise HTTPException(401, detail="Unauthorized")
    if not os.path.exists("noaa_stormevents_pipeline.py"):
        raise HTTPException(500, detail="noaa_stormevents_pipeline.py not found next to app.py")
    try:
        proc = subprocess.run(
            ["python", "noaa_stormevents_pipeline.py"],
            capture_output=True, text=True, check=True, timeout=3600
        )
        _force_reload()
        return {"ok": True, "stdout": proc.stdout[-4000:], "stderr": proc.stderr[-2000:]}
    except subprocess.CalledProcessError as e:
        raise HTTPException(500, detail={"msg":"pipeline failed", "stderr": e.stderr[-4000:]})
    except subprocess.TimeoutExpired:
        raise HTTPException(500, detail="pipeline timed out")

@app.post("/admin/reindex")
def admin_reindex(x_admin_token: str = Header(default="")):
    if not ADMIN_TOKEN:
        raise HTTPException(500, detail="ADMIN_TOKEN not configured on server.")
    if x_admin_token != ADMIN_TOKEN:
        raise HTTPException(401, detail="Unauthorized")
    if not os.path.exists(PARQUET_PATH):
        raise HTTPException(404, detail="Parquet not found; run the pipeline first.")
    _force_reload()
    return {"ok": True, "reloaded": True, "parquet": PARQUET_PATH}

@app.get("/api/next-job")
def next_job(
    x_api_key: str | None = Header(default=None),
    near_lat: float = Query(...),
    near_lon: float = Query(...),
    state: Optional[str] = Query(None),
    max_miles: Optional[float] = Query(None),
    event_types: Optional[List[str]] = Query(None),
    not_before: Optional[str] = Query(None),
):
    _check_api_key(x_api_key)
    df = _load_events()
    q = df
    if not event_types:
        event_types = ["TORNADO", "HURRICANE (TYPHOON)", "TROPICAL STORM"]
    upper_types = [e.upper() for e in event_types]
    q = q[q["EVENT_TYPE"].str.upper().isin(upper_types)]
    if state:
        q = q[q["STATE"] == state.upper()]
    if not_before:
        try:
            ts = pd.to_datetime(not_before)
            q = q[q["BEGIN_TS"] >= ts]
        except Exception:
            raise HTTPException(400, detail="Invalid 'not_before' date")
    lat_col, lon_col = _pick_latlon_cols(q)
    if not lat_col:
        raise HTTPException(400, detail="No lat/lon columns available in dataset")
    q = q.copy()
    dests = list(zip(q[lat_col].astype(float), q[lon_col].astype(float)))
    q["DIST_MILES"] = _matrix_distances((near_lat, near_lon), dests)
    if max_miles is not None:
        q = q[(q["DIST_MILES"].notna()) & (q["DIST_MILES"] <= max_miles)]
    if q.empty:
        return {"item": None, "reason": "no matching jobs"}
    q = q.sort_values(["EVENT_PRIORITY", "DIST_MILES", "BEGIN_TS"], ascending=[True, True, False])
    row = q.iloc[0]
    return {"item": row.to_dict()}

@app.get("/api/next-batch")
def next_batch(
    x_api_key: str | None = Header(default=None),
    near_lat: float = Query(...),
    near_lon: float = Query(...),
    state: Optional[str] = Query(None),
    max_miles: Optional[float] = Query(None),
    event_types: Optional[List[str]] = Query(None),
    not_before: Optional[str] = Query(None),
    limit: int = Query(25, ge=1, le=200),
):
    _check_api_key(x_api_key)
    df = _load_events()
    q = df
    if not event_types:
        event_types = ["TORNADO", "HURRICANE (TYPHOON)", "TROPICAL STORM"]
    upper_types = [e.upper() for e in event_types]
    q = q[q["EVENT_TYPE"].str.upper().isin(upper_types)]
    if state:
        q = q[q["STATE"] == state.upper()]
    if not_before:
        try:
            ts = pd.to_datetime(not_before)
            q = q[q["BEGIN_TS"] >= ts]
        except Exception:
            raise HTTPException(400, detail="Invalid 'not_before' date")
    lat_col, lon_col = _pick_latlon_cols(q)
    if not lat_col:
        raise HTTPException(400, detail="No lat/lon columns available in dataset")
    q = q.copy()
    dests_all = list(zip(q[lat_col].astype(float), q[lon_col].astype(float)))
    q["DIST_MILES"] = _matrix_distances((near_lat, near_lon), dests_all)
    if max_miles is not None:
        q = q[(q["DIST_MILES"].notna()) & (q["DIST_MILES"] <= max_miles)]
    if q.empty:
        return {"items": []}
    q = q.sort_values(["EVENT_PRIORITY", "DIST_MILES", "BEGIN_TS"], ascending=[True, True, False])
    cols = [c for c in [
        "EVENT_ID","EPISODE_ID","STATE","CZ_NAME","EVENT_TYPE",
        "BEGIN_TS","END_TS","EVENT_PRIORITY","DIST_MILES",
        "WFO","SOURCE","MAGNITUDE","TOR_F_SCALE","INJURIES_DIRECT","INJURIES_INDIRECT",
        "FATALITIES_TOTAL","FATALITIES_DIRECT","FATALITIES_INDIRECT",
        "BEGIN_LAT","BEGIN_LON","LAT","LON"
    ] if c in q.columns]
    items = q[cols].head(limit).to_dict(orient="records")
    return {"count": len(items), "items": items, "provider": MATRIX_PROVIDER if MATRIX_PROVIDER else "local-haversine"}
