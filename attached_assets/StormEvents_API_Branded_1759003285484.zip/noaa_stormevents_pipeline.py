import os
import re
import time
import requests
import pandas as pd
from bs4 import BeautifulSoup

# ---------- CONFIG ----------
INDEX_URL = "https://www.ncei.noaa.gov/pub/data/swdi/stormevents/csvfiles/"
YEAR_MIN, YEAR_MAX = 1950, 2025
DATE_MIN = pd.Timestamp("1950-01-01")
DATE_MAX = pd.Timestamp("2025-09-26")
TARGET_EVENT_TYPES = {"TORNADO", "HURRICANE (TYPHOON)", "TROPICAL STORM"}
OUT_PARQUET = os.getenv("NOAA_PARQUET", "storm_events_filtered.parquet")
OUT_COUNTY_SUMMARY = os.getenv("NOAA_COUNTY_SUMMARY", "storm_events_county_summary.csv")
OUT_EVENT_SUMMARY = os.getenv("NOAA_EVENT_SUMMARY", "storm_events_event_summary.csv")
TIMEOUT = 60
RETRY = 4
BACKOFF = 2.0

def http_get(url: str, timeout: int = TIMEOUT, retry: int = RETRY) -> requests.Response:
    delay = 1.0
    for attempt in range(1, retry + 1):
        try:
            r = requests.get(url, timeout=timeout)
            r.raise_for_status()
            return r
        except Exception:
            if attempt >= retry:
                raise
            time.sleep(delay)
            delay *= BACKOFF

def scrape_index() -> list[str]:
    resp = http_get(INDEX_URL)
    soup = BeautifulSoup(resp.text, "html.parser")
    hrefs = [a.get("href") for a in soup.find_all("a") if a.get("href")]
    return [h for h in hrefs if h.startswith("StormEvents_") and h.endswith(".csv.gz")]

def build_year_files(index_names: list[str]):
    DETAILS_RE = re.compile(r"^StormEvents_details-ftp_v1\.0_d(\d{4})_c\d{8}\.csv\.gz$")
    LOCATIONS_RE = re.compile(r"^StormEvents_locations-ftp_v1\.0_d(\d{4})_c\d{8}\.csv\.gz$")
    FATALITIES_RE = re.compile(r"^StormEvents_fatalities-ftp_v1\.0_d(\d{4})_c\d{8}\.csv\.gz$")
    years = {}
    def ensure(y):
        if y not in years:
            years[y] = {"details": None, "locations": None, "fatalities": None}
        return years[y]
    for name in index_names:
        m = DETAILS_RE.match(name)
        if m:
            y = int(m.group(1))
            if YEAR_MIN <= y <= YEAR_MAX:
                ensure(y)["details"] = INDEX_URL + name
            continue
        m = LOCATIONS_RE.match(name)
        if m:
            y = int(m.group(1))
            if YEAR_MIN <= y <= YEAR_MAX:
                ensure(y)["locations"] = INDEX_URL + name
            continue
        m = FATALITIES_RE.match(name)
        if m:
            y = int(m.group(1))
            if YEAR_MIN <= y <= YEAR_MAX:
                ensure(y)["fatalities"] = INDEX_URL + name
            continue
    return years

def read_noaa_csv(url: str) -> pd.DataFrame:
    return pd.read_csv(url, low_memory=False, compression="gzip")

def normalize_cols(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = [c.upper() for c in df.columns]
    return df

def parse_begin_end_time(df: pd.DataFrame) -> pd.DataFrame:
    def to_ts(d, t):
        s = (pd.Series(d).astype(str).str.strip().replace("nan", pd.NA))
        u = (pd.Series(t).astype(str).str.strip().replace("nan", pd.NA))
        out = pd.to_datetime(s + " " + u, errors="coerce")
        mask = out.isna()
        if mask.any():
            out.loc[mask] = pd.to_datetime(s[mask], errors="coerce")
        return out

    if "BEGIN_DATE_TIME" in df.columns:
        df["BEGIN_TS"] = pd.to_datetime(df["BEGIN_DATE_TIME"], errors="coerce")
    elif "BEGIN_DATE" in df.columns and "BEGIN_TIME" in df.columns:
        df["BEGIN_TS"] = to_ts(df["BEGIN_DATE"], df["BEGIN_TIME"])
    elif "BEGIN_DATE" in df.columns:
        df["BEGIN_TS"] = pd.to_datetime(df["BEGIN_DATE"], errors="coerce")
    else:
        df["BEGIN_TS"] = pd.NaT

    if "END_DATE_TIME" in df.columns:
        df["END_TS"] = pd.to_datetime(df["END_DATE_TIME"], errors="coerce")
    elif "END_DATE" in df.columns and "END_TIME" in df.columns:
        df["END_TS"] = to_ts(df["END_DATE"], df["END_TIME"])
    elif "END_DATE" in df.columns:
        df["END_TS"] = pd.to_datetime(df["END_DATE"], errors="coerce")
    else:
        df["END_TS"] = pd.NaT

    return df

def clean_details(df: pd.DataFrame) -> pd.DataFrame:
    df = normalize_cols(df)
    if "EVENT_TYPE" in df.columns:
        df["EVENT_TYPE"] = df["EVENT_TYPE"].astype(str).str.upper().str.strip()
    if "STATE" in df.columns:
        df["STATE"] = df["STATE"].astype(str).str.strip()
    if "CZ_NAME" in df.columns:
        df["CZ_NAME"] = df["CZ_NAME"].astype(str).str.title().str.strip()
    df = parse_begin_end_time(df)
    mask_type = df["EVENT_TYPE"].isin(TARGET_EVENT_TYPES) if "EVENT_TYPE" in df.columns else True
    mask_date = df["BEGIN_TS"].between(DATE_MIN, DATE_MAX, inclusive="both")
    df = df[mask_type & mask_date].copy()
    if "EVENT_ID" in df.columns:
        df["EVENT_ID"] = pd.to_numeric(df["EVENT_ID"], errors="coerce").astype("Int64")
    return df

def clean_locations(df: pd.DataFrame) -> pd.DataFrame:
    df = normalize_cols(df)
    if "EVENT_ID" in df.columns:
        df["EVENT_ID"] = pd.to_numeric(df["EVENT_ID"], errors="coerce").astype("Int64")
    for col in ("STATE", "CZ_NAME"):
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip()
    keep = [c for c in df.columns if c in {"EVENT_ID", "EPISODE_ID", "STATE", "CZ_NAME", "WFO", "LOCATION", "LAT", "LON"}]
    return df[keep].copy() if keep else df

def clean_fatalities(df: pd.DataFrame) -> pd.DataFrame:
    df = normalize_cols(df)
    if "EVENT_ID" in df.columns:
        df["EVENT_ID"] = pd.to_numeric(df["EVENT_ID"], errors="coerce").astype("Int64")
    for c in ("FATALITY_TYPE", "FATALITY_SEX"):
        if c in df.columns:
            df[c] = df[c].astype(str).str.upper().str.strip()
    keep = [c for c in df.columns if c in {"EVENT_ID", "FATALITY_ID", "FATALITY_TYPE", "FATALITY_AGE", "FATALITY_SEX", "FATALITY_DATE"}]
    out = df[keep].copy() if keep else df
    if "FATALITY_DATE" in out.columns:
        out["FATALITY_TS"] = pd.to_datetime(out["FATALITY_DATE"], errors="coerce")
    return out

def safe_merge(left: pd.DataFrame, right: pd.DataFrame, on: str) -> pd.DataFrame:
    if left.empty or right.empty:
        return left.copy()
    return left.merge(right, on=on, how="left", suffixes=("", "_LOC"))

def main():
    print("Scraping NOAA index …")
    names = scrape_index()
    years = build_year_files(names)

    combined_rows = []
    for y in sorted(years.keys()):
        fs = years[y]
        if not fs["details"]:
            continue

        print(f"Year {y} — downloading")
        ddf = read_noaa_csv(fs["details"])
        ddf = clean_details(ddf)
        if ddf.empty:
            print("  -> no matching events after filters")
            continue

        if fs["locations"]:
            ldf = read_noaa_csv(fs["locations"])
            ldf = clean_locations(ldf)
            ddf = safe_merge(ddf, ldf, on="EVENT_ID")

        if fs["fatalities"]:
            fdf = read_noaa_csv(fs["fatalities"])
            fdf = clean_fatalities(fdf)
            if not fdf.empty and "EVENT_ID" in fdf.columns:
                agg = fdf.groupby("EVENT_ID").agg(
                    FATALITIES_TOTAL=("FATALITY_ID", "count"),
                    FATALITIES_DIRECT=("FATALITY_TYPE", lambda s: int((s == "D").sum())),
                    FATALITIES_INDIRECT=("FATALITY_TYPE", lambda s: int((s == "I").sum())),
                ).reset_index()
                ddf = ddf.merge(agg, on="EVENT_ID", how="left")

        combined_rows.append(ddf)

    if not combined_rows:
        print("No data wrote; empty result set")
        return

    full = pd.concat(combined_rows, ignore_index=True)
    if "STATE" in full.columns:
        full["STATE"] = full["STATE"].astype(str).str.upper()
    if "CZ_NAME" in full.columns:
        full["CZ_NAME"] = full["CZ_NAME"].astype(str).str.title()

    print(f"Writing {OUT_PARQUET}")
    full.to_parquet(OUT_PARQUET, index=False)

    full["YEAR"] = full["BEGIN_TS"].dt.year
    def priority_label(s: str) -> int:
        s = (s or "").upper()
        if s in ("TORNADO", "HURRICANE (TYPHOON)"):
            return 1
        if s == "TROPICAL STORM":
            return 2
        return 3
    full["EVENT_PRIORITY"] = full["EVENT_TYPE"].map(priority_label)

    county_summary = (
        full.groupby(["STATE", "CZ_NAME", "YEAR", "EVENT_TYPE"], dropna=False)
        .agg(
            EVENTS=("EVENT_ID", "nunique"),
            DIRECT_FATALITIES=("FATALITIES_DIRECT", "sum"),
            INDIRECT_FATALITIES=("FATALITIES_INDIRECT", "sum"),
        ).reset_index()
        .sort_values(["YEAR","STATE","CZ_NAME","EVENT_TYPE"])
    )
    for c in ("DIRECT_FATALITIES", "INDIRECT_FATALITIES"):
        if c in county_summary.columns:
            county_summary[c] = county_summary[c].fillna(0).astype(int)
    print(f"Writing {OUT_COUNTY_SUMMARY}")
    county_summary.to_csv(OUT_COUNTY_SUMMARY, index=False)

    event_summary = (
        full.groupby(["YEAR", "EVENT_TYPE"], dropna=False)
        .agg(
            EVENTS=("EVENT_ID", "nunique"),
            DIRECT_FATALITIES=("FATALITIES_DIRECT", "sum"),
            INDIRECT_FATALITIES=("FATALITIES_INDIRECT", "sum"),
        ).reset_index()
        .sort_values(["YEAR","EVENT_TYPE"])
    )
    for c in ("DIRECT_FATALITIES", "INDIRECT_FATALITIES"):
        if c in event_summary.columns:
            event_summary[c] = event_summary[c].fillna(0).astype(int)
    print(f"Writing {OUT_EVENT_SUMMARY}")
    event_summary.to_csv(OUT_EVENT_SUMMARY, index=False)

    print("✅ Pipeline done")

if __name__ == "__main__":
    main()
