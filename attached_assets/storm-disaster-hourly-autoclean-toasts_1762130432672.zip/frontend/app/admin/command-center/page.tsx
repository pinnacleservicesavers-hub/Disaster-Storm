"use client";
import { ToastProvider, useToast } from './toast';
import { useEffect, useState } from 'react';
function formatRemaining(ms:number){
  if (isNaN(ms)) return '—';
  if (ms <= 0) return 'expired';
  const sec = Math.floor(ms/1000);
  const h = Math.floor(sec/3600);
  const m = Math.floor((sec%3600)/60);
  const s = sec%60;
  if (h>0) return `${h}h ${m}m ${s}s`;
  if (m>0) return `${m}m ${s}s`;
  return `${s}s`;
}

import { useEffect, useState } from 'react';

async function api(path:string, opts:any={}){ const res = await fetch(path, { headers:{'Content-Type':'application/json'}, ...opts}); try{ return await res.json(); }catch(e){ return {}; } }

export default function AdminCenter(){
  const push = (msg:string)=>{ try{ (window as any).__toaster?.(msg); }catch(e){} };
  const [now, setNow] = useState<number>(Date.now());
  const [shares, setShares] = useState<any[]>([]);
  const loadShares = async()=>{ const r = await api('/admin/export/shares'); setShares(r.shares||[]); };
  useEffect(()=>{ loadShares(); },[]);
  return (
    <ToastProvider>
    <main className='p-8 space-y-6 max-w-5xl mx-auto'>
      <h1 className='text-2xl font-bold'>Admin Command Center</h1>
      <section className='border rounded p-4 space-y-3'>
        <div className='flex items-center justify-between'>
          <h2 className='text-lg font-semibold'>Shares & Downloads</h2>
          <div className='flex items-center gap-2'>
            <button className='px-3 py-1 rounded border text-sm' onClick={async()=>{ const j = await api('/admin/export/shares/cleanup',{method:'POST'}); alert(`Removed ${j.removed||0} expired link(s)`); loadShares(); }}>Clean expired</button>
            <button className='px-3 py-1 rounded border text-sm' onClick={loadShares}>Refresh</button>
          </div>
        </div>
        <div className='border rounded divide-y'>
          {shares.length ? shares.map((s:any)=>(
            <div key={s.token} className='p-2 flex flex-col md:flex-row md:items-center md:justify-between gap-2'>
              <div className='text-sm'>
                <div className='font-mono text-xs break-all'>Token: {s.token}</div>
                <div>File: <span className='font-medium'>{s.filename}</span></div>
                <div className={s.expired ? 'text-red-600 text-sm' : 'text-gray-600 text-sm'}>Expires: {s.expires_at} {(new Date(s.expires_at).getTime()-now<=0 || s.expired) ? '(expired)' : `(in ${formatRemaining(new Date(s.expires_at).getTime()-now)})`} {s.expired ? '(expired)' : ''}</div>
              </div>
              <div className='flex items-center gap-2'>
                <button className='px-2 py-1 border rounded text-sm' onClick={()=>{ const url = `/admin/export/download/${s.token}`; navigator.clipboard?.writeText(window.location.origin + url); }}>Copy link</button>
                <a className={'px-2 py-1 border rounded text-sm ' + (s.expired?'opacity-50 pointer-events-none':'')} href={`/admin/export/download/${s.token}`} target='_blank'>Open</a>
                <button className='px-2 py-1 border rounded text-sm' onClick={async()=>{ await fetch(`/admin/export/shares/${s.token}`, { method:'DELETE' }); loadShares(); }}>Revoke</button>
              </div>
            </div>
          )) : <div className='p-2 text-sm text-gray-500'>No active shares</div>}
        </div>
      </section>
    </main>
    </ToastProvider>
  );
}
