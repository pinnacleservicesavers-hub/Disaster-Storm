# SLM Storm App v2 — Stripe + Dropbox Sign + Lien Rules

## New in this version
- **Stripe Checkout** endpoint to take card payments for a Job.
- **Dropbox Sign** endpoint to send Contract/AOB for e-sign (test mode supported).
- **State-specific lien rules** table + API to compute deadlines; rules are editable per state.

## Setup
- Add Secrets in Replit:
  - SUPABASE_URL, SUPABASE_KEY
  - TWILIO_SID, TWILIO_TOKEN, TWILIO_NUMBER
  - OPENAI_API_KEY
  - LOCATIONIQ_KEY
  - STRIPE_SECRET (and STRIPE_WEBHOOK_SECRET later)
  - DROPBOX_SIGN_KEY (and DROPBOX_SIGN_TEST=1 for sandbox)
  - PUBLIC_URL (your app's URL, used by Stripe redirect)

## Supabase SQL
Run `supabase_schema.sql` first, then `supabase_lien_rules.sql` to add the lien tables.

## Webhooks
- **Stripe**: point to `/webhooks/stripe` (configure raw body verification before production).
- **Dropbox Sign**: point to `/webhooks/dropbox-sign` (add event hash verification).

## Usage
- Map: shows recent damage reports (public and SPC LSR).
- **Report Damage** button: GPS + notes → creates a report.
- **Create Payment Link**: quick Stripe Checkout for a Job ID.
- POST `/api/sign/send` with job + customer info + URLs of your contract/AOB PDFs to request signatures.
- GET `/api/lien/deadline?state=GA&completion_date=2025-08-01` to compute a deadline from editable rules.
