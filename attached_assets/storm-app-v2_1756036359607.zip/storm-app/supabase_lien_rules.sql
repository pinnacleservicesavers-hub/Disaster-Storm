create table if not exists lien_rules (
  state text primary key, -- e.g., 'GA'
  days integer not null default 90, -- days after completion to file lien
  notes text,
  require_prelim boolean default false
);

-- seed a few defaults (edit as you go)
insert into lien_rules(state, days, notes, require_prelim) values
  ('GA', 90, 'Typical 90-day window after substantial completion. Confirm project type.', false)
on conflict (state) do nothing;
