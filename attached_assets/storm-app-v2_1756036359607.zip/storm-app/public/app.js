const map = L.map('map').setView([32.46,-84.99], 6);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);

async function loadReports(){
  const r = await fetch('/api/reports?hours=24');
  const reports = await r.json();
  reports.forEach(rep => {
    const m = L.marker([rep.lat, rep.lon]).addTo(map);
    m.bindPopup(`<b>${rep.address || 'Unverified address'}</b><br/>${rep.notes || ''}<br/><i>${rep.source}</i>`);
  });
}

async function reportDamage(){
  if (!navigator.geolocation) return alert("GPS not available");
  navigator.geolocation.getCurrentPosition(async pos => {
    const body = { lat: pos.coords.latitude, lon: pos.coords.longitude, notes: prompt('Describe damage (optional)') || '' };
    const r = await fetch('/api/report-damage', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
    const data = await r.json();
    if (data.ok){ alert('Report received.'); location.reload(); } else { alert('Error: '+(data.error||'unknown')); }
  }, err => alert(err.message), { enableHighAccuracy:true });
}

async function createPaymentLink(){
  const job = prompt("Enter Job ID for payment:");
  if (!job) return;
  const lineItem = prompt("Describe line item (e.g., Emergency Tree Removal)");
  const amount = prompt("Amount in dollars (e.g., 1500)");
  const email = prompt("Customer email (optional)");
  const body = {
    job_id: job,
    customer_email: email || undefined,
    line_items: [{ name: lineItem || 'Service', amount_cents: Math.round(parseFloat(amount||'0')*100), qty: 1 }]
  };
  const r = await fetch('/api/pay/checkout-session', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const data = await r.json();
  if (data.url) window.open(data.url, '_blank'); else alert(JSON.stringify(data));
}

document.getElementById('reportBtn').addEventListener('click', reportDamage);
document.getElementById('payBtn').addEventListener('click', createPaymentLink);
loadReports();
