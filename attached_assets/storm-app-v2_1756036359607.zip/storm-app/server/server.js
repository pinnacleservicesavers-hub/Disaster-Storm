import express from "express";
import cors from "cors";
import axios from "axios";
import { createClient } from "@supabase/supabase-js";
import Stripe from "stripe";
import * as Sign from "@dropbox/sign";
import rawBody from "raw-body";
import path from "path";
import { fileURLToPath } from "url";
import "./alertWorker.js"; // background jobs

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

// --- Stripe & Dropbox Sign setup ---
const stripe = new Stripe(process.env.STRIPE_SECRET || "", { apiVersion: "2023-10-16" });
const stripeWebhookSecret = process.env.STRIPE_WEBHOOK_SECRET || "";
const signClient = new Sign.SignatureRequestApi();
Sign.Configuration.username = process.env.DROPBOX_SIGN_KEY || ""; // api key

// Health
app.get("/health", (_, res) => res.json({ ok: true, time: new Date().toISOString() }));

// ------------------ Damage Reports ------------------
app.get("/api/reports", async (req, res) => {
  const hours = Number(req.query.hours || 24);
  const since = new Date(Date.now() - hours * 3600 * 1000).toISOString();
  const { data, error } = await supabase.from("damage_reports").select("*").gte("created_at", since).order("created_at", { ascending:false }).limit(500);
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post("/api/report-damage", async (req, res) => {
  try {
    const { lat, lon, notes = "", photo_urls = [] } = req.body;
    if (typeof lat !== "number" || typeof lon !== "number") return res.status(400).json({ error: "lat/lon required" });
    let address=null, city=null, state=null, zip=null;
    try {
      const r = await axios.get("https://us1.locationiq.com/v1/reverse", { params: { key: process.env.LOCATIONIQ_KEY, lat, lon, format: "json" }});
      const a = r.data?.address || {};
      address = r.data?.display_name || null; city=a.city||a.town||a.village||null; state=a.state||null; zip=a.postcode||null;
    } catch {}
    const { data, error } = await supabase.from("damage_reports").insert({ lat, lon, address, city, state, zip, notes, source:"public", photos: photo_urls }).select().single();
    if (error) return res.status(500).json({ error: error.message });
    res.json({ ok: true, report: data });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ------------------ Lien Rules (state-specific) ------------------
app.get("/api/lien/rules", async (req, res) => {
  const { data, error } = await supabase.from("lien_rules").select("*").order("state");
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post("/api/lien/rules", async (req, res) => {
  // upsert: {state:"GA", days:90, notes:"Most residential jobs ...", require_prelim:false}
  const body = req.body || {};
  if (!body.state || !body.days) return res.status(400).json({ error: "state and days required" });
  const { data, error } = await supabase.from("lien_rules").upsert(body).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// compute deadline from a job completion date + state rule
app.get("/api/lien/deadline", async (req, res) => {
  const { state, completion_date } = req.query;
  if (!state || !completion_date) return res.status(400).json({ error: "state and completion_date required" });
  const { data: rule } = await supabase.from("lien_rules").select("*").eq("state", state).maybeSingle();
  const days = rule?.days || 90;
  const base = new Date(completion_date);
  const deadline = new Date(base.getTime() + days*24*3600*1000);
  res.json({ state, completion_date, days, deadline: deadline.toISOString().slice(0,10), notes: rule?.notes || null });
});

// ------------------ Dropbox Sign: send contract/AOB ------------------
app.post("/api/sign/send", async (req, res) => {
  /* expects:
     {
       job_id, customer_name, customer_email,
       subject, message, contract_pdf_url, aob_pdf_url
     }
  */
  const { job_id, customer_name, customer_email, subject = "Contract", message = "Please review and sign.", contract_pdf_url, aob_pdf_url } = req.body;
  if (!job_id || !customer_email || !contract_pdf_url) return res.status(400).json({ error: "missing required fields" });

  try {
    const payload = new Sign.SignatureRequestSendRequest();
    payload.title = subject;
    payload.subject = subject;
    payload.message = message;
    payload.signers = [{ email_address: customer_email, name: customer_name || "Customer" }];
    payload.file_urls = aob_pdf_url ? [contract_pdf_url, aob_pdf_url] : [contract_pdf_url];
    payload.test_mode = process.env.DROPBOX_SIGN_TEST === "1"; // set 1 for sandbox
    const resp = await signClient.signatureRequestSend(payload);
    // store marker on job (you can save resp.signature_request.signature_request_id)
    await supabase.from("artifacts").insert({ job_id, kind:"doc", url_or_text:`DropboxSign:${resp.body.signature_request?.signature_request_id || "sent"}` });
    res.json({ ok:true, id: resp.body.signature_request?.signature_request_id });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Dropbox Sign webhook (mark signed)
app.post("/webhooks/dropbox-sign", express.raw({ type: "*/*" }), async (req, res) => {
  // NOTE: Add verification using event hash if desired.
  try {
    const event = JSON.parse(req.body.toString());
    const eventType = event?.event?.event_type;
    if (eventType === "signature_request_all_signed") {
      const srid = event?.signature_request?.signature_request_id;
      // Record a signed artifact; job id would be resolved if you stored mapping
      await supabase.from("artifacts").insert({ kind:"doc", url_or_text:`DropboxSign:SIGNED:${srid}` });
    }
    res.status(200).send("ok");
  } catch {
    res.status(200).send("ok");
  }
});

// ------------------ Stripe: checkout for a job ------------------
app.post("/api/pay/checkout-session", async (req, res) => {
  /* expects: { job_id, customer_email, line_items: [{name, amount_cents, qty}] } */
  const { job_id, customer_email, line_items = [] } = req.body;
  if (!stripe || !process.env.STRIPE_SECRET) return res.status(400).json({ error: "Stripe not configured" });
  const items = line_items.map(li => ({
    price_data: { currency:"usd", product_data:{ name: li.name }, unit_amount: li.amount_cents },
    quantity: li.qty || 1
  }));
  try {
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      customer_email: customer_email,
      line_items: items,
      success_url: (process.env.PUBLIC_URL || "http://localhost:3000") + "/paid.html?job=" + job_id,
      cancel_url: (process.env.PUBLIC_URL || "http://localhost:3000") + "/cancel.html?job=" + job_id,
      metadata: { job_id }
    });
    res.json({ id: session.id, url: session.url });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Stripe webhook
app.post("/webhooks/stripe", async (req, res) => {
  let event = req.body;
  const sig = req.headers["stripe-signature"];
  try {
    if (stripeWebhookSecret) {
      // Need raw body to verify; reconfigure route as raw in production
      res.status(400).send("Configure raw body for verification.");
      return;
    }
  } catch (e) {
    return res.status(400).send(`Webhook Error: ${e.message}`);
  }
  // Fallback (dev): trust payload
  if (event.type === "checkout.session.completed") {
    const job_id = event.data.object.metadata?.job_id;
    const total = event.data.object.amount_total;
    await supabase.from("invoices").insert({
      job_id, total: (total||0)/100, method:"card", paid:true
    });
    await supabase.from("artifacts").insert({ job_id, kind:"payment", url_or_text:`Stripe checkout ${event.data.object.id}` });
  }
  res.json({ received: true });
});

// ------------------ AI justifications ------------------
app.post("/api/ai/explain-overage", async (req, res) => {
  try {
    const { scope, lineItems = [], reasons = [] } = req.body;
    const prompt = `Write a firm, professional justification to an insurance adjuster explaining why an emergency tree service invoice exceeds Xactimate for this scope. Keep it factual and cite safety, access, crane setup/teardown, utility coordination, traffic control, night/weekend deployment, debris volume, downed lines, and hazard premiums when relevant.
Scope:\n${scope}\n
Line items:\n${JSON.stringify(lineItems, null, 2)}\n
Reasons: ${reasons.join(", ")}`;
    const resp = await axios.post("https://api.openai.com/v1/chat/completions", {
      model: "gpt-5-thinking",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.2
    }, { headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` } });
    res.json({ text: resp.data.choices?.[0]?.message?.content || "" });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// -------------- SPA Fallback --------------
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "..", "public", "index.html")));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`SLM server running on :${PORT}`));
