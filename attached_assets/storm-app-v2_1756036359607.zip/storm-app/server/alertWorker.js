import axios from "axios";
import cron from "node-cron";
import { createClient } from "@supabase/supabase-js";
import Twilio from "twilio";

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
const twilio = Twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);

const STATES = (process.env.COVERED_STATES || "GA,FL,AL,NC,SC,TN,TX,LA,MI,VA,MD,DE,NJ,NY,CT,RI,MA,NH,ME,PA,VT,OH,KY,WV,OK,KS,NE,SD,IN,MO,IL").split(",").map(s=>s.trim());

function stateList(){ return STATES.join(","); }

async function fetchActiveAlerts(){
  const url = "https://api.weather.gov/alerts/active";
  const params = { status:"actual", area: stateList(), event: "Tornado Warning,Severe Thunderstorm Warning,Hurricane Warning,Hurricane Watch,Tornado Watch" };
  const { data } = await axios.get(url, { params, headers: { "User-Agent": "SLM-StormApp (support@yourdomain.com)" }});
  return data.features || [];
}

async function upsertAlertAndNotify(feature){
  const id = feature.id;
  const p = feature.properties || {};
  const area = p.areaDesc || "";
  const event = p.event || "";
  const ends = p.ends || p.expires || null;
  await supabase.from("alerts").upsert({ id, type:event, state:null, county_fips:null, starts_at:p.onset || p.sent, ends_at:ends, geom:feature.geometry });
  const msg = `⚠️ ${event}\n${area}\nStart: ${p.onset || p.sent}\nEnd: ${ends || "TBD"}\n${p.headline || ""}`;

  const { data: subs } = await supabase.from("subcontractors").select("name,phone,states,sms_opt_in").eq("sms_opt_in", true);
  for (const s of (subs||[])){
    const has = (s.states||[]).some(st => STATES.includes(st));
    if (!has || !s.phone) continue;
    try { await twilio.messages.create({ to: s.phone, from: process.env.TWILIO_NUMBER, body: msg }); } catch(e){}
  }
}

async function fetchLSRToday(){
  const url = "https://www.spc.noaa.gov/climo/reports/today.csv";
  const { data } = await axios.get(url, { responseType:"text" });
  return data;
}

function parseLSR(csv){
  const rows = csv.split(/\r?\n/).filter(Boolean).slice(1);
  const out = [];
  for (const line of rows){
    const cols = line.split(",");
    if (cols.length < 10) continue;
    const type = cols[2]?.trim();
    if (!["TORNADO","TSTM WND DMG","HAIL","TSTM WND GST"].includes(type)) continue;
    const lat = parseFloat(cols[7]), lon = parseFloat(cols[8]);
    if (Number.isNaN(lat) || Number.isNaN(lon)) continue;
    out.push({ type, lat, lon, city: cols[4], county: cols[5], state: cols[6], remarks: cols.slice(9).join(",") });
  }
  return out;
}

async function ingestLSR(){
  try {
    const text = await fetchLSRToday();
    const items = parseLSR(text);
    for (const it of items){
      await supabase.from("damage_reports").upsert({ lat:it.lat, lon:it.lon, address:null, city:it.city, state:it.state, notes:`${it.type}: ${it.remarks}`, source:"lsr" }, { onConflict:"lat,lon,source" });
    }
  } catch(e){}
}

cron.schedule("*/2 * * * *", async () => {
  try { const feats = await fetchActiveAlerts(); for (const f of feats) await upsertAlertAndNotify(f); } catch(e){}
});

cron.schedule("*/15 * * * *", async () => { await ingestLSR(); });
