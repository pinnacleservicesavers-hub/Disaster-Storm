
from fastapi import APIRouter, Response
from ..utils.store import store
import io, zipfile, json, csv

router = APIRouter()

@router.get('/admin/contractors')
def list_contractors():
    items = []
    for uid, u in (store.users or {}).items():
        # Heuristic: user marked as contractor or has a profile with company name
        profile = (u or {}).get('profile', {})
        if (u or {}).get('role') == 'contractor' or profile.get('company_name'):
            items.append({ 'id': uid, 'company_name': profile.get('company_name') or u.get('name') or uid, 'email': profile.get('email') or u.get('email') })
    return { 'contractors': items }


@router.get("/admin/export/all.zip")
def export_all(scrub: bool = False):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        # SCRUB helper
        def _scrub_user(u):
            if not scrub: return u
            u = dict(u or {})
            for k in ['email','phone','phone_number']:
                if k in u: u[k] = '***'
            p = dict(u.get('profile') or {})
            for k in ['email','phone','phone_number','address']:
                if k in p: p[k] = '***'
            u['profile'] = p
            return u

        def _scrub_job(j):
            if not scrub: return j
            j = dict(j or {})
            for k in ['homeowner_email','insurer_email','phone','phone_number']:
                if k in j: j[k] = '***'
            # scrub reminder audit recipients
            ra = []
            for r in j.get('reminder_audit', []) or []:
                r = dict(r)
                if isinstance(r.get('to'), list): r['to'] = ['***' for _ in r['to']]
                elif r.get('to'): r['to'] = '***'
                ra.append(r)
            j['reminder_audit'] = ra
            return j

        # JSON dumps
        z.writestr("users.json", json.dumps({uid:_scrub_user(u) for uid,u in (store.users or {}).items()}, indent=2, default=str))
        z.writestr("jobs.json", json.dumps({jid:_scrub_job(j) for jid,j in (store.jobs or {}).items()}, indent=2, default=str))
        z.writestr("invoices.json", json.dumps(store.invoices, indent=2, default=str))
        z.writestr("settings.json", json.dumps(store.settings, indent=2, default=str))

        # CSV audit (org-wide)
        out = "id,when,job_id,to,subject,status\n"
        for job_id, job in store.jobs.items():
            for r in job.get("reminder_audit", []):
                to_raw = r.get('to', [])
                to_str = ';'.join(['***' for _ in to_raw]) if (scrub and isinstance(to_raw, list)) else ('***' if (scrub and to_raw) else (';'.join(to_raw) if isinstance(to_raw, list) else str(to_raw)))
                subj = (r.get("subject") or "").replace('"','""')
                out += f"{r.get('id')},{r.get('when')},{job_id},"{to_str}","{subj}",{r.get('status')}\n"
        z.writestr("reminder-audit-all.csv", out)

    buf.seek(0)
    return Response(content=buf.read(), media_type="application/zip",
                    headers={"Content-Disposition": "attachment; filename=storm-disaster-export-all.zip"})
