from fastapi import APIRouter, Request, Response
from ..utils.store import store

router = APIRouter()

@router.post("/twilio/inbound")
async def twilio_inbound(request: Request):
    form = await request.form()
    from_num = form.get("From", "")
    body = (form.get("Body") or "").strip().upper()
    # Handle STOP/HELP
    # In real system, map phone->user and set consent
    if body == "STOP":
        # crude: opt-out all users for demo
        for u in store.users.values(): u["consent_comm"] = False
        return Response(content="<Response><Message>You have been opted out.</Message></Response>", media_type="application/xml")
    if body == "HELP":
        return Response(content="<Response><Message>Storm Disaster Alerts: Reply STOP to opt out.</Message></Response>", media_type="application/xml")
    return Response(content="<Response></Response>", media_type="application/xml")
