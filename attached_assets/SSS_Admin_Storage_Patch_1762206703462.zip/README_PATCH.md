# SSS Patch Bundle — Admin + Storage + Inbound Attachments

## Drop-in files
- app/utils/storage.py
- app/routers/email_inbound_sendgrid.py
- app/routers/reports_admin.py
- web/admin/index.html
- requirements-append.txt

## Env
ADMIN_TOKEN=superlongrandomstring
# Choose one provider:
# S3
STORAGE_PROVIDER=s3
S3_BUCKET=your-bucket
S3_REGION=us-east-1
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
# GCS
# STORAGE_PROVIDER=gcs
# GCS_BUCKET=your-bucket
# GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
# Azure
# STORAGE_PROVIDER=azure
# AZURE_STORAGE_CONNECTION_STRING=...
# AZURE_CONTAINER=your-container

## Wire routers (app/main.py)
from app.routers import email_inbound_sendgrid, reports_admin
app.include_router(email_inbound_sendgrid.router, prefix="/api", tags=["email"])
app.include_router(reports_admin.router, prefix="/api", tags=["reports"])

## Append deps
Append `requirements-append.txt` to your requirements and install.
