import os, re, unicodedata
from datetime import datetime, timedelta
from typing import Optional, List

from app.core.config import settings

def _slugify(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip("-")
    value = re.sub(r"-{2,}", "-", value)
    return value or "file"

def normalized_key(prefix: str, filename: str) -> str:
    base, dot, ext = filename.rpartition(".")
    base = _slugify(base or filename)
    ext = _slugify(ext) if dot else ""
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%S")
    name = f"{base}-{ts}.{ext}" if ext else f"{base}-{ts}"
    prefix = prefix.strip("/")
    return f"{prefix}/{name}" if prefix else name

def _s3_client():
    import boto3
    session = boto3.session.Session(
        aws_access_key_id=settings.aws_access_key_id,
        aws_secret_access_key=settings.aws_secret_access_key,
        region_name=settings.s3_region
    )
    return session.client("s3")

def _s3_put_and_url(data: bytes, key: str, content_type: str) -> str:
    s3 = _s3_client()
    s3.put_object(Bucket=settings.s3_bucket, Key=key, Body=data, ContentType=content_type)
    return _s3_sign(key, 7)

def _s3_sign(key: str, days:int=7) -> str:
    s3 = _s3_client()
    return s3.generate_presigned_url(
        ClientMethod="get_object",
        Params={"Bucket": settings.s3_bucket, "Key": key},
        ExpiresIn=days * 24 * 3600
    )

def _s3_list(prefix: str) -> List[dict]:
    s3 = _s3_client()
    resp = s3.list_objects_v2(Bucket=settings.s3_bucket, Prefix=prefix)
    return [{"key": c["Key"], "size": c["Size"], "last_modified": c["LastModified"].isoformat()} for c in resp.get("Contents", [])]

def _gcs_client():
    from google.cloud import storage
    return storage.Client()

def _gcs_put_and_url(data: bytes, key: str, content_type: str) -> str:
    client = _gcs_client(); bucket = client.bucket(settings.gcs_bucket); blob = bucket.blob(key)
    blob.upload_from_string(data, content_type=content_type)
    return _gcs_sign(key, 7)

def _gcs_sign(key: str, days:int=7) -> str:
    client = _gcs_client(); bucket = client.bucket(settings.gcs_bucket); blob = bucket.blob(key)
    return blob.generate_signed_url(expiration=timedelta(days=days), method="GET")

def _gcs_list(prefix: str) -> List[dict]:
    client = _gcs_client(); bucket = client.bucket(settings.gcs_bucket)
    items=[]
    for b in client.list_blobs(bucket, prefix=prefix):
        items.append({"key": b.name, "size": b.size, "last_modified": b.updated.isoformat() if b.updated else None})
    return items

def _az_client():
    from azure.storage.blob import BlobServiceClient
    conn = settings.azure_connection_string or os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    return BlobServiceClient.from_connection_string(conn)

def _az_put_and_url(data: bytes, key: str, content_type: str) -> str:
    from azure.storage.blob import ContentSettings
    svc = _az_client(); container = svc.get_container_client(settings.azure_container)
    container.upload_blob(name=key, data=data, overwrite=True, content_settings=ContentSettings(content_type=content_type))
    return _az_sign(key, 7)

def _az_sign(key: str, days:int=7) -> str:
    svc = _az_client()
    return f"{svc.url}/{settings.azure_container}/{key}"

def _az_list(prefix: str) -> List[dict]:
    svc = _az_client(); container = svc.get_container_client(settings.azure_container)
    return [{"key": b.name, "size": b.size, "last_modified": b.last_modified.isoformat() if b.last_modified else None}
            for b in container.list_blobs(name_starts_with=prefix)]

def store_bytes_and_get_url(data: bytes, key: str, content_type: str = "application/octet-stream") -> str:
    provider = (settings.storage_provider or "").lower()
    if provider == "s3":
        return _s3_put_and_url(data, key, content_type)
    if provider == "gcs":
        return _gcs_put_and_url(data, key, content_type)
    if provider == "azure":
        return _az_put_and_url(data, key, content_type)
    raise RuntimeError("Storage provider not configured")

def store_pdf_and_get_url(pdf_bytes: bytes, filename: str) -> str:
    key = normalized_key(f"fnol/{datetime.utcnow().strftime('%Y/%m/%d')}", filename)
    return store_bytes_and_get_url(pdf_bytes, key, content_type="application/pdf")

def sign_url_for_key(key: str, days:int=7) -> str:
    provider = (settings.storage_provider or "").lower()
    if provider == "s3":
        return _s3_sign(key, days)
    if provider == "gcs":
        return _gcs_sign(key, days)
    if provider == "azure":
        return _az_sign(key, days)
    raise RuntimeError("Storage provider not configured")

def list_prefix(prefix: str) -> list[dict]:
    provider = (settings.storage_provider or "").lower()
    if provider == "s3":
        return _s3_list(prefix)
    if provider == "gcs":
        return _gcs_list(prefix)
    if provider == "azure":
        return _az_list(prefix)
    return []
