from fastapi import APIRouter, Depends, Header, HTTPException, Query
from app.core.db import SessionLocal
from app.core.config import settings
from app.utils.storage import list_prefix, sign_url_for_key

router = APIRouter()

def admin_guard(authorization: str | None = Header(default=None, alias="Authorization")):
    if not settings.admin_token:
        raise HTTPException(status_code=403, detail="Admin token not configured")
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing Bearer token")
    token = authorization.split(" ", 1)[1].strip()
    if token != settings.admin_token:
        raise HTTPException(status_code=403, detail="Invalid admin token")
    return True

@router.get("/reports/fnol/list")
def list_fnol(_: bool = Depends(admin_guard)):
    return {"items": list_prefix("fnol/")}

@router.get("/reports/sign")
def sign_key(key: str = Query(..., description="Exact storage key"), _: bool = Depends(admin_guard)):
    return {"url": sign_url_for_key(key, days=7)}
