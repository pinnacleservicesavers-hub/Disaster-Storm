
# Storm Disaster — Next Upgrades

Backend:
```
pip install -r backend/requirements.txt
uvicorn backend.app.main:app --reload --port 8000
```

Frontend (example Next.js):
```
cd frontend
npm i
echo "NEXT_PUBLIC_API_BASE=http://localhost:8000" > .env.local
npm run dev
```

New endpoints:
- `GET /carriers/presets/{state}` and `/carriers/presets/{state}/{peril}`
- `POST /policy/summarize`
- `POST /evidence/tag`
- `GET /letters/demand/{claim_id}.pdf` and `/letters/lien/{claim_id}.pdf`

UI:
- `/contractor/claims/submit` has **Preset** by state+peril, **Auto‑tag Evidence**, and one-click **Demand/Lien** PDFs.
