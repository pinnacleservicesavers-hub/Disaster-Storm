
from fastapi import FastAPI
from .routers import carriers, policy, evidence, jobs, claims, letters

app = FastAPI()
app.include_router(carriers.router)
app.include_router(policy.router)
app.include_router(evidence.router)
app.include_router(jobs.router)
app.include_router(claims.router)
app.include_router(letters.router)
