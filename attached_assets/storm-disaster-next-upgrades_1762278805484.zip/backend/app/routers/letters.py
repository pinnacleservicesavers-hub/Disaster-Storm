
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
import io
from ..utils.store import store

router = APIRouter()

def _header(can, title):
    can.setFont("Helvetica-Bold", 14); can.drawString(1*inch, 10.5*inch, title)
    can.setFont("Helvetica", 10)

@router.get("/letters/demand/{claim_id}.pdf")
def demand_letter(claim_id: str, state: str="FL", amount: float=0.0, days_since_completion: int=60):
    claims = store.settings.get("claims", {})
    c = claims.get(claim_id)
    if not c: raise HTTPException(status_code=404, detail="Claim not found")
    p = c["payload"]; cust = p.get("customer",{}); pol = p.get("policy",{})
    buf = io.BytesIO(); can = canvas.Canvas(buf, pagesize=LETTER); _header(can, f"Demand for Payment — {claim_id}")
    y = 10*inch
    def line(t): 
        nonlocal y; can.drawString(1*inch, y, t[:110]); y -= 14
        if y<1*inch: can.showPage(); _header(can, f"Demand for Payment — {claim_id}"); y = 10*inch
    line(f"Insured: {cust.get('name')}  Policy#: {pol.get('policy_number','')}  Claim#: {pol.get('claim_number','')}  State: {state}")
    line(f"Property: {cust.get('address','')}")
    line(f"Outstanding amount due to contractor: ${amount:,.2f}")
    line(" ")
    line("This is a formal demand for payment for covered work performed to mitigate and repair storm damage.")
    line("Work was completed in accordance with industry standards and to prevent further damage (duty to mitigate).")
    line(f"As of {days_since_completion} days after completion, payment has not been received.")
    if p.get("aob_present"):
        line("Per the Assignment of Benefits executed by the insured, contractor is an assignee with rights to payment.")
    line("Please remit payment in full within 10 calendar days or provide written explanation citing specific policy provisions.")
    line("Failure to timely pay may result in remedies including interest, lien filing, and pursuit of statutory remedies as available under state law.")
    can.showPage(); can.save(); buf.seek(0)
    return StreamingResponse(buf, media_type="application/pdf", headers={"Content-Disposition": f"inline; filename=demand_{claim_id}.pdf"})

@router.get("/letters/lien/{claim_id}.pdf")
def lien_notice(claim_id: str, state: str="FL", amount: float=0.0):
    claims = store.settings.get("claims", {})
    c = claims.get(claim_id)
    if not c: raise HTTPException(status_code=404, detail="Claim not found")
    p = c["payload"]; cust = p.get("customer",{})
    buf = io.BytesIO(); can = canvas.Canvas(buf, pagesize=LETTER); _header(can, f"Notice of Intent to Lien — {claim_id}")
    y = 10*inch
    def line(t): 
        nonlocal y; can.drawString(1*inch, y, t[:110]); y -= 14
        if y<1*inch: can.showPage(); _header(can, f"Notice of Intent to Lien — {claim_id}"); y = 10*inch
    line(f"Owner: {cust.get('name')}  Address: {cust.get('address','')}  State: {state}")
    line(f"Amount claimed: ${amount:,.2f}")
    line("This is a Notice of Intent to File a Mechanic's Lien for non-payment for labor and materials.")
    line("Unless paid in full within 10 days, the contractor may record a lien as permitted by state statute.")
    line("This is not legal advice. Consult local counsel to confirm statutory form, timing, and service requirements.")
    can.showPage(); can.save(); buf.seek(0)
    return StreamingResponse(buf, media_type="application/pdf", headers={"Content-Disposition": f"inline; filename=lien_{claim_id}.pdf"})
