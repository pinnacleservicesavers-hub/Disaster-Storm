# SSS Patch — Audit FTS UI + Queue Monitor

## What’s included
- `web/admin/audits.html` — now has an **FTS search** box and rebuild button.
- `web/admin/queue.html` — **Queue Monitor** with list, retry now, retry all, and stats.
- `app/routers/audit_queue_admin.py` — admin-only endpoints to manage the queue:
  - `GET /api/audit/queue/list`
  - `GET /api/audit/queue/stats`
  - `POST /api/audit/queue/retry?id=<rowid>`
  - `POST /api/audit/queue/retry_all`

## Wire-up
In `app/main.py`:
```python
from app.routers import audit_queue_admin
app.include_router(audit_queue_admin.router, prefix="/api", tags=["audit-queue"])
```

Navigate to:
- `/web/admin/audits.html` for audit logs + FTS search
- `/web/admin/queue.html` for webhook queue monitoring
