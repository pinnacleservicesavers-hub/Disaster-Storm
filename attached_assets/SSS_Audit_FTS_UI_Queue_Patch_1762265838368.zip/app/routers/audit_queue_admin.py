from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from datetime import datetime
from app.core.db import SessionLocal
from app.core.security import role_required

router = APIRouter()

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

@router.get("/audit/queue/list")
def q_list(_: dict = Depends(role_required(["admin"])), db: Session = Depends(get_db)):
    conn = db.connection()
    conn.execute("""CREATE TABLE IF NOT EXISTS audit_webhook_queue (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        payload TEXT NOT NULL,
        next_attempt_ts TEXT NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0
    );""")
    rows = conn.execute("SELECT id, payload, next_attempt_ts, attempts FROM audit_webhook_queue ORDER BY id ASC").fetchall()
    items = [ {"id": r[0], "payload": r[1], "next_attempt_ts": r[2], "attempts": r[3]} for r in rows ]
    return {"count": len(items), "items": items}

@router.get("/audit/queue/stats")
def q_stats(_: dict = Depends(role_required(["admin"])), db: Session = Depends(get_db)):
    conn = db.connection()
    conn.execute("""CREATE TABLE IF NOT EXISTS audit_webhook_queue (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        payload TEXT NOT NULL,
        next_attempt_ts TEXT NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0
    );""")
    row = conn.execute("SELECT COUNT(1) FROM audit_webhook_queue").fetchone()
    return {"pending": int(row[0]) if row else 0, "worker_started": datetime.utcnow().isoformat() + "Z"}

@router.post("/audit/queue/retry")
def q_retry(id: int = Query(..., ge=1), _: dict = Depends(role_required(["admin"])), db: Session = Depends(get_db)):
    conn = db.connection()
    now = datetime.utcnow().isoformat() + "Z"
    conn.execute("UPDATE audit_webhook_queue SET next_attempt_ts=:ts WHERE id=:id", {"ts": now, "id": id})
    return {"ok": True, "id": id}

@router.post("/audit/queue/retry_all")
def q_retry_all(_: dict = Depends(role_required(["admin"])), db: Session = Depends(get_db)):
    conn = db.connection()
    now = datetime.utcnow().isoformat() + "Z"
    conn.execute("UPDATE audit_webhook_queue SET next_attempt_ts=:ts", {"ts": now})
    return {"ok": True}
