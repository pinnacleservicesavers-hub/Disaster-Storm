import pg from 'pg';
const { Pool } = pg;

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false }
});

export async function query(q, params = []) {
  const client = await pool.connect();
  try {
    const res = await client.query(q, params);
    return res.rows;
  } finally {
    client.release();
  }
}
