import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

/**
 * Classify damage and suggest service categories from free text.
 * Returns { priority, categories: string[], notes }
 */
export async function classifyLead({ description }) {
  // Simple fallback without calling the API (so it runs even before keys exist)
  if (!process.env.OPENAI_API_KEY) {
    return { priority: 'high', categories: ['tree','roofing'], notes: 'Fallback classification without OpenAI key.' };
  }
  const prompt = `A homeowner reported: """${description||''}""".
Identify disaster repair categories from this list only:
[tree, roofing, gutters, fence, pool, windows, siding, general_contractor, electrical, plumbing, water_mitigation, foundation, glass, debris_hauling].
Return JSON with: priority (emergency/high/medium/low), categories (array), notes (short).`;

  const rsp = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{role:"user", content: prompt}],
    temperature: 0
  });

  try {
    const text = rsp.choices[0].message.content;
    const json = JSON.parse(text.match(/{[\s\S]*}/)?.[0] || '{}');
    return json;
  } catch(e) {
    return { priority: 'high', categories: ['general_contractor'], notes: 'Parse error; defaulted.' };
  }
}
