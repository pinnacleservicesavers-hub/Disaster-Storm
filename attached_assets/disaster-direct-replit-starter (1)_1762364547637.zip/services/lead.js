import { query } from './db.js';
import { classifyLead } from './ai.js';
import { sendSMS, placeCall } from './twilio.js';
import { sendEmail } from './email.js';

const DEFAULT_CATEGORIES = ['tree','roofing','gutters','fence','pool','windows','siding','general_contractor','electrical','plumbing','water_mitigation','foundation','glass','debris_hauling'];

export async function createLead(payload) {
  const { name, phone, email, address, description } = payload;
  const rows = await query(
    `insert into leads (name, phone, email, address, status)
     values ($1,$2,$3,$4,'new') returning *`,
    [name, phone, email, address]
  );
  const lead = rows[0];
  lead.description = description;
  return lead;
}

export async function expandServices(lead) {
  // Use AI to decide categories; fall back to general+tree
  const cls = await classifyLead({ description: lead.description });
  const cats = Array.from(new Set(cls?.categories?.length ? cls.categories : ['tree','general_contractor']));
  const pr = cls?.priority || 'high';
  await query(`update leads set priority=$1 where id=$2`, [pr, lead.id]);

  const values = cats.map((c,i)=>`($1,$${i+2})`).join(',');
  await query(
    `insert into lead_services (lead_id, category) values ${values}`,
    [lead.id, ...cats]
  );
}

export async function routeLead(leadId) {
  // Precompute routing (Tier 1/Tier 2) – in real code, select contractors by trade + score.
  // Placeholder: nothing to do yet.
  return true;
}

export async function sendOutreach(leadId) {
  const rows = await query(`select * from leads where id=$1`, [leadId]);
  const lead = rows[0];
  if (!lead) return;

  const appIos = process.env.APP_DOWNLOAD_IOS || 'https://example.com/ios';
  const appAndroid = process.env.APP_DOWNLOAD_ANDROID || 'https://example.com/android';
  const site = process.env.PUBLIC_WEBSITE || 'https://example.com';

  const sms = `Hi ${lead.name||'there'}, this is the Disaster Direct Response Assistant.
We detected possible storm damage in your area. If you have homeowners insurance,
most repairs can be completed with little to no out-of-pocket cost.
Download the app: ${appIos} / ${appAndroid}
Or visit: ${site}
You can upload photos/videos and track your recovery. We’re here to help.`;

  if (lead.phone) await sendSMS({ to: lead.phone, body: sms });

  const twiml = `<Response>
    <Say voice="Polly.Matthew">Hello ${lead.name || 'there'}, this is the Disaster Direct Response Assistant.</Say>
    <Pause length="1"/>
    <Say>We detected possible storm damage in your area. If you have homeowners insurance, most repairs can be completed with little to no out of pocket cost.</Say>
    <Say>You can receive a text with a download link to our app and website after this call. We are here to help.</Say>
  </Response>`;
  if (lead.phone) await placeCall({ to: lead.phone, twiml });

  const emailHtml = `
    <p>Hi ${lead.name || 'there'},</p>
    <p>Disaster Direct connects you with verified local professionals for multi-trade recovery: tree removal, roofing, fencing, pool repair, windows, water mitigation, general contracting, and more.</p>
    <p>If you have homeowners insurance, most repairs can be completed with little to no out-of-pocket cost. Our contractors work on your behalf to reduce stress and coordinate the full restoration.</p>
    <p><strong>Download the app:</strong> <a href="${appIos}">iOS</a> | <a href="${appAndroid}">Android</a><br/>
    <strong>Website:</strong> <a href="${site}">${site}</a></p>
    <p>You can upload photos and videos, track progress, and message your team in one place.</p>
    <p>— Disaster Direct Response Team</p>
  `;
  if (lead.email) {
    await sendEmail({ to: lead.email, subject: "We’re here to help after the storm", html: emailHtml });
  }

  await query(`update leads set status='contacted' where id=$1`, [leadId]);
}
