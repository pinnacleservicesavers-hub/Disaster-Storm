import sgMail from '@sendgrid/mail';
sgMail.setApiKey(process.env.SENDGRID_API_KEY || '');

export async function sendEmail({to, subject, html}) {
  if (!process.env.SENDGRID_API_KEY) {
    console.log('[sendEmail] (dry run) ->', to, subject);
    return;
  }
  await sgMail.send({
    to,
    from: { email: 'no-reply@disaster-direct.com', name: 'Disaster Direct' },
    subject,
    html
  });
}
