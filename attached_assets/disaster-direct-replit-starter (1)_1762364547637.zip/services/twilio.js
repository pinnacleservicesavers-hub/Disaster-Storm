import twilio from 'twilio';

const client = twilio(process.env.TWILIO_ACCOUNT_SID || '', process.env.TWILIO_AUTH_TOKEN || '');

/**
 * Pick a local-from number by lead's area code. 
 * For production, preload a map in DB; for now, we accept a Messaging Service SID for SMS.
 */
export function pickLocalNumberFor(areaCode) {
  // Placeholder: implement lookup. Fallback to Messaging Service if configured.
  return { fromNumber: null, messagingServiceSid: process.env.TWILIO_MESSAGING_SERVICE_SID || null };
}

export async function sendSMS({ to, body }) {
  const areaCode = (to||'').replace(/\D/g,'').slice(-10, -7);
  const sel = pickLocalNumberFor(areaCode);
  if (!process.env.TWILIO_ACCOUNT_SID) {
    console.log('[sendSMS] (dry run) ->', to, body);
    return;
  }
  await client.messages.create({
    to,
    body,
    ...(sel.messagingServiceSid ? { messagingServiceSid: sel.messagingServiceSid } : { from: sel.fromNumber })
  });
}

export async function placeCall({ to, twiml }) {
  const areaCode = (to||'').replace(/\D/g,'').slice(-10, -7);
  const sel = pickLocalNumberFor(areaCode);
  if (!process.env.TWILIO_ACCOUNT_SID) {
    console.log('[placeCall] (dry run) ->', to);
    return;
  }
  await client.calls.create({
    to,
    ...(sel.fromNumber ? { from: sel.fromNumber } : { from: '+18005550199' }), // fallback
    twiml
  });
}
