# Disaster Direct – Replit Starter (AI Lead Management + Outreach)

This starter gives you an Express API, Postgres schema, and service modules for:
- Lead intake
- AI classification (OpenAI)
- Local-area-code SMS + calls (Twilio)
- Email outreach (SendGrid)
- Multi-service pipeline (tree, roofing, fence, pool, windows, water mitigation, GC, electrical, plumbing, foundation, glass, debris hauling)

## Quick Start (Replit)
1. Create a new **Node.js** Replit and upload this folder, or import from GitHub after pushing it.
2. Add **Secrets** (see `.env.example` for keys).
3. Provision Postgres (Supabase is recommended) and run `db/schema.sql`.
4. Click **Run** (or `npm run dev`). You should see `Disaster Direct API on :3000`.
5. Test intake:
   ```bash
   curl -X POST http://localhost:3000/api/leads/intake -H "Content-Type: application/json" -d '{
     "name":"Sarah Johnson",
     "phone":"+18135550123",
     "email":"sarah@example.com",
     "address":"2847 Bayshore Dr, Tampa, FL",
     "description":"Tree through roof and broken fence, possible pool debris."
   }'
   ```
6. You will see SMS/voice/email logs (dry run if keys are missing).

## Notes
- **Local numbers & caller ID**: buy Twilio numbers per area code; map them in `pickLocalNumberFor()` or use a Messaging Service with Geo-Match for SMS. For caller ID name, use **Branded Calls** (Android/supported carriers) and consider CNAM for landlines.
- Add contractor ranking + tiered assignment in `routeLead()` and implement accept/lock logic under `/api/assignments/:id/accept`.
- Frontend: build a Service Grid UI showing checkboxes for each category and lock states.

## Environment Variables
See `.env.example` and set these in Replit → Secrets.
