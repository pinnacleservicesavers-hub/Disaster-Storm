-- Disaster Direct minimal schema
create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text,
  phone text,
  email text,
  address text,
  lat double precision,
  lng double precision,
  insurance_status text check (insurance_status in ('unknown','verified','probable')) default 'unknown',
  ai_confidence integer default 0,
  priority text check (priority in ('emergency','high','medium','low')) default 'medium',
  status text check (status in ('new','contacted','qualified','assigned','closed')) default 'new'
);

create table if not exists contractors (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  company_name text not null,
  phone text,
  area_codes_supported text[] default '{}',
  trades text[] default '{}',
  equipment text[] default '{}',
  license_verified boolean default false,
  insurance_verified boolean default false,
  performance_score integer default 50,
  response_time_ms_avg integer default 0,
  active boolean default true
);

create table if not exists lead_services (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id) on delete cascade,
  category text not null,
  needed boolean default true,
  assigned_contractor_id uuid references contractors(id),
  assigned_at timestamptz,
  completed_at timestamptz,
  notes text
);

create table if not exists assignments (
  id uuid primary key default gen_random_uuid(),
  lead_service_id uuid references lead_services(id) on delete cascade,
  contractor_id uuid references contractors(id),
  state text check (state in ('offered','accepted','expired')) default 'offered',
  round integer default 1,
  created_at timestamptz not null default now()
);
