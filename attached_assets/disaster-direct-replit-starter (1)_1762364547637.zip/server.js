import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import { query } from './services/db.js';
import { createLead, expandServices, routeLead, sendOutreach } from './services/lead.js';

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.get('/', (_,res)=>res.send('Disaster Direct API is running'));

// Intake a lead
app.post('/api/leads/intake', async (req, res) => {
  try {
    const lead = await createLead(req.body);
    await expandServices(lead);
    await routeLead(lead.id);
    await sendOutreach(lead.id);
    res.json({ ok: true, leadId: lead.id });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok:false, error: e.message });
  }
});

// List leads (basic)
app.get('/api/leads', async (req, res) => {
  const leads = await query(`
    select l.*, json_agg(ls.*) as services
    from leads l
    left join lead_services ls on ls.lead_id = l.id
    group by l.id
    order by l.created_at desc
    limit 100
  `);
  res.json(leads);
});

// Contractor accepts a service assignment (placeholder)
app.post('/api/assignments/:id/accept', async (req, res) => {
  // In production: verify contractor auth, lock category, expire others.
  res.json({ ok: true });
});

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log(`Disaster Direct API on :${port}`));
