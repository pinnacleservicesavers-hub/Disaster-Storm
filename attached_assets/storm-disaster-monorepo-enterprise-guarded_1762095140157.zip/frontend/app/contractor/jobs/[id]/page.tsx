"use client";
import { useParams } from "next/navigation";
import { useState } from "react";
import { api, API_BASE } from "@/lib/api";

export default function JobDetail() {
  const params = useParams();
  const id = params?.id as string;
  const [labor, setLabor] = useState("1000");
  const [equipment, setEquipment] = useState("2500");
  const [materials, setMaterials] = useState("300");
  const [result, setResult] = useState<any>();

  const generate = async () => {
    const breakdown = { labor, equipment, materials };
    const inv = await api(`/claims/${id}/invoice`, { method:"POST", body: JSON.stringify({ breakdown })});
    const comps = await api(`/jobs/${id}/comparables`, { method:"POST", body: JSON.stringify({ breakdown })});
    setResult({ inv, comps });
  };

  return (
    <main className="p-8 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-semibold">Job {id}</h1>
      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Cost Breakdown</h2>
        <div className="grid grid-cols-3 gap-2">
          <input className="border p-2" value={labor} onChange={e=>setLabor(e.target.value)} placeholder="Labor $" />
          <input className="border p-2" value={equipment} onChange={e=>setEquipment(e.target.value)} placeholder="Equipment $" />
          <input className="border p-2" value={materials} onChange={e=>setMaterials(e.target.value)} placeholder="Materials $" />
        </div>
        <button onClick={generate} className="bg-black text-white px-4 py-2 rounded">Generate Invoice & Comparables</button>
      </section>
      {result && (
        <section className="space-y-2">
          <h2 className="text-lg font-semibold">Results</h2>
          <div className="border rounded p-3">
            <div>Xactimate total: ${result.inv.xactimate.total}</div>
            <div>True vs Xactimate variance: {result.comps.variance}</div>
          </div>
          <div className="flex gap-4">
            <a className="underline" target="_blank" href={`${API_BASE}/claims/${id}/report.html`}>Open HTML Report</a>
            <a className="underline" target="_blank" href={`${API_BASE}/claims/${id}/report.pdf`}>Download PDF Report</a>
          </div>
        
          <div className="flex gap-4">
            <a className="underline" target="_blank" href={`${API_BASE}/claims/${id}/submission.zip`}>Download Submission ZIP</a>
          </div>
        </section>
      )}

    </main>
  );
}
