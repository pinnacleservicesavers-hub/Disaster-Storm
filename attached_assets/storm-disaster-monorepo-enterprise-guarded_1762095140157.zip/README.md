# Storm Disaster — Agentic AI Platform (Monorepo)

This repo contains:
- `backend/` — FastAPI + agent stubs + routes
- `frontend/` — Next.js + Tailwind portal (contractor & homeowner)

## Quick Start

### Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
# open http://localhost:8000/docs
```

### Frontend
```bash
cd frontend
npm install
npm run dev
# open http://localhost:3000
```

## Environment
Copy `.env.example` from each package to `.env` and fill values (LLM key, Twilio, Stripe, etc.).


## Integrations wired
- Stripe checkout & webhook (stubbed prices) — set `STRIPE_*` in backend `.env`
- Twilio inbound SMS webhook for STOP/HELP: `POST /twilio/inbound`
- DocuSign envelope creation stub — replace with real SDK
- S3 storage service scaffold with presigned URLs
- HTML → PDF claim report at `/claims/{job_id}/report.pdf` (WeasyPrint)


## Database (Postgres/Supabase)
- Set `USE_DB=true` and `DATABASE_URL=postgresql+asyncpg://...`
- Run migrations:
```bash
cd backend
alembic upgrade head
```

## DocuSign Embedded Signing
- Fill DocuSign creds in `.env` and replace the stub in `app/services/docusign_svc.py` with the official SDK example for embedded signing.
- Endpoint: `POST /contracts/sign` returns `sign_url` to open in browser.

## Twilio Outbound (per-user)
- Save user phone on signup/profile.
- Outbound messages sent via `MessagingService.notify()` if `consent_comm=true`.
- Inbound webhook `/twilio/inbound` handles `STOP` and `HELP`.


## Auth & Roles
- JWT issued on login. Set `JWT_SECRET` in backend `.env`.
- Frontend stores token in localStorage and sends `Authorization: Bearer` for API calls.

## S3 Uploads
- Request presigned URL via `POST /uploads/presign { key }`, then `PUT` the file to returned URL.
- Ensure your S3 CORS allows PUT from your portal origin.

## Insurer Submission Pack
- `GET /claims/{job_id}/submission.zip` bundles PDF report + manifest JSON for easy emailing/uploading.


## Role Guards & Refresh
- Protected endpoints use `roles_required([...])` dependencies.
- `/auth/refresh` issues a new access token; client stores `refresh` in localStorage.

## Insurer Portal
- Login as role `insurer` to access `/insurer/dashboard` and download submission ZIPs.
