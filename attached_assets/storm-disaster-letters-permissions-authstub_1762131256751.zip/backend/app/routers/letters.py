
from fastapi import APIRouter, Request
from pydantic import BaseModel, Field
from ..utils.store import store
from ..utils.security import get_ctx, require_admin, require_job_access
from datetime import datetime, timedelta
import smtplib, ssl, os
from email.message import EmailMessage

router = APIRouter()

class LetterSchedule(BaseModel):
    job_id: str
    kind: str = Field(..., description="late|demand")
    to_emails: list[str]
    days_from_now: int = 0

TEMPLATES = {
    "late": {
        "subject": "Late notice — Job {job_id} per signed agreement",
        "body": "This is a friendly late notice for Job {job_id}. As agreed in the binding contract, payment is due upon completion. Please remit payment to avoid further steps."
    },
    "demand": {
        "subject": "60-day demand — Job {job_id}",
        "body": "This is a demand letter for Job {job_id}. Per the contract and applicable state law, we request payment in full. Failure to remit may result in a lien and further action. If already paid, thank you—please disregard."
    }
}

def _send_email(smtp_host,smtp_port,smtp_user,smtp_pass,to_list,subject,text):
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = smtp_user or "no-reply@stormdisaster.local"
    msg["To"] = ", ".join(to_list)
    msg.set_content(text)
    try:
        ctx = ssl.create_default_context()
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls(context=ctx)
            if smtp_user: server.login(smtp_user, smtp_pass)
            server.send_message(msg)
        return True, None
    except Exception as e:
        return False, str(e)

@router.post("/letters/schedule")
def schedule_letter(body: LetterSchedule, request: Request):
    job = store.jobs.setdefault(body.job_id, {})
    ctx = get_ctx(request)
    require_job_access(ctx, job)
    due_at = (datetime.utcnow() + timedelta(days=int(body.days_from_now))).isoformat()
    item = {
        "id": store.new_id(),
        "kind": body.kind,
        "to_emails": body.to_emails,
        "subject": TEMPLATES[body.kind]["subject"].format(job_id=body.job_id),
        "body": TEMPLATES[body.kind]["body"].format(job_id=body.job_id),
        "due_at": due_at,
        "status": "scheduled"
    }
    job.setdefault("letters", []).append(item)
    job.setdefault("timeline", []).append({"job_id": body.job_id, "kind":"note", "message": f"Letter scheduled ({body.kind}) for {due_at}", "when": datetime.utcnow().isoformat()})
    store.jobs[body.job_id] = job
    return {"ok": True, "letter": item}

@router.post("/letters/run")
def run_letters(request: Request):
    # Anyone can trigger in demo; protect with admin in production
    ctx = get_ctx(request)
    # require_admin(ctx)  # Uncomment to admin-protect
    now = datetime.utcnow().isoformat()
    processed = []
    for job_id, job in store.jobs.items():
        for L in job.get("letters", []):
            if L["status"] == "scheduled" and L["due_at"] <= now:
                ok, err = _send_email(
                    os.getenv("SMTP_HOST","smtp.example.com"),
                    int(os.getenv("SMTP_PORT","587")),
                    os.getenv("SMTP_USER","user@example.com"),
                    os.getenv("SMTP_PASS","pass"),
                    L["to_emails"],
                    L["subject"],
                    L["body"]
                )
                L["status"] = "sent" if ok else f"error:{err}"
                job.setdefault("timeline", []).append({"job_id": job_id, "kind":"note", "message": f"Letter {L['id']} ({L['kind']}) {L['status']}", "when": datetime.utcnow().isoformat()})
                processed.append({"job_id": job_id, "letter_id": L["id"], "status": L["status"], "kind": L["kind"]})
        store.jobs[job_id] = job
    return {"processed": processed}
