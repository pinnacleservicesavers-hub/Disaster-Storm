"use client";
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { api, API_BASE } from '@/lib/api';
import { useToast } from '@/app/admin/command-center/toast';

export default function JobDetail(){
  const id = (useParams().id as string) || 'A1';
  const [rem, setRem] = useState<any>({paused:false, reminders:[]});
  const load = async()=> setRem(await api(`/payments/reminders/list/${id}`));
  useEffect(()=>{ load(); },[]);
  const push = (msg:string)=>{ try{ (window as any).__toaster?.(msg); }catch(e){} };
  return (
    <main className="p-8 space-y-4">
      <h1 className="text-2xl font-semibold">Job {id}</h1>
      <div className="border rounded p-3 space-y-2">
        <div className="flex items-center gap-3">
          <div className={rem.paused?'text-red-600':'text-green-700'}>Reminders: {rem.paused ? 'Paused' : 'Active'}</div>
          <button onClick={async()=>{ await api(`/payments/reminders/${rem.paused?'resume':'pause'}/${id}`, { method:'POST' }); load(); }} className="px-3 py-1 rounded border">{rem.paused?'Resume':'Pause'}</button>
        </div>
        <div className="text-sm text-gray-600">Scheduled reminders</div>
        <div className="border rounded">{rem.reminders.map((r:any)=>(<div key={r.id} className="p-2 border-b flex justify-between"><div>{r.level} — {r.status}</div><div>due {r.due_at}</div></div>))}</div>
        <div className="mt-3 border-t pt-3">
          <div className="font-semibold text-sm">Schedule a reminder</div>
          <div className="flex flex-col md:flex-row gap-2 text-sm mt-2">
            <input id="schedEmails" className="border p-2 flex-1" placeholder="to emails (comma separated)" />
            <select id="schedLevel" className="border p-2">
              <option value="gentle">gentle</option>
              <option value="firm">firm</option>
              <option value="final">final</option>
            </select>
            <input id="schedFirst" className="border p-2 w-28" placeholder="first in (days)" />
            <button className="px-3 py-2 border rounded" onClick={async()=>{
              const to = (document.getElementById('schedEmails') as HTMLInputElement).value.split(',').map(x=>x.trim()).filter(Boolean);
              const level = (document.getElementById('schedLevel') as HTMLSelectElement).value;
              const first = parseInt((document.getElementById('schedFirst') as HTMLInputElement).value||'3',10);
              try{
                await api('/payments/reminders/schedule', { method:'POST', body: JSON.stringify({ job_id: id, to_emails: to, level, first_in_days: first }) });
                push('Reminder scheduled'); load();
              }catch(e){ push('Failed to schedule'); }
            }}>Schedule</button>
          </div>
        </div>
        <div className="text-right">
          <a className="underline text-sm" target="_blank" href={`${API_BASE}/payments/reminders/audit/${id}/csv`} onClick={()=>{ try{ (window as any).__toaster?.('Downloading CSV…'); }catch(e){} }}>Export audit CSV</a>
        
        <div className="mt-3 border-t pt-3">
          <div className="font-semibold text-sm">Letters</div>
          <div className="flex flex-wrap items-center gap-2 text-sm mt-2">
            <button className="px-3 py-2 border rounded" onClick={async()=>{
              try{
                await api('/letters/schedule', { method:'POST', body: JSON.stringify({ job_id: id, kind:'late', to_emails: ['insured@example.com'], days_from_now: 1 }) });
                try{ (window as any).__toaster?.('Late letter scheduled'); }catch(e){}
              }catch(e){ try{ (window as any).__toaster?.('Failed to schedule late letter'); }catch(e){} }
            }}>Schedule Late Letter (+1 day)</button>
            <button className="px-3 py-2 border rounded" onClick={async()=>{
              try{
                await api('/letters/schedule', { method:'POST', body: JSON.stringify({ job_id: id, kind:'demand', to_emails: ['insured@example.com'], days_from_now: 60 }) });
                try{ (window as any).__toaster?.('Demand letter scheduled (+60d)'); }catch(e){}
              }catch(e){ try{ (window as any).__toaster?.('Failed to schedule demand letter'); }catch(e){} }
            }}>Schedule Demand Letter (+60 days)</button>
          </div>
        </div>

      </div>
    </main>
  );
}
