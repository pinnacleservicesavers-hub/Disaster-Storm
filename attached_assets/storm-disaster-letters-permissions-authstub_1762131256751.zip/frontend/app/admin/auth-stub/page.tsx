
"use client";
import { useEffect, useState } from "react";

export default function AuthStub(){
  const [role, setRole] = useState<string>('admin');
  const [uid, setUid] = useState<string>('demo-contractor');
  useEffect(()=>{
    const r = localStorage.getItem('role'); const u = localStorage.getItem('user_id');
    if(r) setRole(r); if(u) setUid(u);
  },[]);
  const save = ()=>{ localStorage.setItem('role', role); localStorage.setItem('user_id', uid); alert('Saved. Reload pages to apply.'); };
  return (
    <main className="p-8 space-y-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold">Auth Stub</h1>
      <div className="space-y-2">
        <label className="block text-sm">Role
          <select className="border p-2 block w-full" value={role} onChange={e=>setRole(e.target.value)}>
            <option value="admin">admin</option>
            <option value="contractor">contractor</option>
            <option value="homeowner">homeowner</option>
          </select>
        </label>
        <label className="block text-sm">User ID
          <input className="border p-2 block w-full" value={uid} onChange={e=>setUid(e.target.value)} placeholder="demo-contractor" />
        </label>
        <button onClick={save} className="px-4 py-2 border rounded">Save</button>
      </div>
      <p className="text-xs text-gray-500">This stub only sets headers for API calls. Replace with real auth later.</p>
    </main>
  );
}
