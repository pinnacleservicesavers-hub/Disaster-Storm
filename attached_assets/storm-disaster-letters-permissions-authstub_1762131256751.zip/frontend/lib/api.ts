
export const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";

function authHeaders(){
  if (typeof window === 'undefined') return {};
  const role = localStorage.getItem('role') || 'admin';
  const uid = localStorage.getItem('user_id') || 'demo-contractor';
  return { 'X-User-Role': role, 'X-User-Id': uid };
}

export async function api(path: string, opts: RequestInit = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...authHeaders(),
      ...(opts.headers||{})
    },
    ...opts
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
