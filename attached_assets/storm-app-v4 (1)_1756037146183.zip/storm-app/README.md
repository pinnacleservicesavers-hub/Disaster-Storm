# SLM Storm App v4 — Claim Packet PDF, Voice Recording, Polished Dashboard

**What's new**
- **Export Claim Packet (PDF)** at `/api/jobs/:id/export/packet.pdf` (includes timeline + embedded photos).
- **Twilio Voice bridge with consent and recording** (`/api/voice/start-bridge`) + TwiML `/twilio/voice/bridge` and recording callback.
- **Polished dashboard** (`/`) with live map + quick actions + property lookup tool.
- Keeps all earlier features (alerts, SPC pins, Jobs UI, uploads, Stripe, Dropbox Sign, lien reminders).

**New Secrets**
```
TWILIO_SID=...
TWILIO_TOKEN=...
TWILIO_NUMBER=+1XXXXXXXXXX
PUBLIC_URL=https://<your-repl-url>  # required for Twilio webhooks and Stripe redirects
```

**Notes**
- The recording callback stores recording URLs as artifacts without a job_id (Twilio webhook doesn't include it by default). You can pass a job param through the bridge URL and store it in `artifacts` if needed.
- PDF embeds public image URLs; for large batches, expect bigger files.
- For production Stripe webhooks, enable raw-body verification.
