async function fetchJobs(){ const r = await fetch('/api/jobs'); return r.json(); }
function jobCard(j){
  return `<div class="job">
    <div><b>${j.customer_name||'Unnamed'}</b> — ${j.address||''} ${j.city||''}, ${j.state||''}</div>
    <div class="row small">Status: ${j.status} • Job ID: ${j.id}</div>
    <div class="row" style="margin-top:6px;">
      <button onclick="openPayment('${j.id}')">Stripe Payment</button>
      <button onclick="sendSign('${j.id}')">Send Contract/AOB</button>
      <button onclick="exportPacket('${j.id}')">Export Claim Packet (PDF)</button>
      <label style="margin-left:auto">Upload<input type="file" onchange="uploadFile('${j.id}', this.files[0])"></label>
    </div>
  </div>`;
}
async function openPayment(id){
  const name = prompt("Line item", "Emergency Tree Service");
  const amt = parseFloat(prompt("Amount (USD)", "1500")||"0");
  const email = prompt("Customer email (optional)");
  const r = await fetch('/api/pay/checkout-session',{ method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ job_id:id, customer_email: email||undefined, line_items:[{ name, amount_cents: Math.round(amt*100), qty:1 }] })
  });
  const data = await r.json(); if (data.url) window.open(data.url,'_blank'); else alert(JSON.stringify(data));
}
async function sendSign(id){
  const email = prompt("Customer Email"); if (!email) return;
  const name = prompt("Customer Name") || "Customer";
  const contractUrl = prompt("Contract PDF URL (public)");
  const aobUrl = prompt("AOB PDF URL (optional)");
  const r = await fetch('/api/sign/send',{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({
    job_id:id, customer_email:email, customer_name:name, contract_pdf_url:contractUrl, aob_pdf_url:aobUrl
  })});
  const data = await r.json(); alert(data.ok ? "Sent for signature" : JSON.stringify(data));
}
async function exportPacket(id){ window.open('/api/jobs/'+id+'/export/packet.pdf','_blank'); }
async function uploadFile(id, file){
  const fd = new FormData(); fd.append('file', file);
  const r = await fetch('/api/jobs/'+id+'/upload', { method:'POST', body: fd });
  const data = await r.json(); if (data.ok) alert("Uploaded"); else alert(JSON.stringify(data));
}
async function render(){ const jobs = await fetchJobs(); document.getElementById('jobs').innerHTML = jobs.map(jobCard).join(""); }
render();
