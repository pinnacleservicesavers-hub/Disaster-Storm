import express from "express";
import cors from "cors";
import axios from "axios";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import PDFDocument from "pdfkit";
import dayjs from "dayjs";
import archiver from "archiver";
import { createClient } from "@supabase/supabase-js";
import Stripe from "stripe";
import * as Sign from "@dropbox/sign";
import Twilio from "twilio";
import cron from "node-cron";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

// --- Clients ---
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
const stripe = new Stripe(process.env.STRIPE_SECRET || "", { apiVersion: "2023-10-16" });
const signClient = new Sign.SignatureRequestApi();
Sign.Configuration.username = process.env.DROPBOX_SIGN_KEY || "";
const twilio = Twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);

// ---------- Basic endpoints ----------
app.get("/health", (_, res) => res.json({ ok: true, time: new Date().toISOString() }));

// ---------- Reports ----------
app.get("/api/reports", async (req, res) => {
  const hours = Number(req.query.hours || 48);
  const since = new Date(Date.now() - hours*3600*1000).toISOString();
  const { data, error } = await supabase.from("damage_reports").select("*").gte("created_at", since).order("created_at", { ascending:false }).limit(500);
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post("/api/report-damage", async (req, res) => {
  try {
    const { lat, lon, notes = "", photo_urls = [] } = req.body;
    if (typeof lat !== "number" || typeof lon !== "number") return res.status(400).json({ error: "lat/lon required" });
    let address=null, city=null, state=null, zip=null;
    try {
      const r = await axios.get("https://us1.locationiq.com/v1/reverse", { params: { key: process.env.LOCATIONIQ_KEY, lat, lon, format: "json" }});
      const a = r.data?.address || {};
      address = r.data?.display_name || null; city=a.city||a.town||a.village||null; state=a.state||null; zip=a.postcode||null;
    } catch {}
    const { data, error } = await supabase.from("damage_reports").insert({ lat, lon, address, city, state, zip, notes, source:"public", photos: photo_urls }).select().single();
    if (error) return res.status(500).json({ error: error.message });
    res.json({ ok:true, report:data });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------- Jobs ----------
app.get("/api/jobs", async (req, res) => {
  const { data, error } = await supabase.from("jobs").select("*").order("created_at", { ascending:false }).limit(200);
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.get("/api/jobs/:id", async (req, res) => {
  const id = req.params.id;
  const { data: job, error } = await supabase.from("jobs").select("*").eq("id", id).single();
  if (error) return res.status(404).json({ error: "Not found" });
  const { data: artifacts } = await supabase.from("artifacts").select("*").eq("job_id", id).order("created_at", { ascending:true });
  res.json({ ...job, artifacts: artifacts || [] });
});

app.post("/api/jobs", async (req, res) => {
  const body = req.body || {};
  const { data, error } = await supabase.from("jobs").insert(body).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.patch("/api/jobs/:id", async (req, res) => {
  const { data, error } = await supabase.from("jobs").update(req.body).eq("id", req.params.id).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ---------- Uploads to Supabase Storage ----------
const upload = multer({ storage: multer.memoryStorage() });
app.post("/api/jobs/:id/upload", upload.single("file"), async (req, res) => {
  try {
    const jobId = req.params.id;
    if (!req.file) return res.status(400).json({ error: "file required" });
    const bucket = process.env.SUPABASE_BUCKET || "artifacts";
    const ext = (req.file.originalname || "file").split(".").pop();
    const key = `${jobId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { data: up, error: upErr } = await supabase.storage.from(bucket).upload(key, req.file.buffer, { contentType: req.file.mimetype });
    if (upErr) return res.status(500).json({ error: upErr.message });
    const { data: pub } = await supabase.storage.from(bucket).getPublicUrl(key);
    await supabase.from("artifacts").insert({ job_id: jobId, kind: req.file.mimetype.startsWith("video") ? "video" : "photo", url_or_text: pub.publicUrl });
    res.json({ ok:true, url: pub.publicUrl });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------- Property lookup (Estated) ----------
app.get("/api/property/lookup", async (req, res) => {
  const address = req.query.address || "";
  const token = process.env.ESTATED_TOKEN;
  if (!token) return res.status(400).json({ error: "ESTATED_TOKEN not set" });
  try {
    const r = await axios.get("https://api.estated.com/property/v3", { params: { token, address } });
    res.json(r.data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------- Dropbox Sign & Stripe (same pattern as v3) ----------
app.post("/api/sign/send", async (req, res) => {
  const { job_id, customer_name, customer_email, subject = "Contract", message = "Please review and sign.", contract_pdf_url, aob_pdf_url } = req.body;
  if (!job_id || !customer_email || !contract_pdf_url) return res.status(400).json({ error: "missing required fields" });
  try {
    const payload = new Sign.SignatureRequestSendRequest();
    payload.title = subject; payload.subject = subject; payload.message = message;
    payload.signers = [{ email_address: customer_email, name: customer_name || "Customer" }];
    payload.file_urls = aob_pdf_url ? [contract_pdf_url, aob_pdf_url] : [contract_pdf_url];
    payload.test_mode = process.env.DROPBOX_SIGN_TEST === "1";
    const resp = await signClient.signatureRequestSend(payload);
    await supabase.from("artifacts").insert({ job_id, kind:"doc", url_or_text:`DropboxSign:${resp.body.signature_request?.signature_request_id}` });
    res.json({ ok:true, id: resp.body.signature_request?.signature_request_id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/pay/checkout-session", async (req, res) => {
  const { job_id, customer_email, line_items = [] } = req.body;
  if (!process.env.STRIPE_SECRET) return res.status(400).json({ error: "Stripe not configured" });
  const items = line_items.map(li => ({ price_data: { currency:"usd", product_data:{ name: li.name }, unit_amount: li.amount_cents }, quantity: li.qty || 1 }));
  try {
    const session = await stripe.checkout.sessions.create({
      mode: "payment", customer_email, line_items: items,
      success_url: (process.env.PUBLIC_URL || "http://localhost:3000") + "/paid.html?job=" + job_id,
      cancel_url: (process.env.PUBLIC_URL || "http://localhost:3000") + "/cancel.html?job=" + job_id,
      metadata: { job_id }
    });
    res.json({ url: session.url });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------- Claim packet export (PDF + optional ZIP) ----------
async function buildPacketPDF(jobId){
  const { data: job } = await supabase.from("jobs").select("*").eq("id", jobId).single();
  const { data: artifacts } = await supabase.from("artifacts").select("*").eq("job_id", jobId).order("created_at", { ascending:true });
  const doc = new PDFDocument({ margin: 36 });
  const tmp = path.join(__dirname, `packet-${jobId}.pdf`);
  const stream = fs.createWriteStream(tmp);
  doc.pipe(stream);
  doc.fontSize(18).text("Emergency Tree Service — Claim Packet", { align: "center" });
  doc.moveDown(1);
  doc.fontSize(12).text(`Customer: ${job.customer_name||""}`);
  doc.text(`Address: ${job.address||""} ${job.city||""}, ${job.state||""} ${job.zip||""}`);
  doc.text(`Claim #: ${job.claim_number||"—"}`);
  doc.text(`Status: ${job.status}`);
  if (job.completion_date) doc.text(`Completion Date: ${job.completion_date}`);
  doc.moveDown(1).text("Timeline:", { underline: true });
  (artifacts||[]).forEach((a, i) => {
    doc.text(`${i+1}. [${dayjs(a.created_at).format("YYYY-MM-DD HH:mm")}] ${a.kind}: ${a.url_or_text?.slice(0, 120)}`);
  });
  doc.moveDown(1).text("Photos:", { underline: true });
  for (const a of (artifacts||[])) {
    if (a.kind === "photo" && a.url_or_text) {
      try {
        const r = await axios.get(a.url_or_text, { responseType: "arraybuffer" });
        const img = Buffer.from(r.data);
        doc.addPage();
        doc.text(`${dayjs(a.created_at).format("YYYY-MM-DD HH:mm")} — ${job.address||""}`);
        doc.image(img, { fit: [500, 700], align: "center" });
      } catch {}
    }
  }
  doc.end();
  await new Promise(r => stream.on("finish", r));
  return tmp;
}

app.get("/api/jobs/:id/export/packet.pdf", async (req, res) => {
  try {
    const pdfPath = await buildPacketPDF(req.params.id);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename=claim-packet-${req.params.id}.pdf`);
    fs.createReadStream(pdfPath).pipe(res).on("finish", () => fs.unlink(pdfPath, ()=>{}));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------- Twilio Voice: consent + recording + bridge ----------
app.post("/api/voice/start-bridge", async (req, res) => {
  // { agent: "+1706...", customer: "+1706...", job_id:"..." }
  const { agent, customer, job_id } = req.body || {};
  if (!agent || !customer) return res.status(400).json({ error: "agent and customer required (E.164)" });
  try {
    const url = (process.env.PUBLIC_URL || "http://localhost:3000") + `/twilio/voice/bridge?customer=${encodeURIComponent(customer)}&job=${encodeURIComponent(job_id||"")}`;
    const call = await twilio.calls.create({ to: agent, from: process.env.TWILIO_NUMBER, url });
    res.json({ ok:true, sid: call.sid });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// TwiML: play consent and dial customer with recording
app.post("/twilio/voice/bridge", (req, res) => {
  const customer = req.query.customer;
  const job = req.query.job || "";
  const recCb = (process.env.PUBLIC_URL || "") + "/twilio/voice/recording";
  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Joanna">This call may be recorded to document emergency service work. If you do not wish to be recorded, please hang up and ask us to call you without recording.</Say>
  <Pause length="1"/>
  <Dial record="record-from-answer" recordingStatusCallback="${recCb}" timeout="25">${customer}</Dial>
</Response>`;
  res.type("text/xml").send(twiml);
});

// Handle recording callback
app.post("/twilio/voice/recording", async (req, res) => {
  const recordingUrl = req.body?.RecordingUrl || req.query?.RecordingUrl;
  const callSid = req.body?.CallSid || req.query?.CallSid;
  // We don’t have job_id here without extra params; log generic and later match by time/job notes.
  if (recordingUrl) {
    await supabase.from("artifacts").insert({ job_id: null, kind:"call", url_or_text: recordingUrl });
  }
  res.send("ok");
});

// ---------- Simple cron: daily task list at 10:00 UTC ----------
cron.schedule("0 10 * * *", async ()=>{
  try {
    const today = new Date().toISOString().slice(0,10);
    const { data: subs } = await supabase.from("subcontractors").select("id,name,phone,sms_opt_in").eq("sms_opt_in", true);
    for (const s of (subs||[])){
      if (!s.phone) continue;
      const { data: jobs } = await supabase.from("jobs").select("customer_name,address,city,state").eq("assigned_sub_id", s.id).neq("status", "closed");
      const list = (jobs||[]).slice(0,10).map(j => `• ${j.customer_name||""} – ${j.address||""} ${j.city||""}, ${j.state||""}`).join("\n") || "No assigned jobs.";
      const msg = `Good morning ${s.name||""}. Today's tasks:\n${list}`;
      try { await twilio.messages.create({ to:s.phone, from:process.env.TWILIO_NUMBER, body: msg }); } catch {}
    }
  } catch {}
});

// ---------- Pages ----------
app.get("/", (_, res) => res.sendFile(path.join(__dirname, "..", "public", "dashboard.html")));
app.get("/jobs", (_, res) => res.sendFile(path.join(__dirname, "..", "public", "jobs.html")));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Storm App v4 running on :"+PORT));
