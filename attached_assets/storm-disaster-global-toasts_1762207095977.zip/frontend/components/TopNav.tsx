
"use client";
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { auth, type Role } from '@/lib/auth';
import { api } from '@/lib/api';
import Breadcrumbs from '@/components/Breadcrumbs';
import Toast from '@/components/Toast';

export default function TopNav(){
  const [role, setRole] = useState<Role>('contractor');
  const [user, setUser] = useState('user');
  const [hasToken, setHasToken] = useState(false);
  const [authHealthy, setAuthHealthy] = useState<boolean | null>(null);
  const [authKeys, setAuthKeys] = useState<number>(0);
  const [lastFetch, setLastFetch] = useState<string>('');
  const [toastMsg, setToastMsg] = useState<string>('');
  const [showToast, setShowToast] = useState(false);

  useEffect(()=>{
    const s = auth.getSession();
    if(s){ setRole(s.role); setUser(s.userId); setHasToken(Boolean(s.token)); }
  },[]);

  useEffect(()=>{
    let prev: boolean | null = null;
    const pollAuthHealth = async()=>{
      try{
        const j = await api('/health/auth');
        const healthy = Boolean(j?.jwks_loaded);
        setAuthHealthy(healthy);
        setAuthKeys(Number(j?.jwks_keys || 0));
        if (j?.jwks_meta?.last_fetch) setLastFetch(String(j.jwks_meta.last_fetch));
        if (prev !== null && healthy !== prev){
          setToastMsg(healthy ? 'Auth OK' : 'Auth Issue');
          setShowToast(true);
        }
        prev = healthy;
      }catch(e){
        setAuthHealthy(false);
        if (prev !== null && prev !== false){
          setToastMsg('Auth Issue');
          setShowToast(true);
        }
        prev = false;
      }
    };
    pollAuthHealth();
    const id = setInterval(pollAuthHealth, 60000);
    return ()=> clearInterval(id);
  },[]);

  const updateRole = (r: Role)=>{
    setRole(r);
    auth.setSession({ role: r, userId: user, scopes: [] });
    location.reload();
  };
  const logout = ()=>{ auth.clear(); location.href = '/signout'; };

  const badge = (
    <div title={lastFetch ? `Last JWKS fetch: ${new Date(lastFetch).toLocaleString()}` : 'JWKS status'} className="hidden sm:flex items-center gap-1 text-xs px-2 py-1 rounded border">
      <span className={`inline-block w-2 h-2 rounded-full ${authHealthy===null ? 'bg-gray-400' : (authHealthy ? 'bg-green-500' : 'bg-red-500')}`} />
      <span className="text-gray-700">{authHealthy===null ? 'Auth …' : (authHealthy ? 'Auth OK' : 'Auth Issue')}</span>
      <span className="text-gray-400">· {authKeys}</span>
    </div>
  );

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur border-b">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/" className="font-bold">Storm&nbsp;Disaster</Link>
            <nav className="hidden md:flex items-center gap-2 text-sm">
              <Link href="/contractor" className="px-2 py-1 rounded hover:bg-gray-100">Contractor</Link>
              <Link href="/admin" className="px-2 py-1 rounded hover:bg-gray-100">Admin</Link>
              <Link href="/homeowner" className="px-2 py-1 rounded hover:bg-gray-100">Homeowner</Link>
            </nav>
          </div>
          <div className="flex items-center gap-2 text-sm">
            {role === 'admin' ? (<a href="/admin/oidc/diagnostics">{badge}</a>) : null}
            {!hasToken ? (
              <button className="px-3 py-1 border rounded" onClick={()=>auth.login()}>Login</button>
            ) : (
              <>
                <span className="text-gray-500 hidden sm:inline">Role:</span>
                <select className="border p-1 rounded" value={role} onChange={e=>updateRole(e.target.value as Role)}>
                  <option value="admin">admin</option>
                  <option value="contractor">contractor</option>
                  <option value="homeowner">homeowner</option>
                </select>
                <span className="hidden md:inline text-gray-500">|</span>
                <span className="hidden md:inline text-gray-600">User:</span>
                <input
                  className="border p-1 rounded w-36 hidden md:inline"
                  defaultValue={user}
                  onBlur={(e)=>{ setUser(e.target.value); auth.setSession({ role, userId: e.target.value, scopes: [] }); }}
                />
                <button className="ml-2 px-2 py-1 border rounded hover:bg-gray-100" onClick={logout}>Logout</button>
              </>
            )}
          </div>
        </div>
      </header>
      <div className="max-w-6xl mx-auto px-4">
        <Breadcrumbs />
      </div>
      <Toast message={toastMsg} show={showToast} onClose={()=>setShowToast(false)} />
    </>
  );
}
