
"use client";
import { useEffect, useState } from 'react';

export default function Toast({ message, show, onClose }: { message: string; show: boolean; onClose?: ()=>void }){
  const [visible, setVisible] = useState(show);
  useEffect(()=>{
    setVisible(show);
    if(show){
      const t=setTimeout(()=>{ setVisible(false); onClose && onClose(); }, 3500);
      return ()=>clearTimeout(t);
    }
  }, [show, onClose]);
  if(!visible) return null;
  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-black text-white text-sm px-4 py-2 rounded shadow-lg z-50">
      {message}
    </div>
  );
}
