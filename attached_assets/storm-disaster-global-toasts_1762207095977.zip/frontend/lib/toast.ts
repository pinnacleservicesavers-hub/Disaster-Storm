
type ToastType = 'info' | 'success' | 'error';
type Toast = { id: number; message: string; type: ToastType; timeout?: number };

let listeners: ((t: Toast) => void)[] = [];
let idCounter = 1;

export function onToast(fn: (t: Toast) => void){
  listeners.push(fn);
  return () => { listeners = listeners.filter(x => x !== fn); };
}
export function showToast(message: string, type: ToastType = 'info', timeout = 3500){
  const t: Toast = { id: idCounter++, message, type, timeout };
  listeners.forEach(fn => fn(t));
}
export function success(message: string, timeout = 3500){ showToast(message, 'success', timeout); }
export function error(message: string, timeout = 4000){ showToast(message, 'error', timeout); }
export type { Toast, ToastType };
