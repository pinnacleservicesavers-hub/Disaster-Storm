
import { showToast } from '@/lib/toast';
export const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "";
function authHeaders(){
  if (typeof window === 'undefined') return {};
  const role = localStorage.getItem('role') || 'admin';
  const uid = localStorage.getItem('user_id') || 'demo-contractor';
  const scopes = localStorage.getItem('scopes') || '';
  const token = localStorage.getItem('token') || '';
  const h: Record<string,string> = { 'X-User-Role': role, 'X-User-Id': uid, 'X-Scopes': scopes };
  if (token) h['Authorization'] = `Bearer ${token}`;
  return h;
}
export async function api(path: string, opts: RequestInit & { toastSuccess?: string; toastError?: string } = {}){
  const res = await fetch(`${API_BASE}${path}`, { headers: { 'Content-Type':'application/json', ...authHeaders(), ...(opts.headers||{}) }, ...opts });
  if(!res.ok){
    let t=''; try{ t = await res.text(); }catch(e){}
    if (opts.toastError) showToast(opts.toastError, 'error');
    throw new Error(t || `HTTP ${res.status}`);
  }
  try{ const j = await res.json(); if (opts.toastSuccess) showToast(opts.toastSuccess, 'success'); return j; }catch(e){ if (opts.toastSuccess) showToast(opts.toastSuccess, 'success'); return {}; }
}
