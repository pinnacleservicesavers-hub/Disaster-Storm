
"use client";
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';

export default function SMTPSettings(){
  const [host, setHost] = useState('');
  const [port, setPort] = useState<number>(587);
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');
  const [useTLS, setUseTLS] = useState(true);
  const [testTo, setTestTo] = useState('');

  useEffect(()=>{
    (async()=>{
      try{
        const j = await api('/admin/smtp');
        setHost(j.host || ''); setPort(Number(j.port || 587)); setUser(j.user || ''); setUseTLS(Boolean(j.use_tls ?? true));
      }catch{ /* handled by api */ }
    })();
  },[]);

  const save = async()=>{
    await api('/admin/smtp', { method: 'POST', body: JSON.stringify({ host, port, user, password, use_tls: useTLS }), toastSuccess: 'SMTP settings saved', toastError: 'Failed to save SMTP settings' });
  };
  const test = async()=>{
    await api(`/admin/smtp/test?to=${encodeURIComponent(testTo)}`, { method: 'POST', toastSuccess: 'Test email sent', toastError: 'SMTP test failed' });
  };

  return (
    <main className="p-8 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold">SMTP Settings</h1>
      <div className="grid gap-2">
        <label className="text-sm">Host<input className="border p-2 w-full" value={host} onChange={e=>setHost(e.target.value)} /></label>
        <label className="text-sm">Port<input type="number" className="border p-2 w-full" value={port} onChange={e=>setPort(parseInt(e.target.value||'0',10))} /></label>
        <label className="text-sm">User<input className="border p-2 w-full" value={user} onChange={e=>setUser(e.target.value)} /></label>
        <label className="text-sm">Password<input type="password" className="border p-2 w-full" value={password} onChange={e=>setPassword(e.target.value)} /></label>
        <label className="text-sm inline-flex items-center gap-2"><input type="checkbox" checked={useTLS} onChange={e=>setUseTLS(e.target.checked)} /> Use TLS</label>
      </div>
      <div className="flex items-center gap-2">
        <button className="px-3 py-1 border rounded" onClick={save}>Save</button>
        <input className="border p-2" placeholder="test@you.com" value={testTo} onChange={e=>setTestTo(e.target.value)} />
        <button className="px-3 py-1 border rounded" onClick={test} disabled={!testTo}>Send Test</button>
      </div>
    </main>
  );
}
