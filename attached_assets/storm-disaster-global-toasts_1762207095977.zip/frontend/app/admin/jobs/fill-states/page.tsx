
"use client";
import { useState } from 'react';
import { api } from '@/lib/api';

export default function BulkFillStates(){
  const [stateFilter, setStateFilter] = useState('');
  const [zipFilter, setZipFilter] = useState('');
  const [csvUrl, setCsvUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const run = async()=>{
    setBusy(true);
    try{
      const j = await api('/admin/jobs/fill_states', { method: 'POST', body: JSON.stringify({ state: stateFilter, zip_like: zipFilter }), toastSuccess: 'Bulk fill completed', toastError: 'Bulk fill failed' });
      // Optionally update UI with j.details...
    } finally {
      setBusy(false);
    }
  };
  const exportCsv = async()=>{
    try{
      const res = await fetch('/admin/jobs/fill_states.csv', { method: 'POST' });
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      setCsvUrl(url);
    }catch{ /* ignore */ }
  };

  return (
    <main className="p-8 max-w-2xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold">Bulk Fill States</h1>
      <div className="grid grid-cols-2 gap-2">
        <input className="border p-2" placeholder="State (e.g., FL)" value={stateFilter} onChange={e=>setStateFilter(e.target.value)} />
        <input className="border p-2" placeholder="ZIP contains..." value={zipFilter} onChange={e=>setZipFilter(e.target.value)} />
      </div>
      <div className="flex items-center gap-2">
        <button className="px-3 py-1 border rounded" onClick={run} disabled={busy}>{busy ? 'Running…' : 'Run Fill'}</button>
        <button className="px-3 py-1 border rounded" onClick={exportCsv}>Export CSV</button>
        {csvUrl && <a className="px-3 py-1 border rounded" href={csvUrl} download="fill_states.csv">Download CSV</a>}
      </div>
    </main>
  );
}
