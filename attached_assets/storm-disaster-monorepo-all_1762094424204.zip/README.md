# Storm Disaster — Agentic AI Platform (Monorepo)

This repo contains:
- `backend/` — FastAPI + agent stubs + routes
- `frontend/` — Next.js + Tailwind portal (contractor & homeowner)

## Quick Start

### Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
# open http://localhost:8000/docs
```

### Frontend
```bash
cd frontend
npm install
npm run dev
# open http://localhost:3000
```

## Environment
Copy `.env.example` from each package to `.env` and fill values (LLM key, Twilio, Stripe, etc.).
