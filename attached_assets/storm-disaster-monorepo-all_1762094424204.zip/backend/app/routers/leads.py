from fastapi import APIRouter
from ..utils.store import store
router = APIRouter()

@router.get("")
def list_leads():
    return {"leads": list(store.leads.values())}

@router.post("/accept/{lead_id}")
def accept(lead_id: str):
    lead = store.leads.get(lead_id)
    if not lead: return {"ok": False, "error":"lead not found"}
    lead["status"]="locked"
    # In real flow: create job from lead
    return {"accepted": lead_id}
