from fastapi import APIRouter, Response
from pydantic import BaseModel
from ..utils.store import store
from ..deps import build_dependencies

router = APIRouter()
deps = build_dependencies()

class InvoiceBody(BaseModel):
    breakdown: dict

@router.post("/{job_id}/invoice")
async def create_invoice(job_id: str, body: InvoiceBody):
    inv_id = store.new_id()
    xact = await deps.xact.estimate(body.breakdown)
    inv = {"id": inv_id, "job_id": job_id, "breakdown": body.breakdown, "xactimate": xact, "status":"draft"}
    store.invoices[inv_id] = inv
    return {"invoice_id": inv_id, "xactimate": xact}

@router.get("/{job_id}/report.html")
def report_html(job_id: str):
    # find first invoice for job (demo)
    inv = next((v for v in store.invoices.values() if v["job_id"] == job_id), None)
    true_total = 0.0
    if inv:
        for v in inv["breakdown"].values():
            try: true_total += float(v)
            except: pass
    xact_total = inv["xactimate"]["total"] if inv else 0.0
    variance = true_total - xact_total
    html = f"""
    <!doctype html>
    <html><head><meta charset='utf-8'><title>Claim Report - Job {job_id}</title>
    <style>
      body {{ font-family: Arial, sans-serif; padding: 24px; }}
      h1, h2 {{ margin: 0 0 8px; }}
      .card {{ border: 1px solid #ddd; border-radius: 8px; padding: 16px; margin-bottom: 16px; }}
      table {{ width: 100%; border-collapse: collapse; }}
      td, th {{ border-bottom: 1px solid #eee; padding: 8px; text-align: left; }}
      .muted {{ color: #666; }}
    </style></head><body>
      <h1>Insurer-Facing Claim Report</h1>
      <div class='muted'>Job ID: {job_id}</div>
      <div class='card'>
        <h2>Comparables</h2>
        <table>
          <tr><th>Comparable</th><th>Total</th></tr>
          <tr><td>True apples-to-apples</td><td>${true_total:,.2f}</td></tr>
          <tr><td>Xactimate</td><td>${xact_total:,.2f}</td></tr>
          <tr><td><strong>Variance</strong></td><td><strong>${variance:,.2f}</strong></td></tr>
        </table>
      </div>
      <div class='card'>
        <h2>Breakdown</h2>
        <table>
          <tr><th>Item</th><th>Amount</th></tr>
          {''.join(f'<tr><td>{k}</td><td>${v}</td></tr>' for k,v in (inv['breakdown'].items() if inv else {}.items()))}
        </table>
      </div>
      <div class='card'>
        <h2>Narrative</h2>
        <p>This work was necessary to mitigate further loss and restore safe access per industry standards. 
        Pricing reflects labor, equipment (e.g., crane), and materials at market rates during emergency conditions. 
        Where totals exceed Xactimate, we provide justification based on scope specificity, safety constraints, and local market surge.</p>
      </div>
    </body></html>
    """
    return Response(content=html, media_type="text/html")

@router.post("/{job_id}/submit")
def submit(job_id: str): return {"submitted": True}

@router.post("/{job_id}/negotiate")
def negotiate(job_id: str): return {"status": "in_progress"}

@router.post("/{job_id}/status/ping")
def ping(job_id: str): return {"ok": True}

@router.post("/{job_id}/letters")
def letters(job_id: str): return {"generated": ["reminder", "demand"]}
