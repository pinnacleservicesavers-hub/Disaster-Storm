from fastapi import APIRouter
router = APIRouter()

@router.post("/checkout")
def checkout(): return {"checkout": "payment_link"}

@router.post("/webhook")
def webhook(): return {"ok": True}
