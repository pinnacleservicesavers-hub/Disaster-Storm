from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store

router = APIRouter()

@router.get("")
def list_jobs():
    return {"jobs": list(store.jobs.values())}

class AnalyzeBody(BaseModel):
    breakdown: dict = {}

@router.post("/{job_id}/media")
def upload_media(job_id: str):
    return {"ok": True}

@router.post("/{job_id}/analyze")
def analyze(job_id: str, body: AnalyzeBody):
    labels = ["tree_diameter: 24in", "roof_shingles_missing: 120", "hail_size: 1.5in"]
    return {"labels": labels, "measurements": {"tree_weight_est_lb": 1800}, "breakdown": body.breakdown}

@router.post("/{job_id}/comparables")
def comps(job_id: str, body: AnalyzeBody):
    # very simple comparable stub
    true_total = sum([float(v) for v in body.breakdown.values() if str(v).replace('.','',1).isdigit()])
    xactimate_total = round(true_total*0.9, 2)
    return {"true": {"total": true_total}, "xactimate": {"total": xactimate_total}, "variance": true_total - xactimate_total}

@router.post("/{job_id}/contract/sign")
def sign(job_id: str): return {"signed": True}
