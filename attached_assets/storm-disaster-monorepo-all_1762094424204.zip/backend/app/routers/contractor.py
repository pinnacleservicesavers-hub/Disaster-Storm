from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store

router = APIRouter()

class Profile(BaseModel):
    user_id: str
    company_name: str|None = None
    licenses: list[str]|None = None
    insurance: str|None = None
    alert_channels: list[str]|None = None

@router.post("/profile")
def upsert_profile(body: Profile):
    u = store.users.get(body.user_id)
    if not u: return {"ok": False, "error":"user not found"}
    u["profile"] = body.dict()
    return {"ok": True}

@router.get("/profile/{user_id}")
def get_profile(user_id: str):
    u = store.users.get(user_id)
    return {"profile": u.get("profile", {}) if u else {}}

@router.post("/contracts/validate")
def validate_contract():
    # stubbed response
    return {"action": "review", "result": {"is_legal": True, "issues": [], "aob_included": True}}

@router.post("/contracts/generate")
def generate_contract():
    return {"action": "generate", "contract": "Contract Template with AOB (if permitted). Terms..."} 
