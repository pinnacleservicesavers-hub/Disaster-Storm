from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from ..utils.store import store

router = APIRouter()

class SignupBody(BaseModel):
    email: str
    password: str
    role: str  # contractor | homeowner

@router.post("/signup")
def signup(body: SignupBody):
    if body.email in (u.get("email") for u in store.users.values()):
        return {"ok": False, "error": "Email already exists"}
    uid = store.new_id()
    store.users[uid] = {"id": uid, "email": body.email, "password": body.password, "role": body.role}
    return {"ok": True, "id": uid}

class LoginBody(BaseModel):
    email: str
    password: str

@router.post("/login")
def login(body: LoginBody):
    for uid, u in store.users.items():
        if u["email"] == body.email and u["password"] == body.password:
            token = store.new_id()
            store.sessions[token] = uid
            return {"token": token, "user": {"id": uid, "role": u["role"], "email": u["email"]}}
    return {"ok": False, "error": "Invalid credentials"}
