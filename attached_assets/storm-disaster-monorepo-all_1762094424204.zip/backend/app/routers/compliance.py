from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store

router = APIRouter()

class ConsentBody(BaseModel):
    user_id: str
    consent_comm: bool

@router.post("/consent")
def set_consent(body: ConsentBody):
    u = store.users.get(body.user_id)
    if not u: return {"ok": False, "error":"user not found"}
    u["consent_comm"] = body.consent_comm
    return {"ok": True, "consent_comm": u["consent_comm"]}

@router.post("/optout")
def optout(): return {"opted_out": True}
