from fastapi import APIRouter
from pydantic import BaseModel
from ..utils.store import store

router = APIRouter()

class CheckoutBody(BaseModel):
    user_id: str
    plan: str  # one_time | monthly

@router.post("/checkout")
def checkout(body: CheckoutBody):
    # stub: mark as active
    store.memberships[body.user_id] = {"plan": body.plan, "status":"active"}
    return {"status":"active", "plan": body.plan, "checkout_url":"https://example.com/checkout"}

@router.post("/webhook")
def webhook(): return {"ok": True}
