class ClaimAgent:
    def __init__(self, deps):
        self.llm = deps.llm
        self.storage = deps.storage
        self.xact = deps.xact

    async def analyze_and_update(self, evt):
        labels = ["tree_diameter: 24in", "roof_shingles_missing: 120", "hail_size: 1.5in"]
        true_comp = {"labor_hours": 12, "equipment": "75-ton crane", "rate": 250}
        xact_comp = await self.xact.estimate(evt.get("breakdown", {}))
        story = await self.llm("Compose an insurer-facing narrative using good-faith language.")
        return {"labels": labels, "true": true_comp, "xact": xact_comp, "story": story}
