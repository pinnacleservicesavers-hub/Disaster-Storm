class FinanceAgent:
    def __init__(self, deps):
        self.msg = deps.msg

    async def remind_and_collect(self, evt):
        # send polite reminder to payer; stub
        return {"reminded": True}
