class WeatherAgent:
    def __init__(self, deps):
        self.deps = deps
