class NegotiatorAgent:
    def __init__(self, deps):
        self.llm = deps.llm
        self.msg = deps.msg

    async def prepare_rebuttal(self, evt):
        rebuttal = await self.llm(
            "Draft a concise rebuttal citing duty of good faith and necessity of mitigation. "
            "Do not invent statutes; keep generic."
        )
        return {"rebuttal": rebuttal}
