from typing import Dict, Any

class LegalAgent:
    def __init__(self, deps):
        self.llm = deps.llm
        self.doc_store = deps.storage

    async def validate_or_generate(self, evt: Dict[str, Any]):
        state = evt.get("state", "NY")
        trade = evt.get("trade", "tree_service")
        user_contract = evt.get("contract_text")
        if user_contract:
            review = await self.llm(
                f"Review this contract for {state} law and {trade}. "
                "Flag missing clauses (AOB, indemnification, cancellation, pricing, lien). "
                "Return JSON."
                "\n\n" + user_contract
            )
            return {"action":"review", "result": review}
        else:
            template = await self.llm(
                f"Draft a contractor agreement for {trade} in {state} with AOB if permitted. "
                "Include lien, change orders, payment terms, dispute, and photo consent. "
                "Return plain text."
            )
            return {"action":"generate", "contract": template}
