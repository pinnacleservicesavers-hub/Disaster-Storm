from typing import Dict, Any
import uuid, time

class Store:
    def __init__(self):
        self.users: Dict[str, Dict[str, Any]] = {}
        self.sessions: Dict[str, str] = {}
        self.leads: Dict[str, Dict[str, Any]] = {
            "1": {"id":"1","scope":"Tree Removal","address":"123 Elm St","region":"Metro","scopes":["tree_removal"],"status":"open"}
        }
        self.jobs: Dict[str, Dict[str, Any]] = {
            "A1": {"id":"A1","status":"in_progress","address":"456 Oak Ave","contractor_id":None,"homeowner_id":None}
        }
        self.invoices: Dict[str, Dict[str, Any]] = {}
        self.consents: Dict[str, Dict[str, Any]] = {}
        self.memberships: Dict[str, Dict[str, Any]] = {}

    def new_id(self): return str(uuid.uuid4())
store = Store()
