import asyncio
from typing import Callable, Awaitable, Dict, Any, List

class EventBus:
    def __init__(self):
        self.handlers: List[Callable[[Dict[str, Any]], Awaitable]] = []

    def subscribe(self, handler: Callable[[Dict[str, Any]], Awaitable]):
        self.handlers.append(handler)

    async def publish(self, event: Dict[str, Any]):
        await asyncio.gather(*(h(event) for h in self.handlers))
