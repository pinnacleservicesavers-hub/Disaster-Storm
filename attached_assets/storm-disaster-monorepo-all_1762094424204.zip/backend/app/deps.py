from typing import Any
from .utils.store import store

class Deps:
    def __init__(self):
        self.llm = self._llm_client()
        self.db = self._db()
        self.msg = self._msg()
        self.storage = self._storage()
        self.xact = self._xact()

    def _llm_client(self):
        async def call(prompt: str):
            # Replace with real LLM client usage
            return "<llm-output>"
        return call

    def _db(self):
        # Simple facade over in-memory store for demo
        class DB:
            def __init__(self, s): self.s = s
            def find_contractors_for_region(self, region, scopes):
                return [u for u in self.s.users.values() if u.get("role")=="contractor"]
        return DB(store)

    def _msg(self):
        from .services.twilio_svc import MessagingService
        return MessagingService("sid", "token", "+10000000000")

    def _storage(self):
        class Store: ...
        return Store()

    def _xact(self):
        class Xact:
            async def estimate(self, breakdown):
                total = 0
                for k,v in breakdown.items():
                    try: total += float(v)
                    except: pass
                return {"total": total, "breakdown": breakdown}
        return Xact()

def build_dependencies():
    return Deps()
