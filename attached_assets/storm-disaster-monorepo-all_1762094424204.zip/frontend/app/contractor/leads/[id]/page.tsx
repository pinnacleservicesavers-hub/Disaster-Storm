"use client";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";

export default function LeadDetail() {
  const params = useParams(); const router = useRouter();
  const id = params?.id as string;
  const [lead, setLead] = useState<any>();
  useEffect(()=>{
    api("/leads").then(r=>{
      const f = r.leads.find((x:any)=>x.id===id); setLead(f);
    })
  },[id]);
  const accept = async ()=>{ await api(`/leads/accept/${id}`, { method:"POST"}); router.push("/contractor/dashboard"); };
  if (!lead) return <main className="p-8">Loading...</main>;
  return (
    <main className="p-8 max-w-3xl mx-auto space-y-4">
      <h1 className="text-xl font-semibold">Lead {lead.id}</h1>
      <div className="border p-4 rounded">
        <div>Scope: {lead.scope}</div>
        <div>Address: {lead.address}</div>
        <div>Status: {lead.status}</div>
      </div>
      <button onClick={accept} className="bg-black text-white px-4 py-2 rounded">Accept Lead</button>
    </main>
  );
}
