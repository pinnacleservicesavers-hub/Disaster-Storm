export default function HomeownerDashboard() {
  const jobs = [{ id: "A1", status: "in_progress", contractor: "ABC Tree", address: "456 Oak Ave" }];
  return (
    <main className="p-8 max-w-5xl mx-auto space-y-8">
      <h1 className="text-2xl font-bold">Homeowner Dashboard</h1>
      <section>
        <h2 className="text-lg font-semibold mb-2">Your Jobs</h2>
        <div className="border rounded">
          {jobs.map(j => (
            <div key={j.id} className="p-3 border-b">
              <div className="font-medium">#{j.id} — {j.status}</div>
              <div className="text-sm text-gray-600">{j.contractor} — {j.address}</div>
            </div>
          ))}
        </div>
      </section>
      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Upload Photos/Videos</h2>
        <input type="file" multiple className="border p-2 w-full" />
      </section>
    </main>
  );
}
