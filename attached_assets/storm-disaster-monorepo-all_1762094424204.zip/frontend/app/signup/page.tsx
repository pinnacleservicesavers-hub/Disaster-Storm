"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/api";

export default function Signup() {
  const router = useRouter();
  const [role, setRole] = useState("contractor");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");

  const submit = async (e:any) => {
    e.preventDefault();
    try {
      await api("/auth/signup", { method: "POST", body: JSON.stringify({ email, password, role }) });
      router.push("/login");
    } catch (e:any) {
      setErr("Sign up failed");
    }
  };

  return (
    <main className="p-8 max-w-md mx-auto space-y-4">
      <h1 className="text-xl font-semibold">Sign Up</h1>
      {err && <div className="text-red-600">{err}</div>}
      <form onSubmit={submit} className="space-y-2">
        <select className="border p-2 w-full" value={role} onChange={e=>setRole(e.target.value)}>
          <option value="contractor">Contractor</option>
          <option value="homeowner">Homeowner</option>
        </select>
        <input className="border p-2 w-full" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="border p-2 w-full" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="bg-black text-white px-4 py-2 rounded w-full">Create Account</button>
      </form>
    </main>
  );
}
