import Link from "next/link";
export default function Home() {
  return (
    <main className="p-8 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Storm Disaster Portal</h1>
      <div className="space-x-4">
        <Link className="underline" href="/login">Login</Link>
        <Link className="underline" href="/signup">Sign up</Link>
      </div>
    </main>
  );
}
