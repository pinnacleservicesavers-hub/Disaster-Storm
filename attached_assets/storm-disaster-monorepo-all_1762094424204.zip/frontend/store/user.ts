"use client";
import { create } from "zustand";

type User = { id: string; email: string; role: "contractor"|"homeowner" };
type State = { user?: User; token?: string; setUser: (u: User, t: string)=>void; logout: ()=>void };

export const useUser = create<State>((set)=> ({
  user: undefined,
  token: undefined,
  setUser: (u, t) => set({ user: u, token: t }),
  logout: () => set({ user: undefined, token: undefined }),
}));
