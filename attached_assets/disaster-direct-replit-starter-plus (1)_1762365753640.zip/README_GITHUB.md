# Disaster Direct — AI Lead Management & Outreach

(Extended instructions omitted here due to size.)