// storm_to_parcels.js
// Replit-ready. Pipeline:
// 1) Download NOAA Storm Events CSV (or read local file)
// 2) Extract deduped county/state pairs for hurricanes & tornadoes
// 3) Resolve state & county FIPS via Census API
// 4) Get county polygon/bbox via TIGERweb
// 5) Query Regrid Parcel API for parcels within the county bbox/polygon
// 6) Save results to JSON files in /tmp (or send to your DB)

require('dotenv').config();
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const csv = require('csv-parse');
const turf = require('@turf/turf');

const NOAA_CSV_URL = process.env.NOAA_CSV_URL || '';
const LOCAL_NOAA_CSV = process.env.LOCAL_NOAA_CSV || '/tmp/storm_events.csv';
const REGRID_API_KEY = process.env.REGRID_API_KEY || '';
const ATTOM_API_KEY = process.env.ATTOM_API_KEY || '';
const START_YEAR = process.env.START_YEAR || '1950';
const END_YEAR = process.env.END_YEAR || '2025';
const OUTPUT_DIR = process.env.OUTPUT_DIR || './output';

if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR, { recursive: true });

async function downloadFile(url, destPath) {
  console.log('Downloading', url);
  const res = await fetch(url);
  if (!res.ok) throw new Error('Download failed: ' + res.status);
  const fileStream = fs.createWriteStream(destPath);
  await new Promise((resolve, reject) => {
    res.body.pipe(fileStream);
    res.body.on('error', reject);
    fileStream.on('finish', resolve);
  });
  console.log('Saved to', destPath);
}

async function ensureNoaaCsv() {
  if (NOAA_CSV_URL) {
    await downloadFile(NOAA_CSV_URL, LOCAL_NOAA_CSV);
  }
  if (!fs.existsSync(LOCAL_NOAA_CSV)) {
    throw new Error('No NOAA CSV found. Set NOAA_CSV_URL or upload CSV to ' + LOCAL_NOAA_CSV);
  }
  return LOCAL_NOAA_CSV;
}

async function parseNoaaCsv(csvPath) {
  return new Promise((resolve, reject) => {
    const read = fs.createReadStream(csvPath);
    const parser = csv.parse({ columns: true, skip_empty_lines: true });
    const counties = new Set();
    parser.on('readable', () => {
      let record;
      while ((record = parser.read())) {
        const eventType = (record.EVENT_TYPE || record.event_type || '').toLowerCase();
        const state = (record.STATE || record.state || '').trim();
        const cz = (record.CZ_NAME || record.County || record.CountyName || record.cz_name || '').trim();

        if (!state || !cz) continue;

        if (eventType.includes('tornado') ||
            eventType.includes('hurricane') ||
            eventType.includes('tropical') ||
            eventType.includes('tropical storm') ||
            eventType.includes('storm surge') ||
            eventType.includes('hurricane gust') ) {
          const key = `${cz}||${state}`;
          counties.add(key);
        }
      }
    });
    parser.on('error', reject);
    parser.on('end', () => resolve(Array.from(counties).map(s => {
      const [cz, state] = s.split('||');
      return { countyName: cz, stateName: state };
    })));
    read.pipe(parser);
  });
}

async function getStateFipsMap() {
  const url = 'https://api.census.gov/data/2020/dec/pl?get=NAME&for=state:*';
  const res = await fetch(url);
  if (!res.ok) throw new Error('Census states fetch failed: ' + res.status);
  const json = await res.json();
  const map = {};
  for (let i=1;i<json.length;i++){
    const [name, fips] = json[i];
    map[name.toLowerCase()] = fips.padStart(2,'0');
  }
  return map;
}

async function getCountyFips(stateFips, countyName) {
  const url = `https://api.census.gov/data/2020/dec/pl?get=NAME&for=county:*&in=state:${stateFips}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Census counties fetch failed: ' + res.status);
  const json = await res.json();
  for (let i=1;i<json.length;i++){
    const [name, stFips, countyFips] = json[i];
    const normalized = name.replace(/county/i,'').replace(/parish/i,'').replace(/borough/i,'').replace(/census area/i,'').trim().toLowerCase();
    const target = countyName.replace(/county/i,'').trim().toLowerCase();
    if (normalized === target || normalized.startsWith(target) || target.startsWith(normalized)) {
      return stFips.padStart(2,'0') + countyFips.padStart(3,'0');
    }
  }
  return null;
}

async function fetchCountyGeojson(countyFips) {
  const stateFips = countyFips.slice(0,2);
  const countyCode = countyFips.slice(2);
  const where = `STATE='${stateFips}' AND COUNTY='${countyCode}'`;
  const url = `https://tigerweb.geo.census.gov/arcgis/rest/services/TIGERweb/County/MapServer/1/query?where=${encodeURIComponent(where)}&outFields=*&outSR=4326&f=geojson`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('TIGERweb query failed: ' + res.status);
  const geojson = await res.json();
  if (geojson && geojson.features && geojson.features.length) return geojson.features[0].geometry;
  return null;
}

async function fetchParcelsRegridByPolygon(geometry) {
  if (!REGRID_API_KEY) throw new Error('REGRID_API_KEY not set in environment');
  const bbox = turf.bbox(geometry);
  const [minX,minY,maxX,maxY] = bbox;
  const url = `https://api.regrid.com/v1/parcels/search?bbox=${minX},${minY},${maxX},${maxY}&api_key=${encodeURIComponent(REGRID_API_KEY)}`;
  const res = await fetch(url);
  if (!res.ok) {
    const txt = await res.text().catch(()=>String(res.status));
    throw new Error('Regrid request failed: ' + res.status + ' ' + txt);
  }
  return res.json();
}

function saveJson(name, obj) {
  const p = path.join(OUTPUT_DIR, name + '.json');
  fs.writeFileSync(p, JSON.stringify(obj, null, 2));
  console.log('Saved', p);
}

(async () => {
  try {
    console.log('Starting pipeline...');
    const csvPath = await ensureNoaaCsv();
    console.log('Parsing NOAA CSV...');
    const countyPairs = await parseNoaaCsv(csvPath);
    console.log('Found', countyPairs.length, 'unique county/state entries (hurricane/tornado).');
    saveJson('noaa_counties_raw', countyPairs);

    console.log('Fetching state FIPS map from Census...');
    const stateMap = await getStateFipsMap();

    const resolved = [];
    for (const cs of countyPairs) {
      const { countyName, stateName } = cs;
      const stateKey = stateName.trim().toLowerCase();
      const stateFips = stateMap[stateKey];
      if (!stateFips) {
        console.warn('State not found in Census list:', stateName, ' — skipping', countyName);
        continue;
      }
      const countyFips = await getCountyFips(stateFips, countyName);
      if (!countyFips) {
        console.warn('Could not resolve FIPS for', countyName, stateName);
        resolved.push({ countyName, stateName, stateFips, countyFips: null });
        continue;
      }
      console.log('Resolved', countyName, stateName, '-> FIPS', countyFips);
      resolved.push({ countyName, stateName, stateFips, countyFips });
    }
    saveJson('resolved_counties', resolved);

    for (const r of resolved) {
      if (!r.countyFips) continue;
      console.log('Fetching geometry for', r.countyName, r.stateName, 'FIPS', r.countyFips);
      try {
        const geometry = await fetchCountyGeojson(r.countyFips);
        if (!geometry) {
          console.warn('Geometry not found for', r.countyFips);
          continue;
        }
        saveJson(`geometry_${r.countyFips}`, geometry);
        console.log('Querying Regrid for parcels in', r.countyFips);
        const parcels = await fetchParcelsRegridByPolygon(geometry);
        console.log('Regrid returned', (parcels && parcels.items && parcels.items.length) || 0, 'parcels (may be paged).');
        saveJson(`parcels_${r.countyFips}`, parcels);
      } catch (err) {
        console.error('County processing error for', r.countyFips, err.message);
      }
    }

    console.log('Pipeline complete. Output JSON files located in', OUTPUT_DIR);
  } catch (err) {
    console.error('Pipeline failed', err);
  }
})();
