# Contractor Storm Pipeline (Regrid/ATTOM + NOAA)
This package includes:
- `noaa_extract_counties.py` — Python script to download NOAA StormEvents 'details' CSVs (1950–2025) and extract a deduplicated list of counties affected by tornadoes/hurricanes.
- `storm_to_parcels.js` — Node.js pipeline to convert county list -> FIPS -> TIGERweb geometry -> Regrid parcel pulls.
- `package.json` — Node dependencies for the pipeline.

Instructions:
1. For Python script:
   - `pip install requests tqdm`
   - `python noaa_extract_counties.py --outdir ./output`
   - Output: `output/counties_dedup.csv` and `output/counties_dedup.json`

2. For Node pipeline:
   - `npm install`
   - Set Replit Secrets or environment variables:
     - `REGRID_API_KEY` (recommended)
     - `ATTOM_API_KEY` (optional)
     - `NOAA_CSV_URL` (optional) or upload CSV to `/tmp/storm_events.csv`
   - `npm start` (runs `storm_to_parcels.js`)
   - Output JSONs saved under `./output`.

Notes:
- Regrid and ATTOM are paid APIs; request bulk export for county-scale runs to avoid per-parcel costs.
- County scraping is fragile; prefer Regrid/ATTOM for nationwide coverage.
