#!/usr/bin/env python3
"""
noaa_extract_counties.py
Downloads NOAA StormEvents yearly 'details' CSV.gz files (1950-2025),
streams them, extracts county/state pairs for tornadoes/hurricanes/tropical events,
and writes deduplicated list to CSV + JSON.

Usage:
  pip install requests tqdm python-dateutil
  python noaa_extract_counties.py --outdir ./output

Notes:
 - NOAA index used: https://www.ncei.noaa.gov/pub/data/swdi/stormevents/csvfiles/
 - The script streams .gz from NOAA; it DOES NOT store all raw CSVs uncompressed on disk.
 - For very large runs you may need more disk/timeout settings.
"""

import os
import sys
import gzip
import csv
import io
import argparse
import requests
from tqdm import tqdm
from urllib.parse import urljoin

# NOAA CSV index root (public)
BASE_INDEX = "https://www.ncei.noaa.gov/pub/data/swdi/stormevents/csvfiles/"

# The list of yearly detail filenames (NOAA naming pattern)
YEARS = list(range(1950, 2026))  # inclusive

# Keywords to match event types (case-insensitive)
KEYWORDS = [
    "tornado",
    "hurricane",
    "tropical",
    "tropical storm",
    "storm surge",
    "hurricane gust",
    "tropical cyclone",
    "tropical depression"
]

# Column name hints (NOAA changed formats over years).
POSSIBLE_EVENT_COLS = ["EVENT_TYPE", "event_type", "EVENTTYPE", "EVENTTYPE"]
POSSIBLE_STATE_COLS = ["STATE", "state", "STATE_NAME", "State"]
POSSIBLE_COUNTY_COLS = ["CZ_NAME", "cz_name", "COUNTY", "County", "COUNTYNAME", "CZ_FIPS"]

# Timeout for downloads
DOWNLOAD_TIMEOUT = 60  # seconds

def matches_keywords(event_type):
    if not event_type:
        return False
    s = event_type.lower()
    for k in KEYWORDS:
        if k in s:
            return True
    return False

def stream_parse_gz_csv(url):
    """
    Stream a remote .csv.gz and yield rows as dicts.
    """
    headers = {"User-Agent": "StrategicLandBot/1.0 (+https://yourdomain.example)"}
    with requests.get(url, stream=True, timeout=DOWNLOAD_TIMEOUT, headers=headers) as r:
        r.raise_for_status()
        gz = gzip.GzipFile(fileobj=r.raw)
        text_stream = io.TextIOWrapper(gz, encoding="utf-8", errors="replace", newline="")
        reader = csv.DictReader(text_stream)
        for row in reader:
            yield row

def find_column(row, possible_names):
    for k in possible_names:
        if k in row:
            return k
    keys = list(row.keys())
    k_lower_map = {key.lower(): key for key in keys}
    for name in possible_names:
        ln = name.lower()
        if ln in k_lower_map:
            return k_lower_map[ln]
    return None

def process_one_year(url, seen_pairs):
    try:
        for row in stream_parse_gz_csv(url):
            if not hasattr(process_one_year, "col_cache"):
                process_one_year.col_cache = {}
            cols = process_one_year.col_cache.get('cols')
            if not cols:
                cols = {
                    'event': find_column(row, POSSIBLE_EVENT_COLS),
                    'state': find_column(row, POSSIBLE_STATE_COLS),
                    'county': find_column(row, POSSIBLE_COUNTY_COLS)
                }
                process_one_year.col_cache['cols'] = cols
            event_col = cols['event']
            state_col = cols['state']
            county_col = cols['county']

            if not event_col or not state_col or not county_col:
                keys = list(row.keys())
                for k in keys:
                    kl = k.lower()
                    if 'event' in kl and not event_col:
                        event_col = k
                    if ('state' in kl or 'st' == kl) and not state_col:
                        state_col = k
                    if ('cz' in kl or 'county' in kl) and not county_col:
                        county_col = k

            event_type = row.get(event_col, "") if event_col else ""
            if not matches_keywords(event_type):
                continue

            state = row.get(state_col, "").strip() if state_col else ""
            county = row.get(county_col, "").strip() if county_col else ""

            if not county or not state:
                continue
            c = county.replace("County", "").replace("Parish", "").strip()
            s = state.strip()
            pair = (c.title(), s.upper())
            seen_pairs.add(pair)
    except Exception as e:
        print("WARN: failed processing URL:", url, "error:", e, file=sys.stderr)

def main(outdir):
    os.makedirs(outdir, exist_ok=True)
    seen_pairs = set()

    urls = []
    # exact filenames pattern (using common NOAA suffixes from index)
    suffixes = ["c20250520", "c20250702", "c20250721", "c20250731", "c20250818"]
    for y in YEARS:
        # try the most common suffix order
        for sfx in suffixes:
            fn = f"StormEvents_details-ftp_v1.0_d{y}_{sfx}.csv.gz"
            urls.append(urljoin(BASE_INDEX, fn))

    # Also include the single 1950 file with common suffix
    urls.insert(0, urljoin(BASE_INDEX, "StormEvents_details-ftp_v1.0_d1950_c20250520.csv.gz"))

    print("Attempting to fetch %d NOAA candidate files (best-effort). If a 404 occurs the script warns and continues." % len(urls))

    for url in urls:
        print("Processing:", url)
        try:
            r = requests.head(url, timeout=20)
            if r.status_code == 404:
                print(" -> Not found (404):", url)
                continue
            if r.status_code >= 400:
                print(" -> HTTP error", r.status_code, "for", url)
                continue
            process_one_year(url, seen_pairs)
        except Exception as e:
            print(" -> Error accessing:", url, ":", e)
            continue

    out_csv = os.path.join(outdir, "counties_dedup.csv")
    out_json = os.path.join(outdir, "counties_dedup.json")
    rows = [{"county": c, "state": s} for (c,s) in sorted(seen_pairs)]
    import json
    with open(out_csv, "w", newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=["county","state"])
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
    with open(out_json, "w", encoding='utf-8') as f:
        json.dump(rows, f, indent=2)
    print("Wrote:", out_csv, out_json)
    print("Total unique county/state pairs:", len(rows))

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", default="./output")
    args = parser.parse_args()
    main(args.outdir)
